#!/bin/bash

# Character Forge — D&D 5e Character Creator

NODE_REQUIRED_MAJOR=22
NODE_VERSION="22.23.1"

clear
echo ""
echo " ====================================================="
echo "   Character Forge — D&D 5e Character Creator"
echo " ====================================================="
echo ""

cd "$(dirname "$0")"

# ── Check Node.js ─────────────────────────────────────────
check_node() {
    if command -v node &>/dev/null; then
        local major
        major=$(node --version 2>/dev/null | cut -d. -f1 | tr -d 'v')
        if [ -n "$major" ] && [ "$major" -ge "$NODE_REQUIRED_MAJOR" ] 2>/dev/null; then
            return 0
        fi
    fi
    return 1
}

if ! check_node; then
    echo " [!] Node.js v22+ is required."
    echo " [..] Attempting to install via system package manager..."
    echo ""

    if command -v apt-get &>/dev/null; then
        # Debian/Ubuntu — use NodeSource repo for v22
        curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - 2>/dev/null \
            && sudo apt-get install -y nodejs
    elif command -v dnf &>/dev/null; then
        curl -fsSL https://rpm.nodesource.com/setup_22.x | sudo bash - 2>/dev/null \
            && sudo dnf install -y nodejs
    elif command -v pacman &>/dev/null; then
        sudo pacman -Sy --noconfirm nodejs npm
    elif command -v brew &>/dev/null; then
        brew install node@22
    else
        echo " [!] No supported package manager found."
        echo "     Install Node.js v22 from: https://nodejs.org"
        exit 1
    fi

    if ! check_node; then
        echo ""
        echo " [!] Node.js install did not complete successfully."
        echo "     Please install manually from https://nodejs.org"
        echo "     then run this script again."
        exit 1
    fi
fi

echo " [OK] Node.js $(node --version) found"

if [ ! -f "dnd-creator/package.json" ]; then
    echo " [!] Cannot find app files. Run from the correct folder."
    exit 1
fi

cd dnd-creator

if [ ! -d "node_modules" ]; then
    echo " [..] Setting up app (first run only)..."
    npm install --silent
fi

echo ""
echo " Starting at http://localhost:3000"
echo " Press Ctrl+C to stop."
echo ""

(sleep 2 && xdg-open "http://localhost:3000" 2>/dev/null || true) &
node server/server.js
