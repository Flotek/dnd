const path = require('path');
const Database = require('better-sqlite3');

const dbPath = path.join(__dirname, 'characters.db');
const db = new Database(dbPath);

db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS characters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    race_id TEXT,
    class_id TEXT,
    subclass_id TEXT,
    background_id TEXT,
    level INTEGER DEFAULT 1,
    data TEXT NOT NULL,           -- full character sheet JSON blob
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );
`);

module.exports = db;
