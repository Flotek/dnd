// Load .env file if present (must be first)
const dotenvPath = require('path').join(__dirname, '..', '.env');
try {
  require('fs').readFileSync(dotenvPath, 'utf-8').split('\n').forEach(line => {
    const [k, ...v] = line.trim().split('=');
    if (k && !k.startsWith('#') && v.length) process.env[k.trim()] = v.join('=').trim();
  });
} catch (e) { /* no .env file, that's fine */ }

const fs = require('fs');
const path = require('path');
const express = require('express');
const multer = require('multer');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const CUSTOM_DIR = path.join(DATA_DIR, 'custom');

// ensure custom dir exists
fs.mkdirSync(CUSTOM_DIR, { recursive: true });

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 }, // 50 MB
  fileFilter(req, file, cb) {
    if (file.mimetype === 'application/pdf') cb(null, true);
    else cb(new Error('Only PDF files are supported'));
  },
});

app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// ---------- Data loading (base SRD data + optional user-added custom data) ----------

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch (e) {
    return fallback;
  }
}

// For array-shaped files (races, classes, backgrounds, feats, spells):
// base file + custom/<name>.json (array) gets concatenated, with items
// sharing an `id`/`name` in custom overriding the base entry.
function loadArrayData(name, keyField) {
  const base = readJson(path.join(DATA_DIR, `${name}.json`), []);
  const custom = readJson(path.join(CUSTOM_DIR, `${name}.json`), []);
  const map = new Map();
  for (const item of base) map.set(item[keyField], item);
  for (const item of custom) map.set(item[keyField], item); // custom overrides/adds
  return Array.from(map.values());
}

// Equipment is a single object with sub-arrays (weapons, armor, packs, adventuringGear)
function loadEquipmentData() {
  const base = readJson(path.join(DATA_DIR, 'equipment.json'), {});
  const custom = readJson(path.join(CUSTOM_DIR, 'equipment.json'), {});
  const merged = { ...base };
  for (const section of Object.keys(custom)) {
    merged[section] = [...(base[section] || []), ...(custom[section] || [])];
  }
  return merged;
}

function getAllData() {
  return {
    races: loadArrayData('races', 'id'),
    classes: loadArrayData('classes', 'id'),
    backgrounds: loadArrayData('backgrounds', 'id'),
    feats: loadArrayData('feats', 'id'),
    spells: loadArrayData('spells', 'name'),
    equipment: loadEquipmentData(),
  };
}

// ---------- Status endpoint ----------
app.get('/api/status', (req, res) => {
  res.json({ pdfImportAvailable: !!process.env.ANTHROPIC_API_KEY });
});

// ---------- Data API (reloads from disk each call, so editing JSON files just works) ----------

app.get('/api/data', (req, res) => res.json(getAllData()));
app.get('/api/data/races', (req, res) => res.json(loadArrayData('races', 'id')));
app.get('/api/data/classes', (req, res) => res.json(loadArrayData('classes', 'id')));
app.get('/api/data/backgrounds', (req, res) => res.json(loadArrayData('backgrounds', 'id')));
app.get('/api/data/feats', (req, res) => res.json(loadArrayData('feats', 'id')));
app.get('/api/data/spells', (req, res) => res.json(loadArrayData('spells', 'name')));
app.get('/api/data/equipment', (req, res) => res.json(loadEquipmentData()));

// ---------- PDF Import API ----------

const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages';
const EXTRACT_PROMPT = `You are a D&D 5e rules data extractor. The attached PDF is a D&D sourcebook or homebrew document.

Extract ALL game content from it: races, classes, subclasses, backgrounds, feats, spells, and equipment.

Return ONLY a raw JSON object (no markdown, no backticks, no explanation) in this exact shape:
{
  "source": "<book/document name>",
  "races": [ /* array, same schema as example below */ ],
  "classes": [ /* array */ ],
  "backgrounds": [ /* array */ ],
  "feats": [ /* array */ ],
  "spells": [ /* array */ ],
  "equipment": { "weapons": [], "armor": [], "packs": [], "adventuringGear": [] }
}

SCHEMA for each type — include only fields present in the source:

races item: { "id": "kebab-case-unique", "name": "Full Name", "size": "Medium|Small|Large", "speed": 30, "abilityBonuses": { "str": 2 }, "traits": ["trait description"], "languages": ["Common"] }

classes item: { "id": "kebab-case", "name": "Name", "hitDie": 8, "primaryAbility": ["str"], "savingThrows": ["str","con"], "armorProficiencies": [], "weaponProficiencies": [], "toolProficiencies": [], "skillChoices": { "count": 2, "options": ["Skill1"] }, "spellcasting": null, "subclassLevel": 3, "subclasses": [{ "id": "id", "name": "Name" }], "startingEquipment": ["item"] }
  spellcasting (if applicable): { "ability": "int", "type": "prepared|known|known-pact|prepared-book", "cantripsAt1": 3, "spellsAt1": 6 }

backgrounds item: { "id": "kebab-case", "name": "Name", "skillProficiencies": ["Skill1","Skill2"], "languages": 0, "toolProficiencies": [], "equipment": ["item"], "feature": "Feature Name: description" }

feats item: { "id": "kebab-case", "name": "Name", "prerequisite": null, "summary": "One concise sentence of what the feat does mechanically." }

spells item: { "name": "Spell Name", "level": 0, "school": "Evocation", "classes": ["wizard"], "summary": "One sentence mechanical description." }

equipment.weapons item: { "name": "Name", "category": "Simple Melee|Simple Ranged|Martial Melee|Martial Ranged", "damage": "1d6 slashing", "properties": ["Light"], "cost": "10 gp", "weight": 3 }
equipment.armor item: { "name": "Name", "category": "Light|Medium|Heavy|Shield", "baseAC": 11, "addDex": true, "dexCap": null, "stealthDisadvantage": false, "cost": "10 gp", "weight": 10 }

If a category has no content in the document, return an empty array/object for it.
Focus on mechanical accuracy. Descriptions should be concise but functionally complete.`;

async function extractWithClaude(pdfBase64, apiKey) {
  const body = {
    model: 'claude-sonnet-4-6',
    max_tokens: 8000,
    messages: [{
      role: 'user',
      content: [
        { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: pdfBase64 } },
        { type: 'text', text: EXTRACT_PROMPT },
      ],
    }],
  };

  const res = await fetch(ANTHROPIC_API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Anthropic API error ${res.status}`);
  }

  const data = await res.json();
  const text = data.content.map(b => b.text || '').join('');
  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}

function mergeIntoCustom(extracted) {
  const results = { added: {}, updated: {} };

  const arrayFiles = [
    { key: 'races', file: 'races.json', id: 'id' },
    { key: 'classes', file: 'classes.json', id: 'id' },
    { key: 'backgrounds', file: 'backgrounds.json', id: 'id' },
    { key: 'feats', file: 'feats.json', id: 'id' },
    { key: 'spells', file: 'spells.json', id: 'name' },
  ];

  for (const { key, file, id } of arrayFiles) {
    const incoming = extracted[key] || [];
    if (!incoming.length) continue;

    const filePath = path.join(CUSTOM_DIR, file);
    const existing = readJson(filePath, []);
    const map = new Map(existing.map(x => [x[id], x]));

    let added = 0, updated = 0;
    for (const item of incoming) {
      if (map.has(item[id])) updated++;
      else added++;
      map.set(item[id], item);
    }

    fs.writeFileSync(filePath, JSON.stringify([...map.values()], null, 2));
    results.added[key] = added;
    results.updated[key] = updated;
  }

  // Equipment (object with sub-arrays)
  const eq = extracted.equipment || {};
  const hasEquipment = Object.values(eq).some(a => Array.isArray(a) && a.length > 0);
  if (hasEquipment) {
    const filePath = path.join(CUSTOM_DIR, 'equipment.json');
    const existing = readJson(filePath, {});
    const merged = { ...existing };
    for (const section of ['weapons', 'armor', 'packs', 'adventuringGear']) {
      if (!eq[section]?.length) continue;
      const existingNames = new Set((existing[section] || []).map(x => x.name));
      const newItems = eq[section].filter(x => !existingNames.has(x.name));
      merged[section] = [...(existing[section] || []), ...newItems];
      results.added.equipment = (results.added.equipment || 0) + newItems.length;
    }
    fs.writeFileSync(filePath, JSON.stringify(merged, null, 2));
  }

  return results;
}

// List custom content already imported
app.get('/api/import/library', (req, res) => {
  const summary = {};
  for (const [key, file, idField] of [
    ['races','races.json','id'], ['classes','classes.json','id'],
    ['backgrounds','backgrounds.json','id'], ['feats','feats.json','id'],
    ['spells','spells.json','name'],
  ]) {
    const items = readJson(path.join(CUSTOM_DIR, file), []);
    summary[key] = items.map(x => ({ id: x[idField] || x.name, name: x.name }));
  }
  const eq = readJson(path.join(CUSTOM_DIR, 'equipment.json'), {});
  summary.equipment = Object.values(eq).flat().map(x => ({ name: x.name }));
  res.json(summary);
});

// Delete a single custom item
app.delete('/api/import/library/:type/:id', (req, res) => {
  const { type, id } = req.params;
  const fileMap = { races: ['races.json','id'], classes: ['classes.json','id'],
    backgrounds: ['backgrounds.json','id'], feats: ['feats.json','id'], spells: ['spells.json','name'] };
  if (!fileMap[type]) return res.status(400).json({ error: 'Unknown type' });
  const [file, idField] = fileMap[type];
  const filePath = path.join(CUSTOM_DIR, file);
  const existing = readJson(filePath, []);
  const filtered = existing.filter(x => x[idField] !== id);
  fs.writeFileSync(filePath, JSON.stringify(filtered, null, 2));
  res.json({ ok: true, removed: existing.length - filtered.length });
});

// Main PDF import endpoint (API key / Claude extraction)
app.post('/api/import/pdf', upload.single('pdf'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No PDF uploaded' });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(503).json({ error: 'PDF import is not configured. Add ANTHROPIC_API_KEY to your .env file.' });

  try {
    const pdfBase64 = req.file.buffer.toString('base64');
    const extracted = await extractWithClaude(pdfBase64, apiKey);
    const mergeResult = mergeIntoCustom(extracted);
    res.json({ ok: true, source: extracted.source || req.file.originalname, counts: mergeResult });
  } catch (err) {
    console.error('PDF import error:', err);
    res.status(500).json({ error: err.message || 'Extraction failed' });
  }
});

// Client-side extraction result — browser parses PDF locally, sends structured JSON here to save
app.post('/api/import/save', (req, res) => {
  const extracted = req.body;
  if (!extracted) return res.status(400).json({ error: 'No data provided' });
  try {
    const mergeResult = mergeIntoCustom(extracted);
    res.json({ ok: true, source: extracted.source || 'Local PDF', counts: mergeResult });
  } catch (err) {
    console.error('Save extracted data error:', err);
    res.status(500).json({ error: err.message || 'Save failed' });
  }
});

// ---------- Character CRUD API ----------

app.get('/api/characters', (req, res) => {
  const rows = db.prepare(
    `SELECT id, name, race_id, class_id, subclass_id, background_id, level, created_at, updated_at
     FROM characters ORDER BY updated_at DESC`
  ).all();
  res.json(rows);
});

app.get('/api/characters/:id', (req, res) => {
  const row = db.prepare(`SELECT * FROM characters WHERE id = ?`).get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Character not found' });
  res.json({ ...row, data: JSON.parse(row.data) });
});

app.post('/api/characters', (req, res) => {
  const c = req.body;
  if (!c || !c.name) return res.status(400).json({ error: 'Character name is required' });

  const stmt = db.prepare(`
    INSERT INTO characters (name, race_id, class_id, subclass_id, background_id, level, data)
    VALUES (@name, @race_id, @class_id, @subclass_id, @background_id, @level, @data)
  `);
  const info = stmt.run({
    name: c.name,
    race_id: c.raceId || null,
    class_id: c.classId || null,
    subclass_id: c.subclassId || null,
    background_id: c.backgroundId || null,
    level: c.level || 1,
    data: JSON.stringify(c),
  });
  res.status(201).json({ id: info.lastInsertRowid });
});

app.put('/api/characters/:id', (req, res) => {
  const c = req.body;
  if (!c || !c.name) return res.status(400).json({ error: 'Character name is required' });

  const stmt = db.prepare(`
    UPDATE characters
    SET name=@name, race_id=@race_id, class_id=@class_id, subclass_id=@subclass_id,
        background_id=@background_id, level=@level, data=@data, updated_at=datetime('now')
    WHERE id=@id
  `);
  const info = stmt.run({
    id: req.params.id,
    name: c.name,
    race_id: c.raceId || null,
    class_id: c.classId || null,
    subclass_id: c.subclassId || null,
    background_id: c.backgroundId || null,
    level: c.level || 1,
    data: JSON.stringify(c),
  });
  if (info.changes === 0) return res.status(404).json({ error: 'Character not found' });
  res.json({ ok: true });
});

app.delete('/api/characters/:id', (req, res) => {
  const info = db.prepare(`DELETE FROM characters WHERE id = ?`).run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Character not found' });
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`\n⚔  Character Forge — D&D 5e Character Creator`);
  console.log(`   Running at http://localhost:${PORT}\n`);
});
