@echo off
title Character Forge — D&D 5e Character Creator
color 0A
cls

set NODE_VERSION=22.23.1
set NODE_REQUIRED_MAJOR=22
set NODE_MSI_URL=https://nodejs.org/dist/v22.23.1/node-v22.23.1-x64.msi
set NODE_MSI_FILE=%TEMP%\node-v22.23.1-x64.msi

echo.
echo  =====================================================
echo    Character Forge -- D^&D 5e Character Creator
echo  =====================================================
echo.

:: ── Check if Node.js v22+ is already installed ────────────
node --version >nul 2>&1
if %errorlevel% neq 0 goto :install_node

:: Node exists — check if it's v22+
for /f "tokens=1 delims=v." %%M in ('node --version 2^>nul') do set "DUMMY=%%M"
for /f "tokens=2 delims=v." %%M in ('node --version 2^>nul') do set "NODE_MAJOR=%%M"
if "%NODE_MAJOR%" == "" goto :install_node
if %NODE_MAJOR% LSS %NODE_REQUIRED_MAJOR% goto :install_node

for /f "tokens=*" %%v in ('node --version') do set NODE_VER=%%v
echo  [OK] Node.js %NODE_VER% found
goto :run_app

:: ── Install Node.js v22.23.1 ──────────────────────────────
:install_node
echo  [!] Node.js v22+ is required.
echo.
echo  Downloading Node.js v%NODE_VERSION% (about 30 MB)...
echo  This only happens once.
echo.

:: Use PowerShell to download the installer silently
powershell -NoProfile -Command ^
  "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; ^
   $wc = New-Object System.Net.WebClient; ^
   Write-Host '  Downloading...'; ^
   $wc.DownloadFile('%NODE_MSI_URL%', '%NODE_MSI_FILE%'); ^
   Write-Host '  Installing Node.js (takes about 1 minute)...'; ^
   Start-Process msiexec.exe -Wait -ArgumentList '/i \"%NODE_MSI_FILE%\" /quiet /norestart ADDLOCAL=ALL'; ^
   Write-Host '  Done.'"

if %errorlevel% neq 0 (
    echo.
    echo  [!] Automatic install failed.
    echo.
    echo  Please install manually:
    echo    1. Open your browser and go to:
    echo       https://nodejs.org/dist/v22.23.1/node-v22.23.1-x64.msi
    echo    2. Run the downloaded installer
    echo    3. Double-click "Start Windows.bat" again
    echo.
    pause
    exit /b 1
)

echo.
echo  [OK] Node.js installed. Please close this window and
echo       double-click "Start Windows.bat" again.
echo       (Windows needs to refresh its PATH first.)
echo.
pause
exit /b 0

:: ── Run the app ───────────────────────────────────────────
:run_app
echo.
cd /d "%~dp0dnd-creator"

if not exist package.json (
    echo  [!] Cannot find app files.
    echo      Make sure "Start Windows.bat" is next to the "dnd-creator" folder.
    pause
    exit /b 1
)

:: Install npm packages on first run only
if not exist node_modules (
    echo  [..] Setting up app (first run only, ~30 seconds)...
    call npm install --silent 2>nul
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo  [!] Setup failed. Please try running:
        echo      npm install
        echo      inside the dnd-creator folder.
        pause
        exit /b 1
    )
    echo  [OK] Setup complete
)

echo.
echo  =====================================================
echo   Starting Character Forge...
echo   Your browser will open automatically.
echo   KEEP THIS WINDOW OPEN while using the app.
echo   Close this window to shut the app down.
echo  =====================================================
echo.

:: Open browser after 2 second delay
start "" /b cmd /c "timeout /t 2 >nul && start http://localhost:3000"

:: Start the server
node server/server.js

echo.
echo  Server stopped. Press any key to close.
pause >nul
