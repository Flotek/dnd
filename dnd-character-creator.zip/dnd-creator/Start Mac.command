#!/bin/bash

# Character Forge — D&D 5e Character Creator
# Double-click this file in Finder to start the app.

NODE_VERSION="22.23.1"
NODE_REQUIRED_MAJOR=22

# Detect Apple Silicon vs Intel
ARCH=$(uname -m)
if [ "$ARCH" = "arm64" ]; then
    NODE_PKG_URL="https://nodejs.org/dist/v22.23.1/node-v22.23.1-darwin-arm64.tar.gz"
    NODE_DIR="node-v22.23.1-darwin-arm64"
else
    NODE_PKG_URL="https://nodejs.org/dist/v22.23.1/node-v22.23.1-darwin-x64.tar.gz"
    NODE_DIR="node-v22.23.1-darwin-x64"
fi

# Also check for the .pkg installer URL (simpler for non-devs)
NODE_PKG_INSTALLER="https://nodejs.org/dist/v22.23.1/node-v22.23.1.pkg"

clear
echo ""
echo " ====================================================="
echo "   Character Forge — D&D 5e Character Creator"
echo " ====================================================="
echo ""

# Move to the folder containing this script
cd "$(dirname "$0")"

# ── Check Node.js ──────────────────────────────────────────
check_node() {
    if command -v node &>/dev/null; then
        local major
        major=$(node --version 2>/dev/null | cut -d. -f1 | tr -d 'v')
        if [ -n "$major" ] && [ "$major" -ge "$NODE_REQUIRED_MAJOR" ] 2>/dev/null; then
            return 0
        fi
    fi
    return 1
}

if check_node; then
    echo " [OK] Node.js $(node --version) found"
else
    echo " [!] Node.js v22+ is required."
    echo ""
    echo " Choose how to install:"
    echo "   1) Download the installer automatically (recommended)"
    echo "   2) Open nodejs.org in your browser to download manually"
    echo ""
    read -rp " Enter 1 or 2: " choice

    if [ "$choice" = "1" ]; then
        echo ""
        echo " [..] Downloading Node.js v${NODE_VERSION} installer (~30 MB)..."
        TMPDIR_CUSTOM=$(mktemp -d)
        PKG_PATH="$TMPDIR_CUSTOM/node-installer.pkg"

        if command -v curl &>/dev/null; then
            curl -L --progress-bar "$NODE_PKG_INSTALLER" -o "$PKG_PATH"
        elif command -v wget &>/dev/null; then
            wget -q --show-progress "$NODE_PKG_INSTALLER" -O "$PKG_PATH"
        else
            echo " [!] Cannot download — curl and wget both missing."
            open "https://nodejs.org/dist/v22.23.1/node-v22.23.1.pkg"
            echo "     Opening download in browser instead."
            read -rp " Press Enter after installing, then run this launcher again." _
            exit 1
        fi

        echo ""
        echo " [..] Running installer (you may be asked for your Mac password)..."
        sudo installer -pkg "$PKG_PATH" -target /
        rm -rf "$TMPDIR_CUSTOM"

        if check_node; then
            echo " [OK] Node.js $(node --version) installed successfully"
        else
            echo ""
            echo " [!] Install finished but Node.js still not found."
            echo "     Close this window and open a new Terminal, then run:"
            echo "     node --version"
            echo "     If that works, double-click 'Start Mac.command' again."
            read -rp " Press Enter to close..." _
            exit 1
        fi
    else
        echo ""
        echo " Opening download page in your browser..."
        open "https://nodejs.org/dist/v22.23.1/node-v22.23.1.pkg"
        echo ""
        echo " After installing Node.js, double-click 'Start Mac.command' again."
        read -rp " Press Enter to close..." _
        exit 0
    fi
fi

# ── Move into app folder ──────────────────────────────────
if [ ! -f "dnd-creator/package.json" ]; then
    echo ""
    echo " [!] Cannot find the app files."
    echo "     Make sure 'Start Mac.command' is next to the 'dnd-creator' folder."
    read -rp " Press Enter to close..." _
    exit 1
fi

cd dnd-creator

# ── Install npm packages (first run only) ─────────────────
if [ ! -d "node_modules" ]; then
    echo ""
    echo " [..] Setting up app (first run only, ~30 seconds)..."
    npm install --silent
    if [ $? -ne 0 ]; then
        echo ""
        echo " [!] Setup failed. Please open Terminal and run:"
        echo "     cd \"$(pwd)\" && npm install"
        read -rp " Press Enter to close..." _
        exit 1
    fi
    echo " [OK] Setup complete"
fi

echo ""
echo " ====================================================="
echo "  Starting Character Forge..."
echo "  Your browser will open automatically."
echo "  KEEP THIS WINDOW OPEN while using the app."
echo "  Press Ctrl+C or close this window to stop."
echo " ====================================================="
echo ""

# Open browser after brief delay
(sleep 2 && open "http://localhost:3000") &

# Start the server
node server/server.js

echo ""
read -rp " Server stopped. Press Enter to close..." _
