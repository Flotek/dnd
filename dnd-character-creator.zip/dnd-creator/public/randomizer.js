// ============================================================
//  Randomizer — "Roll it for me"
//  Rolls race, class, subclass, background, ability scores and
//  skill proficiencies. Never touches level, feats or ASI slots.
//
//  Loaded AFTER app.js. It reads app.js's globals (state, DATA,
//  SKILLS, ABILITIES, RACE_CHOICES, ASI_LEVELS, api, render…)
//  and wraps the wizard's step renderers to inject its UI.
// ============================================================
(function () {
  "use strict";

  // ---------- dice & picking ----------
  const pick = arr => arr[Math.floor(Math.random() * arr.length)];
  const shuffle = arr => {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  };
  const d = n => 1 + Math.floor(Math.random() * n);
  const roll4d6DropLowest = () => {
    const r = [d(6), d(6), d(6), d(6)].sort((x, y) => y - x);
    return r[0] + r[1] + r[2];
  };

  // ---------- how to arrange rolled scores per class ----------
  const ABILITY_PREFERENCE = {
    barbarian: ["str", "con", "dex", "wis", "cha", "int"],
    bard:      ["cha", "dex", "con", "wis", "int", "str"],
    cleric:    ["wis", "con", "str", "cha", "dex", "int"],
    druid:     ["wis", "con", "dex", "int", "cha", "str"],
    fighter:   ["str", "con", "dex", "wis", "cha", "int"],
    monk:      ["dex", "wis", "con", "str", "cha", "int"],
    paladin:   ["str", "cha", "con", "wis", "dex", "int"],
    ranger:    ["dex", "wis", "con", "str", "int", "cha"],
    rogue:     ["dex", "con", "cha", "wis", "int", "str"],
    sorcerer:  ["cha", "con", "dex", "wis", "int", "str"],
    warlock:   ["cha", "con", "dex", "wis", "int", "str"],
    wizard:    ["int", "con", "dex", "wis", "cha", "str"],
    artificer: ["int", "con", "dex", "wis", "cha", "str"],
  };

  // Falls back to class data so imported/homebrew classes still arrange sensibly
  function abilityPriority(cls) {
    if (!cls) return ABILITIES.slice();
    if (ABILITY_PREFERENCE[cls.id]) return ABILITY_PREFERENCE[cls.id].slice();
    const order = [];
    (cls.primaryAbility || []).forEach(a => { if (ABILITIES.includes(a) && !order.includes(a)) order.push(a); });
    if (!order.includes("con")) order.push("con");
    (cls.savingThrows || []).forEach(a => { if (ABILITIES.includes(a) && !order.includes(a)) order.push(a); });
    ["dex", "wis", "str", "cha", "int"].forEach(a => { if (!order.includes(a)) order.push(a); });
    return order;
  }

  // ---------- ability score generation, per the method chosen in Basics ----------
  function rollScores(method, priority, arrange) {
    let values;
    if (method === "pointbuy") return randomPointBuy(priority, arrange);
    if (method === "standard") values = STANDARD_ARRAY.slice();
    else values = [0, 0, 0, 0, 0, 0].map(roll4d6DropLowest); // "manual" = rolled

    const order = arrange === "chaotic" ? shuffle(priority) : priority;
    values.sort((a, b) => b - a);
    const out = {};
    order.forEach((ab, i) => { out[ab] = values[i]; });
    return out;
  }

  function randomPointBuy(priority, arrange) {
    const s = { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 };
    const order = arrange === "chaotic" ? shuffle(priority) : priority;
    // weight the spend toward the class's key abilities
    const weighted = [];
    order.forEach((ab, i) => { for (let n = 6 - i; n > 0; n--) weighted.push(ab); });

    let budget = 27, guard = 0;
    const affordable = () => ABILITIES.some(a => s[a] < 15 && POINT_BUY_COST[s[a] + 1] - POINT_BUY_COST[s[a]] <= budget);
    while (affordable() && guard++ < 600) {
      const ab = pick(weighted);
      if (s[ab] >= 15) continue;
      const cost = POINT_BUY_COST[s[ab] + 1] - POINT_BUY_COST[s[ab]];
      if (cost > budget) continue;
      s[ab]++; budget -= cost;
    }
    return s;
  }

  // ---------- names ----------
  const NAME_START = ["Ael", "Bran", "Cor", "Dris", "Eld", "Fen", "Gorm", "Hal", "Ily", "Jor", "Kae", "Lir", "Mor", "Nyx", "Orin", "Pyr", "Quen", "Rho", "Sel", "Thal", "Ur", "Vex", "Wyn", "Yar", "Zeph"];
  const NAME_MID = ["", "", "a", "e", "i", "o", "an", "en", "ir", "ol", "ua", "yr", "ath", "ess"];
  const NAME_END = ["ric", "dor", "wyn", "th", "ra", "las", "mir", "gar", "va", "shan", "dric", "ka", "orn", "iel", "us"];
  const SURNAME_A = ["Ash", "Black", "Bright", "Cinder", "Dawn", "Ember", "Frost", "Grey", "Iron", "Mist", "Oak", "Quick", "Storm", "Thorn", "Wild"];
  const SURNAME_B = ["barrow", "bloom", "brand", "fall", "hollow", "mane", "march", "reach", "shade", "song", "step", "vale", "ward", "weaver", "wind"];
  const randomName = () => `${pick(NAME_START)}${pick(NAME_MID)}${pick(NAME_END)} ${pick(SURNAME_A)}${pick(SURNAME_B)}`;

  // ---------- keep stat math honest when the class changes ----------
  // ASI slots are keyed by level ('4', '8', 'vh_1'…). Switching class or race
  // can strand a slot that no longer exists, which would silently keep granting
  // its bonus. Drop only the impossible ones; every valid feat choice survives.
  function pruneStrandedAsiSlots(c) {
    if (!c.asiChoices) return [];
    const legal = new Set((ASI_LEVELS[c.classId] || [4, 8, 12, 16, 19]).filter(l => l <= c.level).map(String));
    if (c.raceId === "variant-human") legal.add("vh_1");
    const dropped = [];
    for (const key of Object.keys(c.asiChoices)) {
      if (!legal.has(key)) { dropped.push(key); delete c.asiChoices[key]; }
    }
    return dropped;
  }

  // ---------- the roll ----------
  function skillsAlreadyGranted(c) {
    const race = getRace(c.raceId);
    return new Set([...(backgroundSkills(c) || []), ...((race && race.skillProficiencies) || [])]);
  }

  function rollRaceChoices(c, taken) {
    // Fill draconic ancestry, lineages, tools, languages and bonus skill picks
    const list = (typeof RACE_CHOICES !== "undefined" && RACE_CHOICES[c.raceId]) || [];
    c.subclassChoices = c.subclassChoices || {};
    for (const ch of list) {
      if (ch.type === "skills") {
        const pool = SKILLS.map(([n]) => n).filter(n => !taken.has(n));
        const chosen = shuffle(pool).slice(0, ch.count);
        chosen.forEach(n => taken.add(n));
        c.subclassChoices[ch.key] = chosen;
      } else if (ch.type === "select" && ch.options && ch.options.length) {
        const isSkillPick = ch.options.every(([v]) => SKILLS.some(([n]) => n === v));
        const opts = isSkillPick ? ch.options.filter(([v]) => !taken.has(v)) : ch.options;
        const chosen = pick(opts.length ? opts : ch.options)[0];
        if (isSkillPick) taken.add(chosen);
        c.subclassChoices[ch.key] = chosen;
      }
    }
  }

  const Randomizer = {
    opts: { name: true, race: true, cls: true, subclass: true, background: true, scores: true, skills: true },
    arrange: "optimized",   // or "chaotic"
    summary: null,

    toggle(key) { this.opts[key] = !this.opts[key]; render(); },
    setArrange(v) { this.arrange = v; render(); },

    // Called by the big die button — animates, then rolls.
    roll(only) {
      const die = document.querySelector(".rnd-die");
      const reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (die && !reduced && !only) {
        die.classList.add("is-rolling");
        setTimeout(() => this.apply(only), 420);
      } else {
        this.apply(only);
      }
    },

    // Re-roll a single field from the Race / Class / Background steps
    rollOne(field) { this.apply(field); },

    apply(only) {
      const c = state.character;
      if (!c || !DATA) return;
      const want = k => (only ? only === k : this.opts[k]);
      const notes = [];

      if (want("race")) {
        const race = pick(DATA.races);
        c.raceId = race.id;
        c.halfElfChoices = [];
        notes.push(race.name);
      }
      if (want("cls")) {
        const cls = pick(DATA.classes);
        c.classId = cls.id;
        c.subclassId = null;
        c.classSkillChoices = [];
        notes.push(cls.name);
      }
      if (want("background")) {
        const bg = pick(DATA.backgrounds);
        c.backgroundId = bg.id;
        notes.push(bg.name);
      }
      if (want("name") && (only === "name" || !c.name.trim())) {
        c.name = randomName();
        notes.push(`“${c.name}”`);
      }

      const cls = getClass(c.classId);
      const race = getRace(c.raceId);
      const priority = abilityPriority(cls);

      // Subclass — only if the character is high enough level to have one
      if ((want("subclass") || want("cls")) && cls && cls.subclasses && cls.subclasses.length) {
        if (c.level >= (cls.subclassLevel || 3)) {
          if (!c.subclassId || want("cls") || only === "subclass") {
            c.subclassId = pick(cls.subclasses).id;
            notes.push(getClass(c.classId).subclasses.find(s => s.id === c.subclassId).name);
          }
        } else {
          c.subclassId = null;
        }
      }

      // Flexible racial bonuses (Half-Elf, Variant Human)
      if ((want("race") || want("scores")) && race && race.abilityBonuses && race.abilityBonuses.choose_two) {
        const fixedCha = race.abilityBonuses.cha === 2;
        c.halfElfChoices = priority.filter(a => !(fixedCha && a === "cha")).slice(0, 2);
      }

      // Racial picks: ancestry, lineage, tools, languages, bonus skills
      if (want("race")) rollRaceChoices(c, skillsAlreadyGranted(c));

      if (want("scores")) {
        c.baseScores = rollScores(c.abilityMethod, priority, this.arrange);
      }

      if (want("skills") || want("cls") || want("background")) {
        const taken = skillsAlreadyGranted(c);
        const options = (cls && cls.skillChoices && cls.skillChoices.options) || [];
        const openSelection = !options.length || options.some(o => /any/i.test(o));
        const pool = (openSelection ? SKILLS.map(([n]) => n) : options).filter(n => !taken.has(n));
        const count = cls ? (cls.skillChoices.count || 2) : 0;
        c.classSkillChoices = shuffle(pool).slice(0, count);
      }

      const dropped = pruneStrandedAsiSlots(c);
      if (dropped.length) notes.push(`cleared ${dropped.length} ASI slot${dropped.length > 1 ? "s" : ""} that no longer exist`);

      this.summary = notes.join(" · ");
      if (state.editingId) api.saveCharacter(c, state.editingId);
      render();
    },

    // Topbar entry point: brand new character, fully rolled
    async newRandom() {
      await Router.go("create");
      this.opts.name = true;
      this.apply();
    },
  };

  window.Randomizer = Randomizer;

  // ============================================================
  //  UI injection — wrap the existing step renderers
  // ============================================================
  const CHECKS = [
    ["name", "Name"], ["race", "Race"], ["cls", "Class"], ["subclass", "Subclass"],
    ["background", "Background"], ["scores", "Ability scores"], ["skills", "Skills"],
  ];

  function methodLabel(c) {
    if (c.abilityMethod === "standard") return "standard array, arranged for the class";
    if (c.abilityMethod === "pointbuy") return "a legal 27-point buy";
    return "4d6 drop lowest";
  }

  function panel() {
    const c = state.character;
    return `
      <div class="rnd-card">
        <div class="rnd-head">
          <div>
            <h3>Roll it for me</h3>
            <p class="rnd-note">
              The dice pick race, class, background, skills and ability scores (${methodLabel(c)}).
              Your <strong>level</strong> and your <strong>feat and ASI choices</strong> are never touched.
            </p>
          </div>
          <button class="rnd-die" onclick="Randomizer.roll()" aria-label="Roll a random character">
            <span class="rnd-die-face">20</span>
            <span class="rnd-die-label">Roll</span>
          </button>
        </div>

        <div class="rnd-opts">
          ${CHECKS.map(([k, label]) => `
            <label class="rnd-chk ${Randomizer.opts[k] ? "on" : ""}">
              <input type="checkbox" ${Randomizer.opts[k] ? "checked" : ""} onchange="Randomizer.toggle('${k}')" />
              ${label}
            </label>`).join("")}
        </div>

        <div class="rnd-arrange">
          <span>Arrange scores</span>
          <button class="rnd-seg ${Randomizer.arrange === "optimized" ? "on" : ""}" onclick="Randomizer.setArrange('optimized')">Best for the class</button>
          <button class="rnd-seg ${Randomizer.arrange === "chaotic" ? "on" : ""}" onclick="Randomizer.setArrange('chaotic')">However they land</button>
        </div>

        ${Randomizer.summary ? `<div class="rnd-result"><strong>Rolled:</strong> ${escapeHtml(Randomizer.summary)}</div>` : ""}
      </div>`;
  }

  function reroll(field, label) {
    return `<button class="rnd-inline" onclick="Randomizer.rollOne('${field}')">🎲 Random ${label}</button>`;
  }

  function wrap(name, extra) {
    const original = window[name];
    if (typeof original !== "function") return;
    window[name] = function () { return extra() + original.apply(this, arguments); };
  }

  wrap("renderBasics", panel);
  wrap("renderRace", () => reroll("race", "race"));
  wrap("renderClass", () => reroll("cls", "class"));
  wrap("renderBackground", () => reroll("background", "background"));
  wrap("renderAbilityScores", () => reroll("scores", "scores"));

  // Topbar button
  document.addEventListener("DOMContentLoaded", () => {
    const nav = document.querySelector(".topnav");
    if (!nav) return;
    const btn = document.createElement("button");
    btn.className = "nav-btn";
    btn.textContent = "🎲 Random Character";
    btn.onclick = () => Randomizer.newRandom();
    nav.insertBefore(btn, nav.lastElementChild);
  });
})();
