// ============ Constants ============
const SKILLS = [
  ["Acrobatics", "dex"], ["Animal Handling", "wis"], ["Arcana", "int"], ["Athletics", "str"],
  ["Deception", "cha"], ["History", "int"], ["Insight", "wis"], ["Intimidation", "cha"],
  ["Investigation", "int"], ["Medicine", "wis"], ["Nature", "int"], ["Perception", "wis"],
  ["Performance", "cha"], ["Persuasion", "cha"], ["Religion", "int"], ["Sleight of Hand", "dex"],
  ["Stealth", "dex"], ["Survival", "wis"],
];
const ABILITIES = ["str", "dex", "con", "int", "wis", "cha"];
const ABILITY_NAMES = { str: "Strength", dex: "Dexterity", con: "Constitution", int: "Intelligence", wis: "Wisdom", cha: "Charisma" };
const STANDARD_ARRAY = [15, 14, 13, 12, 10, 8];
const POINT_BUY_COST = { 8: 0, 9: 1, 10: 2, 11: 3, 12: 4, 13: 5, 14: 7, 15: 9 };
const STEP_NAMES = ["Basics", "Race", "Class", "Background", "Ability Scores", "Skills & Feat", "Equipment", "Spells", "Review"];

// Official 5e spell slots by class type and level
// Full casters: Wizard, Sorcerer, Bard, Cleric, Druid
// Half casters: Paladin, Ranger (slots start at level 2, halved)
// Warlock: pact magic (separate — all slots same level, few in number)
const FULL_CASTER_SLOTS = {
  1:  [2,0,0,0,0,0,0,0,0],
  2:  [3,0,0,0,0,0,0,0,0],
  3:  [4,2,0,0,0,0,0,0,0],
  4:  [4,3,0,0,0,0,0,0,0],
  5:  [4,3,2,0,0,0,0,0,0],
  6:  [4,3,3,0,0,0,0,0,0],
  7:  [4,3,3,1,0,0,0,0,0],
  8:  [4,3,3,2,0,0,0,0,0],
  9:  [4,3,3,3,1,0,0,0,0],
  10: [4,3,3,3,2,0,0,0,0],
  11: [4,3,3,3,2,1,0,0,0],
  12: [4,3,3,3,2,1,0,0,0],
  13: [4,3,3,3,2,1,1,0,0],
  14: [4,3,3,3,2,1,1,0,0],
  15: [4,3,3,3,2,1,1,1,0],
  16: [4,3,3,3,2,1,1,1,0],
  17: [4,3,3,3,2,1,1,1,1],
  18: [4,3,3,3,3,1,1,1,1],
  19: [4,3,3,3,3,2,1,1,1],
  20: [4,3,3,3,3,2,2,1,1],
};
const HALF_CASTER_SLOTS = {
  1:  [0,0,0,0,0,0,0,0,0],
  2:  [2,0,0,0,0,0,0,0,0],
  3:  [3,0,0,0,0,0,0,0,0],
  4:  [3,0,0,0,0,0,0,0,0],
  5:  [4,2,0,0,0,0,0,0,0],
  6:  [4,2,0,0,0,0,0,0,0],
  7:  [4,3,0,0,0,0,0,0,0],
  8:  [4,3,0,0,0,0,0,0,0],
  9:  [4,3,2,0,0,0,0,0,0],
  10: [4,3,2,0,0,0,0,0,0],
  11: [4,3,3,0,0,0,0,0,0],
  12: [4,3,3,0,0,0,0,0,0],
  13: [4,3,3,1,0,0,0,0,0],
  14: [4,3,3,1,0,0,0,0,0],
  15: [4,3,3,2,0,0,0,0,0],
  16: [4,3,3,2,0,0,0,0,0],
  17: [4,3,3,3,1,0,0,0,0],
  18: [4,3,3,3,1,0,0,0,0],
  19: [4,3,3,3,2,0,0,0,0],
  20: [4,3,3,3,2,0,0,0,0],
};
const WARLOCK_SLOTS = {
  // [slotsPerRest, slotLevel]
  1:  [1,1], 2: [2,1], 3: [2,2], 4: [2,2], 5: [3,3],
  6:  [3,3], 7: [4,4], 8: [4,4], 9: [5,5], 10: [5,5],
  11: [5,5], 12: [5,5], 13: [5,5], 14: [5,5], 15: [5,5],
  16: [5,5], 17: [5,5], 18: [5,5], 19: [5,5], 20: [5,5],
};
const FULL_CASTERS  = new Set(["bard","cleric","druid","sorcerer","wizard"]);
const HALF_CASTERS  = new Set(["paladin","ranger"]);

function getSpellSlots(classId, level) {
  if (!classId) return null;
  if (classId === "warlock") {
    const [count, slotLevel] = WARLOCK_SLOTS[level] || [0,0];
    return { type: "pact", slots: [{ level: slotLevel, max: count }] };
  }
  let table = null;
  if (FULL_CASTERS.has(classId))  table = FULL_CASTER_SLOTS;
  if (HALF_CASTERS.has(classId))  table = HALF_CASTER_SLOTS;
  if (!table) return null;
  const row = table[level] || table[20];
  const slots = row.map((max, i) => ({ level: i + 1, max })).filter(s => s.max > 0);
  return slots.length ? { type: "full", slots } : null;
}

// ============ Global state ============
let DATA = null; // { races, classes, backgrounds, feats, spells, equipment }
let state = { view: "list", step: 0, editingId: null, character: null, charList: [] };

function blankCharacter() {
  return {
    name: "", level: 1,
    raceId: null, classId: null, subclassId: null, backgroundId: null,
    abilityMethod: "standard", baseScores: { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 },
    halfElfChoices: [],
    classSkillChoices: [], feat: null,
    equipmentChoice: null, armorId: null, shield: false, extraGear: "",
    cantrips: [], spellsKnown: [],
    spellSlots: {},        // { "1": usedCount, … }
    currentHp: null,       // null = at max; set to a number when damaged
    hitDiceUsed: 0,        // how many hit dice spent this rest cycle
    notes: "",
  };
}

// ============ API ============
const api = {
  async getData() { return (await fetch("/api/data")).json(); },
  async listCharacters() { return (await fetch("/api/characters")).json(); },
  async getCharacter(id) { return (await fetch(`/api/characters/${id}`)).json(); },
  async saveCharacter(char, id) {
    const body = JSON.stringify({ ...char, raceId: char.raceId, classId: char.classId, subclassId: char.subclassId, backgroundId: char.backgroundId });
    const res = await fetch(id ? `/api/characters/${id}` : "/api/characters", {
      method: id ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body,
    });
    return res.json();
  },
  async deleteCharacter(id) { return (await fetch(`/api/characters/${id}`, { method: "DELETE" })).json(); },
};

// ============ Helpers ============
function abilityMod(score) { return Math.floor((score - 10) / 2); }
function fmtMod(n) { return n >= 0 ? `+${n}` : `${n}`; }
function proficiencyBonus(level) { return 2 + Math.floor((level - 1) / 4); }

function getRace(id) { return DATA.races.find(r => r.id === id); }
function getClass(id) { return DATA.classes.find(c => c.id === id); }
function getBackground(id) { return DATA.backgrounds.find(b => b.id === id); }

function finalAbilityScores(c) {
  const race = getRace(c.raceId);
  const scores = { ...c.baseScores };
  if (race) {
    for (const [k, v] of Object.entries(race.abilityBonuses || {})) {
      if (k === "choose_two") continue;
      if (ABILITIES.includes(k)) scores[k] += v;
    }
    if (race.abilityBonuses && race.abilityBonuses.choose_two) {
      for (const ab of c.halfElfChoices) scores[ab] = (scores[ab] || 0) + 1;
    }
  }
  return scores;
}

function computeHP(c) {
  const cls = getClass(c.classId);
  if (!cls) return null;
  const scores = finalAbilityScores(c);
  const conMod = abilityMod(scores.con);
  const level = c.level;
  const hillDwarfBonus = (getRace(c.raceId)?.traits || []).some(t => t.includes("Dwarven Toughness")) ? level : 0;
  let hp = cls.hitDie + conMod; // level 1 max
  for (let lvl = 2; lvl <= level; lvl++) {
    hp += Math.floor(cls.hitDie / 2) + 1 + conMod; // average roll
  }
  return hp + hillDwarfBonus;
}

function computeAC(c) {
  const scores = finalAbilityScores(c);
  const dexMod = abilityMod(scores.dex);
  const armor = DATA.equipment.armor.find(a => a.name === c.armorId);
  let ac;
  if (!armor) ac = 10 + dexMod;
  else {
    let dexBonus = 0;
    if (armor.addDex) dexBonus = armor.dexCap != null ? Math.min(dexMod, armor.dexCap) : dexMod;
    ac = armor.baseAC + dexBonus;
  }
  if (c.shield) ac += 2;
  return ac;
}

function classSkillCount(c) {
  const cls = getClass(c.classId);
  return cls ? cls.skillChoices.count : 0;
}

function backgroundSkills(c) {
  const bg = getBackground(c.backgroundId);
  return bg ? bg.skillProficiencies : [];
}

function allProficientSkills(c) {
  return new Set([...(c.classSkillChoices || []), ...backgroundSkills(c)]);
}

function getSkillRows(c) {
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const proficient = allProficientSkills(c);
  return SKILLS.map(([name, ab]) => {
    const isProf = proficient.has(name);
    return { name, ability: ab, proficient: isProf, mod: abilityMod(scores[ab]) + (isProf ? pb : 0) };
  });
}

function getSavingThrows(c) {
  const cls = getClass(c.classId);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const profs = cls ? cls.savingThrows : [];
  return ABILITIES.map(a => {
    const isProf = profs.includes(a);
    return { ability: a, proficient: isProf, mod: abilityMod(scores[a]) + (isProf ? pb : 0) };
  });
}

// ============ Router ============
const Router = {
  async go(view, id = null) {
    if (view === "list") {
      state.view = "list";
      state.charList = await api.listCharacters();
      render();
    } else if (view === "create") {
      state.view = "wizard"; state.step = 0; state.editingId = null; state.character = blankCharacter();
      render();
    } else if (view === "edit") {
      const row = await api.getCharacter(id);
      state.view = "wizard"; state.step = 0; state.editingId = id; state.character = row.data;
      render();
    } else if (view === "sheet") {
      const row = await api.getCharacter(id);
      state.view = "sheet"; state.editingId = id; state.character = row.data;
      render();
    } else if (view === "import") {
      state.view = "import";
      render();
      ImportPage.loadLibrary();
    }
  },
};

// ============ App actions (exposed on window for inline handlers) ============
const App = {
  goStep(n) { state.step = n; render(); },
  nextStep() { state.step = Math.min(STEP_NAMES.length - 1, state.step + 1); render(); },
  prevStep() { state.step = Math.max(0, state.step - 1); render(); },

  setName(v) { state.character.name = v; },
  setLevel(v) { state.character.level = Math.max(1, Math.min(20, parseInt(v) || 1)); render(); },

  selectRace(id) { state.character.raceId = id; state.character.halfElfChoices = []; render(); },
  toggleHalfElfChoice(ab) {
    const arr = state.character.halfElfChoices;
    const i = arr.indexOf(ab);
    if (i >= 0) arr.splice(i, 1);
    else if (arr.length < 2) arr.push(ab);
    render();
  },

  selectClass(id) { state.character.classId = id; state.character.subclassId = null; state.character.classSkillChoices = []; render(); },
  selectSubclass(id) { state.character.subclassId = id; render(); },

  selectBackground(id) { state.character.backgroundId = id; render(); },

  setAbilityMethod(m) { state.character.abilityMethod = m; state.character.baseScores = { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 }; render(); },
  setStandardArraySlot(ability, value) {
    state.character.baseScores[ability] = parseInt(value) || 8; render();
  },
  setPointBuy(ability, delta) {
    const cur = state.character.baseScores[ability];
    const next = cur + delta;
    if (next < 8 || next > 15) return;
    const spent = ABILITIES.reduce((s, a) => s + POINT_BUY_COST[a === ability ? next : state.character.baseScores[a]], 0);
    if (spent > 27) return;
    state.character.baseScores[ability] = next; render();
  },
  setManualScore(ability, value) {
    state.character.baseScores[ability] = Math.max(1, Math.min(30, parseInt(value) || 10)); render();
  },

  toggleClassSkill(skill) {
    const arr = state.character.classSkillChoices;
    const i = arr.indexOf(skill);
    const max = classSkillCount(state.character);
    if (i >= 0) arr.splice(i, 1);
    else if (arr.length < max && !backgroundSkills(state.character).includes(skill)) arr.push(skill);
    render();
  },
  setFeat(id) { state.character.feat = id || null; render(); },

  setEquipmentChoice(v) { state.character.equipmentChoice = v; render(); },
  setArmor(v) { state.character.armorId = v || null; render(); },
  toggleShield() { state.character.shield = !state.character.shield; render(); },
  setExtraGear(v) { state.character.extraGear = v; },

  toggleCantrip(name) {
    const cls = getClass(state.character.classId);
    const max = cls?.spellcasting?.cantripsAt1 ?? (FULL_CASTERS.has(state.character.classId) ? 5 : 2);
    const arr = state.character.cantrips;
    const i = arr.indexOf(name);
    if (i >= 0) arr.splice(i, 1); else if (arr.length < max) arr.push(name);
    render();
  },
  toggleSpell(name) {
    const cls = getClass(state.character.classId);
    const max = cls?.spellcasting?.spellsAt1 ?? 999;
    const arr = state.character.spellsKnown;
    const i = arr.indexOf(name);
    if (i >= 0) arr.splice(i, 1); else if (arr.length < max) arr.push(name);
    render();
  },
  setNotes(v) { state.character.notes = v; },

  // Spell slot tracking (used on the character sheet view)
  toggleSlot(levelKey, slotIndex) {
    const c = state.character;
    if (!c.spellSlots) c.spellSlots = {};
    const used = c.spellSlots[levelKey] || 0;
    const slotInfo = getSpellSlots(c.classId, c.level);
    if (!slotInfo) return;
    const slotDef = slotInfo.type === "pact"
      ? slotInfo.slots[0]
      : slotInfo.slots.find(s => s.level === parseInt(levelKey));
    if (!slotDef) return;
    const max = slotDef.max;
    // Clicking used slot restores it; clicking empty slot uses it
    if (slotIndex < used) {
      c.spellSlots[levelKey] = slotIndex; // restore down to clicked
    } else {
      c.spellSlots[levelKey] = Math.min(slotIndex + 1, max);
    }
    // Auto-save slot state without full re-render
    api.saveCharacter(c, state.editingId);
    // Re-render just the slot section
    const slotInfo2 = getSpellSlots(c.classId, c.level);
    if (slotInfo2) {
      const el = document.getElementById('spell-slot-tracker');
      if (el) el.outerHTML = renderSpellSlotTracker(c, slotInfo2);
    }
  },

  resetSlots() {
    const c = state.character;
    c.spellSlots = {};
    api.saveCharacter(c, state.editingId);
    const slotInfo = getSpellSlots(c.classId, c.level);
    const el = document.getElementById('spell-slot-tracker');
    if (slotInfo && el) el.outerHTML = renderSpellSlotTracker(c, slotInfo);
  },

  // ── HP tracking ──────────────────────────────────────────
  setCurrentHp(val) {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const v = Math.max(0, Math.min(max, parseInt(val) || 0));
    c.currentHp = v;
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
  },

  adjustHp(delta) {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const cur = c.currentHp ?? max;
    App.setCurrentHp(cur + delta);
  },

  // ── Hit Dice ─────────────────────────────────────────────
  spendHitDie() {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const cur = c.currentHp ?? max;
    if (cur >= max) return;                     // already at full
    const availHD = c.level - (c.hitDiceUsed || 0);
    if (availHD <= 0) { alert("No hit dice remaining."); return; }
    const cls = getClass(c.classId);
    const die = cls ? cls.hitDie : 8;
    const scores = finalAbilityScores(c);
    const conMod = abilityMod(scores.con);
    const roll = Math.floor(Math.random() * die) + 1;
    const heal = Math.max(1, roll + conMod);
    c.currentHp = Math.min(max, cur + heal);
    c.hitDiceUsed = (c.hitDiceUsed || 0) + 1;
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    // Show the roll result briefly
    const msg = document.getElementById('hd-msg');
    if (msg) {
      msg.textContent = `Rolled ${roll} + ${conMod} CON = +${heal} HP`;
      msg.style.opacity = '1';
      setTimeout(() => { msg.style.opacity = '0'; }, 3000);
    }
  },

  // ── Rests ─────────────────────────────────────────────────
  shortRest() {
    // Short rest: player spends hit dice (done via spendHitDie).
    // Warlocks recover pact slots; some class features also recover.
    const c = state.character;
    if (c.classId === "warlock") {
      c.spellSlots = {};
      const slotEl = document.getElementById('spell-slot-tracker');
      const slotInfo = getSpellSlots(c.classId, c.level);
      if (slotInfo && slotEl) slotEl.outerHTML = renderSpellSlotTracker(c, slotInfo);
    }
    api.saveCharacter(c, state.editingId);
    alert("Short rest taken. Spend hit dice to recover HP using the Roll Hit Die button. Warlock pact slots (if any) have been restored.");
  },

  longRest() {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    // Recover half level (min 1) hit dice on long rest
    const hdRecovered = Math.max(1, Math.floor(c.level / 2));
    c.currentHp = max;
    c.hitDiceUsed = Math.max(0, (c.hitDiceUsed || 0) - hdRecovered);
    c.spellSlots = {};
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    const slotEl = document.getElementById('spell-slot-tracker');
    const slotInfo = getSpellSlots(c.classId, c.level);
    if (slotInfo && slotEl) slotEl.outerHTML = renderSpellSlotTracker(c, slotInfo);
  },

  async save() {
    const c = state.character;
    if (!c.name.trim()) { alert("Give your character a name first."); return; }
    await api.saveCharacter(c, state.editingId);
    Router.go("list");
  },
  async deleteChar(id, ev) {
    ev.stopPropagation();
    if (!confirm("Delete this character permanently?")) return;
    await api.deleteCharacter(id);
    Router.go("list");
  },
};
window.App = App; window.Router = Router;

// ============ Rendering ============
function render() {
  const app = document.getElementById("app");
  if (state.view === "list") app.innerHTML = renderList();
  else if (state.view === "sheet") app.innerHTML = renderSheet();
  else if (state.view === "import") app.innerHTML = renderImportPage();
  else app.innerHTML = renderWizard();
}

function renderList() {
  if (!state.charList.length) {
    return `
      <h1>Your Characters</h1>
      <p class="subtitle">Nothing saved yet.</p>
      <div class="empty-state">
        <p>No characters yet. Start your legend.</p>
        <button class="btn btn--primary" onclick="Router.go('create')">+ New Character</button>
      </div>`;
  }
  return `
    <h1>Your Characters</h1>
    <p class="subtitle">${state.charList.length} saved</p>
    <div class="char-grid">
      ${state.charList.map(c => `
        <div class="char-card" onclick="Router.go('sheet', ${c.id})">
          <span class="level-badge">${c.level}</span>
          <h3>${escapeHtml(c.name)}</h3>
          <div class="meta">${labelOr(c.race_id, "races")} ${labelOr(c.class_id, "classes")}</div>
          <div class="meta">${labelOr(c.background_id, "backgrounds")}</div>
          <div class="card-actions">
            <button class="del-btn" onclick="event.stopPropagation(); Router.go('edit', ${c.id})" style="color:var(--gold);">Edit</button>
            <button class="del-btn" onclick="App.deleteChar(${c.id}, event)">Delete</button>
          </div>
        </div>
      `).join("")}
    </div>`;
}

function labelOr(id, coll) {
  if (!id) return "";
  const item = DATA[coll].find(x => x.id === id);
  return item ? item.name : id;
}
function escapeHtml(s) { return (s || "").replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m])); }

function renderWizard() {
  const steps = STEP_NAMES.map((name, i) => `
    <div class="step ${i === state.step ? "active" : i < state.step ? "done" : ""}" onclick="App.goStep(${i})">
      <span class="step-num">${i + 1}</span>${name}
    </div>`).join("");

  const stepRenderers = [
    renderBasics, renderRace, renderClass, renderBackground,
    renderAbilityScores, renderSkillsFeat, renderEquipment, renderSpells, renderReview,
  ];
  const content = stepRenderers[state.step]();

  return `
    <div class="wizard">
      <div class="steps">${steps}</div>
      <div class="panel">
        ${content}
        <div class="wizard-nav">
          <button class="btn" onclick="App.prevStep()" ${state.step === 0 ? "disabled" : ""}>&larr; Back</button>
          ${state.step === STEP_NAMES.length - 1
            ? `<button class="btn btn--primary" onclick="App.save()">Save Character</button>`
            : `<button class="btn btn--primary" onclick="App.nextStep()">Next &rarr;</button>`}
        </div>
      </div>
    </div>`;
}

function renderBasics() {
  const c = state.character;
  return `
    <h2>Basics</h2>
    <div class="field">
      <label>Character Name</label>
      <input type="text" value="${escapeHtml(c.name)}" oninput="App.setName(this.value)" placeholder="e.g. Sylvaine Thorn" />
    </div>
    <div class="field">
      <label>Level</label>
      <input type="text" style="max-width:100px" value="${c.level}" oninput="App.setLevel(this.value)" />
    </div>
    <div class="field">
      <label>Ability Score Method (used in Step 5)</label>
      <select onchange="App.setAbilityMethod(this.value)">
        <option value="standard" ${c.abilityMethod === "standard" ? "selected" : ""}>Standard Array (15,14,13,12,10,8)</option>
        <option value="pointbuy" ${c.abilityMethod === "pointbuy" ? "selected" : ""}>Point Buy (27 points)</option>
        <option value="manual" ${c.abilityMethod === "manual" ? "selected" : ""}>Manual / Rolled</option>
      </select>
    </div>`;
}

function renderRace() {
  const c = state.character;
  const race = getRace(c.raceId);
  return `
    <h2>Race</h2>
    <div class="option-grid">
      ${DATA.races.map(r => `
        <div class="option-card ${c.raceId === r.id ? "selected" : ""}" onclick="App.selectRace('${r.id}')">
          <div class="name">${r.name}</div>
          <div class="sub">Speed ${r.speed} ft · ${Object.entries(r.abilityBonuses || {}).filter(([k]) => k !== "choose_two").map(([k, v]) => `${k.toUpperCase()} +${v}`).join(", ")}</div>
        </div>`).join("")}
    </div>
    ${race ? `
      <h3 style="margin-top:20px;">${race.name} Traits</h3>
      <ul class="trait-list">${race.traits.map(t => `<li>${t}</li>`).join("")}</ul>
      ${race.abilityBonuses && race.abilityBonuses.choose_two ? `
        <div class="field" style="margin-top:14px;">
          <label>Choose 2 abilities to raise by 1 (Half-Elf versatility)</label>
          <div class="option-grid">
            ${ABILITIES.filter(a => a !== "cha").map(a => `
              <div class="option-card ${c.halfElfChoices.includes(a) ? "selected" : ""}" onclick="App.toggleHalfElfChoice('${a}')">
                <div class="name">${ABILITY_NAMES[a]}</div>
              </div>`).join("")}
          </div>
        </div>` : ""}
    ` : ""}`;
}

function renderClass() {
  const c = state.character;
  const cls = getClass(c.classId);
  return `
    <h2>Class</h2>
    <div class="option-grid">
      ${DATA.classes.map(k => `
        <div class="option-card ${c.classId === k.id ? "selected" : ""}" onclick="App.selectClass('${k.id}')">
          <div class="name">${k.name}</div>
          <div class="sub">Hit Die d${k.hitDie} · Saves: ${k.savingThrows.map(s => s.toUpperCase()).join("/")}</div>
        </div>`).join("")}
    </div>
    ${cls ? `
      <h3 style="margin-top:20px;">Starting Equipment</h3>
      <ul class="trait-list">${cls.startingEquipment.map(e => `<li>${e}</li>`).join("")}</ul>
      ${cls.subclasses.length ? `
        <div class="field" style="margin-top:14px;">
          <label>Subclass ${c.level < cls.subclassLevel ? `(chosen at level ${cls.subclassLevel} — optional to pre-select)` : ""}</label>
          <select onchange="App.selectSubclass(this.value)">
            <option value="">— none selected —</option>
            ${cls.subclasses.map(s => `<option value="${s.id}" ${c.subclassId === s.id ? "selected" : ""}>${s.name}</option>`).join("")}
          </select>
        </div>` : ""}
    ` : ""}`;
}

function renderBackground() {
  const c = state.character;
  const bg = getBackground(c.backgroundId);
  return `
    <h2>Background</h2>
    <div class="option-grid">
      ${DATA.backgrounds.map(b => `
        <div class="option-card ${c.backgroundId === b.id ? "selected" : ""}" onclick="App.selectBackground('${b.id}')">
          <div class="name">${b.name}</div>
          <div class="sub">${b.skillProficiencies.join(", ")}</div>
        </div>`).join("")}
    </div>
    ${bg ? `
      <h3 style="margin-top:20px;">${bg.name} Feature</h3>
      <p style="font-size:14px;color:var(--text-muted)">${bg.feature}</p>
      <h3>Equipment</h3>
      <ul class="trait-list">${bg.equipment.map(e => `<li>${e}</li>`).join("")}</ul>
    ` : ""}`;
}

function renderAbilityScores() {
  const c = state.character;
  const scores = finalAbilityScores(c);
  let body = "";
  if (c.abilityMethod === "standard") {
    const used = ABILITIES.map(a => c.baseScores[a]);
    body = `
      <p class="standard-array-pool">Assign each value once: ${STANDARD_ARRAY.join(", ")}</p>
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <select onchange="App.setStandardArraySlot('${a}', this.value)">
              ${STANDARD_ARRAY.map(v => `<option value="${v}" ${c.baseScores[a] === v ? "selected" : ""}>${v}</option>`).join("")}
            </select>
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  } else if (c.abilityMethod === "pointbuy") {
    const spent = ABILITIES.reduce((s, a) => s + POINT_BUY_COST[c.baseScores[a]], 0);
    body = `
      <p class="standard-array-pool">Points spent: ${spent} / 27</p>
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <div>
              <button class="btn" style="padding:4px 10px" onclick="App.setPointBuy('${a}', -1)">−</button>
              <span style="font-family:var(--font-mono);font-size:20px;margin:0 8px;">${c.baseScores[a]}</span>
              <button class="btn" style="padding:4px 10px" onclick="App.setPointBuy('${a}', 1)">+</button>
            </div>
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  } else {
    body = `
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <input type="text" value="${c.baseScores[a]}" oninput="App.setManualScore('${a}', this.value)" />
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  }
  return `<h2>Ability Scores</h2><p class="subtitle">Base score, before racial bonuses are applied (shown as "final").</p>${body}`;
}

function renderSkillsFeat() {
  const c = state.character;
  const cls = getClass(c.classId);
  const bg = getBackground(c.backgroundId);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const bgSkills = bg ? bg.skillProficiencies : [];
  const max = cls ? (cls.skillChoices?.count || 2) : 0;
  const classSkillOptions = cls?.skillChoices?.options || [];
  // If the class has no options (e.g. PDF import didn't capture them) OR says "Any",
  // treat ALL skills as eligible so nothing is greyed out
  const openSelection = !classSkillOptions.length
    || classSkillOptions.some(o => /any/i.test(o));

  return `
    <h2>Skill Proficiencies</h2>
    <p class="subtitle">
      ${bg ? `${bg.name} grants: ${bgSkills.join(", ")}. ` : ""}
      ${cls
        ? openSelection
          ? `Choose any ${max} skills for ${cls.name}.`
          : `Choose ${max} class skills from: ${classSkillOptions.join(", ")}.`
        : "Pick a class first."}
      ${c.classSkillChoices.length}/${max} chosen.
    </p>
    <div>
      ${SKILLS.map(([name, ab]) => {
        const fromBg = bgSkills.includes(name);
        const chosen = c.classSkillChoices.includes(name);
        const atMax = c.classSkillChoices.length >= max && !chosen;
        // Eligible: from bg (always on), or class allows it, or open selection
        const eligible = !fromBg && (openSelection || classSkillOptions.includes(name));
        const proficient = fromBg || chosen;
        const mod = abilityMod(scores[ab]) + (proficient ? pb : 0);
        return `
          <div class="skill-row">
            <input type="checkbox"
              ${fromBg ? "checked disabled" : ""}
              ${!fromBg && eligible && !atMax ? `onclick="App.toggleClassSkill('${name}')"` : ""}
              ${chosen ? "checked" : ""}
              ${!fromBg && (!eligible || atMax) && !chosen ? "disabled" : ""}
            />
            <span style="${!fromBg && !eligible ? "color:var(--text-muted)" : ""}">
              ${name} <span style="color:var(--text-muted);font-size:12px;">(${ab.toUpperCase()})</span>
            </span>
            <span class="skill-mod">${fmtMod(mod)}</span>
          </div>`;
      }).join("")}
    </div>
    <div class="field" style="margin-top:20px;">
      <label>Optional Feat (house rule — apply per your table)</label>
      <select onchange="App.setFeat(this.value)">
        <option value="">— none —</option>
        ${DATA.feats.map(f => `<option value="${f.id}" ${c.feat === f.id ? "selected" : ""}>${f.name}</option>`).join("")}
      </select>
      ${c.feat ? `<p style="font-size:13px;color:var(--text-muted);margin-top:8px;">${DATA.feats.find(f => f.id === c.feat)?.summary || ""}</p>` : ""}
    </div>`;
}

function renderEquipment() {
  const c = state.character;
  const cls = getClass(c.classId);
  const bg = getBackground(c.backgroundId);
  return `
    <h2>Equipment</h2>
    ${cls ? `<h3>${cls.name} Starting Gear</h3><ul class="trait-list">${cls.startingEquipment.map(e => `<li>${e}</li>`).join("")}</ul>` : ""}
    ${bg ? `<h3>${bg.name} Gear</h3><ul class="trait-list">${bg.equipment.map(e => `<li>${e}</li>`).join("")}</ul>` : ""}
    <div class="field">
      <label>Armor Worn (affects AC)</label>
      <select onchange="App.setArmor(this.value)">
        <option value="">— none / unarmored —</option>
        ${DATA.equipment.armor.filter(a => a.category !== "Shield").map(a => `<option value="${a.name}" ${c.armorId === a.name ? "selected" : ""}>${a.name} (AC ${a.baseAC}${a.addDex ? " + Dex" : ""}${a.dexCap != null && a.dexCap !== null ? ` max ${a.dexCap}` : ""})</option>`).join("")}
      </select>
    </div>
    <div class="field">
      <label><input type="checkbox" ${c.shield ? "checked" : ""} onclick="App.toggleShield()" style="width:auto;margin-right:8px;" />Carrying a Shield (+2 AC)</label>
    </div>
    <div class="field">
      <label>Additional Gear / Weapons (free text)</label>
      <input type="text" value="${escapeHtml(c.extraGear)}" oninput="App.setExtraGear(this.value)" placeholder="e.g. Longsword, 2x potion of healing, 50gp" />
    </div>`;
}

function renderSpells() {
  const c = state.character;
  const cls = getClass(c.classId);
  const CASTER_ABILITY_WIZ = {
    bard: "cha", cleric: "wis", druid: "wis", paladin: "cha",
    ranger: "wis", sorcerer: "cha", warlock: "cha", wizard: "int",
    artificer: "int",
  };
  const slotInfo = getSpellSlots(c.classId, c.level);
  const scAbility = cls?.spellcasting?.ability || CASTER_ABILITY_WIZ[c.classId] || null;
  const isCaster = !!(slotInfo || scAbility);

  if (!cls || !isCaster) {
    return `<h2>Spells</h2><p class="subtitle">${cls ? cls.name : "This class"} doesn't use the standard spellcasting list — skip ahead.</p>`;
  }

  const sc = cls.spellcasting || { ability: scAbility, cantripsAt1: FULL_CASTERS.has(c.classId) ? 3 : 0, spellsAt1: null };
  // Max spell level from actual slot table, capped at 9
  const maxSpellLevel = slotInfo
    ? (slotInfo.type === "pact" ? slotInfo.slots[0].level : Math.max(...slotInfo.slots.map(s => s.level)))
    : Math.min(9, Math.ceil(c.level / 2));

  const allSpells = DATA.spells.filter(s =>
    s.classes.includes(cls.id) || s.classes.length === 0
  );
  const cantrips = allSpells.filter(s => s.level === 0).sort((a, b) => a.name.localeCompare(b.name));
  const leveled = allSpells.filter(s => s.level >= 1 && s.level <= maxSpellLevel)
    .sort((a, b) => a.level - b.level || a.name.localeCompare(b.name));

  const ordinals = ["","1st","2nd","3rd","4th","5th","6th","7th","8th","9th"];

  // Group leveled spells by their spell level
  const byLevel = {};
  for (const s of leveled) {
    if (!byLevel[s.level]) byLevel[s.level] = [];
    byLevel[s.level].push(s);
  }

  const leveledHtml = Object.keys(byLevel).sort((a,b) => a-b).map(lvl => {
    const spellsAtLevel = byLevel[lvl];
    // Show how many slots exist at this level for reference
    let slotNote = "";
    if (slotInfo && slotInfo.type !== "pact") {
      const slot = slotInfo.slots.find(s => s.level === parseInt(lvl));
      if (slot) slotNote = `<span style="font-size:12px;color:var(--text-muted);font-family:var(--font-mono);margin-left:8px;">${slot.max} slots</span>`;
    }
    return `
      <div class="spell-level-header">
        <span>${ordinals[lvl]}-Level Spells</span>${slotNote}
      </div>
      <div class="spell-list" style="margin-bottom:8px;">
        ${spellsAtLevel.map(s => `
          <div class="spell-row ${c.spellsKnown.includes(s.name) ? "selected" : ""}" onclick="App.toggleSpell('${s.name.replace(/'/g, "\\'")}')">
            <span class="sname">${s.name}</span><span class="slevel">${s.school}</span>
            <div class="ssum">${s.summary}</div>
          </div>`).join("")}
      </div>`;
  }).join("") || "<p class='subtitle'>No matching spells in the library yet.</p>";

  return `
    <h2>Spells</h2>
    <p class="subtitle">
      ${cls.name} casts using <strong>${ABILITY_NAMES[scAbility]}</strong>.
      Showing spells up to level ${maxSpellLevel} (your highest available slot).
      ${sc.cantripsAt1 ? `Cantrip slots: ${sc.cantripsAt1}.` : ""}
      ${sc.spellsAt1 != null ? `Spells known limit: ${sc.spellsAt1}.` : "Prepared caster — select what you'd prepare."}
    </p>

    <h3>Cantrips (${c.cantrips.length}${sc.cantripsAt1 ? `/${sc.cantripsAt1}` : ""})</h3>
    <div class="spell-list" style="margin-bottom:20px;">
      ${cantrips.map(s => `
        <div class="spell-row ${c.cantrips.includes(s.name) ? "selected" : ""}" onclick="App.toggleCantrip('${s.name.replace(/'/g, "\\'")}')">
          <span class="sname">${s.name}</span><span class="slevel">${s.school}</span>
          <div class="ssum">${s.summary}</div>
        </div>`).join("") || "<p class='subtitle'>No cantrips available for this class in the library.</p>"}
    </div>

    <h3>Spells Known / Prepared (${c.spellsKnown.length}${sc.spellsAt1 != null ? `/${sc.spellsAt1}` : ""})</h3>
    ${leveledHtml}`;
}

function renderReview() {
  const c = state.character;
  const race = getRace(c.raceId), cls = getClass(c.classId), bg = getBackground(c.backgroundId);
  const scores = finalAbilityScores(c);
  const hp = computeHP(c), ac = computeAC(c), pb = proficiencyBonus(c.level);
  const subclass = cls && cls.subclasses.find(s => s.id === c.subclassId);
  return `
    <h2>Review &amp; Save</h2>
    <div class="summary-grid">
      <div class="summary-block">
        <h3>Identity</h3>
        <div class="stat-line"><span>Name</span><span>${escapeHtml(c.name) || "—"}</span></div>
        <div class="stat-line"><span>Race</span><span>${race ? race.name : "—"}</span></div>
        <div class="stat-line"><span>Class</span><span>${cls ? cls.name : "—"}${subclass ? ` (${subclass.name})` : ""}</span></div>
        <div class="stat-line"><span>Background</span><span>${bg ? bg.name : "—"}</span></div>
        <div class="stat-line"><span>Level</span><span>${c.level}</span></div>
        <div class="stat-line"><span>Proficiency Bonus</span><span>${fmtMod(pb)}</span></div>
      </div>
      <div class="summary-block">
        <h3>Combat</h3>
        <div class="stat-line"><span>Hit Points</span><span>${hp ?? "—"}</span></div>
        <div class="stat-line"><span>Armor Class</span><span>${ac}</span></div>
        <div class="stat-line"><span>Speed</span><span>${race ? race.speed : "—"} ft</span></div>
        <div class="stat-line"><span>Hit Die</span><span>${cls ? `d${cls.hitDie}` : "—"}</span></div>
      </div>
      <div class="summary-block">
        <h3>Ability Scores</h3>
        ${ABILITIES.map(a => `<div class="stat-line"><span>${ABILITY_NAMES[a]}</span><span>${scores[a]} (${fmtMod(abilityMod(scores[a]))})</span></div>`).join("")}
      </div>
      <div class="summary-block">
        <h3>Proficient Skills</h3>
        ${[...allProficientSkills(c)].map(s => `<span class="tag">${s}</span>`).join("") || "<span class='subtitle'>None chosen</span>"}
        ${c.feat ? `<h3 style="margin-top:14px;">Feat</h3><span class="tag">${DATA.feats.find(f => f.id === c.feat)?.name}</span>` : ""}
      </div>
    </div>
    <div class="field" style="margin-top:20px;">
      <label>Notes</label>
      <input type="text" value="${escapeHtml(c.notes)}" oninput="App.setNotes(this.value)" placeholder="Personality, backstory, allies, plot hooks..." />
    </div>`;
}

// ============ HP Tracker ============

function renderHpTracker(c) {
  const max = computeHP(c) ?? 0;
  const cur = c.currentHp ?? max;
  const cls = getClass(c.classId);
  const die = cls ? cls.hitDie : 8;
  const hdTotal = c.level;
  const hdUsed = c.hitDiceUsed || 0;
  const hdLeft = hdTotal - hdUsed;
  const pct = max > 0 ? Math.round((cur / max) * 100) : 0;
  const barColor = pct > 50 ? '#4caf50' : pct > 25 ? '#e6a817' : 'var(--crimson)';

  return `
    <div id="hp-tracker" class="sheet-card">
      <h3 class="sheet-card-title">Hit Points &amp; Rests</h3>
      <div class="hp-main">
        <div class="hp-bar-wrap">
          <div class="hp-bar" style="width:${pct}%;background:${barColor}"></div>
        </div>
        <div class="hp-controls">
          <button class="btn hp-adj" onclick="App.adjustHp(-1)" title="Take 1 damage">−</button>
          <div class="hp-display">
            <input type="text" id="cur-hp-input" class="hp-input" value="${cur}"
              onchange="App.setCurrentHp(this.value)"
              onkeydown="if(event.key==='Enter')App.setCurrentHp(this.value)" />
            <span class="hp-sep">/</span>
            <span class="hp-max">${max}</span>
          </div>
          <button class="btn hp-adj" onclick="App.adjustHp(1)" title="Heal 1">+</button>
        </div>
        <div class="hp-label">Current / Max HP</div>
      </div>

      <div class="hd-row">
        <div class="hd-info">
          <span class="hd-count">${hdLeft}<span style="font-size:13px;color:var(--text-muted)">/${hdTotal}</span></span>
          <span class="hd-label">d${die} Hit Dice</span>
        </div>
        <button class="btn btn--primary" onclick="App.spendHitDie()" ${cur >= max || hdLeft <= 0 ? "disabled" : ""} style="font-size:13px;padding:8px 14px">
          Roll Hit Die
        </button>
      </div>
      <div id="hd-msg" style="font-size:13px;color:var(--gold);min-height:18px;margin-top:4px;transition:opacity .5s;opacity:0"></div>

      <div class="rest-buttons">
        <button class="btn" onclick="App.shortRest()" style="flex:1">☽ Short Rest</button>
        <button class="btn btn--primary" onclick="App.longRest()" style="flex:1">☀ Long Rest</button>
      </div>
    </div>`;
}

// ============ Spell Slot Tracker ============

function renderSpellSlotTracker(c, slotInfo) {
  const slots = c.spellSlots || {};

  if (slotInfo.type === "pact") {
    const s = slotInfo.slots[0];
    const used = slots["pact"] || 0;
    const pips = Array.from({ length: s.max }, (_, i) => `
      <span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('pact', ${i})" title="${i < used ? "Click to restore" : "Click to use"}"></span>
    `).join("");
    return `
      <div id="spell-slot-tracker" class="sheet-card">
        <h3 class="sheet-card-title">Pact Magic Slots</h3>
        <div class="slot-row">
          <span class="slot-label">Level ${s.level}</span>
          <div class="slot-pips">${pips}</div>
          <span class="slot-count">${s.max - used} / ${s.max}</span>
        </div>
        <p class="dim" style="font-size:12px;margin:8px 0 0">Pact slots recover on a short or long rest.</p>
      </div>`;
  }

  const ordinals = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th"];
  const rows = slotInfo.slots.map(s => {
    const key = String(s.level);
    const used = slots[key] || 0;
    const pips = Array.from({ length: s.max }, (_, i) => `
      <span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('${key}', ${i})" title="${i < used ? "Click to restore" : "Click to use"}"></span>
    `).join("");
    return `
      <div class="slot-row">
        <span class="slot-label">${ordinals[s.level - 1]}</span>
        <div class="slot-pips">${pips}</div>
        <span class="slot-count">${s.max - used} / ${s.max}</span>
      </div>`;
  }).join("");

  return `
    <div id="spell-slot-tracker" class="sheet-card">
      <h3 class="sheet-card-title">Spell Slots</h3>
      ${rows}
    </div>`;
}

function renderSheet() {
  const c = state.character;
  const race = getRace(c.raceId), cls = getClass(c.classId), bg = getBackground(c.backgroundId);
  const subclass = cls && cls.subclasses.find(s => s.id === c.subclassId);
  const feat = c.feat && DATA.feats.find(f => f.id === c.feat);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const hp = computeHP(c), ac = computeAC(c);
  const initiative = abilityMod(scores.dex);
  const skillRows = getSkillRows(c);
  const saves = getSavingThrows(c);
  const perception = skillRows.find(s => s.name === "Perception");
  const passivePerception = 10 + (perception ? perception.mod : 0);

  const featuresList = [
    ...(race ? race.traits : []),
    ...(bg ? [bg.feature] : []),
    ...(subclass ? [`${subclass.name} (${cls.name} subclass)`] : []),
    ...(feat ? [`${feat.name}: ${feat.summary}`] : []),
  ];

  const equipmentList = [
    ...(cls ? cls.startingEquipment : []),
    ...(bg ? bg.equipment : []),
    ...(c.armorId ? [`Armor: ${c.armorId}`] : []),
    ...(c.shield ? ["Shield"] : []),
    ...(c.extraGear ? [c.extraGear] : []),
  ];

  // Fallback spellcasting ability per class for when PDF import didn't capture it
  const CASTER_ABILITY = {
    bard: "cha", cleric: "wis", druid: "wis", paladin: "cha",
    ranger: "wis", sorcerer: "cha", warlock: "cha", wizard: "int",
    artificer: "int",
  };

  const spellSection = (() => {
    const slotInfo = getSpellSlots(c.classId, c.level);
    // Use cls.spellcasting if present, otherwise synthesise from known caster table
    const scAbility = cls?.spellcasting?.ability || CASTER_ABILITY[c.classId] || null;
    const isCaster = !!(slotInfo || scAbility);
    if (!isCaster) return "";

    const abMod = scAbility ? abilityMod(scores[scAbility]) : 0;
    const saveDC = 8 + pb + abMod;
    const atkBonus = pb + abMod;
    const cantrips = DATA.spells.filter(s => c.cantrips.includes(s.name));
    const known = DATA.spells.filter(s => c.spellsKnown.includes(s.name));
    return `
      ${slotInfo ? renderSpellSlotTracker(c, slotInfo) : ""}
      <div class="sheet-card">
        <h3 class="sheet-card-title">Spellcasting</h3>
        <div class="spell-meta-row">
          <div><span class="sheet-label">Ability</span><span class="sheet-value">${scAbility ? ABILITY_NAMES[scAbility] : "—"}</span></div>
          <div><span class="sheet-label">Save DC</span><span class="sheet-value">${saveDC}</span></div>
          <div><span class="sheet-label">Attack Bonus</span><span class="sheet-value">${fmtMod(atkBonus)}</span></div>
        </div>
        ${cantrips.length ? `<h4 class="sheet-subhead">Cantrips</h4><ul class="sheet-list">${cantrips.map(s => `<li><strong>${s.name}</strong> <span class="dim">— ${s.summary}</span></li>`).join("")}</ul>` : ""}
        ${known.length ? `<h4 class="sheet-subhead">Spells Known</h4><ul class="sheet-list">${known.map(s => `<li><strong>${s.name}</strong> <span class="dim">(Lvl ${s.level}) — ${s.summary}</span></li>`).join("")}</ul>` : ""}
      </div>`;
  })();

  return `
    <div class="sheet">
      <div class="sheet-toolbar">
        <button class="btn" onclick="Router.go('list')">&larr; Back to Characters</button>
        <button class="btn btn--primary" onclick="Router.go('edit', ${state.editingId})">Edit Character</button>
      </div>

      <div class="sheet-banner">
        <div class="sheet-avatar">${(c.name || "?").trim().charAt(0).toUpperCase()}</div>
        <div class="sheet-banner-text">
          <h1>${escapeHtml(c.name) || "Unnamed"}</h1>
          <div class="sheet-subtitle">
            Level ${c.level} ${race ? race.name : "—"} ${cls ? cls.name : "—"}${subclass ? ` (${subclass.name})` : ""}
          </div>
          <div class="sheet-subtitle dim">${bg ? bg.name : "No background"}</div>
        </div>
      </div>

      <div class="sheet-vitals">
        <div class="vital-box"><span class="vital-num">${ac}</span><span class="vital-label">Armor Class</span></div>
        <div class="vital-box"><span class="vital-num" style="font-size:18px">${c.currentHp ?? hp ?? "—"}<span style="font-size:13px;color:#888">/${hp ?? "—"}</span></span><span class="vital-label">Hit Points</span></div>
        <div class="vital-box"><span class="vital-num">${fmtMod(initiative)}</span><span class="vital-label">Initiative</span></div>
        <div class="vital-box"><span class="vital-num">${race ? race.speed : "—"}</span><span class="vital-label">Speed</span></div>
        <div class="vital-box"><span class="vital-num">${cls ? `d${cls.hitDie}` : "—"}</span><span class="vital-label">Hit Die</span></div>
        <div class="vital-box"><span class="vital-num">${fmtMod(pb)}</span><span class="vital-label">Proficiency</span></div>
      </div>

      <div class="sheet-grid">
        <div class="sheet-col">
          <div class="sheet-card">
            <h3 class="sheet-card-title">Ability Scores</h3>
            <div class="ability-hex-grid">
              ${ABILITIES.map(a => `
                <div class="ability-hex">
                  <div class="hex-ability">${a.toUpperCase()}</div>
                  <div class="hex-mod">${fmtMod(abilityMod(scores[a]))}</div>
                  <div class="hex-score">${scores[a]}</div>
                </div>`).join("")}
            </div>
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">Saving Throws</h3>
            ${saves.map(s => `
              <div class="prof-row">
                <span class="prof-dot ${s.proficient ? "on" : ""}"></span>
                <span>${ABILITY_NAMES[s.ability]}</span>
                <span class="prof-mod">${fmtMod(s.mod)}</span>
              </div>`).join("")}
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">Skills</h3>
            <div class="prof-row" style="border-bottom:1px solid var(--border-dark);padding-bottom:8px;margin-bottom:6px;">
              <span></span><span>Passive Perception</span><span class="prof-mod">${passivePerception}</span>
            </div>
            ${skillRows.map(s => `
              <div class="prof-row">
                <span class="prof-dot ${s.proficient ? "on" : ""}"></span>
                <span>${s.name} <span class="dim">(${s.ability.toUpperCase()})</span></span>
                <span class="prof-mod">${fmtMod(s.mod)}</span>
              </div>`).join("")}
          </div>
        </div>

        <div class="sheet-col sheet-col--wide">
          ${renderHpTracker(c)}

          <div class="sheet-card">
            <h3 class="sheet-card-title">Features &amp; Traits</h3>
            ${featuresList.length ? `<ul class="sheet-list">${featuresList.map(t => `<li>${t}</li>`).join("")}</ul>` : `<p class="dim">None recorded.</p>`}
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">Equipment</h3>
            ${equipmentList.length ? `<ul class="sheet-list">${equipmentList.map(t => `<li>${t}</li>`).join("")}</ul>` : `<p class="dim">None recorded.</p>`}
          </div>

          ${spellSection}

          ${c.notes ? `
          <div class="sheet-card">
            <h3 class="sheet-card-title">Notes</h3>
            <p>${escapeHtml(c.notes)}</p>
          </div>` : ""}
        </div>
      </div>
    </div>`;
}

// ============ PDF Import Page ============

function renderImportPage() {
  return `
    <div class="import-page">
      <div class="import-header">
        <h1>Import Source Material</h1>
        <p class="subtitle">Load PDFs from your computer — all processing happens locally in your browser. No internet, no API key, nothing leaves your machine. Select as many PDFs as you like at once.</p>
      </div>

      <div class="import-grid">
        <div class="import-upload-panel">
          <div class="sheet-card" style="margin-bottom:16px">
            <h3 class="sheet-card-title">🔒 100% Local Processing</h3>
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:24px">✅</span>
              <div>
                <strong style="color:#4caf50">Ready — no setup needed</strong>
                <div class="dim" style="font-size:12px;margin-top:2px">PDF text is extracted in your browser using Mozilla's pdf.js. Parsed data is saved to your local server only.</div>
              </div>
            </div>
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">📄 Load PDFs</h3>
            <div class="drop-zone" id="dropZone"
              ondragover="event.preventDefault(); this.classList.add('drag-over')"
              ondragleave="this.classList.remove('drag-over')"
              ondrop="ImportPage.handleDrop(event)">
              <div class="drop-icon">⬆</div>
              <div>Drag &amp; drop PDFs here</div>
              <div style="color:var(--text-muted);font-size:13px;margin:6px 0">or</div>
              <button class="btn" onclick="document.getElementById('pdfInput').click()">Browse files</button>
              <input type="file" id="pdfInput" accept=".pdf" multiple style="display:none" onchange="ImportPage.handleFileSelect(this)" />
            </div>
            <div id="fileQueue" style="margin-top:10px;display:flex;flex-direction:column;gap:6px;"></div>
            <button class="btn btn--primary" style="width:100%;margin-top:12px" id="importBtn" onclick="ImportPage.runImport()" disabled>
              Extract &amp; Import All
            </button>
          </div>

          <div id="importStatus" style="margin-top:16px"></div>

          <div class="sheet-card" style="margin-top:16px">
            <h3 class="sheet-card-title">ℹ️ What gets extracted</h3>
            <p class="dim" style="font-size:13px;margin:0">The parser recognises D&amp;D 5e formatting to pull out races, classes &amp; subclasses, backgrounds, feats, and spells. Results vary by PDF quality — digital-native PDFs extract best. Scanned/image PDFs won't work. Review the library after import and remove anything garbled.</p>
          </div>
        </div>

        <div>
          <div class="sheet-card">
            <h3 class="sheet-card-title">📚 Imported Content Library</h3>
            <p style="font-size:13px;color:var(--text-muted);margin-top:0">Everything below is available in the character creator. Click × to remove an entry.</p>
            <div id="libraryContent"><p class="dim">Loading…</p></div>
          </div>
        </div>
      </div>
    </div>`;
}

const ImportPage = {
  _files: [],   // array of File objects

  async loadLibrary() {
    const el = document.getElementById('libraryContent');
    if (!el) return;
    try {
      const lib = await (await fetch('/api/import/library')).json();
      const types = ['races','classes','backgrounds','feats','spells'];
      const sections = types.map(type => {
        const items = lib[type] || [];
        if (!items.length) return '';
        return `
          <div style="margin-bottom:14px">
            <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--gold);margin-bottom:6px">${type} (${items.length})</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px">
              ${items.map(it => `
                <span class="tag" style="display:inline-flex;align-items:center;gap:4px">
                  ${escapeHtml(it.name)}
                  <span style="cursor:pointer;color:var(--crimson);font-size:12px" onclick="ImportPage.remove('${type}', '${escapeHtml(it.id || it.name)}')">×</span>
                </span>`).join('')}
            </div>
          </div>`;
      }).filter(Boolean).join('');
      const eqItems = lib.equipment || [];
      const eqSection = eqItems.length ? `
        <div>
          <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--gold);margin-bottom:6px">equipment (${eqItems.length})</div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${eqItems.map(it => `<span class="tag">${escapeHtml(it.name)}</span>`).join('')}
          </div>
        </div>` : '';
      el.innerHTML = sections + eqSection || '<p class="dim">No custom content imported yet.</p>';
    } catch (e) {
      el.innerHTML = '<p class="dim">Could not load library.</p>';
    }
  },

  handleDrop(e) {
    e.preventDefault();
    document.getElementById('dropZone').classList.remove('drag-over');
    const files = [...e.dataTransfer.files].filter(f => f.type === 'application/pdf');
    if (!files.length) { this._globalStatus('error', 'Only PDF files are supported.'); return; }
    this._addFiles(files);
  },

  handleFileSelect(input) {
    const files = [...input.files];
    if (files.length) this._addFiles(files);
    input.value = ''; // reset so same file can be re-added if needed
  },

  _addFiles(newFiles) {
    // Deduplicate by name
    const existing = new Set(this._files.map(f => f.name));
    const toAdd = newFiles.filter(f => !existing.has(f.name));
    this._files.push(...toAdd);
    this._renderQueue();
    document.getElementById('importBtn').disabled = this._files.length === 0;
  },

  removeFile(name) {
    this._files = this._files.filter(f => f.name !== name);
    this._renderQueue();
    document.getElementById('importBtn').disabled = this._files.length === 0;
  },

  _renderQueue() {
    const el = document.getElementById('fileQueue');
    if (!el) return;
    if (!this._files.length) { el.innerHTML = ''; return; }
    el.innerHTML = this._files.map(f => `
      <div class="queue-row" id="qrow-${CSS.escape(f.name)}">
        <span class="queue-icon">📄</span>
        <span class="queue-name">${escapeHtml(f.name)}</span>
        <span class="queue-size">${(f.size / 1024 / 1024).toFixed(1)} MB</span>
        <span class="queue-status" id="qstatus-${CSS.escape(f.name)}"></span>
        <button class="queue-remove" onclick="ImportPage.removeFile('${escapeHtml(f.name)}')" title="Remove">×</button>
      </div>`).join('');
  },

  _setRowStatus(name, html) {
    const el = document.getElementById(`qstatus-${CSS.escape(name)}`);
    if (el) el.innerHTML = html;
  },

  async runImport() {
    if (!this._files.length) return;

    // Load parser once
    if (!window.DnDPDFParser) {
      this._globalStatus('info', '⏳ Loading pdf.js library…');
      await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = '/pdf-parser.js';
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      });
    }

    const btn = document.getElementById('importBtn');
    btn.disabled = true;

    const totals = { added: {}, updated: {} };
    let succeeded = 0, failed = 0;

    // Process sequentially so we don't flood memory with huge PDFs
    for (const file of this._files) {
      this._setRowStatus(file.name, '<span style="color:var(--gold)">⏳ reading…</span>');
      btn.textContent = `Processing ${succeeded + failed + 1} / ${this._files.length}…`;

      try {
        const result = await window.DnDPDFParser.extractDnDContent(
          file,
          (stage, cur, total) => {
            const msgs = { loading:'loading…', reading:`page ${cur}/${total}`, parsing:'parsing…', done:'saving…' };
            this._setRowStatus(file.name, `<span style="color:var(--gold)">⏳ ${msgs[stage] || stage}</span>`);
          }
        );

        const res = await fetch('/api/import/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(result),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Save failed');

        // Accumulate totals
        for (const type of ['races','classes','backgrounds','feats','spells']) {
          totals.added[type] = (totals.added[type] || 0) + (data.counts.added[type] || 0);
          totals.updated[type] = (totals.updated[type] || 0) + (data.counts.updated[type] || 0);
        }

        const addedCount = Object.values(data.counts.added || {}).reduce((s, v) => s + (v || 0), 0);
        this._setRowStatus(file.name, `<span style="color:#4caf50">✅ +${addedCount} items</span>`);
        succeeded++;
      } catch (err) {
        this._setRowStatus(file.name, `<span style="color:var(--crimson)" title="${escapeHtml(err.message)}">❌ failed</span>`);
        failed++;
      }
    }

    btn.textContent = 'Extract & Import All';
    btn.disabled = false;

    // Summary
    const lines = [];
    for (const type of ['races','classes','backgrounds','feats','spells']) {
      const a = totals.added[type] || 0, u = totals.updated[type] || 0;
      if (a || u) lines.push(`${type}: +${a} new, ${u} updated`);
    }
    const summaryColor = failed === 0 ? '#4caf50' : succeeded === 0 ? 'var(--crimson)' : 'var(--gold)';
    this._globalStatus(failed === 0 ? 'success' : 'info', `
      <strong style="color:${summaryColor}">
        ${succeeded === this._files.length ? '✅ All done' : `✅ ${succeeded} done, ❌ ${failed} failed`}
      </strong><br>
      ${lines.join('<br>') || 'No new content found across these PDFs.'}
    `);

    DATA = await api.getData();
    this.loadLibrary();
  },

  _globalStatus(type, html) {
    const el = document.getElementById('importStatus');
    if (!el) return;
    const borderColor = type === 'error' ? 'var(--crimson)' : type === 'success' ? '#4caf50' : 'var(--border-dark)';
    el.innerHTML = `<div style="padding:14px;border-radius:var(--radius);background:var(--ink-panel);border:1px solid ${borderColor};">${html}</div>`;
  },

  async remove(type, id) {
    if (!confirm(`Remove "${id}" from the custom library?`)) return;
    await fetch(`/api/import/library/${type}/${encodeURIComponent(id)}`, { method: 'DELETE' });
    DATA = await api.getData();
    this.loadLibrary();
  },
};

window.ImportPage = ImportPage;

// ============ Boot ============
(async function init() {
  DATA = await api.getData();
  Router.go("list");
})();
