// ============ Constants ============
const SKILLS = [
  ["Acrobatics", "dex"], ["Animal Handling", "wis"], ["Arcana", "int"], ["Athletics", "str"],
  ["Deception", "cha"], ["History", "int"], ["Insight", "wis"], ["Intimidation", "cha"],
  ["Investigation", "int"], ["Medicine", "wis"], ["Nature", "int"], ["Perception", "wis"],
  ["Performance", "cha"], ["Persuasion", "cha"], ["Religion", "int"], ["Sleight of Hand", "dex"],
  ["Stealth", "dex"], ["Survival", "wis"],
];
const ABILITIES = ["str", "dex", "con", "int", "wis", "cha"];
const ABILITY_NAMES = { str: "Strength", dex: "Dexterity", con: "Constitution", int: "Intelligence", wis: "Wisdom", cha: "Charisma" };
const STANDARD_ARRAY = [15, 14, 13, 12, 10, 8];
const POINT_BUY_COST = { 8: 0, 9: 1, 10: 2, 11: 3, 12: 4, 13: 5, 14: 7, 15: 9 };
const STEP_NAMES = ["Basics", "Race", "Class", "Background", "Ability Scores", "Skills & Feat", "Equipment", "Spells", "Review"];

// Official 5e spell slots by class type and level
// Full casters: Wizard, Sorcerer, Bard, Cleric, Druid
// Half casters: Paladin, Ranger (slots start at level 2, halved)
// Warlock: pact magic (separate — all slots same level, few in number)
const FULL_CASTER_SLOTS = {
  1:  [2,0,0,0,0,0,0,0,0],
  2:  [3,0,0,0,0,0,0,0,0],
  3:  [4,2,0,0,0,0,0,0,0],
  4:  [4,3,0,0,0,0,0,0,0],
  5:  [4,3,2,0,0,0,0,0,0],
  6:  [4,3,3,0,0,0,0,0,0],
  7:  [4,3,3,1,0,0,0,0,0],
  8:  [4,3,3,2,0,0,0,0,0],
  9:  [4,3,3,3,1,0,0,0,0],
  10: [4,3,3,3,2,0,0,0,0],
  11: [4,3,3,3,2,1,0,0,0],
  12: [4,3,3,3,2,1,0,0,0],
  13: [4,3,3,3,2,1,1,0,0],
  14: [4,3,3,3,2,1,1,0,0],
  15: [4,3,3,3,2,1,1,1,0],
  16: [4,3,3,3,2,1,1,1,0],
  17: [4,3,3,3,2,1,1,1,1],
  18: [4,3,3,3,3,1,1,1,1],
  19: [4,3,3,3,3,2,1,1,1],
  20: [4,3,3,3,3,2,2,1,1],
};
const HALF_CASTER_SLOTS = {
  1:  [0,0,0,0,0,0,0,0,0],
  2:  [2,0,0,0,0,0,0,0,0],
  3:  [3,0,0,0,0,0,0,0,0],
  4:  [3,0,0,0,0,0,0,0,0],
  5:  [4,2,0,0,0,0,0,0,0],
  6:  [4,2,0,0,0,0,0,0,0],
  7:  [4,3,0,0,0,0,0,0,0],
  8:  [4,3,0,0,0,0,0,0,0],
  9:  [4,3,2,0,0,0,0,0,0],
  10: [4,3,2,0,0,0,0,0,0],
  11: [4,3,3,0,0,0,0,0,0],
  12: [4,3,3,0,0,0,0,0,0],
  13: [4,3,3,1,0,0,0,0,0],
  14: [4,3,3,1,0,0,0,0,0],
  15: [4,3,3,2,0,0,0,0,0],
  16: [4,3,3,2,0,0,0,0,0],
  17: [4,3,3,3,1,0,0,0,0],
  18: [4,3,3,3,1,0,0,0,0],
  19: [4,3,3,3,2,0,0,0,0],
  20: [4,3,3,3,2,0,0,0,0],
};
const WARLOCK_SLOTS = {
  // [slotsPerRest, slotLevel]
  1:  [1,1], 2: [2,1], 3: [2,2], 4: [2,2], 5: [3,3],
  6:  [3,3], 7: [4,4], 8: [4,4], 9: [5,5], 10: [5,5],
  11: [5,5], 12: [5,5], 13: [5,5], 14: [5,5], 15: [5,5],
  16: [5,5], 17: [5,5], 18: [5,5], 19: [5,5], 20: [5,5],
};
const FULL_CASTERS  = new Set(["bard","cleric","druid","sorcerer","wizard"]);
const HALF_CASTERS  = new Set(["paladin","ranger"]);

function getSpellSlots(classId, level) {
  if (!classId) return null;
  if (classId === "warlock") {
    const [count, slotLevel] = WARLOCK_SLOTS[level] || [0,0];
    return { type: "pact", slots: [{ level: slotLevel, max: count }] };
  }
  let table = null;
  if (FULL_CASTERS.has(classId))  table = FULL_CASTER_SLOTS;
  if (HALF_CASTERS.has(classId))  table = HALF_CASTER_SLOTS;
  if (!table) return null;
  const row = table[level] || table[20];
  const slots = row.map((max, i) => ({ level: i + 1, max })).filter(s => s.max > 0);
  return slots.length ? { type: "full", slots } : null;
}

// ============ Global state ============
let DATA = null; // { races, classes, backgrounds, feats, spells, equipment }
let state = { view: "list", step: 0, editingId: null, character: null, charList: [] };

function blankCharacter() {
  return {
    name: "", level: 1,
    raceId: null, classId: null, subclassId: null, backgroundId: null,
    abilityMethod: "standard", baseScores: { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 },
    halfElfChoices: [],
    classSkillChoices: [], feat: null,
    equipmentChoice: null, armorId: null, shield: false, extraGear: "",
    cantrips: [], spellsKnown: [],
    spellSlots: {},        // { "1": usedCount, … }
    currentHp: null,       // null = at max; set to a number when damaged
    hitDiceUsed: 0,        // how many hit dice spent this rest cycle
    tempHp: 0,             // temporary hit points (don't stack, don't recover on rest)
    tempAc: 0,             // temporary AC bonus (shield of faith, etc.)
    resources: {},         // { resourceId: usedAmount } — class/race resource tracking
    notes: "",
  };
}

// ============ API ============
const api = {
  async getData() { return (await fetch("/api/data")).json(); },
  async listCharacters() { return (await fetch("/api/characters")).json(); },
  async getCharacter(id) { return (await fetch(`/api/characters/${id}`)).json(); },
  async saveCharacter(char, id) {
    const body = JSON.stringify({ ...char, raceId: char.raceId, classId: char.classId, subclassId: char.subclassId, backgroundId: char.backgroundId });
    const res = await fetch(id ? `/api/characters/${id}` : "/api/characters", {
      method: id ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body,
    });
    return res.json();
  },
  async deleteCharacter(id) { return (await fetch(`/api/characters/${id}`, { method: "DELETE" })).json(); },
};

// ============ Helpers ============
function abilityMod(score) { return Math.floor((score - 10) / 2); }
function fmtMod(n) { return n >= 0 ? `+${n}` : `${n}`; }
function proficiencyBonus(level) { return 2 + Math.floor((level - 1) / 4); }

function getRace(id) { return DATA.races.find(r => r.id === id); }
function getClass(id) { return DATA.classes.find(c => c.id === id); }
function getBackground(id) { return DATA.backgrounds.find(b => b.id === id); }

function finalAbilityScores(c) {
  const race = getRace(c.raceId);
  const scores = { ...c.baseScores };
  if (race) {
    for (const [k, v] of Object.entries(race.abilityBonuses || {})) {
      if (k === "choose_two") continue;
      if (ABILITIES.includes(k)) scores[k] += v;
    }
    if (race.abilityBonuses && race.abilityBonuses.choose_two) {
      for (const ab of c.halfElfChoices) scores[ab] = (scores[ab] || 0) + 1;
    }
  }
  return scores;
}

function computeHP(c) {
  const cls = getClass(c.classId);
  if (!cls) return null;
  const scores = finalAbilityScores(c);
  const conMod = abilityMod(scores.con);
  const level = c.level;
  const hillDwarfBonus = (getRace(c.raceId)?.traits || []).some(t => t.includes("Dwarven Toughness")) ? level : 0;
  let hp = cls.hitDie + conMod; // level 1 max
  for (let lvl = 2; lvl <= level; lvl++) {
    hp += Math.floor(cls.hitDie / 2) + 1 + conMod; // average roll
  }
  return hp + hillDwarfBonus;
}

function computeAC(c) {
  const scores = finalAbilityScores(c);
  const dexMod = abilityMod(scores.dex);
  const armor = DATA.equipment.armor.find(a => a.name === c.armorId);
  let ac;
  if (!armor) ac = 10 + dexMod;
  else {
    let dexBonus = 0;
    if (armor.addDex) dexBonus = armor.dexCap != null ? Math.min(dexMod, armor.dexCap) : dexMod;
    ac = armor.baseAC + dexBonus;
  }
  if (c.shield) ac += 2;
  return ac;
}

function classSkillCount(c) {
  const cls = getClass(c.classId);
  return cls ? cls.skillChoices.count : 0;
}

function backgroundSkills(c) {
  const bg = getBackground(c.backgroundId);
  return bg ? bg.skillProficiencies : [];
}

function allProficientSkills(c) {
  return new Set([...(c.classSkillChoices || []), ...backgroundSkills(c)]);
}

function getSkillRows(c) {
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const proficient = allProficientSkills(c);
  return SKILLS.map(([name, ab]) => {
    const isProf = proficient.has(name);
    return { name, ability: ab, proficient: isProf, mod: abilityMod(scores[ab]) + (isProf ? pb : 0) };
  });
}

function getSavingThrows(c) {
  const cls = getClass(c.classId);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const profs = cls ? cls.savingThrows : [];
  return ABILITIES.map(a => {
    const isProf = profs.includes(a);
    return { ability: a, proficient: isProf, mod: abilityMod(scores[a]) + (isProf ? pb : 0) };
  });
}

// ============ Router ============
const Router = {
  async go(view, id = null) {
    if (view === "list") {
      state.view = "list";
      state.charList = await api.listCharacters();
      render();
    } else if (view === "create") {
      state.view = "wizard"; state.step = 0; state.editingId = null; state.character = blankCharacter();
      render();
    } else if (view === "edit") {
      const row = await api.getCharacter(id);
      state.view = "wizard"; state.step = 0; state.editingId = id; state.character = row.data;
      render();
    } else if (view === "sheet") {
      const row = await api.getCharacter(id);
      state.view = "sheet"; state.editingId = id; state.character = row.data;
      render();
    } else if (view === "import") {
      state.view = "import";
      render();
      ImportPage.loadLibrary();
    }
  },
};

// ============ App actions (exposed on window for inline handlers) ============
const App = {
  goStep(n) { state.step = n; render(); },
  nextStep() { state.step = Math.min(STEP_NAMES.length - 1, state.step + 1); render(); },
  prevStep() { state.step = Math.max(0, state.step - 1); render(); },

  setName(v) { state.character.name = v; },
  setLevel(v) { state.character.level = Math.max(1, Math.min(20, parseInt(v) || 1)); render(); },

  selectRace(id) { state.character.raceId = id; state.character.halfElfChoices = []; render(); },
  toggleHalfElfChoice(ab) {
    const arr = state.character.halfElfChoices;
    const i = arr.indexOf(ab);
    if (i >= 0) arr.splice(i, 1);
    else if (arr.length < 2) arr.push(ab);
    render();
  },

  selectClass(id) { state.character.classId = id; state.character.subclassId = null; state.character.classSkillChoices = []; render(); },
  selectSubclass(id) { state.character.subclassId = id; render(); },

  selectBackground(id) { state.character.backgroundId = id; render(); },

  setAbilityMethod(m) { state.character.abilityMethod = m; state.character.baseScores = { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 }; render(); },
  setStandardArraySlot(ability, value) {
    state.character.baseScores[ability] = parseInt(value) || 8; render();
  },
  setPointBuy(ability, delta) {
    const cur = state.character.baseScores[ability];
    const next = cur + delta;
    if (next < 8 || next > 15) return;
    const spent = ABILITIES.reduce((s, a) => s + POINT_BUY_COST[a === ability ? next : state.character.baseScores[a]], 0);
    if (spent > 27) return;
    state.character.baseScores[ability] = next; render();
  },
  setManualScore(ability, value) {
    state.character.baseScores[ability] = Math.max(1, Math.min(30, parseInt(value) || 10)); render();
  },

  toggleClassSkill(skill) {
    const arr = state.character.classSkillChoices;
    const i = arr.indexOf(skill);
    const max = classSkillCount(state.character);
    if (i >= 0) arr.splice(i, 1);
    else if (arr.length < max && !backgroundSkills(state.character).includes(skill)) arr.push(skill);
    render();
  },
  setFeat(id) { state.character.feat = id || null; render(); },

  setEquipmentChoice(v) { state.character.equipmentChoice = v; render(); },
  setArmor(v) { state.character.armorId = v || null; render(); },
  toggleShield() { state.character.shield = !state.character.shield; render(); },
  setExtraGear(v) { state.character.extraGear = v; },

  toggleCantrip(name) {
    const cls = getClass(state.character.classId);
    const max = cls?.spellcasting?.cantripsAt1 ?? (FULL_CASTERS.has(state.character.classId) ? 5 : 2);
    const arr = state.character.cantrips;
    const i = arr.indexOf(name);
    if (i >= 0) arr.splice(i, 1); else if (arr.length < max) arr.push(name);
    render();
  },
  toggleSpell(name) {
    const cls = getClass(state.character.classId);
    const max = cls?.spellcasting?.spellsAt1 ?? 999;
    const arr = state.character.spellsKnown;
    const i = arr.indexOf(name);
    if (i >= 0) arr.splice(i, 1); else if (arr.length < max) arr.push(name);
    render();
  },
  setNotes(v) { state.character.notes = v; },

  // Spell slot tracking (used on the character sheet view)
  toggleSlot(levelKey, slotIndex) {
    const c = state.character;
    if (!c.spellSlots) c.spellSlots = {};
    const used = c.spellSlots[levelKey] || 0;
    const slotInfo = getSpellSlots(c.classId, c.level);
    if (!slotInfo) return;
    const slotDef = slotInfo.type === "pact"
      ? slotInfo.slots[0]
      : slotInfo.slots.find(s => s.level === parseInt(levelKey));
    if (!slotDef) return;
    if (slotIndex < used) c.spellSlots[levelKey] = slotIndex;
    else c.spellSlots[levelKey] = Math.min(slotIndex + 1, slotDef.max);
    api.saveCharacter(c, state.editingId);
    // Update pip classes in-place without re-render
    const card = document.getElementById('spell-slot-tracker');
    if (!card) return;
    card.querySelectorAll('.slot-row').forEach(row => {
      const pips = row.querySelectorAll('.slot-pip');
      if (!pips.length) return;
      const onclick = pips[0].getAttribute('onclick') || '';
      const keyMatch = onclick.match(/'([^']+)'/);
      if (!keyMatch) return;
      const k = keyMatch[1];
      const u = c.spellSlots[k] || 0;
      pips.forEach((p, i) => p.classList.toggle('used', i < u));
      const countEl = row.querySelector('.slot-count');
      if (countEl) countEl.textContent = `${pips.length - u} / ${pips.length}`;
    });
  },

  resetSlots() {
    const c = state.character;
    c.spellSlots = {};
    api.saveCharacter(c, state.editingId);
    const card = document.getElementById('spell-slot-tracker');
    if (!card) return;
    card.querySelectorAll('.slot-pip').forEach(p => p.classList.remove('used'));
    card.querySelectorAll('.slot-row').forEach(row => {
      const total = row.querySelectorAll('.slot-pip').length;
      const countEl = row.querySelector('.slot-count');
      if (countEl) countEl.textContent = `${total} / ${total}`;
    });
  },

  // ── HP tracking ──────────────────────────────────────────
  setCurrentHp(val) {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const v = Math.max(0, Math.min(max, parseInt(val) || 0));
    c.currentHp = v;
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    _updateVitals(c);
  },

  adjustHp(delta) {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const cur = c.currentHp ?? max;
    App.setCurrentHp(cur + delta);
  },

  // Temp HP — per 5e rules: doesn't stack (take higher), cleared on long rest only
  setTempHp(val) {
    const c = state.character;
    c.tempHp = Math.max(0, parseInt(val) || 0);
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    _updateVitals(c);
  },

  adjustTempHp(delta) {
    const c = state.character;
    App.setTempHp((c.tempHp || 0) + delta);
  },

  // Temp AC — shield of faith, cover, magic items, etc.
  setTempAc(val) {
    const c = state.character;
    c.tempAc = Math.max(0, parseInt(val) || 0);
    api.saveCharacter(c, state.editingId);
    _updateVitals(c);
  },

  adjustTempAc(delta) {
    const c = state.character;
    App.setTempAc((c.tempAc || 0) + delta);
  },

  // ── Hit Dice ─────────────────────────────────────────────
  spendHitDie() {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const cur = c.currentHp ?? max;
    if (cur >= max) return;                     // already at full
    const availHD = c.level - (c.hitDiceUsed || 0);
    if (availHD <= 0) { alert("No hit dice remaining."); return; }
    const cls = getClass(c.classId);
    const die = cls ? cls.hitDie : 8;
    const scores = finalAbilityScores(c);
    const conMod = abilityMod(scores.con);
    const roll = Math.floor(Math.random() * die) + 1;
    const heal = Math.max(1, roll + conMod);
    c.currentHp = Math.min(max, cur + heal);
    c.hitDiceUsed = (c.hitDiceUsed || 0) + 1;
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    _updateVitals(c);
    // Show the roll result — find hd-msg in the newly rendered card
    const msg = document.getElementById('hd-msg');
    if (msg) {
      msg.textContent = `Rolled ${roll} + ${conMod} CON = +${heal} HP`;
      msg.style.opacity = '1';
      setTimeout(() => { msg.style.opacity = '0'; }, 3000);
    }
  },

  // ── Rests ─────────────────────────────────────────────────
  shortRest() {
    const c = state.character;
    if (!c.resources) c.resources = {};
    // Recover short-rest resources
    const shortRestRes = [
      ...getClassResources(c).filter(r => r.recharge === 'short' || r.recharge === 'both'),
      ...getRaceResources(c).filter(r => r.recharge === 'short' || r.recharge === 'both'),
    ];
    if (c.classId === "warlock") c.spellSlots = {};
    shortRestRes.forEach(r => { c.resources[r.id] = 0; });
    api.saveCharacter(c, state.editingId);
    const recovered = shortRestRes.map(r => r.name).join(", ");
    alert(`Short rest taken.\n\nRecovered: ${recovered || "none"}${c.classId === "warlock" ? ", Pact Magic slots" : ""}\n\nSpend hit dice to recover HP using the Roll Hit Die button.`);
    // Re-render resource card if visible
    const resEl = document.getElementById('class-resources');
    if (resEl) resEl.outerHTML = renderClassResources(c);
  },

  longRest() {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const hdRecovered = Math.max(1, Math.floor(c.level / 2));
    const slotInfo = getSpellSlots(c.classId, c.level);
    const hdLeft = c.level - (c.hitDiceUsed || 0);

    // Build a descriptive prompt
    const lines = [
      `☀ Long Rest — the following will be restored:`,
      `• HP fully restored to maximum (${max} HP)`,
      `• Hit Dice: recover ${hdRecovered} (you currently have ${hdLeft}/${c.level})`,
      `• Temp HP cleared`,
    ];
    if (slotInfo) {
      if (slotInfo.type === "pact") {
        lines.push(`• Pact Magic slots fully restored`);
      } else {
        const slotSummary = slotInfo.slots.map(s => `${s.max}× lvl ${s.level}`).join(", ");
        lines.push(`• All spell slots restored (${slotSummary})`);
      }
    }
    if (!confirm(lines.join("\n"))) return;

    // Apply the rest
    c.currentHp = max;
    c.hitDiceUsed = Math.max(0, (c.hitDiceUsed || 0) - hdRecovered);
    c.spellSlots = {};
    c.tempHp = 0;
    // Restore all long-rest resources
    if (!c.resources) c.resources = {};
    getClassResources(c).forEach(r => { if (r.recharge === 'long' || r.recharge === 'both') c.resources[r.id] = 0; });
    getRaceResources(c).forEach(r => { if (r.recharge === 'long' || r.recharge === 'both') c.resources[r.id] = 0; });
    api.saveCharacter(c, state.editingId);

    // Update HP card
    const hpEl = document.getElementById('hp-tracker');
    if (hpEl) hpEl.outerHTML = renderHpTracker(c);

    // Update resource card
    const resEl = document.getElementById('class-resources');
    if (resEl) resEl.outerHTML = renderClassResources(c);

    // Update spell slot pips in the unified spellcasting card
    const spellCard = document.getElementById('spell-slot-tracker');
    if (spellCard) {
      spellCard.querySelectorAll('.slot-pip').forEach(p => p.classList.remove('used'));
      spellCard.querySelectorAll('.slot-row').forEach(row => {
        const total = row.querySelectorAll('.slot-pip').length;
        const countEl = row.querySelector('.slot-count');
        if (countEl) countEl.textContent = `${total} / ${total}`;
      });
    }

    // Update vitals bar
    _updateVitals(c);
  },

  spendResource(id, max) {
    const c = state.character;
    if (!c.resources) c.resources = {};
    const used = c.resources[id] || 0;
    if (used >= max) return;
    c.resources[id] = used + 1;
    api.saveCharacter(c, state.editingId);
    // Update pip in place
    const pip = document.querySelector(`.res-pip[data-res="${id}"][data-idx="${used}"]`);
    if (pip) pip.classList.add('used');
    const countEl = document.getElementById(`res-count-${id}`);
    if (countEl) countEl.textContent = `${max - (c.resources[id]||0)} / ${max}`;
  },

  restoreResource(id, max) {
    const c = state.character;
    if (!c.resources) c.resources = {};
    const used = c.resources[id] || 0;
    if (used <= 0) return;
    c.resources[id] = used - 1;
    api.saveCharacter(c, state.editingId);
    const pip = document.querySelector(`.res-pip[data-res="${id}"][data-idx="${used - 1}"]`);
    if (pip) pip.classList.remove('used');
    const countEl = document.getElementById(`res-count-${id}`);
    if (countEl) countEl.textContent = `${max - (c.resources[id]||0)} / ${max}`;
  },

  setResourceVal(id, val, max) {
    const c = state.character;
    if (!c.resources) c.resources = {};
    c.resources[id] = Math.max(0, Math.min(max, parseInt(val) || 0));
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById(`res-card-${id.replace(/[^a-z0-9]/g,'')}`);
    if (el) {
      // re-render just that resource's pips
      el.querySelectorAll('.res-pip').forEach((p, i) => {
        p.classList.toggle('used', i < (c.resources[id] || 0));
      });
      const countEl = document.getElementById(`res-count-${id}`);
      if (countEl) countEl.textContent = `${max - (c.resources[id]||0)} / ${max}`;
    }
  },

  async save() {
    const c = state.character;
    if (!c.name.trim()) { alert("Give your character a name first."); return; }
    await api.saveCharacter(c, state.editingId);
    Router.go("list");
  },
  async deleteChar(id, ev) {
    ev.stopPropagation();
    if (!confirm("Delete this character permanently?")) return;
    await api.deleteCharacter(id);
    Router.go("list");
  },
};
window.App = App; window.Router = Router;

// ── Vitals bar live-update helper ──────────────────────────
function _updateVitals(c) {
  const hp = computeHP(c);
  const ac = computeAC(c);
  const tempHp = c.tempHp || 0;
  const tempAc = c.tempAc || 0;

  const hpEl = document.getElementById('vital-hp');
  if (hpEl) {
    hpEl.innerHTML = `
      ${c.currentHp ?? hp ?? "—"}<span style="font-size:13px;color:#888">/${hp ?? "—"}</span>
      ${tempHp > 0 ? `<span style="font-size:12px;color:#64b5f6;display:block;line-height:1.2">+${tempHp} tmp HP</span>` : ""}`;
  }
  const acEl = document.getElementById('vital-ac');
  if (acEl) {
    const totalAc = ac + tempAc;
    acEl.innerHTML = `${totalAc}${tempAc > 0 ? `<span style="font-size:12px;color:#81d4fa;display:block;line-height:1.2">+${tempAc} bonus</span>` : ""}`;
  }
}

// ============ Rendering ============
function render() {
  const app = document.getElementById("app");
  if (state.view === "list") app.innerHTML = renderList();
  else if (state.view === "sheet") app.innerHTML = renderSheet();
  else if (state.view === "import") app.innerHTML = renderImportPage();
  else app.innerHTML = renderWizard();
}

function renderList() {
  if (!state.charList.length) {
    return `
      <h1>Your Characters</h1>
      <p class="subtitle">Nothing saved yet.</p>
      <div class="empty-state">
        <p>No characters yet. Start your legend.</p>
        <button class="btn btn--primary" onclick="Router.go('create')">+ New Character</button>
      </div>`;
  }
  return `
    <h1>Your Characters</h1>
    <p class="subtitle">${state.charList.length} saved</p>
    <div class="char-grid">
      ${state.charList.map(c => `
        <div class="char-card" onclick="Router.go('sheet', ${c.id})">
          <span class="level-badge">${c.level}</span>
          <h3>${escapeHtml(c.name)}</h3>
          <div class="meta">${labelOr(c.race_id, "races")} ${labelOr(c.class_id, "classes")}</div>
          <div class="meta">${labelOr(c.background_id, "backgrounds")}</div>
          <div class="card-actions">
            <button class="del-btn" onclick="event.stopPropagation(); Router.go('edit', ${c.id})" style="color:var(--gold);">Edit</button>
            <button class="del-btn" onclick="App.deleteChar(${c.id}, event)">Delete</button>
          </div>
        </div>
      `).join("")}
    </div>`;
}

function labelOr(id, coll) {
  if (!id) return "";
  const item = DATA[coll].find(x => x.id === id);
  return item ? item.name : id;
}
function escapeHtml(s) { return (s || "").replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m])); }

function renderWizard() {
  const steps = STEP_NAMES.map((name, i) => `
    <div class="step ${i === state.step ? "active" : i < state.step ? "done" : ""}" onclick="App.goStep(${i})">
      <span class="step-num">${i + 1}</span>${name}
    </div>`).join("");

  const stepRenderers = [
    renderBasics, renderRace, renderClass, renderBackground,
    renderAbilityScores, renderSkillsFeat, renderEquipment, renderSpells, renderReview,
  ];
  const content = stepRenderers[state.step]();

  return `
    <div class="wizard">
      <div class="steps">${steps}</div>
      <div class="panel">
        ${content}
        <div class="wizard-nav">
          <button class="btn" onclick="App.prevStep()" ${state.step === 0 ? "disabled" : ""}>&larr; Back</button>
          ${state.step === STEP_NAMES.length - 1
            ? `<button class="btn btn--primary" onclick="App.save()">Save Character</button>`
            : `<button class="btn btn--primary" onclick="App.nextStep()">Next &rarr;</button>`}
        </div>
      </div>
    </div>`;
}

function renderBasics() {
  const c = state.character;
  return `
    <h2>Basics</h2>
    <div class="field">
      <label>Character Name</label>
      <input type="text" value="${escapeHtml(c.name)}" oninput="App.setName(this.value)" placeholder="e.g. Sylvaine Thorn" />
    </div>
    <div class="field">
      <label>Level</label>
      <input type="text" style="max-width:100px" value="${c.level}" oninput="App.setLevel(this.value)" />
    </div>
    <div class="field">
      <label>Ability Score Method (used in Step 5)</label>
      <select onchange="App.setAbilityMethod(this.value)">
        <option value="standard" ${c.abilityMethod === "standard" ? "selected" : ""}>Standard Array (15,14,13,12,10,8)</option>
        <option value="pointbuy" ${c.abilityMethod === "pointbuy" ? "selected" : ""}>Point Buy (27 points)</option>
        <option value="manual" ${c.abilityMethod === "manual" ? "selected" : ""}>Manual / Rolled</option>
      </select>
    </div>`;
}

function renderRace() {
  const c = state.character;
  const race = getRace(c.raceId);
  return `
    <h2>Race</h2>
    <div class="option-grid">
      ${DATA.races.map(r => `
        <div class="option-card ${c.raceId === r.id ? "selected" : ""}" onclick="App.selectRace('${r.id}')">
          <div class="name">${r.name}</div>
          <div class="sub">Speed ${r.speed} ft · ${Object.entries(r.abilityBonuses || {}).filter(([k]) => k !== "choose_two").map(([k, v]) => `${k.toUpperCase()} +${v}`).join(", ")}</div>
        </div>`).join("")}
    </div>
    ${race ? `
      <h3 style="margin-top:20px;">${race.name} Traits</h3>
      <ul class="trait-list">${race.traits.map(t => `<li>${t}</li>`).join("")}</ul>
      ${race.abilityBonuses && race.abilityBonuses.choose_two ? `
        <div class="field" style="margin-top:14px;">
          <label>Choose 2 abilities to raise by 1 (Half-Elf versatility)</label>
          <div class="option-grid">
            ${ABILITIES.filter(a => a !== "cha").map(a => `
              <div class="option-card ${c.halfElfChoices.includes(a) ? "selected" : ""}" onclick="App.toggleHalfElfChoice('${a}')">
                <div class="name">${ABILITY_NAMES[a]}</div>
              </div>`).join("")}
          </div>
        </div>` : ""}
    ` : ""}`;
}

function renderClass() {
  const c = state.character;
  const cls = getClass(c.classId);
  return `
    <h2>Class</h2>
    <div class="option-grid">
      ${DATA.classes.map(k => `
        <div class="option-card ${c.classId === k.id ? "selected" : ""}" onclick="App.selectClass('${k.id}')">
          <div class="name">${k.name}</div>
          <div class="sub">Hit Die d${k.hitDie} · Saves: ${k.savingThrows.map(s => s.toUpperCase()).join("/")}</div>
        </div>`).join("")}
    </div>
    ${cls ? `
      <h3 style="margin-top:20px;">Starting Equipment</h3>
      <ul class="trait-list">${cls.startingEquipment.map(e => `<li>${e}</li>`).join("")}</ul>
      ${cls.subclasses.length ? `
        <div class="field" style="margin-top:14px;">
          <label>Subclass ${c.level < cls.subclassLevel ? `(chosen at level ${cls.subclassLevel} — optional to pre-select)` : ""}</label>
          <select onchange="App.selectSubclass(this.value)">
            <option value="">— none selected —</option>
            ${cls.subclasses.map(s => `<option value="${s.id}" ${c.subclassId === s.id ? "selected" : ""}>${s.name}</option>`).join("")}
          </select>
        </div>` : ""}
    ` : ""}`;
}

function renderBackground() {
  const c = state.character;
  const bg = getBackground(c.backgroundId);
  return `
    <h2>Background</h2>
    <div class="option-grid">
      ${DATA.backgrounds.map(b => `
        <div class="option-card ${c.backgroundId === b.id ? "selected" : ""}" onclick="App.selectBackground('${b.id}')">
          <div class="name">${b.name}</div>
          <div class="sub">${b.skillProficiencies.join(", ")}</div>
        </div>`).join("")}
    </div>
    ${bg ? `
      <h3 style="margin-top:20px;">${bg.name} Feature</h3>
      <p style="font-size:14px;color:var(--text-muted)">${bg.feature}</p>
      <h3>Equipment</h3>
      <ul class="trait-list">${bg.equipment.map(e => `<li>${e}</li>`).join("")}</ul>
    ` : ""}`;
}

function renderAbilityScores() {
  const c = state.character;
  const scores = finalAbilityScores(c);
  let body = "";
  if (c.abilityMethod === "standard") {
    const used = ABILITIES.map(a => c.baseScores[a]);
    body = `
      <p class="standard-array-pool">Assign each value once: ${STANDARD_ARRAY.join(", ")}</p>
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <select onchange="App.setStandardArraySlot('${a}', this.value)">
              ${STANDARD_ARRAY.map(v => `<option value="${v}" ${c.baseScores[a] === v ? "selected" : ""}>${v}</option>`).join("")}
            </select>
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  } else if (c.abilityMethod === "pointbuy") {
    const spent = ABILITIES.reduce((s, a) => s + POINT_BUY_COST[c.baseScores[a]], 0);
    body = `
      <p class="standard-array-pool">Points spent: ${spent} / 27</p>
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <div>
              <button class="btn" style="padding:4px 10px" onclick="App.setPointBuy('${a}', -1)">−</button>
              <span style="font-family:var(--font-mono);font-size:20px;margin:0 8px;">${c.baseScores[a]}</span>
              <button class="btn" style="padding:4px 10px" onclick="App.setPointBuy('${a}', 1)">+</button>
            </div>
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  } else {
    body = `
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <input type="text" value="${c.baseScores[a]}" oninput="App.setManualScore('${a}', this.value)" />
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  }
  return `<h2>Ability Scores</h2><p class="subtitle">Base score, before racial bonuses are applied (shown as "final").</p>${body}`;
}

function renderSkillsFeat() {
  const c = state.character;
  const cls = getClass(c.classId);
  const bg = getBackground(c.backgroundId);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const bgSkills = bg ? bg.skillProficiencies : [];
  const max = cls ? (cls.skillChoices?.count || 2) : 0;
  const classSkillOptions = cls?.skillChoices?.options || [];
  // If the class has no options (e.g. PDF import didn't capture them) OR says "Any",
  // treat ALL skills as eligible so nothing is greyed out
  const openSelection = !classSkillOptions.length
    || classSkillOptions.some(o => /any/i.test(o));

  return `
    <h2>Skill Proficiencies</h2>
    <p class="subtitle">
      ${bg ? `${bg.name} grants: ${bgSkills.join(", ")}. ` : ""}
      ${cls
        ? openSelection
          ? `Choose any ${max} skills for ${cls.name}.`
          : `Choose ${max} class skills from: ${classSkillOptions.join(", ")}.`
        : "Pick a class first."}
      ${c.classSkillChoices.length}/${max} chosen.
    </p>
    <div>
      ${SKILLS.map(([name, ab]) => {
        const fromBg = bgSkills.includes(name);
        const chosen = c.classSkillChoices.includes(name);
        const atMax = c.classSkillChoices.length >= max && !chosen;
        // Eligible: from bg (always on), or class allows it, or open selection
        const eligible = !fromBg && (openSelection || classSkillOptions.includes(name));
        const proficient = fromBg || chosen;
        const mod = abilityMod(scores[ab]) + (proficient ? pb : 0);
        return `
          <div class="skill-row">
            <input type="checkbox"
              ${fromBg ? "checked disabled" : ""}
              ${!fromBg && eligible && !atMax ? `onclick="App.toggleClassSkill('${name}')"` : ""}
              ${chosen ? "checked" : ""}
              ${!fromBg && (!eligible || atMax) && !chosen ? "disabled" : ""}
            />
            <span style="${!fromBg && !eligible ? "color:var(--text-muted)" : ""}">
              ${name} <span style="color:var(--text-muted);font-size:12px;">(${ab.toUpperCase()})</span>
            </span>
            <span class="skill-mod">${fmtMod(mod)}</span>
          </div>`;
      }).join("")}
    </div>
    <div class="field" style="margin-top:20px;">
      <label>Optional Feat (house rule — apply per your table)</label>
      <select onchange="App.setFeat(this.value)">
        <option value="">— none —</option>
        ${DATA.feats.map(f => `<option value="${f.id}" ${c.feat === f.id ? "selected" : ""}>${f.name}</option>`).join("")}
      </select>
      ${c.feat ? `<p style="font-size:13px;color:var(--text-muted);margin-top:8px;">${DATA.feats.find(f => f.id === c.feat)?.summary || ""}</p>` : ""}
    </div>`;
}

function renderEquipment() {
  const c = state.character;
  const cls = getClass(c.classId);
  const bg = getBackground(c.backgroundId);
  return `
    <h2>Equipment</h2>
    ${cls ? `<h3>${cls.name} Starting Gear</h3><ul class="trait-list">${cls.startingEquipment.map(e => `<li>${e}</li>`).join("")}</ul>` : ""}
    ${bg ? `<h3>${bg.name} Gear</h3><ul class="trait-list">${bg.equipment.map(e => `<li>${e}</li>`).join("")}</ul>` : ""}
    <div class="field">
      <label>Armor Worn (affects AC)</label>
      <select onchange="App.setArmor(this.value)">
        <option value="">— none / unarmored —</option>
        ${DATA.equipment.armor.filter(a => a.category !== "Shield").map(a => `<option value="${a.name}" ${c.armorId === a.name ? "selected" : ""}>${a.name} (AC ${a.baseAC}${a.addDex ? " + Dex" : ""}${a.dexCap != null && a.dexCap !== null ? ` max ${a.dexCap}` : ""})</option>`).join("")}
      </select>
    </div>
    <div class="field">
      <label><input type="checkbox" ${c.shield ? "checked" : ""} onclick="App.toggleShield()" style="width:auto;margin-right:8px;" />Carrying a Shield (+2 AC)</label>
    </div>
    <div class="field">
      <label>Additional Gear / Weapons (free text)</label>
      <input type="text" value="${escapeHtml(c.extraGear)}" oninput="App.setExtraGear(this.value)" placeholder="e.g. Longsword, 2x potion of healing, 50gp" />
    </div>`;
}

function renderSpells() {
  const c = state.character;
  const cls = getClass(c.classId);
  const CASTER_ABILITY_WIZ = {
    bard: "cha", cleric: "wis", druid: "wis", paladin: "cha",
    ranger: "wis", sorcerer: "cha", warlock: "cha", wizard: "int",
    artificer: "int",
  };
  const slotInfo = getSpellSlots(c.classId, c.level);
  const scAbility = cls?.spellcasting?.ability || CASTER_ABILITY_WIZ[c.classId] || null;
  const isCaster = !!(slotInfo || scAbility);

  if (!cls || !isCaster) {
    return `<h2>Spells</h2><p class="subtitle">${cls ? cls.name : "This class"} doesn't use the standard spellcasting list — skip ahead.</p>`;
  }

  const sc = cls.spellcasting || { ability: scAbility, cantripsAt1: FULL_CASTERS.has(c.classId) ? 3 : 0, spellsAt1: null };
  // Max spell level from actual slot table, capped at 9
  const maxSpellLevel = slotInfo
    ? (slotInfo.type === "pact" ? slotInfo.slots[0].level : Math.max(...slotInfo.slots.map(s => s.level)))
    : Math.min(9, Math.ceil(c.level / 2));

  const allSpells = DATA.spells.filter(s =>
    s.classes.includes(cls.id) || s.classes.length === 0
  );
  const cantrips = allSpells.filter(s => s.level === 0).sort((a, b) => a.name.localeCompare(b.name));
  const leveled = allSpells.filter(s => s.level >= 1 && s.level <= maxSpellLevel)
    .sort((a, b) => a.level - b.level || a.name.localeCompare(b.name));

  const ordinals = ["","1st","2nd","3rd","4th","5th","6th","7th","8th","9th"];

  // Group leveled spells by their spell level
  const byLevel = {};
  for (const s of leveled) {
    if (!byLevel[s.level]) byLevel[s.level] = [];
    byLevel[s.level].push(s);
  }

  const leveledHtml = Object.keys(byLevel).sort((a,b) => a-b).map(lvl => {
    const spellsAtLevel = byLevel[lvl];
    // Show how many slots exist at this level for reference
    let slotNote = "";
    if (slotInfo && slotInfo.type !== "pact") {
      const slot = slotInfo.slots.find(s => s.level === parseInt(lvl));
      if (slot) slotNote = `<span style="font-size:12px;color:var(--text-muted);font-family:var(--font-mono);margin-left:8px;">${slot.max} slots</span>`;
    }
    return `
      <div class="spell-level-header">
        <span>${ordinals[lvl]}-Level Spells</span>${slotNote}
      </div>
      <div class="spell-list" style="margin-bottom:8px;">
        ${spellsAtLevel.map(s => `
          <div class="spell-row ${c.spellsKnown.includes(s.name) ? "selected" : ""}" onclick="App.toggleSpell('${s.name.replace(/'/g, "\\'")}')">
            <span class="sname">${s.name}</span><span class="slevel">${s.school}</span>
            <div class="ssum">${s.summary}</div>
          </div>`).join("")}
      </div>`;
  }).join("") || "<p class='subtitle'>No matching spells in the library yet.</p>";

  return `
    <h2>Spells</h2>
    <p class="subtitle">
      ${cls.name} casts using <strong>${ABILITY_NAMES[scAbility]}</strong>.
      Showing spells up to level ${maxSpellLevel} (your highest available slot).
      ${sc.cantripsAt1 ? `Cantrip slots: ${sc.cantripsAt1}.` : ""}
      ${sc.spellsAt1 != null ? `Spells known limit: ${sc.spellsAt1}.` : "Prepared caster — select what you'd prepare."}
    </p>

    <h3>Cantrips (${c.cantrips.length}${sc.cantripsAt1 ? `/${sc.cantripsAt1}` : ""})</h3>
    <div class="spell-list" style="margin-bottom:20px;">
      ${cantrips.map(s => `
        <div class="spell-row ${c.cantrips.includes(s.name) ? "selected" : ""}" onclick="App.toggleCantrip('${s.name.replace(/'/g, "\\'")}')">
          <span class="sname">${s.name}</span><span class="slevel">${s.school}</span>
          <div class="ssum">${s.summary}</div>
        </div>`).join("") || "<p class='subtitle'>No cantrips available for this class in the library.</p>"}
    </div>

    <h3>Spells Known / Prepared (${c.spellsKnown.length}${sc.spellsAt1 != null ? `/${sc.spellsAt1}` : ""})</h3>
    ${leveledHtml}`;
}

function renderReview() {
  const c = state.character;
  const race = getRace(c.raceId), cls = getClass(c.classId), bg = getBackground(c.backgroundId);
  const scores = finalAbilityScores(c);
  const hp = computeHP(c), ac = computeAC(c), pb = proficiencyBonus(c.level);
  const subclass = cls && cls.subclasses.find(s => s.id === c.subclassId);
  return `
    <h2>Review &amp; Save</h2>
    <div class="summary-grid">
      <div class="summary-block">
        <h3>Identity</h3>
        <div class="stat-line"><span>Name</span><span>${escapeHtml(c.name) || "—"}</span></div>
        <div class="stat-line"><span>Race</span><span>${race ? race.name : "—"}</span></div>
        <div class="stat-line"><span>Class</span><span>${cls ? cls.name : "—"}${subclass ? ` (${subclass.name})` : ""}</span></div>
        <div class="stat-line"><span>Background</span><span>${bg ? bg.name : "—"}</span></div>
        <div class="stat-line"><span>Level</span><span>${c.level}</span></div>
        <div class="stat-line"><span>Proficiency Bonus</span><span>${fmtMod(pb)}</span></div>
      </div>
      <div class="summary-block">
        <h3>Combat</h3>
        <div class="stat-line"><span>Hit Points</span><span>${hp ?? "—"}</span></div>
        <div class="stat-line"><span>Armor Class</span><span>${ac}</span></div>
        <div class="stat-line"><span>Speed</span><span>${race ? race.speed : "—"} ft</span></div>
        <div class="stat-line"><span>Hit Die</span><span>${cls ? `d${cls.hitDie}` : "—"}</span></div>
      </div>
      <div class="summary-block">
        <h3>Ability Scores</h3>
        ${ABILITIES.map(a => `<div class="stat-line"><span>${ABILITY_NAMES[a]}</span><span>${scores[a]} (${fmtMod(abilityMod(scores[a]))})</span></div>`).join("")}
      </div>
      <div class="summary-block">
        <h3>Proficient Skills</h3>
        ${[...allProficientSkills(c)].map(s => `<span class="tag">${s}</span>`).join("") || "<span class='subtitle'>None chosen</span>"}
        ${c.feat ? `<h3 style="margin-top:14px;">Feat</h3><span class="tag">${DATA.feats.find(f => f.id === c.feat)?.name}</span>` : ""}
      </div>
    </div>
    <div class="field" style="margin-top:20px;">
      <label>Notes</label>
      <input type="text" value="${escapeHtml(c.notes)}" oninput="App.setNotes(this.value)" placeholder="Personality, backstory, allies, plot hooks..." />
    </div>`;
}

// ============ Class & Race Resources ============

function getClassResources(c) {
  const lvl = c.level;
  const scores = finalAbilityScores(c);
  const wisMod = abilityMod(scores.wis);
  const chaMod = abilityMod(scores.cha);
  const strMod = abilityMod(scores.str);
  const conMod = abilityMod(scores.con);
  const intMod = abilityMod(scores.int);

  const table = {
    barbarian: [
      { id:'rage', name:'Rage', max: [2,2,3,3,3,4,4,4,4,4,4,5,5,5,5,5,6,6,6,null][lvl-1] ?? 6,
        recharge:'long', icon:'🔥',
        desc:'On your turn, enter rage as a bonus action. Lasts 1 minute. +2 damage (scales), resistance to B/P/S, advantage on STR checks/saves.' },
    ],
    bard: [
      { id:'bardic', name:'Bardic Inspiration', max: Math.max(1, chaMod),
        recharge: lvl >= 5 ? 'short' : 'long', icon:'🎵',
        desc:`Grant a d${[6,6,6,6,8,8,8,10,10,10,12,12,12,12,12,12,12,12,12,12][lvl-1] ?? 12} Bardic Inspiration to an ally who can add it to one attack, check, or save within 10 min.` },
    ],
    cleric: [
      { id:'channel', name:'Channel Divinity', max: lvl >= 18 ? 3 : lvl >= 6 ? 2 : 1,
        recharge:'short', icon:'✨', desc:'Use a Channel Divinity option granted by your domain or Turn Undead.' },
    ],
    druid: [
      { id:'wildshape', name:'Wild Shape', max: 2, recharge:'short', icon:'🐺',
        desc:`Transform into beasts CR ≤ ${Math.floor(lvl/3)} for up to ${Math.floor(lvl/2)} hours. Uses recover on short or long rest.` },
    ],
    fighter: [
      { id:'actionsurge', name:'Action Surge', max: lvl >= 17 ? 2 : 1,
        recharge:'short', icon:'⚡', desc:'On your turn, take one additional action. Recover on short or long rest.' },
      { id:'secondwind', name:'Second Wind', max: 1, recharge:'short', icon:'💨',
        desc:`Bonus action: regain 1d10 + ${lvl} HP. Recover on short or long rest.` },
      ...(c.subclassId === 'battle-master' ? [
        { id:'superiority', name:'Superiority Dice', max: lvl >= 15 ? 6 : lvl >= 7 ? 5 : lvl >= 3 ? 4 : 0,
          recharge:'short', icon:'🎲', desc:`d${lvl >= 18 ? 12 : lvl >= 10 ? 10 : 8} dice for Battle Master maneuvers. Recover on short or long rest.` }
      ] : []),
    ],
    monk: () => {
      const ki = lvl;
      return [
        { id:'ki', name:'Ki Points', max: ki, recharge:'short', icon:'🌀',
          desc:`Spend to power monk abilities: Flurry of Blows (1), Patient Defense (1), Step of the Wind (1), Stunning Strike (1), etc. Recover on short or long rest.` },
        { id:'deflect', name:'Deflect Missiles', max: 1, recharge:'short', icon:'🛡',
          desc:'Reaction: reduce ranged weapon damage by 1d10 + DEX + monk level. If reduced to 0, catch and throw it (costs 1 Ki).' },
        ...(lvl >= 4 ? [{ id:'slowfall', name:'Slow Fall', max: 1, recharge:'short', icon:'🍃',
          desc:'Reaction: reduce falling damage by 5 × monk level.' }] : []),
        ...(lvl >= 5 ? [{ id:'stunning', name:'Stunning Strike', max: null, recharge: null, icon:'⭐',
          desc:`After hitting with a melee attack, spend 1 Ki (DC ${8+proficiencyBonus(lvl)+wisMod} CON save or stunned until end of your next turn).` }] : []),
        ...(lvl >= 7 ? [{ id:'evasion', name:'Evasion', max: null, recharge: null, icon:'💨',
          desc:'When a DEX save halves damage, you take none on success and half on fail.' }] : []),
        ...(lvl >= 9 ? [{ id:'unarmored4', name:'Unarmored Movement', max: null, recharge: null, icon:'🏃',
          desc:`Speed +${[0,0,10,10,10,15,15,15,15,20,20,20,20,25,25,25,25,30,30,30][lvl-1] || 30}ft; at 9th can run on walls/water at end of turn.` }] : []),
      ];
    },
    paladin: [
      { id:'layonhands', name:'Lay on Hands', max: lvl * 5, recharge:'long', icon:'🙏',
        desc:`Pool of ${lvl * 5} HP. Use action to restore HP from pool, or spend 5 HP to cure one disease or poison.` },
      { id:'channel_pal', name:'Channel Divinity', max: 1, recharge:'short', icon:'✨',
        desc:'Use a Channel Divinity option from your Sacred Oath (e.g. Sacred Weapon, Vow of Enmity).' },
      ...(lvl >= 2 ? [{ id:'divsmite', name:'Divine Smite', max: null, recharge: null, icon:'⚔',
        desc:'When you hit with a melee weapon, expend a spell slot to deal 2d8 radiant (+1d8 per slot level above 1st, +1d8 vs undead/fiends, max 5d8).' }] : []),
    ],
    ranger: [
      ...(lvl >= 1 ? [{ id:'favored', name:"Favored Enemy", max: null, recharge: null, icon:'🎯',
        desc:`Advantage on Survival checks to track, and on INT checks to recall info about: your chosen enemy types.` }] : []),
    ],
    rogue: [
      { id:'cunning', name:'Cunning Action', max: null, recharge: null, icon:'🗡',
        desc:'Bonus action each turn: Dash, Disengage, or Hide.' },
      ...(lvl >= 5 ? [{ id:'uncanny', name:'Uncanny Dodge', max: null, recharge: null, icon:'👁',
        desc:'Reaction when an attacker you can see hits you: halve the damage.' }] : []),
      ...(lvl >= 7 ? [{ id:'evasion_r', name:'Evasion', max: null, recharge: null, icon:'💨',
        desc:'When a DEX save halves damage, you take none on success and half on fail.' }] : []),
      ...(lvl >= 11 ? [{ id:'reliable', name:'Reliable Talent', max: null, recharge: null, icon:'🎯',
        desc:'When you make an ability check with proficiency, treat d20 rolls of 9 or below as 10.' }] : []),
      ...(c.subclassId === 'thief' && lvl >= 17 ? [{ id:'thiefsreflexes', name:"Thief's Reflexes", max: null, recharge: null, icon:'⚡',
        desc:'Take two turns in first round of combat (second at initiative −10).' }] : []),
    ],
    sorcerer: [
      { id:'sorcery', name:'Sorcery Points', max: lvl, recharge:'long', icon:'✨',
        desc:'Spend to create spell slots (Flexible Casting), or use Metamagic options: Careful (1), Distant (1), Empowered (1), Extended (1), Heightened (3), Quickened (2), Subtle (1), Twinned (varies).' },
      ...(c.subclassId === 'wild-magic' ? [
        { id:'tideschaos', name:'Tides of Chaos', max: 1, recharge:'long', icon:'🌊',
          desc:'Gain advantage on one attack roll, ability check, or saving throw. Recover on long rest (or after a Wild Magic Surge).' },
      ] : []),
    ],
    warlock: [
      { id:'eldritch', name:'Eldritch Invocations', max: null, recharge: null, icon:'👁',
        desc:`You know ${Math.min(8,[0,2,2,3,4,4,5,6,6,7,7,7,8,8,8,8,8,8,8,8][lvl-1]||2)} invocations. Their benefits are always active unless they cost a spell slot.` },
    ],
    wizard: [
      { id:'arcane_rec', name:'Arcane Recovery', max: 1, recharge:'long', icon:'📖',
        desc:`Once per long rest (during a short rest): recover spell slots totaling up to ${Math.ceil(lvl/2)} levels combined (no slot above 5th).` },
    ],
    artificer: [
      { id:'infusions', name:'Infuse Item', max: Math.floor(lvl/2), recharge:'long', icon:'⚙',
        desc:`Infuse up to ${Math.floor(lvl/2)} items with magical properties from your list of known infusions. Infusions last until you die or re-infuse.` },
    ],
  };

  const entry = table[c.classId];
  if (!entry) return [];
  const resources = typeof entry === 'function' ? entry() : entry;
  // Filter out passive features (max: null) that are just informational
  return resources;
}

function getRaceResources(c) {
  const lvl = c.level;
  const resources = [];

  if (c.raceId === 'dragonborn') {
    const die = lvl >= 16 ? '5d6' : lvl >= 11 ? '4d6' : lvl >= 6 ? '3d6' : '2d6';
    resources.push({ id:'breath', name:'Breath Weapon', max: 1, recharge:'short', icon:'🐉',
      desc:`Exhale destructive energy in a 15 ft cone or 30 ft line. Each creature makes a DEX/CON save (DC ${8+proficiencyBonus(lvl)+Math.max(0,Math.floor((10-10)/2))}) or takes ${die} damage.` });
  }
  if (c.raceId === 'half-orc') {
    resources.push({ id:'relentless', name:'Relentless Endurance', max: 1, recharge:'long', icon:'💪',
      desc:'When reduced to 0 HP but not killed, drop to 1 HP instead. Once per long rest.' });
  }
  if (c.raceId === 'lightfoot-halfling' || c.raceId === 'stout-halfling') {
    resources.push({ id:'lucky_race', name:'Lucky', max: null, recharge: null, icon:'🍀',
      desc:'When you roll a 1 on a d20 for an attack, check, or save, reroll and use the new result.' });
  }
  if (c.raceId === 'high-elf') {
    resources.push({ id:'elf_cantrip', name:'High Elf Cantrip', max: null, recharge: null, icon:'✨',
      desc:'You know one wizard cantrip (Intelligence-based) from your High Elf heritage.' });
  }
  if (c.raceId === 'hill-dwarf' || c.raceId === 'mountain-dwarf') {
    resources.push({ id:'stonecunning', name:'Stonecunning', max: null, recharge: null, icon:'⛏',
      desc:'Whenever you make an INT (History) check about stonework, add double your proficiency bonus.' });
    resources.push({ id:'dwarven_resilience', name:'Dwarven Resilience', max: null, recharge: null, icon:'🛡',
      desc:'Advantage on saving throws vs poison, and resistance to poison damage.' });
  }
  if (c.raceId === 'tiefling') {
    resources.push({ id:'hellish_reb', name:'Hellish Rebuke', max: 1, recharge:'long', icon:'🔥',
      desc:'Once per long rest (at 3rd level+): cast hellish rebuke as a 2nd-level spell (reaction, target takes 3d10 fire on failed DEX save).' });
    resources.push({ id:'darkness_tief', name:'Darkness', max: 1, recharge:'long', icon:'🌑',
      desc:'Once per long rest (at 5th level+): cast darkness. No material components.' });
  }
  if (c.raceId === 'forest-gnome') {
    resources.push({ id:'speak_beasts', name:'Speak with Beasts', max: null, recharge: null, icon:'🐇',
      desc:'Communicate simple ideas to Small or smaller beasts. They can convey simple information back.' });
  }
  if (c.raceId === 'half-elf') {
    resources.push({ id:'skill_vers', name:'Skill Versatility', max: null, recharge: null, icon:'📚',
      desc:'Proficiency in two additional skills of your choice from your Half-Elf heritage.' });
  }

  return resources;
}

function renderClassResources(c) {
  const classRes = getClassResources(c);
  const raceRes  = getRaceResources(c);
  const all = [...classRes, ...raceRes];
  if (!all.length) return `<div id="class-resources"></div>`;

  if (!c.resources) c.resources = {};

  const renderResource = (r) => {
    if (r.max === null) {
      // Passive feature — just informational, no pips
      return `
        <div class="res-block res-block--passive">
          <div class="res-header">
            <span class="res-icon">${r.icon}</span>
            <span class="res-name">${r.name}</span>
            <span class="res-recharge dim" style="font-size:11px">${r.recharge ? `(${r.recharge} rest)` : 'passive'}</span>
          </div>
          <div class="res-desc">${r.desc}</div>
        </div>`;
    }

    const used = c.resources[r.id] || 0;
    const remaining = r.max - used;
    const safeId = r.id.replace(/[^a-z0-9_]/g, '');

    // Use pips for small pools (≤20), numeric input for larger ones
    const usePips = r.max <= 20;
    const pipsHtml = usePips ? `
      <div class="res-pips" id="res-card-${safeId}">
        ${Array.from({ length: r.max }, (_, i) => `
          <span class="res-pip ${i < used ? 'used' : ''}"
            data-res="${r.id}" data-idx="${i}"
            onclick="${i < used ? `App.restoreResource('${r.id}',${r.max})` : `App.spendResource('${r.id}',${r.max})`}"
            title="${i < used ? 'Click to restore' : 'Click to spend'}"></span>
        `).join('')}
      </div>` : `
      <div class="res-numeric" id="res-card-${safeId}">
        <button class="btn hp-adj" onclick="App.restoreResource('${r.id}',${r.max})">+</button>
        <input type="text" class="temp-hp-input active" value="${remaining}"
          onchange="App.setResourceVal('${r.id}', ${r.max} - parseInt(this.value||0), ${r.max})"
          title="Remaining ${r.name}" style="width:50px" />
        <button class="btn hp-adj" onclick="App.spendResource('${r.id}',${r.max})">−</button>
      </div>`;

    return `
      <div class="res-block">
        <div class="res-header">
          <span class="res-icon">${r.icon}</span>
          <span class="res-name">${r.name}</span>
          <span class="res-count-wrap">
            <span id="res-count-${r.id}" class="res-count">${remaining} / ${r.max}</span>
            <span class="res-recharge dim">${r.recharge === 'short' ? '☽ short' : r.recharge === 'both' ? '☽/☀ rest' : '☀ long'}</span>
          </span>
        </div>
        ${pipsHtml}
        <div class="res-desc">${r.desc}</div>
      </div>`;
  };

  const classHtml = classRes.length ? classRes.map(renderResource).join('') : '';
  const raceHtml  = raceRes.length  ? raceRes.map(renderResource).join('')  : '';

  return `
    <div id="class-resources" class="sheet-card">
      <h3 class="sheet-card-title">Class &amp; Race Resources</h3>
      ${classHtml}
      ${raceHtml ? `<div style="border-top:1px solid var(--border-dark);margin-top:8px;padding-top:8px">${raceHtml}</div>` : ''}
    </div>`;
}

// ============ HP Tracker ============

function renderHpTracker(c) {
  const max = computeHP(c) ?? 0;
  const cur = c.currentHp ?? max;
  const cls = getClass(c.classId);
  const die = cls ? cls.hitDie : 8;
  const hdTotal = c.level;
  const hdUsed = c.hitDiceUsed || 0;
  const hdLeft = hdTotal - hdUsed;
  const pct = max > 0 ? Math.round((cur / max) * 100) : 0;
  const barColor = pct > 50 ? '#4caf50' : pct > 25 ? '#e6a817' : 'var(--crimson)';
  const tempHp = c.tempHp || 0;

  return `
    <div id="hp-tracker" class="sheet-card">
      <h3 class="sheet-card-title">Hit Points &amp; Rests</h3>

      <div class="hp-main">
        <div class="hp-bar-wrap">
          <div class="hp-bar" style="width:${pct}%;background:${barColor}"></div>
        </div>
        <div class="hp-controls">
          <button class="btn hp-adj" onclick="App.adjustHp(-1)" title="Take 1 damage">−</button>
          <div class="hp-display">
            <input type="text" id="cur-hp-input" class="hp-input" value="${cur}"
              onchange="App.setCurrentHp(this.value)"
              onkeydown="if(event.key==='Enter')App.setCurrentHp(this.value)" />
            <span class="hp-sep">/</span>
            <span class="hp-max">${max}</span>
          </div>
          <button class="btn hp-adj" onclick="App.adjustHp(1)" title="Heal 1">+</button>
        </div>
        <div class="hp-label">Current / Max HP</div>
      </div>

      <div class="temp-hp-row">
        <div class="temp-hp-label">
          <span class="temp-hp-icon">🛡</span>
          <span>Temp HP</span>
        </div>
        <div class="temp-hp-controls">
          <button class="btn hp-adj" onclick="App.adjustTempHp(-1)" title="Remove 1 temp HP">−</button>
          <input type="text" class="temp-hp-input ${tempHp > 0 ? 'active' : ''}"
            value="${tempHp}"
            onchange="App.setTempHp(this.value)"
            onkeydown="if(event.key==='Enter')App.setTempHp(this.value)"
            title="Temporary hit points don't stack — take the higher value" />
          <button class="btn hp-adj" onclick="App.adjustTempHp(1)" title="Add 1 temp HP">+</button>
        </div>
      </div>

      <div class="hd-row">
        <div class="hd-info">
          <span class="hd-count">${hdLeft}<span style="font-size:13px;color:var(--text-muted)">/${hdTotal}</span></span>
          <span class="hd-label">d${die} Hit Dice</span>
        </div>
        <button class="btn btn--primary" onclick="App.spendHitDie()"
          ${cur >= max || hdLeft <= 0 ? "disabled" : ""}
          style="font-size:13px;padding:8px 14px">
          Roll Hit Die
        </button>
      </div>
      <div id="hd-msg" style="font-size:13px;color:var(--gold);min-height:18px;margin-top:4px;transition:opacity .5s;opacity:0"></div>

      <div class="rest-buttons">
        <button class="btn" onclick="App.shortRest()" style="flex:1">☽ Short Rest</button>
        <button class="btn btn--primary" onclick="App.longRest()" style="flex:1">☀ Long Rest</button>
      </div>
    </div>`;
}

// ============ Spell Slot Tracker ============

function renderSpellSlotTracker(c, slotInfo) {
  const slots = c.spellSlots || {};

  if (slotInfo.type === "pact") {
    const s = slotInfo.slots[0];
    const used = slots["pact"] || 0;
    const pips = Array.from({ length: s.max }, (_, i) => `
      <span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('pact', ${i})" title="${i < used ? "Click to restore" : "Click to use"}"></span>
    `).join("");
    return `
      <div id="spell-slot-tracker" class="sheet-card">
        <h3 class="sheet-card-title">Pact Magic Slots</h3>
        <div class="slot-row">
          <span class="slot-label">Level ${s.level}</span>
          <div class="slot-pips">${pips}</div>
          <span class="slot-count">${s.max - used} / ${s.max}</span>
        </div>
        <p class="dim" style="font-size:12px;margin:8px 0 0">Pact slots recover on a short or long rest.</p>
      </div>`;
  }

  const ordinals = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th"];
  const rows = slotInfo.slots.map(s => {
    const key = String(s.level);
    const used = slots[key] || 0;
    const pips = Array.from({ length: s.max }, (_, i) => `
      <span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('${key}', ${i})" title="${i < used ? "Click to restore" : "Click to use"}"></span>
    `).join("");
    return `
      <div class="slot-row">
        <span class="slot-label">${ordinals[s.level - 1]}</span>
        <div class="slot-pips">${pips}</div>
        <span class="slot-count">${s.max - used} / ${s.max}</span>
      </div>`;
  }).join("");

  return `
    <div id="spell-slot-tracker" class="sheet-card">
      <h3 class="sheet-card-title">Spell Slots</h3>
      ${rows}
    </div>`;
}

function renderSheet() {
  const c = state.character;
  const race = getRace(c.raceId), cls = getClass(c.classId), bg = getBackground(c.backgroundId);
  const subclass = cls && cls.subclasses.find(s => s.id === c.subclassId);
  const feat = c.feat && DATA.feats.find(f => f.id === c.feat);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const hp = computeHP(c), ac = computeAC(c);
  const initiative = abilityMod(scores.dex);
  const skillRows = getSkillRows(c);
  const saves = getSavingThrows(c);
  const perception = skillRows.find(s => s.name === "Perception");
  const passivePerception = 10 + (perception ? perception.mod : 0);

  // ── SRD subclass features (built-in fallback — shown when no features field on subclass object) ──
  const SUBCLASS_FEATURES = {
    // Barbarian
    "berserker": [
      { level: 3,  name: "Frenzy", desc: "While raging, you can go into a frenzy. You can make a single melee weapon attack as a bonus action on each turn. When your rage ends you suffer one level of exhaustion." },
      { level: 6,  name: "Mindless Rage", desc: "You can't be charmed or frightened while raging. Effects already active are suspended for the duration." },
      { level: 10, name: "Intimidating Presence", desc: "Use an action to frighten one creature within 30 ft. They make a Wisdom save (DC 8 + prof + Cha mod) or be frightened until end of your next turn. Recharges on long rest." },
      { level: 14, name: "Retaliation", desc: "When you take damage from a creature within 5 ft, you can use your reaction to make a melee weapon attack against that creature." },
    ],
    "totem-warrior": [
      { level: 3,  name: "Spirit Seeker", desc: "Cast beast sense and speak with animals as rituals." },
      { level: 3,  name: "Totem Spirit", desc: "Choose Bear (resist all damage except psychic while raging), Eagle (Dash as bonus action, enemies have disadvantage on opportunity attacks), or Wolf (allies have advantage on melee attacks against enemies adjacent to you)." },
      { level: 6,  name: "Aspect of the Beast", desc: "Bear: carry twice normal, double max load. Eagle: see up to 1 mile clearly, spot hidden creatures. Wolf: track at a fast pace without penalty, and pass through difficult terrain easily." },
      { level: 10, name: "Spirit Walker", desc: "Cast commune with nature as a ritual." },
      { level: 14, name: "Totemic Attunement", desc: "Bear: frightened creatures attack you in melee if able. Eagle: fly speed equal to walking while raging. Wolf: if you move 15 ft toward an enemy, knock them prone if they fail a Strength save." },
    ],
    // Bard
    "lore": [
      { level: 3,  name: "Bonus Proficiencies", desc: "Proficiency in three skills of your choice." },
      { level: 3,  name: "Cutting Words", desc: "Reaction to use a Bardic Inspiration die to subtract the result from a creature's attack roll, ability check, or damage roll." },
      { level: 6,  name: "Additional Magical Secrets", desc: "Learn two spells from any class spell list." },
      { level: 14, name: "Peerless Skill", desc: "When making an ability check, spend a Bardic Inspiration die and add the result to your check." },
    ],
    "valor": [
      { level: 3,  name: "Bonus Proficiencies", desc: "Proficiency with medium armor, shields, and martial weapons." },
      { level: 3,  name: "Combat Inspiration", desc: "Creatures with your Bardic Inspiration can add the die to weapon damage rolls or AC against an attack." },
      { level: 6,  name: "Extra Attack", desc: "Attack twice when you take the Attack action." },
      { level: 14, name: "Battle Magic", desc: "After casting a bard spell, you can use a bonus action to make a weapon attack." },
    ],
    // Cleric domains
    "life": [
      { level: 1,  name: "Bonus Proficiency", desc: "Heavy armor proficiency." },
      { level: 1,  name: "Disciple of Life", desc: "Your healing spells restore additional HP equal to 2 + the spell's level." },
      { level: 2,  name: "Channel Divinity: Preserve Life", desc: "Restore HP equal to 5 × cleric level among any creatures within 30 ft (up to half their HP max each)." },
      { level: 6,  name: "Blessed Healer", desc: "When you cast a healing spell on another creature, you regain HP equal to 2 + the spell's level." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 radiant damage on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Supreme Healing", desc: "Instead of rolling dice for healing spells, use the maximum number for each die." },
    ],
    "light": [
      { level: 1,  name: "Bonus Cantrip", desc: "You learn the light cantrip." },
      { level: 1,  name: "Warding Flare", desc: "When a creature attacks you, use your reaction to impose disadvantage (equal to Wis mod uses per long rest)." },
      { level: 2,  name: "Channel Divinity: Radiance of the Dawn", desc: "Dispel magical darkness within 30 ft and deal 2d10 + cleric level radiant damage to hostile creatures (Con save for half)." },
      { level: 6,  name: "Improved Flare", desc: "You can use Warding Flare to protect other creatures within 30 ft." },
      { level: 8,  name: "Potent Spellcasting", desc: "Add Wisdom modifier to cantrip damage rolls." },
      { level: 17, name: "Corona of Light", desc: "Activate as an action: 60 ft radius bright light, sunlight. Enemies have disadvantage on saves against spells dealing fire or radiant damage." },
    ],
    "knowledge": [
      { level: 1,  name: "Blessings of Knowledge", desc: "Learn two languages and proficiency in two skills from: Arcana, History, Nature, Religion (double proficiency bonus on those)." },
      { level: 2,  name: "Channel Divinity: Knowledge of the Ages", desc: "Gain proficiency in any skill or tool for 10 minutes." },
      { level: 6,  name: "Channel Divinity: Read Thoughts", desc: "Read a creature's surface thoughts (Wis save) and cast suggestion without a slot once." },
      { level: 8,  name: "Potent Spellcasting", desc: "Add Wisdom modifier to cantrip damage rolls." },
      { level: 17, name: "Visions of the Past", desc: "Spend 1 minute meditating to see visions of the recent past of an object or location." },
    ],
    "tempest": [
      { level: 1,  name: "Bonus Proficiencies", desc: "Martial weapons and heavy armor." },
      { level: 1,  name: "Wrath of the Storm", desc: "Reaction when hit by an attacker within 5 ft: deal 2d8 lightning or thunder damage (Dex save halves). Uses = Wis mod per long rest." },
      { level: 2,  name: "Channel Divinity: Destructive Wrath", desc: "Maximize lightning or thunder damage instead of rolling." },
      { level: 6,  name: "Thunderbolt Strike", desc: "When you deal lightning damage to a Large or smaller creature, push it 10 ft away." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 thunder damage on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Stormborn", desc: "Flying speed equal to walking speed when not underground or indoors." },
    ],
    "trickery": [
      { level: 1,  name: "Blessing of the Trickster", desc: "Touch a willing creature (not yourself) to give it advantage on Dexterity (Stealth) checks for 1 hour." },
      { level: 2,  name: "Channel Divinity: Invoke Duplicity", desc: "Create an illusion of yourself for 1 minute; you can cast spells as if from its space; allies get advantage when you and the illusion flank an enemy." },
      { level: 6,  name: "Channel Divinity: Cloak of Shadows", desc: "Use channel divinity to become invisible until end of next turn or you attack or cast a spell." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 poison damage on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Improved Duplicity", desc: "Create four duplicates instead of one with Invoke Duplicity; move any number of them up to 30 ft as a bonus action." },
    ],
    "war": [
      { level: 1,  name: "Bonus Proficiencies", desc: "Martial weapons and heavy armor." },
      { level: 1,  name: "War Priest", desc: "When you use the Attack action, you can make one weapon attack as a bonus action (uses = Wis mod per long rest)." },
      { level: 2,  name: "Channel Divinity: Guided Strike", desc: "Add +10 to an attack roll (after seeing the d20 but before knowing if it hits)." },
      { level: 6,  name: "Channel Divinity: War God's Blessing", desc: "Reaction to give an ally within 30 ft a +10 to their attack roll." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 damage (matching weapon type) on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Avatar of Battle", desc: "Resistance to bludgeoning, piercing, and slashing damage from nonmagical weapons." },
    ],
    "nature": [
      { level: 1,  name: "Acolyte of Nature", desc: "Learn one druid cantrip and proficiency in one of: Animal Handling, Nature, or Survival." },
      { level: 1,  name: "Bonus Proficiency", desc: "Heavy armor proficiency." },
      { level: 2,  name: "Channel Divinity: Charm Animals and Plants", desc: "Charm beasts and plant creatures within 30 ft (Wis save) for 1 minute." },
      { level: 6,  name: "Dampen Elements", desc: "Reaction when you or an ally within 30 ft takes acid, cold, fire, lightning, or thunder damage: grant resistance to the trigger damage." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 cold, fire, or lightning damage on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Master of Nature", desc: "Command charmed animals and plants as a bonus action." },
    ],
    // Druid
    "land": [
      { level: 2,  name: "Bonus Cantrip", desc: "Learn one druid cantrip of your choice." },
      { level: 2,  name: "Natural Recovery", desc: "Once per short rest, recover spell slots totaling up to half your druid level (rounded up), none above 5th level." },
      { level: 3,  name: "Circle Spells", desc: "Gain bonus spells based on your chosen terrain (arctic, coast, desert, forest, grassland, mountain, swamp, or Underdark)." },
      { level: 6,  name: "Land's Stride", desc: "Moving through nonmagical difficult terrain costs no extra movement. Advantage on saves vs plants created by magic." },
      { level: 10, name: "Nature's Ward", desc: "Immune to disease and poison; can't be charmed or frightened by elementals or fey." },
      { level: 14, name: "Nature's Sanctuary", desc: "When a beast or plant attacks you, it makes a Wis save or must choose a different target (fails = immune for 24 hours)." },
    ],
    "moon": [
      { level: 2,  name: "Combat Wild Shape", desc: "Wild Shape as a bonus action; spend spell slots while in beast form to regain HP (1d8 per slot level)." },
      { level: 2,  name: "Circle Forms", desc: "Wild Shape into beasts with CR up to 1 (CR = level/3 from 6th level) — including those with swim or fly speeds from 8th level." },
      { level: 6,  name: "Primal Strike", desc: "Beast form attacks count as magical for overcoming resistance." },
      { level: 10, name: "Elemental Wild Shape", desc: "Use two Wild Shape uses to transform into an air, earth, fire, or water elemental." },
      { level: 14, name: "Thousand Forms", desc: "Cast alter self at will." },
    ],
    // Fighter
    "champion": [
      { level: 3,  name: "Improved Critical", desc: "Weapon attacks score a critical hit on a roll of 19 or 20." },
      { level: 7,  name: "Remarkable Athlete", desc: "Add half proficiency bonus (round up) to Strength, Dexterity, or Constitution checks not already using proficiency. Running long jump distance increases by Str mod." },
      { level: 10, name: "Additional Fighting Style", desc: "Choose a second Fighting Style option." },
      { level: 15, name: "Superior Critical", desc: "Weapon attacks score a critical hit on a roll of 18–20." },
      { level: 18, name: "Survivor", desc: "At the start of your turn, regain HP equal to 5 + Con mod if you have fewer than half your max HP (as long as you have at least 1 HP)." },
    ],
    "battle-master": [
      { level: 3,  name: "Combat Superiority", desc: "Learn 3 maneuvers (4 at 7th, 5 at 10th, 6 at 15th). Gain 4 superiority dice (d8, increasing to d10 at 10th and d12 at 18th). Dice recharge on short or long rest." },
      { level: 3,  name: "Student of War", desc: "Proficiency with one artisan's tool of your choice." },
      { level: 7,  name: "Know Your Enemy", desc: "Spend 1 minute observing a creature to learn two comparative traits (Str, Dex, Con, AC, HP, class levels, or Fighter levels)." },
      { level: 15, name: "Relentless", desc: "If you have no superiority dice left when you roll initiative, regain one." },
    ],
    "eldritch-knight": [
      { level: 3,  name: "Spellcasting", desc: "Cast wizard spells (Intelligence). Learn spells from Abjuration and Evocation schools (two exceptions allowed). Spell slots recharge on long rest." },
      { level: 3,  name: "Weapon Bond", desc: "Ritual bond with up to two weapons. Bonded weapons can't be disarmed; teleport them to your hand as a bonus action." },
      { level: 7,  name: "War Magic", desc: "When you cast a cantrip, make one weapon attack as a bonus action." },
      { level: 10, name: "Eldritch Strike", desc: "When you hit with a weapon attack, the target has disadvantage on its next save against your spells until end of your next turn." },
      { level: 15, name: "Arcane Charge", desc: "When you use Action Surge, teleport up to 30 ft to an unoccupied space you can see before or after the extra action." },
      { level: 18, name: "Improved War Magic", desc: "When you use your action to cast a spell, make one weapon attack as a bonus action." },
    ],
    // Monk
    "open-hand": [
      { level: 3,  name: "Open Hand Technique", desc: "After hitting with a Flurry of Blows attack: push target 15 ft (Str save), knock prone (Dex save), or prevent reactions until start of your next turn." },
      { level: 6,  name: "Wholeness of Body", desc: "Restore HP equal to 3 × monk level as an action once per long rest." },
      { level: 11, name: "Tranquility", desc: "Cast sanctuary on yourself before each long rest. Effect lasts until you start a short or long rest." },
      { level: 17, name: "Quivering Palm", desc: "Set vibrations in a creature with an unarmed strike (3 ki). Within 30 days, use action to deal 10d10 damage or reduce to 0 HP (Con save halves; stunned instead on success). One creature at a time." },
    ],
    "shadow": [
      { level: 3,  name: "Shadow Arts", desc: "Cast darkness, darkvision, pass without trace, or silence for 2 ki (no spell slots). Also learn minor illusion." },
      { level: 6,  name: "Shadow Step", desc: "Bonus action: teleport up to 60 ft from one area of dim light or darkness to another. Advantage on first melee attack this turn." },
      { level: 11, name: "Cloak of Shadows", desc: "When in dim light or darkness, use action to become invisible. Ends on attack, casting, or bright light." },
      { level: 17, name: "Opportunist", desc: "Reaction: make an unarmed strike against a creature within 5 ft when another creature hits it with a melee attack." },
    ],
    "four-elements": [
      { level: 3,  name: "Disciple of the Elements", desc: "Learn two elemental disciplines — ki-powered abilities mimicking spells, using your monk's ki and save DC." },
      { level: 6,  name: "Additional Disciplines", desc: "Learn one more elemental discipline." },
      { level: 11, name: "Additional Disciplines", desc: "Learn one more elemental discipline. Can spend 3 ki to increase a discipline's effect when casting at 3rd level or higher." },
      { level: 17, name: "Additional Disciplines", desc: "Learn one more elemental discipline. Can spend 4 ki to increase a discipline's effect when casting at 4th level or higher." },
    ],
    // Paladin
    "devotion": [
      { level: 3,  name: "Sacred Weapon", desc: "Imbue a weapon with positive energy for 1 minute (Channel Divinity): add Cha mod to attack rolls; weapon emits bright light 20 ft, dim 20 ft." },
      { level: 3,  name: "Turn the Unholy", desc: "Channel Divinity: fiends and undead within 30 ft make a Wis save or are turned for 1 minute." },
      { level: 7,  name: "Aura of Devotion", desc: "You and friendly creatures within 10 ft can't be charmed while you are conscious (30 ft at 18th level)." },
      { level: 15, name: "Purity of Spirit", desc: "Always under effects of protection from evil and good." },
      { level: 20, name: "Holy Nimbus", desc: "Aura of sunlight (30 ft) for 1 minute: start of each enemy's turn in the aura deals 10 radiant damage; advantage on saves vs spells by fiends and undead. 1/long rest." },
    ],
    "ancients": [
      { level: 3,  name: "Nature's Wrath", desc: "Channel Divinity: conjure spectral vines to restrain a creature within 10 ft (Str or Dex save)." },
      { level: 3,  name: "Turn the Faithless", desc: "Channel Divinity: fey and fiends within 30 ft make a Wis save or are turned for 1 minute." },
      { level: 7,  name: "Aura of Warding", desc: "You and friendly creatures within 10 ft have resistance to spell damage (30 ft at 18th level)." },
      { level: 15, name: "Undying Sentinel", desc: "When you would drop to 0 HP, drop to 1 HP instead (1/long rest). Also no longer age." },
      { level: 20, name: "Elder Champion", desc: "Transform for 1 minute (1/long rest): regain 10 HP at start of each turn, spells cost 1 less action, enemies within 10 ft must use extra action to save against your paladin spells. "},
    ],
    "vengeance": [
      { level: 3,  name: "Abjure Enemy", desc: "Channel Divinity: one creature within 60 ft makes Wis save. Fiend/undead at disadvantage. On fail: frightened and speed 0 for 1 minute. On success: halved speed." },
      { level: 3,  name: "Vow of Enmity", desc: "Channel Divinity: advantage on attacks against one creature within 10 ft for 1 minute." },
      { level: 7,  name: "Relentless Avenger", desc: "When you hit with an opportunity attack, move up to half your speed immediately after (doesn't provoke opportunity attacks)." },
      { level: 15, name: "Soul of Vengeance", desc: "When a creature under your Vow of Enmity makes an attack, use your reaction to make a weapon attack against it." },
      { level: 20, name: "Avenging Angel", desc: "Transform for 1 hour (1/long rest): fly speed 60 ft; aura of menace 30 ft (Wis save or frightened, disadvantage on saves vs you until no longer frightened)." },
    ],
    // Ranger
    "hunter": [
      { level: 3,  name: "Hunter's Prey", desc: "Choose one: Colossus Slayer (+1d8 on one attack/turn vs damaged foe), Giant Killer (reaction attack against Large+ that attacks you), or Horde Breaker (attack a second adjacent creature once per turn)." },
      { level: 7,  name: "Defensive Tactics", desc: "Choose one: Escape the Horde (no opportunity attacks while moving), Multiattack Defense (+4 AC after being hit until start of next turn), Steel Will (advantage vs frightened)." },
      { level: 11, name: "Multiattack", desc: "Choose one: Volley (ranged attack against all creatures in a 10 ft radius point) or Whirlwind Attack (melee attack against each creature within reach)." },
      { level: 15, name: "Superior Hunter's Defense", desc: "Choose one: Evasion (Dex save — take no damage on success, half on fail), Stand Against the Tide (reaction to redirect a missed melee attack to another creature), or Uncanny Dodge (reaction to halve an attack's damage)." },
    ],
    "beast-master": [
      { level: 3,  name: "Ranger's Companion", desc: "Bond with a beast CR ≤ 1/4 of ranger level (min 1/4). It acts on your initiative; uses your proficiency bonus; obeys your commands." },
      { level: 7,  name: "Exceptional Training", desc: "Bonus action to command companion to Dash, Disengage, Dodge, or Help. Its attacks count as magical." },
      { level: 11, name: "Bestial Fury", desc: "Companion can make two attacks when you command it to attack." },
      { level: 15, name: "Share Spells", desc: "Spells you cast on yourself also affect your companion if it's within 30 ft." },
    ],
    // Rogue
    "thief": [
      { level: 3,  name: "Fast Hands", desc: "Use the bonus action from Cunning Action to use a Sleight of Hand check, Use an Object, or use thieves' tools." },
      { level: 3,  name: "Second-Story Work", desc: "Climbing no longer costs extra movement. Running jump distance increases by Dex mod." },
      { level: 9,  name: "Supreme Sneak", desc: "Advantage on Stealth checks when moving at half speed." },
      { level: 13, name: "Use Magic Device", desc: "Ignore class, race, and level requirements on magic items." },
      { level: 17, name: "Thief's Reflexes", desc: "Take two turns in the first round of combat; second turn at initiative − 10." },
    ],
    "assassin": [
      { level: 3,  name: "Bonus Proficiencies", desc: "Proficiency with disguise kit and poisoner's kit." },
      { level: 3,  name: "Assassinate", desc: "Advantage on attacks against creatures that haven't taken a turn yet. Any hit against a surprised creature is a critical hit." },
      { level: 9,  name: "Infiltration Expertise", desc: "Spend 7 days and 25 gp to create a false identity supported by documents." },
      { level: 13, name: "Impostor", desc: "Unerringly mimic another person's speech, writing, and behavior after studying them for 3 hours." },
      { level: 17, name: "Death Strike", desc: "On a critical hit against a surprised creature, double the damage (Con save DC 8 + Prof + Dex mod negates)." },
    ],
    "arcane-trickster": [
      { level: 3,  name: "Spellcasting", desc: "Cast wizard spells (Intelligence). Enchantment and Illusion spells only (two exceptions). Spell slots recharge on long rest." },
      { level: 3,  name: "Mage Hand Legerdemain", desc: "Enhanced Mage Hand: invisible; can stow/retrieve items from pockets, pick locks, and disarm traps remotely; contested by Perception vs Sleight of Hand." },
      { level: 9,  name: "Magical Ambush", desc: "When you cast a spell while hidden, the target has disadvantage on its saving throw." },
      { level: 13, name: "Versatile Trickster", desc: "Use bonus action to distract a creature with Mage Hand: advantage on attack rolls vs it until end of your turn." },
      { level: 17, name: "Spell Thief", desc: "Reaction after failing a save vs a spell: steal it. Caster makes an ability check vs DC 10 + spell level; on fail, you lose the spell memory but can cast it once using the caster's ability within 8 hours." },
    ],
    // Sorcerer
    "draconic": [
      { level: 1,  name: "Dragon Ancestor", desc: "Choose a dragon type; learn its language; gain advantage on Charisma checks vs dragons of that type." },
      { level: 1,  name: "Draconic Resilience", desc: "HP max increases by 1 per sorcerer level. When not wearing armor, AC = 13 + Dex mod." },
      { level: 6,  name: "Elemental Affinity", desc: "Add Cha mod to spells dealing ancestor's damage type. Spend 1 sorcery point for resistance to that type for 1 hour." },
      { level: 14, name: "Dragon Wings", desc: "Sprout dragon wings as a bonus action, gaining flying speed equal to your walking speed." },
      { level: 18, name: "Draconic Presence", desc: "Spend 5 sorcery points to radiate awe or fear (60 ft) for 1 minute: creatures in the aura make a Wis save or are charmed/frightened." },
    ],
    "wild-magic": [
      { level: 1,  name: "Wild Magic Surge", desc: "When you cast a level 1+ sorcerer spell, the DM can ask you to roll a d20. On a 1, roll on the Wild Magic Surge table." },
      { level: 1,  name: "Tides of Chaos", desc: "Gain advantage on one attack, check, or save. Recharges on long rest (or immediately after a Wild Magic Surge)." },
      { level: 6,  name: "Bend Luck", desc: "Spend 2 sorcery points (reaction) to add or subtract 1d4 from another creature's attack, check, or save." },
      { level: 14, name: "Controlled Chaos", desc: "Whenever you roll on the Wild Magic Surge table, roll twice and use either result." },
      { level: 18, name: "Spell Bombardment", desc: "Once per turn, when you roll maximum on a damage die, add another die of the same type to the damage." },
    ],
    // Warlock
    "archfey": [
      { level: 1,  name: "Fey Presence", desc: "Action (1/short rest): creatures in a 10 ft cube make a Wis save or become charmed or frightened until end of your next turn." },
      { level: 6,  name: "Misty Escape", desc: "Reaction when you take damage: turn invisible and teleport up to 60 ft. Ends at start of your next turn." },
      { level: 10, name: "Beguiling Defenses", desc: "Immune to being charmed. When a creature tries to charm you, you can use your reaction to turn the charm back on them." },
      { level: 14, name: "Dark Delirium", desc: "Action (1/short rest): charm or frighten a creature for 1 minute; each turn it thinks it's in a different location; Wis save at end of each of its turns." },
    ],
    "fiend": [
      { level: 1,  name: "Dark One's Blessing", desc: "When you reduce a hostile creature to 0 HP, gain temp HP = Cha mod + warlock level (minimum 1)." },
      { level: 6,  name: "Dark One's Own Luck", desc: "Add 1d10 to one ability check or save per short or long rest." },
      { level: 10, name: "Fiendish Resilience", desc: "Choose a damage type after a short or long rest to become resistant to it (not bludgeoning, piercing, or slashing from magical weapons)." },
      { level: 14, name: "Hurl Through Hell", desc: "When you hit a creature, send it through hell until end of your next turn: it takes 10d10 psychic damage on return. 1/long rest." },
    ],
    "great-old-one": [
      { level: 1,  name: "Awakened Mind", desc: "Telepathically communicate with any creature within 30 ft that can understand a language." },
      { level: 6,  name: "Entropic Ward", desc: "Reaction: impose disadvantage on an attack roll against you. If it misses, gain advantage on your next attack vs it. 1/short rest." },
      { level: 10, name: "Thought Shield", desc: "Others can't read your mind. Resistance to psychic damage. When you take psychic damage, the attacker takes the same amount." },
      { level: 14, name: "Create Thrall", desc: "Touch an incapacitated humanoid to charm it indefinitely (no saves). Telepathic link while on the same plane." },
    ],
    // Wizard
    "abjuration": [
      { level: 2,  name: "Abjuration Savant", desc: "Half gold and time cost to copy Abjuration spells into spellbook." },
      { level: 2,  name: "Arcane Ward", desc: "Casting an Abjuration spell creates a ward with HP = 2× wizard level + Int mod. Ward absorbs damage first; recharge by casting Abjuration spells (recharge = 2× spell level)." },
      { level: 6,  name: "Projected Ward", desc: "Reaction: Arcane Ward absorbs damage for an ally within 30 ft." },
      { level: 10, name: "Improved Abjuration", desc: "Add proficiency bonus to ability checks made as part of Abjuration spells (e.g., counterspell, dispel magic)." },
      { level: 14, name: "Spell Resistance", desc: "Advantage on saves vs spells. Resistance to spell damage." },
    ],
    "conjuration": [
      { level: 2,  name: "Conjuration Savant", desc: "Half gold and time cost to copy Conjuration spells into spellbook." },
      { level: 2,  name: "Minor Conjuration", desc: "Create a small object in an unoccupied space within 10 ft as an action. Object disappears after 1 hour or when you use this again." },
      { level: 6,  name: "Benign Transposition", desc: "Teleport up to 30 ft to an unoccupied space, or swap places with a willing Small/Medium creature. Recharges on long rest or when casting a Conjuration spell." },
      { level: 10, name: "Focused Conjuration", desc: "While concentrating on a Conjuration spell, your concentration can't be broken by taking damage." },
      { level: 14, name: "Durable Summons", desc: "Creatures you conjure gain 30 temporary hit points." },
    ],
    "divination": [
      { level: 2,  name: "Divination Savant", desc: "Half gold and time cost to copy Divination spells." },
      { level: 2,  name: "Portent", desc: "Roll two d20s after each long rest; replace any d20 roll made by you or a creature you can see with one of these results (before the roll)." },
      { level: 6,  name: "Expert Divination", desc: "When you cast a Divination spell of 2nd level or higher, regain one spent spell slot of a lower level." },
      { level: 10, name: "The Third Eye", desc: "Action (1/short rest): gain darkvision 60 ft, see the Ethereal Plane 60 ft, read any language, or see invisible creatures 10 ft." },
      { level: 14, name: "Greater Portent", desc: "Roll three d20s for Portent instead of two." },
    ],
    "enchantment": [
      { level: 2,  name: "Enchantment Savant", desc: "Half gold and time cost to copy Enchantment spells." },
      { level: 2,  name: "Hypnotic Gaze", desc: "Action: charm and incapacitate a creature within 5 ft while maintaining (Wis save). Unlimited use but requires action/concentration each turn." },
      { level: 6,  name: "Instinctive Charm", desc: "Reaction when attacked: redirect the attacker to attack the nearest other creature (Wis save negates; immune for 24 hours on success). 1/long rest vs same target." },
      { level: 10, name: "Split Enchantment", desc: "Cast a single-target Enchantment spell and target a second creature with it for free." },
      { level: 14, name: "Alter Memories", desc: "When you charm a creature with an Enchantment spell, you can make it forget the duration of the effect (Int save)." },
    ],
    "evocation": [
      { level: 2,  name: "Evocation Savant", desc: "Half gold and time cost to copy Evocation spells." },
      { level: 2,  name: "Sculpt Spells", desc: "Create pockets of safety in your Evocation spells: choose a number of creatures equal to 1 + spell level; they automatically succeed on the save and take no damage." },
      { level: 6,  name: "Potent Cantrip", desc: "Your damaging cantrips deal half damage on a successful save." },
      { level: 10, name: "Empowered Evocation", desc: "Add Intelligence modifier to damage rolls of any Evocation spell you cast." },
      { level: 14, name: "Overchannel", desc: "Deal maximum damage with a wizard Evocation spell of 5th level or lower. Each use after the first (per long rest) deals 2d12 necrotic damage to you, increasing by 2d12 per extra use." },
    ],
    "illusion": [
      { level: 2,  name: "Illusion Savant", desc: "Half gold and time cost to copy Illusion spells." },
      { level: 2,  name: "Improved Minor Illusion", desc: "Learn minor illusion (or another cantrip if already known). Can create both sound and image with a single casting." },
      { level: 6,  name: "Malleable Illusions", desc: "When concentrating on an Illusion spell, use an action to change the nature of the illusion (per the spell's allowed effects)." },
      { level: 10, name: "Illusory Self", desc: "Reaction when attacked: interpose an illusion to cause the attack to miss. Recharges on short or long rest." },
      { level: 14, name: "Illusory Reality", desc: "Once per casting: after casting an Illusion spell, make one inanimate non-damaging object in the illusion real for 1 minute." },
    ],
    "necromancy": [
      { level: 2,  name: "Necromancy Savant", desc: "Half gold and time cost to copy Necromancy spells." },
      { level: 2,  name: "Grim Harvest", desc: "When you kill a creature with a spell, regain HP equal to twice the spell's level (or 3× for Necromancy spells). Doesn't apply to undead or constructs." },
      { level: 6,  name: "Undead Thralls", desc: "Animate Dead adds one extra corpse/skeleton per casting. Undead you create gain bonus HP (= wizard level) and add your proficiency bonus to damage rolls." },
      { level: 10, name: "Inured to Undeath", desc: "Resistance to necrotic damage. Maximum HP can't be reduced." },
      { level: 14, name: "Command Undead", desc: "Action: charm an undead creature (Int save; advantage if Int ≥ 8). Mindless undead auto-fail. Lasts until you use this again or the target succeeds on its save." },
    ],
    "transmutation": [
      { level: 2,  name: "Transmutation Savant", desc: "Half gold and time cost to copy Transmutation spells." },
      { level: 2,  name: "Minor Alchemy", desc: "Transform one Small or larger non-magical object from one material into another (wood, stone, iron, copper, silver). Reverts after 1 hour or when concentration breaks." },
      { level: 6,  name: "Transmuter's Stone", desc: "Spend 8 hours creating a stone that grants one of: darkvision 60 ft, +10 speed, proficiency in Con saves, or resistance to acid/cold/fire/lightning/thunder. Only one stone at a time." },
      { level: 10, name: "Shapechanger", desc: "Cast polymorph on yourself at will without expending a spell slot; only into beast form." },
      { level: 14, name: "Master Transmuter", desc: "As an action, consume the Transmuter's Stone to choose one: major transformation, panacea (remove all curses/diseases/poisons and restore HP to max), restore life (cast raise dead without a spell slot), restore youth." },
    ],
  };

  const featuresList = [
    ...(race ? race.traits : []),
    ...(bg ? [bg.feature] : []),
    ...(feat ? [`${feat.name}: ${feat.summary}`] : []),
  ];

  // Subclass features — rich grouped display
  const subclassFeatures = (() => {
    if (!subclass) return "";
    const builtIn = SUBCLASS_FEATURES[subclass.id];
    // Filter to features at or below character level
    const available = builtIn ? builtIn.filter(f => f.level <= c.level) : [];

    return `
      <div style="margin-top:12px">
        <h4 class="sheet-subhead" style="margin-top:0">${subclass.name}</h4>
        ${available.length ? available.map(f => `
          <div class="feature-block">
            <div class="feature-name">${f.name} <span class="dim" style="font-size:11px;font-weight:400">(level ${f.level})</span></div>
            <div class="feature-desc">${f.desc}</div>
          </div>`).join("") : `<p class="dim" style="font-size:13px">No feature details available for this subclass in the SRD data. If you imported this class from a PDF, feature text can be added to <code>server/data/custom/classes.json</code>.</p>`}
      </div>`;
  })();

  const featuresSection = `
    <div class="sheet-card">
      <h3 class="sheet-card-title">Features &amp; Traits</h3>
      ${featuresList.length ? `<ul class="sheet-list" style="margin-bottom:${subclassFeatures ? "14px" : "0"}">${featuresList.map(t => `<li>${t}</li>`).join("")}</ul>` : ""}
      ${subclassFeatures}
      ${!featuresList.length && !subclassFeatures ? `<p class="dim">None recorded.</p>` : ""}
    </div>`;

  // ── Weapon attack computation ─────────────────────────────
  const strMod = abilityMod(scores.str);
  const dexMod = abilityMod(scores.dex);

  // Gather all weapons from the data library for lookup
  const weaponLib = DATA.equipment?.weapons || [];

  // Build a list of weapons the character is carrying, parsed from all gear sources
  const allGearText = [
    ...(cls ? cls.startingEquipment : []),
    ...(bg ? bg.equipment : []),
    c.extraGear || "",
  ].join(", ").toLowerCase();

  // Collect proficient weapon categories
  const profWeapons = (cls?.weaponProficiencies || []).map(p => p.toLowerCase());
  function isProficientWith(weapon) {
    const cat = (weapon.category || "").toLowerCase();
    const name = (weapon.name || "").toLowerCase();
    return profWeapons.some(p =>
      p.includes("simple") && cat.includes("simple") ||
      p.includes("martial") && cat.includes("martial") ||
      p === name
    );
  }

  // Match weapons from gear text against weapon library
  const equippedWeapons = weaponLib.filter(w =>
    allGearText.includes(w.name.toLowerCase())
  );

  function weaponAttackBonus(weapon) {
    const props = (weapon.properties || []).map(p => p.toLowerCase());
    const isRanged = weapon.category?.toLowerCase().includes("ranged");
    const isFinesse = props.some(p => p.includes("finesse"));
    const prof = isProficientWith(weapon) ? pb : 0;
    let abilityMd;
    if (isFinesse) abilityMd = Math.max(strMod, dexMod);
    else if (isRanged) abilityMd = dexMod;
    else abilityMd = strMod;
    return { bonus: prof + abilityMd, abilityMod: abilityMd, prof };
  }

  function weaponDamage(weapon) {
    const props = (weapon.properties || []).map(p => p.toLowerCase());
    const isRanged = weapon.category?.toLowerCase().includes("ranged");
    const isFinesse = props.some(p => p.includes("finesse"));
    let abilityMd;
    if (isFinesse) abilityMd = Math.max(strMod, dexMod);
    else if (isRanged) abilityMd = dexMod;
    else abilityMd = strMod;
    const modStr = abilityMd !== 0 ? ` ${fmtMod(abilityMd)}` : "";
    return `${weapon.damage}${modStr}`;
  }

  const weaponSection = `
    <div class="sheet-card">
      <h3 class="sheet-card-title">Equipment &amp; Weapons</h3>
      ${equippedWeapons.length ? `
        <div class="weapon-table">
          <div class="weapon-header">
            <span>Weapon</span><span>Attack</span><span>Damage</span><span>Type</span>
          </div>
          ${equippedWeapons.map(w => {
            const { bonus } = weaponAttackBonus(w);
            const props = (w.properties || []).map(p => p.toLowerCase());
            const isVersatile = props.find(p => p.startsWith("versatile"));
            const versatileDmg = isVersatile ? isVersatile.match(/\(([^)]+)\)/)?.[1] : null;
            const dmgType = w.damage?.split(" ").slice(1).join(" ") || "";
            const dmgDice = w.damage?.split(" ")[0] || "";
            const abilityMd = weaponAttackBonus(w).abilityMod;
            const modStr = abilityMd !== 0 ? ` ${fmtMod(abilityMd)}` : "";
            return `
              <div class="weapon-row">
                <span class="weapon-name">
                  ${w.name}
                  ${isProficientWith(w) ? '<span class="wpn-badge prof">Prof</span>' : '<span class="wpn-badge">No Prof</span>'}
                </span>
                <span class="weapon-atk">${fmtMod(bonus)}</span>
                <span class="weapon-dmg">${dmgDice}${modStr}${versatileDmg ? ` <span class="dim">(${versatileDmg}${modStr} 2H)</span>` : ""}</span>
                <span class="weapon-type dim">${dmgType}</span>
              </div>`;
          }).join("")}
        </div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:10px">
          Weapons detected from your gear. Add weapons in the Edit step under "Additional Gear."
        </div>
      ` : `<p class="dim" style="font-size:13px;margin:0 0 10px">No weapons detected. Add them in Edit → Equipment (e.g. "Longsword, Dagger").</p>`}
      ${[
        ...(cls ? cls.startingEquipment : []),
        ...(bg ? bg.equipment : []),
        ...(c.armorId ? [`Armor: ${c.armorId}`] : []),
        ...(c.shield ? ["Shield (+2 AC)"] : []),
        ...(c.extraGear ? [c.extraGear] : []),
      ].length ? `
        <h4 class="sheet-subhead">All Gear</h4>
        <ul class="sheet-list">
          ${[
            ...(cls ? cls.startingEquipment : []),
            ...(bg ? bg.equipment : []),
            ...(c.armorId ? [`Armor: ${c.armorId}`] : []),
            ...(c.shield ? ["Shield (+2 AC)"] : []),
            ...(c.extraGear ? [c.extraGear] : []),
          ].map(t => `<li>${t}</li>`).join("")}
        </ul>` : ""}
    </div>`;

  // Fallback spellcasting ability per class for when PDF import didn't capture it
  const CASTER_ABILITY = {
    bard: "cha", cleric: "wis", druid: "wis", paladin: "cha",
    ranger: "wis", sorcerer: "cha", warlock: "cha", wizard: "int",
    artificer: "int",
  };

  const spellSection = (() => {
    const slotInfo = getSpellSlots(c.classId, c.level);
    const scAbility = cls?.spellcasting?.ability || CASTER_ABILITY[c.classId] || null;
    const isCaster = !!(slotInfo || scAbility);
    if (!isCaster) return "";

    const abMod = scAbility ? abilityMod(scores[scAbility]) : 0;
    const saveDC = 8 + pb + abMod;
    const atkBonus = pb + abMod;
    const cantrips = DATA.spells.filter(s => c.cantrips.includes(s.name));
    const known = DATA.spells.filter(s => c.spellsKnown.includes(s.name));

    // Slot tracker rows rendered inline inside the card
    const slotsHtml = (() => {
      if (!slotInfo) return "";
      const slots = c.spellSlots || {};
      const ordinals = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th"];
      if (slotInfo.type === "pact") {
        const s = slotInfo.slots[0];
        const used = slots["pact"] || 0;
        const pips = Array.from({ length: s.max }, (_, i) =>
          `<span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('pact',${i})"></span>`
        ).join("");
        return `
          <div style="margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--border-dark)">
            <div style="font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--text-muted);margin-bottom:8px">Pact Magic Slots <span style="font-size:10px">(short/long rest)</span></div>
            <div class="slot-row">
              <span class="slot-label">Lvl ${s.level}</span>
              <div class="slot-pips">${pips}</div>
              <span class="slot-count">${s.max - used} / ${s.max}</span>
            </div>
          </div>`;
      }
      return `
        <div style="margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--border-dark)">
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--text-muted);margin-bottom:8px">Spell Slots</div>
          ${slotInfo.slots.map(s => {
            const key = String(s.level);
            const used = slots[key] || 0;
            const pips = Array.from({ length: s.max }, (_, i) =>
              `<span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('${key}',${i})"></span>`
            ).join("");
            return `
              <div class="slot-row">
                <span class="slot-label">${ordinals[s.level - 1]}</span>
                <div class="slot-pips">${pips}</div>
                <span class="slot-count">${s.max - used} / ${s.max}</span>
              </div>`;
          }).join("")}
        </div>`;
    })();

    return `
      <div class="sheet-card" id="spell-slot-tracker">
        <h3 class="sheet-card-title">Spellcasting</h3>
        <div class="spell-meta-row" style="margin-bottom:12px">
          <div><span class="sheet-label">Ability</span><span class="sheet-value">${scAbility ? ABILITY_NAMES[scAbility] : "—"}</span></div>
          <div><span class="sheet-label">Save DC</span><span class="sheet-value">${saveDC}</span></div>
          <div><span class="sheet-label">Atk Bonus</span><span class="sheet-value">${fmtMod(atkBonus)}</span></div>
        </div>
        ${slotsHtml}
        ${cantrips.length ? `<h4 class="sheet-subhead">Cantrips</h4><ul class="sheet-list">${cantrips.map(s => `<li><strong>${s.name}</strong> <span class="dim">— ${s.summary}</span></li>`).join("")}</ul>` : ""}
        ${known.length ? `<h4 class="sheet-subhead">Spells Known / Prepared</h4><ul class="sheet-list">${known.map(s => `<li><strong>${s.name}</strong> <span class="dim">(Lvl ${s.level}) — ${s.summary}</span></li>`).join("")}</ul>` : ""}
      </div>`;
  })();

  return `
    <div class="sheet">
      <div class="sheet-toolbar">
        <button class="btn" onclick="Router.go('list')">&larr; Back to Characters</button>
        <button class="btn btn--primary" onclick="Router.go('edit', ${state.editingId})">Edit Character</button>
      </div>

      <div class="sheet-banner">
        <div class="sheet-avatar">${(c.name || "?").trim().charAt(0).toUpperCase()}</div>
        <div class="sheet-banner-text">
          <h1>${escapeHtml(c.name) || "Unnamed"}</h1>
          <div class="sheet-subtitle">
            Level ${c.level} ${race ? race.name : "—"} ${cls ? cls.name : "—"}${subclass ? ` (${subclass.name})` : ""}
          </div>
          <div class="sheet-subtitle dim">${bg ? bg.name : "No background"}</div>
        </div>
      </div>

      <div class="sheet-vitals">
        <div class="vital-box vital-box--interactive">
          <span class="vital-num" id="vital-ac">${computeAC(c) + (c.tempAc || 0)}${(c.tempAc || 0) > 0 ? `<span style="font-size:12px;color:#81d4fa;display:block;line-height:1.2">+${c.tempAc} bonus</span>` : ""}</span>
          <span class="vital-label">Armor Class</span>
          <div class="vital-mini-controls">
            <button class="vital-adj" onclick="App.adjustTempAc(-1)" title="Remove AC bonus">−</button>
            <span class="vital-adj-label">tmp AC</span>
            <button class="vital-adj" onclick="App.adjustTempAc(1)" title="Add AC bonus">+</button>
          </div>
        </div>
        <div class="vital-box">
          <span class="vital-num" id="vital-hp" style="font-size:18px">
            ${c.currentHp ?? hp ?? "—"}<span style="font-size:13px;color:#888">/${hp ?? "—"}</span>
            ${(c.tempHp || 0) > 0 ? `<span style="font-size:12px;color:#64b5f6;display:block;line-height:1.2">+${c.tempHp} tmp HP</span>` : ""}
          </span>
          <span class="vital-label">Hit Points</span>
        </div>
        <div class="vital-box"><span class="vital-num">${fmtMod(initiative)}</span><span class="vital-label">Initiative</span></div>
        <div class="vital-box"><span class="vital-num">${race ? race.speed : "—"}</span><span class="vital-label">Speed</span></div>
        <div class="vital-box"><span class="vital-num">${cls ? `d${cls.hitDie}` : "—"}</span><span class="vital-label">Hit Die</span></div>
        <div class="vital-box"><span class="vital-num">${fmtMod(pb)}</span><span class="vital-label">Proficiency</span></div>
      </div>

      <div class="sheet-grid">

        <!-- Col 1: Ability Scores / Saves / Skills -->
        <div class="sheet-col">
          <div class="sheet-card">
            <h3 class="sheet-card-title">Ability Scores</h3>
            <div class="ability-hex-grid">
              ${ABILITIES.map(a => `
                <div class="ability-hex">
                  <div class="hex-ability">${a.toUpperCase()}</div>
                  <div class="hex-mod">${fmtMod(abilityMod(scores[a]))}</div>
                  <div class="hex-score">${scores[a]}</div>
                </div>`).join("")}
            </div>
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">Saving Throws</h3>
            ${saves.map(s => `
              <div class="prof-row">
                <span class="prof-dot ${s.proficient ? "on" : ""}"></span>
                <span>${ABILITY_NAMES[s.ability]}</span>
                <span class="prof-mod">${fmtMod(s.mod)}</span>
              </div>`).join("")}
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">Skills</h3>
            <div class="prof-row" style="border-bottom:1px solid var(--border-dark);padding-bottom:8px;margin-bottom:6px;">
              <span></span><span>Passive Perception</span><span class="prof-mod">${passivePerception}</span>
            </div>
            ${skillRows.map(s => `
              <div class="prof-row">
                <span class="prof-dot ${s.proficient ? "on" : ""}"></span>
                <span>${s.name} <span class="dim">(${s.ability.toUpperCase()})</span></span>
                <span class="prof-mod">${fmtMod(s.mod)}</span>
              </div>`).join("")}
          </div>
        </div>

        <!-- Col 2: HP / Class Resources / Equipment & Weapons -->
        <div class="sheet-col sheet-col--mid">
          ${renderHpTracker(c)}
          ${renderClassResources(c)}
          ${weaponSection}
        </div>

        <!-- Col 3: Spellcasting / Features / Notes -->
        <div class="sheet-col sheet-col--right">
          ${spellSection}
          ${featuresSection}
          ${c.notes ? `
          <div class="sheet-card">
            <h3 class="sheet-card-title">Notes</h3>
            <p>${escapeHtml(c.notes)}</p>
          </div>` : ""}
        </div>

      </div>
    </div>`;
}

// ============ PDF Import Page ============

function renderImportPage() {
  return `
    <div class="import-page">
      <div class="import-header">
        <h1>Import Source Material</h1>
        <p class="subtitle">Load PDFs from your computer — all processing happens locally in your browser. No internet, no API key, nothing leaves your machine. Select as many PDFs as you like at once.</p>
      </div>

      <div class="import-grid">
        <div class="import-upload-panel">
          <div class="sheet-card" style="margin-bottom:16px">
            <h3 class="sheet-card-title">🔒 100% Local Processing</h3>
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:24px">✅</span>
              <div>
                <strong style="color:#4caf50">Ready — no setup needed</strong>
                <div class="dim" style="font-size:12px;margin-top:2px">PDF text is extracted in your browser using Mozilla's pdf.js. Parsed data is saved to your local server only.</div>
              </div>
            </div>
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">📄 Load PDFs</h3>
            <div class="drop-zone" id="dropZone"
              ondragover="event.preventDefault(); this.classList.add('drag-over')"
              ondragleave="this.classList.remove('drag-over')"
              ondrop="ImportPage.handleDrop(event)">
              <div class="drop-icon">⬆</div>
              <div>Drag &amp; drop PDFs here</div>
              <div style="color:var(--text-muted);font-size:13px;margin:6px 0">or</div>
              <button class="btn" onclick="document.getElementById('pdfInput').click()">Browse files</button>
              <input type="file" id="pdfInput" accept=".pdf" multiple style="display:none" onchange="ImportPage.handleFileSelect(this)" />
            </div>
            <div id="fileQueue" style="margin-top:10px;display:flex;flex-direction:column;gap:6px;"></div>
            <button class="btn btn--primary" style="width:100%;margin-top:12px" id="importBtn" onclick="ImportPage.runImport()" disabled>
              Extract &amp; Import All
            </button>
          </div>

          <div id="importStatus" style="margin-top:16px"></div>

          <div class="sheet-card" style="margin-top:16px">
            <h3 class="sheet-card-title">ℹ️ What gets extracted</h3>
            <p class="dim" style="font-size:13px;margin:0">The parser recognises D&amp;D 5e formatting to pull out races, classes &amp; subclasses, backgrounds, feats, and spells. Results vary by PDF quality — digital-native PDFs extract best. Scanned/image PDFs won't work. Review the library after import and remove anything garbled.</p>
          </div>
        </div>

        <div>
          <div class="sheet-card">
            <h3 class="sheet-card-title">📚 Imported Content Library</h3>
            <p style="font-size:13px;color:var(--text-muted);margin-top:0">Everything below is available in the character creator. Click × to remove an entry.</p>
            <div id="libraryContent"><p class="dim">Loading…</p></div>
          </div>
        </div>
      </div>
    </div>`;
}

const ImportPage = {
  _files: [],   // array of File objects

  async loadLibrary() {
    const el = document.getElementById('libraryContent');
    if (!el) return;
    try {
      const lib = await (await fetch('/api/import/library')).json();
      const types = ['races','classes','backgrounds','feats','spells'];
      const sections = types.map(type => {
        const items = lib[type] || [];
        if (!items.length) return '';
        return `
          <div style="margin-bottom:14px">
            <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--gold);margin-bottom:6px">${type} (${items.length})</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px">
              ${items.map(it => `
                <span class="tag" style="display:inline-flex;align-items:center;gap:4px">
                  ${escapeHtml(it.name)}
                  <span style="cursor:pointer;color:var(--crimson);font-size:12px" onclick="ImportPage.remove('${type}', '${escapeHtml(it.id || it.name)}')">×</span>
                </span>`).join('')}
            </div>
          </div>`;
      }).filter(Boolean).join('');
      const eqItems = lib.equipment || [];
      const eqSection = eqItems.length ? `
        <div>
          <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--gold);margin-bottom:6px">equipment (${eqItems.length})</div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${eqItems.map(it => `<span class="tag">${escapeHtml(it.name)}</span>`).join('')}
          </div>
        </div>` : '';
      el.innerHTML = sections + eqSection || '<p class="dim">No custom content imported yet.</p>';
    } catch (e) {
      el.innerHTML = '<p class="dim">Could not load library.</p>';
    }
  },

  handleDrop(e) {
    e.preventDefault();
    document.getElementById('dropZone').classList.remove('drag-over');
    const files = [...e.dataTransfer.files].filter(f => f.type === 'application/pdf');
    if (!files.length) { this._globalStatus('error', 'Only PDF files are supported.'); return; }
    this._addFiles(files);
  },

  handleFileSelect(input) {
    const files = [...input.files];
    if (files.length) this._addFiles(files);
    input.value = ''; // reset so same file can be re-added if needed
  },

  _addFiles(newFiles) {
    // Deduplicate by name
    const existing = new Set(this._files.map(f => f.name));
    const toAdd = newFiles.filter(f => !existing.has(f.name));
    this._files.push(...toAdd);
    this._renderQueue();
    document.getElementById('importBtn').disabled = this._files.length === 0;
  },

  removeFile(name) {
    this._files = this._files.filter(f => f.name !== name);
    this._renderQueue();
    document.getElementById('importBtn').disabled = this._files.length === 0;
  },

  _renderQueue() {
    const el = document.getElementById('fileQueue');
    if (!el) return;
    if (!this._files.length) { el.innerHTML = ''; return; }
    el.innerHTML = this._files.map(f => `
      <div class="queue-row" id="qrow-${CSS.escape(f.name)}">
        <span class="queue-icon">📄</span>
        <span class="queue-name">${escapeHtml(f.name)}</span>
        <span class="queue-size">${(f.size / 1024 / 1024).toFixed(1)} MB</span>
        <span class="queue-status" id="qstatus-${CSS.escape(f.name)}"></span>
        <button class="queue-remove" onclick="ImportPage.removeFile('${escapeHtml(f.name)}')" title="Remove">×</button>
      </div>`).join('');
  },

  _setRowStatus(name, html) {
    const el = document.getElementById(`qstatus-${CSS.escape(name)}`);
    if (el) el.innerHTML = html;
  },

  async runImport() {
    if (!this._files.length) return;

    // Load parser once
    if (!window.DnDPDFParser) {
      this._globalStatus('info', '⏳ Loading pdf.js library…');
      await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = '/pdf-parser.js';
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      });
    }

    const btn = document.getElementById('importBtn');
    btn.disabled = true;

    const totals = { added: {}, updated: {} };
    let succeeded = 0, failed = 0;

    // Process sequentially so we don't flood memory with huge PDFs
    for (const file of this._files) {
      this._setRowStatus(file.name, '<span style="color:var(--gold)">⏳ reading…</span>');
      btn.textContent = `Processing ${succeeded + failed + 1} / ${this._files.length}…`;

      try {
        const result = await window.DnDPDFParser.extractDnDContent(
          file,
          (stage, cur, total) => {
            const msgs = { loading:'loading…', reading:`page ${cur}/${total}`, parsing:'parsing…', done:'saving…' };
            this._setRowStatus(file.name, `<span style="color:var(--gold)">⏳ ${msgs[stage] || stage}</span>`);
          }
        );

        const res = await fetch('/api/import/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(result),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Save failed');

        // Accumulate totals
        for (const type of ['races','classes','backgrounds','feats','spells']) {
          totals.added[type] = (totals.added[type] || 0) + (data.counts.added[type] || 0);
          totals.updated[type] = (totals.updated[type] || 0) + (data.counts.updated[type] || 0);
        }

        const addedCount = Object.values(data.counts.added || {}).reduce((s, v) => s + (v || 0), 0);
        this._setRowStatus(file.name, `<span style="color:#4caf50">✅ +${addedCount} items</span>`);
        succeeded++;
      } catch (err) {
        this._setRowStatus(file.name, `<span style="color:var(--crimson)" title="${escapeHtml(err.message)}">❌ failed</span>`);
        failed++;
      }
    }

    btn.textContent = 'Extract & Import All';
    btn.disabled = false;

    // Summary
    const lines = [];
    for (const type of ['races','classes','backgrounds','feats','spells']) {
      const a = totals.added[type] || 0, u = totals.updated[type] || 0;
      if (a || u) lines.push(`${type}: +${a} new, ${u} updated`);
    }
    const summaryColor = failed === 0 ? '#4caf50' : succeeded === 0 ? 'var(--crimson)' : 'var(--gold)';
    this._globalStatus(failed === 0 ? 'success' : 'info', `
      <strong style="color:${summaryColor}">
        ${succeeded === this._files.length ? '✅ All done' : `✅ ${succeeded} done, ❌ ${failed} failed`}
      </strong><br>
      ${lines.join('<br>') || 'No new content found across these PDFs.'}
    `);

    DATA = await api.getData();
    this.loadLibrary();
  },

  _globalStatus(type, html) {
    const el = document.getElementById('importStatus');
    if (!el) return;
    const borderColor = type === 'error' ? 'var(--crimson)' : type === 'success' ? '#4caf50' : 'var(--border-dark)';
    el.innerHTML = `<div style="padding:14px;border-radius:var(--radius);background:var(--ink-panel);border:1px solid ${borderColor};">${html}</div>`;
  },

  async remove(type, id) {
    if (!confirm(`Remove "${id}" from the custom library?`)) return;
    await fetch(`/api/import/library/${type}/${encodeURIComponent(id)}`, { method: 'DELETE' });
    DATA = await api.getData();
    this.loadLibrary();
  },
};

window.ImportPage = ImportPage;

// ============ Boot ============
(async function init() {
  DATA = await api.getData();
  Router.go("list");
})();
