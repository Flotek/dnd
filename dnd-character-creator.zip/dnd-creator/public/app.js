// ============ Constants ============
const SKILLS = [
  ["Acrobatics", "dex"], ["Animal Handling", "wis"], ["Arcana", "int"], ["Athletics", "str"],
  ["Deception", "cha"], ["History", "int"], ["Insight", "wis"], ["Intimidation", "cha"],
  ["Investigation", "int"], ["Medicine", "wis"], ["Nature", "int"], ["Perception", "wis"],
  ["Performance", "cha"], ["Persuasion", "cha"], ["Religion", "int"], ["Sleight of Hand", "dex"],
  ["Stealth", "dex"], ["Survival", "wis"],
];
const ABILITIES = ["str", "dex", "con", "int", "wis", "cha"];
const ABILITY_NAMES = { str: "Strength", dex: "Dexterity", con: "Constitution", int: "Intelligence", wis: "Wisdom", cha: "Charisma" };
const STANDARD_ARRAY = [15, 14, 13, 12, 10, 8];
const POINT_BUY_COST = { 8: 0, 9: 1, 10: 2, 11: 3, 12: 4, 13: 5, 14: 7, 15: 9 };
const STEP_NAMES = ["Basics", "Race", "Class", "Background", "Ability Scores", "Skills & Feat", "Equipment", "Spells", "Review"];

// Official 5e spell slots by class type and level
// Full casters: Wizard, Sorcerer, Bard, Cleric, Druid
// Half casters: Paladin, Ranger (slots start at level 2, halved)
// Warlock: pact magic (separate — all slots same level, few in number)
const FULL_CASTER_SLOTS = {
  1:  [2,0,0,0,0,0,0,0,0],
  2:  [3,0,0,0,0,0,0,0,0],
  3:  [4,2,0,0,0,0,0,0,0],
  4:  [4,3,0,0,0,0,0,0,0],
  5:  [4,3,2,0,0,0,0,0,0],
  6:  [4,3,3,0,0,0,0,0,0],
  7:  [4,3,3,1,0,0,0,0,0],
  8:  [4,3,3,2,0,0,0,0,0],
  9:  [4,3,3,3,1,0,0,0,0],
  10: [4,3,3,3,2,0,0,0,0],
  11: [4,3,3,3,2,1,0,0,0],
  12: [4,3,3,3,2,1,0,0,0],
  13: [4,3,3,3,2,1,1,0,0],
  14: [4,3,3,3,2,1,1,0,0],
  15: [4,3,3,3,2,1,1,1,0],
  16: [4,3,3,3,2,1,1,1,0],
  17: [4,3,3,3,2,1,1,1,1],
  18: [4,3,3,3,3,1,1,1,1],
  19: [4,3,3,3,3,2,1,1,1],
  20: [4,3,3,3,3,2,2,1,1],
};
const HALF_CASTER_SLOTS = {
  1:  [0,0,0,0,0,0,0,0,0],
  2:  [2,0,0,0,0,0,0,0,0],
  3:  [3,0,0,0,0,0,0,0,0],
  4:  [3,0,0,0,0,0,0,0,0],
  5:  [4,2,0,0,0,0,0,0,0],
  6:  [4,2,0,0,0,0,0,0,0],
  7:  [4,3,0,0,0,0,0,0,0],
  8:  [4,3,0,0,0,0,0,0,0],
  9:  [4,3,2,0,0,0,0,0,0],
  10: [4,3,2,0,0,0,0,0,0],
  11: [4,3,3,0,0,0,0,0,0],
  12: [4,3,3,0,0,0,0,0,0],
  13: [4,3,3,1,0,0,0,0,0],
  14: [4,3,3,1,0,0,0,0,0],
  15: [4,3,3,2,0,0,0,0,0],
  16: [4,3,3,2,0,0,0,0,0],
  17: [4,3,3,3,1,0,0,0,0],
  18: [4,3,3,3,1,0,0,0,0],
  19: [4,3,3,3,2,0,0,0,0],
  20: [4,3,3,3,2,0,0,0,0],
};
const WARLOCK_SLOTS = {
  // [slotsPerRest, slotLevel]
  1:  [1,1], 2: [2,1], 3: [2,2], 4: [2,2], 5: [3,3],
  6:  [3,3], 7: [4,4], 8: [4,4], 9: [5,5], 10: [5,5],
  11: [5,5], 12: [5,5], 13: [5,5], 14: [5,5], 15: [5,5],
  16: [5,5], 17: [5,5], 18: [5,5], 19: [5,5], 20: [5,5],
};

// Spells Known by class and level (for "known" casters — Bard, Sorcerer, Ranger, Warlock)
const SPELLS_KNOWN = {
  bard:     [null, 4,5,6,7,8,9,10,11,12,14,15,15,16,18,19,19,20,22,22,22],
  sorcerer: [null, 2,3,4,5,6,7,8,9,10,11,12,12,13,13,14,14,15,15,15,15],
  ranger:   [null, 0,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11],
  warlock:  [null, 2,3,4,5,6,7,8,9,10,10,11,11,12,12,13,13,14,14,15,15],
};
// ASI / Feat opportunity levels per class
const ASI_LEVELS = {
  barbarian: [4,8,12,16,19],
  bard:      [4,8,12,16,19],
  cleric:    [4,8,12,16,19],
  druid:     [4,8,12,16,19],
  fighter:   [4,6,8,12,14,16,19],  // extra at 6 and 14
  monk:      [4,8,12,16,19],
  paladin:   [4,8,12,16,19],
  ranger:    [4,8,12,16,19],
  rogue:     [4,8,10,12,16,19],    // extra at 10
  sorcerer:  [4,8,12,16,19],
  warlock:   [4,8,12,16,19],
  wizard:    [4,8,12,16,19],
  artificer: [4,8,12,16,19],
};

// What each level unlocks for all classes
// Returns array of {type, label, detail} for a given class+level
function getLevelUnlocks(classId, level, subclassId) {
  const unlocks = [];
  const cls = getClass(classId);
  const subclassLevel = cls?.subclassLevel || 3;

  // Subclass selection
  if (level === subclassLevel) unlocks.push({type:'subclass', label:'Choose Your Subclass', detail:`Pick your ${cls?.name || ''} archetype`});

  // ASI / Feat
  const asiLevels = ASI_LEVELS[classId] || [4,8,12,16,19];
  if (asiLevels.includes(level)) unlocks.push({type:'asi_or_feat', label:'Ability Score Improvement or Feat', detail:'Increase two ability scores by 1, one by 2, or take a feat'});

  // Extra Attack
  const extraAttackLevels = {fighter:[5,11,20], barbarian:[5], paladin:[5], ranger:[5], monk:[5]};
  if (extraAttackLevels[classId]?.includes(level)) unlocks.push({type:'passive', label:'Extra Attack', detail:`You can attack twice (${level>=11&&classId==='fighter'?'three times':''}) when you take the Attack action`});

  // Class-specific unlocks
  const classUnlocks = getClassLevelUnlocks(classId, level, subclassId);
  unlocks.push(...classUnlocks);

  return unlocks;
}

function getClassLevelUnlocks(classId, level, subclassId) {
  const u = [];
  switch(classId) {
    case 'barbarian':
      if(level===1)  u.push({type:'passive',label:'Rage & Unarmored Defense',detail:'Rage: bonus action, resistance to B/P/S, damage bonus. Unarmored Defense: AC = 10 + DEX + CON'});
      if(level===2)  u.push({type:'passive',label:'Reckless Attack & Danger Sense',detail:'Reckless Attack: advantage on STR attacks (enemies get advantage back). Danger Sense: advantage on DEX saves you can see'});
      if(level===3)  u.push({type:'passive',label:'Primal Knowledge',detail:'Proficiency in one additional skill from Barbarian list'});
      if(level===5)  u.push({type:'passive',label:'Fast Movement',detail:'Speed increases by 10 ft while not wearing heavy armor'});
      if(level===7)  u.push({type:'passive',label:'Feral Instinct',detail:'Advantage on Initiative; can rage to act on surprise round'});
      if(level===9)  u.push({type:'passive',label:'Brutal Critical',detail:'Roll one additional damage die on critical hits with melee weapons'});
      if(level===10) u.push({type:'passive',label:'Primal Knowledge (2nd)',detail:'Proficiency in a second additional skill from Barbarian list'});
      if(level===11) u.push({type:'passive',label:'Relentless Rage',detail:'DC 10 CON save to drop to 1 HP instead of 0 while raging'});
      if(level===15) u.push({type:'passive',label:'Persistent Rage',detail:'Rage ends only if you fall unconscious or choose to end it'});
      if(level===17) u.push({type:'passive',label:'Brutal Critical (2nd die)',detail:'Roll two additional damage dice on melee critical hits'});
      if(level===18) u.push({type:'passive',label:'Indomitable Might',detail:'Minimum result of STR check equals your STR score'});
      if(level===20) u.push({type:'passive',label:'Primal Champion',detail:'+4 STR, +4 CON'});
      break;
    case 'bard':
      if(level===1)  u.push({type:'passive',label:'Bardic Inspiration & Spellcasting',detail:`Bardic Inspiration: d6 (scales with level). Charisma-based spellcasting.`});
      if(level===2)  u.push({type:'passive',label:'Jack of All Trades & Song of Rest',detail:'Add half proficiency to non-proficient checks. Song of Rest: allies regain 1d6 HP on short rest'});
      if(level===3)  u.push({type:'expertise',label:'Expertise',detail:'Choose 2 skills you know — double proficiency on those'});
      if(level===5)  u.push({type:'passive',label:'Bardic Inspiration: d8 & Font of Inspiration',detail:'Inspiration die upgrades to d8; recover all uses on short rest'});
      if(level===6)  u.push({type:'passive',label:'Countercharm',detail:'Use action to grant advantage on saves vs charm/frighten to nearby allies'});
      if(level===10) u.push({type:'expertise',label:'Expertise (2nd)',detail:'Choose 2 more skills for double proficiency'});
      if(level===10) u.push({type:'passive',label:'Bardic Inspiration: d10',detail:'Inspiration die upgrades to d10'});
      if(level===15) u.push({type:'passive',label:'Bardic Inspiration: d12',detail:'Inspiration die upgrades to d12'});
      if(level===20) u.push({type:'passive',label:'Superior Inspiration',detail:'Regain one Bardic Inspiration use when you roll initiative with none left'});
      break;
    case 'cleric':
      if(level===1)  u.push({type:'passive',label:'Divine Domain & Spellcasting',detail:'Choose your domain subclass. Wisdom-based spellcasting'});
      if(level===2)  u.push({type:'passive',label:'Channel Divinity (1 use)',detail:'Use domain-specific Channel Divinity options. Turn Undead available to all clerics'});
      if(level===5)  u.push({type:'passive',label:'Destroy Undead (CR 1/2)',detail:'Undead that fail Turn Undead save are destroyed if CR ≤ 1/2'});
      if(level===6)  u.push({type:'passive',label:'Channel Divinity (2 uses)',detail:'Gain a second Channel Divinity use per short rest'});
      if(level===8)  u.push({type:'passive',label:'Destroy Undead (CR 1)',detail:'Destroy undead of CR 1 or lower'});
      if(level===10) u.push({type:'passive',label:'Divine Intervention',detail:'Implore your deity for aid (% chance = cleric level). Recharges on long rest on success'});
      if(level===11) u.push({type:'passive',label:'Destroy Undead (CR 2)',detail:'Destroy undead of CR 2 or lower'});
      if(level===14) u.push({type:'passive',label:'Destroy Undead (CR 3)',detail:'Destroy undead of CR 3 or lower'});
      if(level===17) u.push({type:'passive',label:'Destroy Undead (CR 4)',detail:'Destroy undead of CR 4 or lower'});
      if(level===18) u.push({type:'passive',label:'Channel Divinity (3 uses)',detail:'Gain a third Channel Divinity use per short rest'});
      if(level===20) u.push({type:'passive',label:'Divine Intervention (Guaranteed)',detail:'Divine Intervention now succeeds automatically'});
      break;
    case 'druid':
      if(level===1)  u.push({type:'passive',label:'Druidic & Spellcasting',detail:'Know Druidic secret language. Wisdom-based prepared spellcasting'});
      if(level===2)  u.push({type:'passive',label:'Wild Shape (2 uses)',detail:'Transform into beasts up to CR 1/4 (no swim/fly). CR limit increases with level'});
      if(level===4)  u.push({type:'passive',label:'Wild Shape improvement',detail:'Wild Shape into CR 1/2 beasts with swim speed'});
      if(level===8)  u.push({type:'passive',label:'Wild Shape improvement',detail:'Wild Shape into CR 1 beasts with fly speed'});
      if(level===18) u.push({type:'passive',label:'Timeless Body & Beast Spells',detail:'Age 10x slower. Cast spells in Wild Shape form'});
      if(level===20) u.push({type:'passive',label:'Archdruid',detail:'Unlimited Wild Shape uses'});
      break;
    case 'fighter':
      if(level===1)  u.push({type:'choice',label:'Fighting Style',detail:'Choose a fighting style',options:['Archery','Defense','Dueling','Great Weapon Fighting','Protection','Two-Weapon Fighting','Blind Fighting','Interception','Superior Technique','Thrown Weapon Fighting','Unarmed Fighting'],key:'fighting_style_1'});
      if(level===1)  u.push({type:'passive',label:'Second Wind',detail:'Bonus action: regain 1d10 + fighter level HP (short/long rest)'});
      if(level===2)  u.push({type:'passive',label:'Action Surge',detail:'Take one additional action on your turn (short/long rest)'});
      if(level===5)  u.push({type:'passive',label:'Extra Attack',detail:'Attack twice when you take the Attack action'});
      if(level===9)  u.push({type:'passive',label:'Indomitable',detail:'Reroll a failed saving throw (1/long rest; 2 uses at 13th, 3 at 17th)'});
      if(level===11) u.push({type:'passive',label:'Extra Attack (3)',detail:'Attack three times when you take the Attack action'});
      if(level===13) u.push({type:'passive',label:'Indomitable (2 uses)',detail:'Two uses of Indomitable per long rest'});
      if(level===17) u.push({type:'passive',label:'Indomitable (3 uses)',detail:'Three uses of Indomitable per long rest; Action Surge recharges to 2 uses'});
      if(level===20) u.push({type:'passive',label:'Extra Attack (4)',detail:'Attack four times when you take the Attack action'});
      break;
    case 'monk':
      if(level===1)  u.push({type:'passive',label:'Unarmored Defense & Martial Arts',detail:'AC = 10+DEX+WIS unarmored. Martial arts die: d4 (scales). Bonus unarmed strike after unarmed/monk weapon attack'});
      if(level===2)  u.push({type:'passive',label:'Ki Points & Unarmored Movement',detail:`Ki Points = level (short rest). Flurry of Blows, Patient Defense, Step of the Wind. Speed +10 ft`});
      if(level===3)  u.push({type:'passive',label:'Deflect Missiles & Slow Fall',detail:'Reaction to reduce ranged hit damage. Reaction to reduce fall damage by 5×level'});
      if(level===5)  u.push({type:'passive',label:'Stunning Strike & Extra Attack',detail:'Spend 1 ki after hitting to stun target (CON save). Attack twice'});
      if(level===6)  u.push({type:'passive',label:'Ki-Empowered Strikes',detail:'Unarmed strikes count as magical'});
      if(level===7)  u.push({type:'passive',label:'Evasion & Stillness of Mind',detail:'DEX save: no damage on success. Action to end charm/frighten on self'});
      if(level===10) u.push({type:'passive',label:'Purity of Body',detail:'Immune to disease and poison'});
      if(level===13) u.push({type:'passive',label:'Tongue of the Sun and Moon',detail:'Understand all spoken languages; all creatures understand you'});
      if(level===14) u.push({type:'passive',label:'Diamond Soul',detail:'Proficiency in all saves; spend 1 ki to reroll a failed save'});
      if(level===15) u.push({type:'passive',label:'Timeless Body',detail:'No longer need food or water; age 10x slower'});
      if(level===18) u.push({type:'passive',label:'Empty Body',detail:'4 ki: invisible and resistant to all but force for 1 minute. 8 ki: Astral Projection'});
      if(level===20) u.push({type:'passive',label:'Perfect Self',detail:'Regain 4 ki when you roll initiative with none remaining'});
      break;
    case 'paladin':
      if(level===1)  u.push({type:'passive',label:'Divine Sense & Lay on Hands',detail:`Detect fiends/celestials/undead within 60 ft. Lay on Hands: ${level*5} HP healing pool`});
      if(level===2)  u.push({type:'choice',label:'Fighting Style',detail:'Choose a Paladin fighting style',options:['Defense','Dueling','Great Weapon Fighting','Protection','Blessed Warrior','Blind Fighting','Interception'],key:'fighting_style_1'});
      if(level===2)  u.push({type:'passive',label:'Spellcasting & Divine Smite',detail:'CHA-based spellcasting. Divine Smite: expend slot on hit for 2d8+ radiant'});
      if(level===5)  u.push({type:'passive',label:'Extra Attack & Divine Health',detail:'Attack twice. Immune to disease'});
      if(level===6)  u.push({type:'passive',label:'Aura of Protection',detail:'You and friendly creatures within 10 ft add CHA modifier to all saving throws'});
      if(level===10) u.push({type:'passive',label:'Aura of Courage',detail:'You and friendly creatures within 10 ft cannot be frightened while you\'re conscious'});
      if(level===11) u.push({type:'passive',label:'Improved Divine Smite',detail:'+1d8 radiant damage on all melee weapon hits'});
      if(level===14) u.push({type:'passive',label:'Cleansing Touch',detail:'Use action to end one spell on a willing creature (CHA mod uses/long rest)'});
      if(level===18) u.push({type:'passive',label:'Auras improve to 30 ft',detail:'Aura of Protection and Aura of Courage now extend to 30 ft'});
      break;
    case 'ranger':
      if(level===1)  u.push({type:'passive',label:'Favored Enemy & Natural Explorer',detail:'Choose a favored enemy type and a favored terrain'});
      if(level===2)  u.push({type:'choice',label:'Fighting Style',detail:'Choose a Ranger fighting style',options:['Archery','Defense','Dueling','Two-Weapon Fighting','Blind Fighting','Thrown Weapon Fighting'],key:'fighting_style_1'});
      if(level===2)  u.push({type:'passive',label:'Spellcasting',detail:'WIS-based spellcasting. Spell slots recover on long rest'});
      if(level===3)  u.push({type:'passive',label:'Primeval Awareness',detail:'Expend spell slot to sense creature types within 1 mile (6 in favored terrain)'});
      if(level===5)  u.push({type:'passive',label:'Extra Attack',detail:'Attack twice when you take the Attack action'});
      if(level===6)  u.push({type:'passive',label:'Favored Enemy & Natural Explorer (2nd)',detail:'Choose an additional favored enemy and terrain'});
      if(level===8)  u.push({type:'passive',label:'Land\'s Stride',detail:'Move through nonmagical difficult terrain without cost; advantage vs magical plants'});
      if(level===10) u.push({type:'passive',label:'Hide in Plain Sight',detail:'Spend 1 minute to hide while motionless in natural surroundings (+10 to Stealth)'});
      if(level===14) u.push({type:'passive',label:'Vanish',detail:'Hide as a bonus action; can\'t be tracked by nonmagical means'});
      if(level===18) u.push({type:'passive',label:'Feral Senses',detail:'No disadvantage while attacking invisible creatures; aware of invisible within 30 ft'});
      if(level===20) u.push({type:'passive',label:'Foe Slayer',detail:'Once per turn, add WIS modifier to attack or damage against favored enemy'});
      break;
    case 'rogue':
      if(level===1)  u.push({type:'expertise',label:'Expertise (2 skills)',detail:'Double proficiency bonus on two skills you are proficient in'});
      if(level===1)  u.push({type:'passive',label:'Sneak Attack & Thieves\' Cant',detail:`Sneak Attack: +${Math.ceil(level/2)}d6 once per turn with finesse/ranged weapon when you have advantage or ally is adjacent. Know Thieves' Cant`});
      if(level===2)  u.push({type:'passive',label:'Cunning Action',detail:'Bonus action: Dash, Disengage, or Hide'});
      if(level===5)  u.push({type:'passive',label:'Uncanny Dodge',detail:'Reaction: halve damage from an attacker you can see'});
      if(level===6)  u.push({type:'expertise',label:'Expertise (2 more skills)',detail:'Choose 2 more skills for double proficiency'});
      if(level===7)  u.push({type:'passive',label:'Evasion',detail:'DEX save: no damage on success, half on fail'});
      if(level===11) u.push({type:'passive',label:'Reliable Talent',detail:'Treat d20 rolls of 9 or lower as 10 for proficient ability checks'});
      if(level===14) u.push({type:'passive',label:'Blindsense',detail:'Aware of hidden/invisible creatures within 10 ft'});
      if(level===15) u.push({type:'passive',label:'Slippery Mind',detail:'Proficiency in WIS saving throws'});
      if(level===18) u.push({type:'passive',label:'Elusive',detail:'No attack roll has advantage against you while you\'re not incapacitated'});
      if(level===20) u.push({type:'passive',label:'Stroke of Luck',detail:'Turn a missed attack into a hit, or a failed check into a 20 (1/short or long rest)'});
      break;
    case 'sorcerer':
      if(level===1)  u.push({type:'passive',label:'Spellcasting & Sorcerous Origin',detail:'CHA-based spellcasting. Origin grants features at levels 1, 6, 14, 18'});
      if(level===2)  u.push({type:'passive',label:'Font of Magic — Sorcery Points',detail:`${level} Sorcery Points (long rest). Convert to slots or use for Metamagic`});
      if(level===3)  u.push({type:'choice',label:'Metamagic (choose 2)',detail:'Choose your first two Metamagic options',options:['Careful','Distant','Empowered','Extended','Heightened','Quickened','Subtle','Twinned'],key:'metamagic',multi:2});
      if(level===10) u.push({type:'choice',label:'Metamagic (choose 1 more)',detail:'Learn a third Metamagic option',options:['Careful','Distant','Empowered','Extended','Heightened','Quickened','Subtle','Twinned','Transmuted','Seeking'],key:'metamagic_3',multi:1});
      if(level===17) u.push({type:'choice',label:'Metamagic (choose 1 more)',detail:'Learn a fourth Metamagic option',options:['Careful','Distant','Empowered','Extended','Heightened','Quickened','Subtle','Twinned','Transmuted','Seeking'],key:'metamagic_4',multi:1});
      if(level===20) u.push({type:'passive',label:'Sorcerous Restoration',detail:'Regain 4 Sorcery Points on short rest'});
      break;
    case 'warlock':
      if(level===1)  u.push({type:'passive',label:'Otherworldly Patron & Pact Magic',detail:'CHA-based spellcasting with short-rest slots. Patron grants features at levels 1, 6, 10, 14'});
      if(level===2)  u.push({type:'choice',label:'Eldritch Invocations (choose 2)',detail:'Gain 2 Eldritch Invocations. Gain more at levels 5, 7, 9, 12, 15, 18',options:['Agonizing Blast','Armor of Shadows','Ascendant Step','Beast Speech','Beguiling Influence','Bewitching Whispers','Book of Ancient Secrets','Chains of Carceri','Devil\'s Sight','Dreadful Word','Eldritch Sight','Eldritch Spear','Eyes of the Rune Keeper','Fiendish Vigor','Gaze of Two Minds','Gift of the Ever-Living Ones','Grasp of Hadar','Improved Pact Weapon','Lance of Lethargy','Lifedrinker','Mask of Many Faces','Master of Myriad Forms','Minions of Chaos','Mire the Mind','Misty Visions','One with Shadows','Otherworldly Leap','Repelling Blast','Sculptor of Flesh','Sign of Ill Omen','Thief of Five Fates','Thirsting Blade','Tomb of Levistus','Trickster\'s Escape','Visions of Distant Realms','Voice of the Chain Master','Whispers of the Grave','Witch Sight'],key:'invocations',multi:2});
      if(level===3)  u.push({type:'choice',label:'Pact Boon',detail:'Choose your Pact Boon',options:['Pact of the Blade','Pact of the Chain','Pact of the Tome'],key:'pact_boon'});
      if(level===11) u.push({type:'passive',label:'Mystic Arcanum (6th level)',detail:'Cast one 6th-level spell without a spell slot (1/long rest)'});
      if(level===13) u.push({type:'passive',label:'Mystic Arcanum (7th level)',detail:'Cast one 7th-level spell without a spell slot (1/long rest)'});
      if(level===15) u.push({type:'passive',label:'Mystic Arcanum (8th level)',detail:'Cast one 8th-level spell without a spell slot (1/long rest)'});
      if(level===17) u.push({type:'passive',label:'Mystic Arcanum (9th level)',detail:'Cast one 9th-level spell without a spell slot (1/long rest)'});
      if(level===20) u.push({type:'passive',label:'Eldritch Master',detail:'Spend 1 minute to regain all Pact Magic slots (1/long rest)'});
      break;
    case 'wizard':
      if(level===1)  u.push({type:'passive',label:'Spellcasting & Arcane Recovery',detail:'INT-based spellcasting. Arcane Recovery: regain spell slots on short rest (up to half level)'});
      if(level===2)  u.push({type:'passive',label:'Arcane Tradition',detail:'Your school/tradition grants features at 2, 6, 10, 14'});
      if(level===18) u.push({type:'passive',label:'Spell Mastery',detail:'Cast one 1st-level and one 2nd-level spell at will (without slots)'});
      if(level===20) u.push({type:'passive',label:'Signature Spells',detail:'Always have two 3rd-level spells prepared; cast each once per day without a slot'});
      break;
  }
  return u;
}
// levels 10, 14, 18 — each grants 2 spells from any class
const MAGICAL_SECRETS_LEVELS = [10, 14, 18];
function getMagicalSecretsCount(classId, level) {
  if (classId !== "bard") return 0;
  return MAGICAL_SECRETS_LEVELS.filter(l => level >= l).length * 2;
}
// Cantrips Known by class and level
const CANTRIPS_KNOWN = {
  bard:     [null, 2,2,2,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4],
  sorcerer: [null, 4,4,4,5,5,5,6,6,6,6,6,6,6,6,6,6,6,6,6],
  wizard:   [null, 3,3,3,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5],
  cleric:   [null, 3,3,3,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5],
  druid:    [null, 2,2,2,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4],
  warlock:  [null, 2,2,2,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4],
};
const FULL_CASTERS  = new Set(["bard","cleric","druid","sorcerer","wizard"]);
const HALF_CASTERS  = new Set(["paladin","ranger"]);

function getSpellSlots(classId, level) {
  if (!classId) return null;
  if (classId === "warlock") {
    const [count, slotLevel] = WARLOCK_SLOTS[level] || [0,0];
    return { type: "pact", slots: [{ level: slotLevel, max: count }] };
  }
  let table = null;
  if (FULL_CASTERS.has(classId))  table = FULL_CASTER_SLOTS;
  if (HALF_CASTERS.has(classId))  table = HALF_CASTER_SLOTS;
  if (!table) return null;
  const row = table[level] || table[20];
  const slots = row.map((max, i) => ({ level: i + 1, max })).filter(s => s.max > 0);
  return slots.length ? { type: "full", slots } : null;
}

// How much a class contributes to the multiclass spellcaster level (PHB p.164)
const THIRD_CASTER_SUBS = new Set(['eldritch-knight','eldritch-knight-2024','arcane-trickster','arcane-trickster-2024']);
function casterLevelContribution(classId, level, subclassId) {
  if (!classId || !level) return 0;
  if (classId === 'warlock') return 0;                       // Pact Magic is separate
  if (FULL_CASTERS.has(classId)) return level;               // bard/cleric/druid/sorcerer/wizard
  if (classId === 'artificer')   return Math.ceil(level / 2); // artificer rounds up
  if (HALF_CASTERS.has(classId)) return Math.floor(level / 2);// paladin/ranger round down
  if (THIRD_CASTER_SUBS.has(subclassId)) return Math.floor(level / 3);
  return 0;
}

// Spell slots accounting for every class the character has levels in.
function getEffectiveSpellSlots(c) {
  if (!c || !c.classId) return null;
  const entries = [
    { classId: c.classId, level: getPrimaryLevel(c), subclassId: c.subclassId },
    ...(c.multiclasses || []).map(m => ({ classId: m.classId, level: m.level || 0, subclassId: m.subclassId })),
  ].filter(e => e.level > 0);

  const warlock = entries.find(e => e.classId === 'warlock');
  const casters = entries.filter(e => casterLevelContribution(e.classId, e.level, e.subclassId) > 0);

  let main = null;
  if (casters.length === 1) {
    // Single spellcasting class — use that class's own table (half casters differ from the shared table)
    const only = casters[0];
    main = getSpellSlots(only.classId, only.level)
        || (THIRD_CASTER_SUBS.has(only.subclassId)
              ? slotsFromFullTable(Math.floor(only.level / 3))
              : null);
  } else if (casters.length > 1) {
    // Two or more — sum contributions and read the shared multiclass table
    const total = casters.reduce((s, e) => s + casterLevelContribution(e.classId, e.level, e.subclassId), 0);
    main = slotsFromFullTable(total);
  }

  const pact = warlock ? getSpellSlots('warlock', warlock.level) : null;
  if (main && pact) return { type: 'full', slots: main.slots, pact: pact.slots };
  return main || pact;
}

const CASTER_ABILITY_MAP = {
  bard:"cha", cleric:"wis", druid:"wis", paladin:"cha",
  ranger:"wis", sorcerer:"cha", warlock:"cha", wizard:"int", artificer:"int",
};

// Every class the character can actually cast from, primary + multiclass.
// Returns [{classId, level, subclassId, ability}] sorted by level descending.
function getCastingClasses(c) {
  if (!c || !c.classId) return [];
  const consider = [
    { classId: c.classId, level: getPrimaryLevel(c), subclassId: c.subclassId },
    ...(c.multiclasses || []).map(m => ({ classId: m.classId, level: m.level || 0, subclassId: m.subclassId })),
  ].filter(e => e.level > 0);

  const out = [];
  for (const e of consider) {
    const ability = CASTER_ABILITY_MAP[e.classId];
    if (ability) out.push({ ...e, ability });
    else if (THIRD_CASTER_SUBS.has(e.subclassId)) out.push({ ...e, ability: 'int' }); // EK / Arcane Trickster
  }
  return out.sort((a, b) => b.level - a.level);
}

function slotsFromFullTable(casterLevel) {
  if (!casterLevel || casterLevel < 1) return null;
  const row = FULL_CASTER_SLOTS[Math.min(20, casterLevel)] || FULL_CASTER_SLOTS[20];
  const slots = row.map((max, i) => ({ level: i + 1, max })).filter(s => s.max > 0);
  return slots.length ? { type: 'full', slots } : null;
}

// ============ Global state ============
let DATA = null; // { races, classes, backgrounds, feats, spells, equipment }
let state = { view: "list", step: 0, editingId: null, character: null, charList: [], levelUpChoices: {} };

function blankCharacter() {
  return {
    name: "", level: 1,
    raceId: null, classId: null, subclassId: null, backgroundId: null,
    abilityMethod: "standard", baseScores: { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 },
    halfElfChoices: [],
    classSkillChoices: [], feat: null,
    featChoices: {},
    subclassChoices: {},
    asiChoices: {},
    multiclasses: [],      // [{classId, level, subclassId}] for additional classes
    featsGranted: {},        // { "race_1": {featId, choices}, "class_4": {type:"feat"|"asi", ...} }
    levelHistory: [],        // array of level-up records for display
    equipmentChoice: null, armorId: null, shield: false, extraGear: "",
    cantrips: [], spellsKnown: [],
    spellSlots: {},        // { "1": usedCount, … }
    currentHp: null,       // null = at max; set to a number when damaged
    hitDiceUsed: 0,        // how many hit dice spent this rest cycle
    tempHp: 0,             // temporary hit points
    tempAc: 0,             // temporary AC bonus
    manualMaxHp: null,     // null = use computed value; set to override HP max
    resources: {},         // { resourceId: usedAmount } — class/race resource tracking
    notes: "",
  };
}

// ============ API ============
const api = {
  async getData() { return (await fetch("/api/data?v=" + Date.now())).json(); },
  async listCharacters() { return (await fetch("/api/characters")).json(); },
  async getCharacter(id) { return (await fetch(`/api/characters/${id}`)).json(); },
  async saveCharacter(char, id) {
    const body = JSON.stringify({ ...char, raceId: char.raceId, classId: char.classId, subclassId: char.subclassId, backgroundId: char.backgroundId });
    const res = await fetch(id ? `/api/characters/${id}` : "/api/characters", {
      method: id ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body,
    });
    return res.json();
  },
  async deleteCharacter(id) { return (await fetch(`/api/characters/${id}`, { method: "DELETE" })).json(); },
};

// ============ Helpers ============
function abilityMod(score) { const n = parseInt(score); return isNaN(n) ? 0 : Math.floor((n - 10) / 2); }
function fmtMod(n) { const num = typeof n === 'number' && !isNaN(n) ? n : 0; return num >= 0 ? `+${num}` : `${num}`; }
// Total character level is c.level. Primary class level = total - sum of MC levels.
function getPrimaryLevel(c) {
  const mcTotal = (c.multiclasses || []).reduce((sum, mc) => sum + (parseInt(mc.level) || 0), 0);
  return Math.max(1, (parseInt(c.level) || 1) - mcTotal);
}

// Returns a display string like "Bard 8 / Barbarian 1"
function getClassLevelString(c) {
  const cls = getClass(c.classId);
  const primaryLvl = getPrimaryLevel(c);
  const parts = [`${cls?.name || c.classId} ${primaryLvl}`];
  for (const mc of (c.multiclasses || [])) {
    const mcCls = getClass(mc.classId);
    parts.push(`${mcCls?.name || mc.classId} ${mc.level}`);
  }
  return parts.join(' / ');
}

function proficiencyBonus(level) { const l = parseInt(level) || 1; return 2 + Math.floor((l - 1) / 4); }

function getRace(id) { return (DATA?.races || []).find(r => r.id === id) || null; }
function getClass(id) { return (DATA?.classes || []).find(c => c.id === id) || null; }
function getBackground(id) { return (DATA?.backgrounds || []).find(b => b.id === id) || null; }

function finalAbilityScores(c) {
  const base = { str: 10, dex: 10, con: 10, int: 10, wis: 10, cha: 10 };
  const scores = { ...base, ...(c.baseScores || {}) };
  // Ensure all values are numbers
  for (const k of ABILITIES) scores[k] = parseInt(scores[k]) || 10;
  const race = getRace(c.raceId);
  if (race) {
    for (const [k, v] of Object.entries(race.abilityBonuses || {})) {
      if (k === "choose_two") continue;
      if (ABILITIES.includes(k)) scores[k] = (scores[k] || 10) + (parseInt(v) || 0);
    }
    if (race.abilityBonuses && race.abilityBonuses.choose_two) {
      for (const ab of (c.halfElfChoices || [])) scores[ab] = (scores[ab] || 10) + 1;
    }
  }

  // Apply all ASI choices from the wizard (one per eligible level)
  // Apply ASI choices — iterate ALL stored keys (includes 'vh_1', '4', '8', etc.)
  for (const [slotKey, choice] of Object.entries(c.asiChoices || {})) {
    if (!choice) continue;
    if (choice.type === 'asi') {
      if (choice.ab1 && ABILITIES.includes(choice.ab1)) scores[choice.ab1] = Math.min(20, (scores[choice.ab1]||10) + 1);
      if (choice.ab2 && ABILITIES.includes(choice.ab2)) scores[choice.ab2] = Math.min(20, (scores[choice.ab2]||10) + 1);
    }
    if (choice.type === 'feat') {
      const fc = choice.featChoices || {};
      const featId = choice.featId;
      // All player-choice ability fields across every feat
      const allChoiceFields = ['stat_boost','res_ability','fey_ability','shadow_ability','tk_ability','tp_ability','obs_ability',
        'crush_stat','pierce_stat','slash_stat','brawler_stat','chef_stat','fade_stat','second_stat','gem_stat',
        'flash_stat','revenant_stat','boon_off_stat','weapon_master_stat',
        'fey_tele_ability','ea_ability','sn_ability','of_ability','fp_ability','dh_ability','dbh_ability'];
      allChoiceFields.forEach(field => {
        if (fc[field] && ABILITIES.includes(fc[field])) scores[fc[field]] = Math.min(20, (scores[fc[field]]||10) + 1);
      });
      // Fixed-ability feats
      if (featId === 'actor')               scores.cha = Math.min(20, (scores.cha||10) + 1);
      if (featId === 'aberrant-dragonmark') scores.con = Math.min(20, (scores.con||10) + 1);
      if (featId === 'heavily-armored')     scores.str = Math.min(20, (scores.str||10) + 1);
      if (featId === 'heavy-armor-master')  scores.str = Math.min(20, (scores.str||10) + 1);
      if (featId === 'durable')             scores.con = Math.min(20, (scores.con||10) + 1);
      if (featId === 'keen-mind')           scores.int = Math.min(20, (scores.int||10) + 1);
      if (featId === 'linguist')            scores.int = Math.min(20, (scores.int||10) + 1);
      if (featId === 'empathic')            scores.wis = Math.min(20, (scores.wis||10) + 1);
      if (featId === 'gunner')              scores.dex = Math.min(20, (scores.dex||10) + 1);
    }
  }

  // Also apply level-up ASI history (featsGranted from level-up flow)
  for (const [, entry] of Object.entries(c.featsGranted || {})) {
    if (entry.type === 'asi') {
      if (entry.ab1 && ABILITIES.includes(entry.ab1)) scores[entry.ab1] = Math.min(20, (scores[entry.ab1]||10) + 1);
      if (entry.ab2 && ABILITIES.includes(entry.ab2)) scores[entry.ab2] = Math.min(20, (scores[entry.ab2]||10) + 1);
    }
  }

  // Apply legacy single feat stat bonuses (c.feat / c.featChoices)
  const lfc = c.featChoices || {};
  // Fixed +1 ability feats
  if (c.feat === 'actor')               scores.cha = Math.min(20, (scores.cha||10) + 1);
  if (c.feat === 'aberrant-dragonmark') scores.con = Math.min(20, (scores.con||10) + 1);
  if (c.feat === 'durable')             scores.con = Math.min(20, (scores.con||10) + 1);
  if (c.feat === 'empathic')            scores.wis = Math.min(20, (scores.wis||10) + 1);
  if (c.feat === 'heavily-armored')     scores.str = Math.min(20, (scores.str||10) + 1);
  if (c.feat === 'heavy-armor-master')  scores.str = Math.min(20, (scores.str||10) + 1);
  if (c.feat === 'gunner')              scores.dex = Math.min(20, (scores.dex||10) + 1);
  if (c.feat === 'keen-mind')           scores.int = Math.min(20, (scores.int||10) + 1);
  if (c.feat === 'linguist')            scores.int = Math.min(20, (scores.int||10) + 1);
  if (c.feat === 'infernal-constitution') scores.con = Math.min(20, (scores.con||10) + 1);
  // Player-choice +1 ability feats
  const choiceFields = ['stat_boost','res_ability','fey_ability','shadow_ability','tk_ability','tp_ability','obs_ability',
    'crush_stat','pierce_stat','slash_stat','brawler_stat','chef_stat','fade_stat','second_stat','gem_stat',
    'flash_stat','revenant_stat','boon_off_stat','weapon_master_stat',
    'fey_tele_ability','ea_ability','sn_ability','of_ability','fp_ability','dh_ability','dbh_ability'];
  choiceFields.forEach(field => {
    if (lfc[field] && ABILITIES.includes(lfc[field])) scores[lfc[field]] = Math.min(20, (scores[lfc[field]]||10) + 1);
  });

  return scores;
}

function computeHP(c) {
  const cls = getClass(c.classId);
  if (!cls) return c.manualMaxHp || null;
  if (c.manualMaxHp != null && c.manualMaxHp > 0) return c.manualMaxHp;
  const scores = finalAbilityScores(c);
  const conMod = abilityMod(scores.con);
  const level = parseInt(c.level) || 1;
  const hitDie = parseInt(cls.hitDie) || 8;
  const hillDwarfBonus = (getRace(c.raceId)?.traits || []).some(t => t.includes("Dwarven Toughness")) ? level : 0;
  let hp = hitDie + conMod;
  for (let lvl = 2; lvl <= level; lvl++) hp += Math.floor(hitDie / 2) + 1 + conMod;
  const { hpBonus } = computeFeatBonuses(c);
  return Math.max(1, hp + hillDwarfBonus + hpBonus);
}

// Compute non-ability-score bonuses from feats (initiative, speed, HP, AC)
function computeFeatBonuses(c) {
  let initiative = 0, speed = 0, hpBonus = 0, acBonus = 0;

  function applyFeat(featId) {
    if (featId === 'alert')          initiative += 5;
    if (featId === 'mobile')         speed += 10;
    if (featId === 'boon-of-speed')  speed += 30;
    if (featId === 'tough')          hpBonus += c.level * 2;
    if (featId === 'boon-of-fortitude') hpBonus += 40;
    if (featId === 'dual-wielder')   acBonus += 1; // +1 AC while dual-wielding (approximate)
  }

  if (c.feat) applyFeat(c.feat);
  for (const choice of Object.values(c.asiChoices || {})) {
    if (choice?.type === 'feat' && choice.featId) applyFeat(choice.featId);
  }

  return { initiative, speed, hpBonus, acBonus };
}

function computeAC(c) {
  const scores = finalAbilityScores(c);
  const dexMod = abilityMod(scores.dex);
  const strMod = abilityMod(scores.str);
  const conMod = abilityMod(scores.con);
  const wisMod = abilityMod(scores.wis);
  const armor = (DATA?.equipment?.armor || []).find(a => a.name === c.armorId);
  const shieldBonus = c.shield ? 2 : 0;
  const { acBonus } = computeFeatBonuses(c);

  const allClassIds = [c.classId, ...(c.multiclasses||[]).map(m=>m.classId)];
  const allSubclassIds = [c.subclassId, ...(c.multiclasses||[]).map(m=>m.subclassId)];

  if (!armor) {
    if (c.raceId === 'tortle')     return 17 + shieldBonus + acBonus;
    if (c.raceId === 'lizardfolk') return 13 + dexMod + shieldBonus + acBonus;
    // Barbarian unarmored: 10 + DEX + CON (check primary and multiclass)
    if (allClassIds.includes('barbarian')) return 10 + dexMod + conMod + shieldBonus + acBonus;
    // Monk unarmored: 10 + DEX + WIS
    if (allClassIds.includes('monk'))      return 10 + dexMod + wisMod + shieldBonus + acBonus;
    // Draconic Sorcerer: 13 + DEX
    if (allClassIds.includes('sorcerer') && allSubclassIds.includes('draconic')) return 13 + dexMod + shieldBonus + acBonus;
  }

  const warforgedBonus = c.raceId === 'warforged' ? 1 : 0;

  if (!armor) return 10 + dexMod + shieldBonus + warforgedBonus + acBonus;

  let dexBonus = 0;
  if (armor.addDex) dexBonus = armor.dexCap != null ? Math.min(dexMod, armor.dexCap) : dexMod;
  return (parseInt(armor.baseAC) || 10) + dexBonus + shieldBonus + warforgedBonus + acBonus;
}

function classSkillCount(c) {
  const cls = getClass(c.classId);
  return cls ? cls.skillChoices.count : 0;
}

function backgroundSkills(c) {
  const bg = getBackground(c.backgroundId);
  return bg ? bg.skillProficiencies : [];
}

// Returns a Map of skillName → 'proficient' | 'expertise' | 'half' (Jack of All Trades)
function allSkillProficiencies(c) {
  const result = new Map(); // name → 'proficient' | 'expertise'
  const fc = c.featChoices || {};
  const sc = c.subclassChoices || {};
  const cls = getClass(c.classId);
  const race = getRace(c.raceId);
  const lvl = c.level;

  function addProf(skills) {
    (skills || []).forEach(sk => { if (sk && !result.has(sk)) result.set(sk, 'proficient'); });
  }
  function addExpertise(skills) {
    (skills || []).forEach(sk => { if (sk) result.set(sk, 'expertise'); });
  }

  // 1. Class chosen skills
  addProf(c.classSkillChoices || []);

  // 2. Background skills
  addProf(backgroundSkills(c));

  // 3. Race skill proficiencies (from race data)
  if (race?.skillProficiencies) addProf(race.skillProficiencies);

  // 3b. Race-specific skill picks stored in subclassChoices
  if (c.raceId === 'half-elf')      addProf(sc.half_elf_skills || []);
  if (c.raceId === 'wood-elf')      addProf(['Perception','Stealth']);
  if (c.raceId === 'dark-elf')      addProf(['Perception']);
  if (c.raceId === 'variant-human') addProf(sc.human_skill ? [sc.human_skill] : []);
  if (c.raceId === 'changeling')    addProf(sc.changeling_skills || []);
  if (c.raceId === 'warforged')     addProf(sc.warforged_skill ? [sc.warforged_skill] : []);
  if (c.raceId === 'bugbear')       addProf(['Stealth']);
  if (c.raceId === 'hobgoblin')     addProf(['Athletics','Intimidation']);
  if (c.raceId === 'kenku')         addProf(['Deception','Stealth']);
  if (c.raceId === 'tabaxi')        addProf(['Perception','Stealth']);
  if (c.raceId === 'lizardfolk')    addProf(['Perception','Stealth','Nature','Survival']);

  // 4. Feat skills — from the legacy single feat field
  if (c.feat === 'skilled'   && fc.skilled_picks?.length)  addProf(fc.skilled_picks);
  if (c.feat === 'empathic')                               addProf(['Insight']);
  if (c.feat === 'dungeon-delver')                         addProf(['Perception','Investigation']);
  if (c.feat === 'eldritch-adept') {
    const inv = fc.invocation || '';
    if (inv.includes('Beguiling Influence')) addProf(['Deception','Persuasion']);
  }
  if (c.feat === 'boon-of-skill') addExpertise(SKILLS.map(([n]) => n)); // all skills proficient + one expertise
  if (c.feat === 'observant') {
    if (fc.obs_ability === 'int') addProf(['Investigation']);
    if (fc.obs_ability === 'wis') addProf(['Perception']);
  }

  // 4b. Feat skills from ALL ASI slots
  for (const [slotKey, choice] of Object.entries(c.asiChoices || {})) {
    if (!choice?.type || choice.type !== 'feat') continue;
    const sfc = choice.featChoices || {};
    if (choice.featId === 'skilled' && sfc.skilled_picks?.length) addProf(sfc.skilled_picks);
    if (choice.featId === 'empathic') addProf(['Insight']);
    if (choice.featId === 'dungeon-delver') addProf(['Perception','Investigation']);
    if (choice.featId === 'boon-of-skill') addExpertise(SKILLS.map(([n]) => n));
    if (choice.featId === 'eldritch-adept') {
      const inv = sfc.invocation || '';
      if (inv.includes('Beguiling Influence')) addProf(['Deception','Persuasion']);
    }
    if (choice.featId === 'observant') {
      if (sfc.obs_ability === 'int') addProf(['Investigation']);
      if (sfc.obs_ability === 'wis') addProf(['Perception']);
    }
  }

  // 5. Subclass bonus skills — applies to the primary subclass AND any multiclass subclass
  const allSubIds = [c.subclassId, ...(c.multiclasses || []).map(m => m.subclassId)].filter(Boolean);
  const hasSub = id => allSubIds.includes(id);

  if (hasSub('lore')      && sc.lore_skills?.length)       addProf(sc.lore_skills);
  if (hasSub('knowledge') && sc.know_skills?.length)       addExpertise(sc.know_skills);
  if (hasSub('knowledge') && sc.know_extra_skills?.length) addProf(sc.know_extra_skills);
  if (hasSub('nature')    && sc.nature_skill?.length)      addProf(sc.nature_skill);
  if (hasSub('order')     && sc.order_skill?.length)       addProf(sc.order_skill);
  if (hasSub('peace')     && sc.peace_skill?.length)       addProf(sc.peace_skill);
  if (hasSub('fey-wanderer') && sc.fey_skill?.length)      addProf(sc.fey_skill);
  if (hasSub('mercy')     && sc.mercy_skill?.length)       addProf(sc.mercy_skill);
  if (hasSub('samurai')   && sc.samurai_prof?.length)      addProf(sc.samurai_prof);
  if (hasSub('battle-smith') && sc.bsmith_skill?.length)   addProf(sc.bsmith_skill);
  if (hasSub('bladesinging') && sc.bladesinging_prof?.length) addProf(sc.bladesinging_prof);
  if (hasSub('assassin')  && lvl >= 3)      addProf(['Disguise','Poisoners']);
  if (hasSub('inquisitive'))                addProf(['Insight','Investigation']);
  if (hasSub('scout'))                      addProf(['Nature','Survival']);
  if (hasSub('mastermind'))                 addProf(['Insight','Persuasion']);
  if (hasSub('swashbuckler'))               addProf(['Acrobatics','Persuasion']);

  // 6. Ranger: all rangers get Perception
  if (c.classId === 'ranger') addProf(['Perception']);

  // 7. Expertise — class-based
  if (c.classId === 'bard') {
    addExpertise(sc.bard_expertise_1 || []);
    if (lvl >= 10) addExpertise(sc.bard_expertise_2 || []);
  }
  if (c.classId === 'rogue') {
    addExpertise(sc.rogue_expertise_1 || []);
    if (lvl >= 6) addExpertise(sc.rogue_expertise_2 || []);
  }

  // 8. Multiclass entry proficiencies (5e PHB p.163-164)
  for (const mc of (c.multiclasses || [])) {
    switch (mc.classId) {
      case 'barbarian': break; // no extra skills on multiclass entry (armor/weapon profs only)
      case 'bard':      break; // no skills on multiclass entry
      case 'cleric':    break; // no skills
      case 'druid':     break; // no skills
      case 'fighter':   break; // no skills
      case 'monk':      break; // no skills
      case 'paladin':   break; // no skills
      case 'ranger':    break; // ranger multiclass: pick 1 skill from list — stored in subclassChoices.mc_ranger_skill
        if (sc.mc_ranger_skill) addProf([sc.mc_ranger_skill]);
        break;
      case 'rogue':     // rogue multiclass: 1 skill from rogue list + thieves' tools
        if (sc.mc_rogue_skill) addProf([sc.mc_rogue_skill]);
        break;
      case 'sorcerer':  break;
      case 'warlock':   break;
      case 'wizard':    break;
      case 'artificer': break;
    }
    // Subclass-granted skills from multiclass (if subclass chosen)
    if (mc.subclassId) {
      if (mc.classId === 'bard' && mc.subclassId === 'lore' && sc.mc_lore_skills?.length) addProf(sc.mc_lore_skills);
      if (mc.classId === 'fighter' && mc.subclassId === 'cavalier' && sc.mc_cav_prof) addProf([sc.mc_cav_prof]);
    }
  }

  return result;
}

// Keep simple proficient set for backward compatibility
function allProficientSkills(c) {
  const map = allSkillProficiencies(c);
  return new Set([...map.keys()].filter(k => map.get(k) !== 'half'));
}

function getSkillRows(c) {
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const profMap = allSkillProficiencies(c);
  const overrides = c.skillOverrides || {};
  const fc = c.featChoices || {};
  const sc = c.subclassChoices || {};

  // Jack of All Trades — Bard adds half pb to non-proficient skills at level 2
  const hasJoat = c.classId === 'bard' && c.level >= 2;
  // Remarkable Athlete — Champion fighter adds half pb (round up) to STR/DEX/CON
  const hasRemarkable = c.classId === 'fighter' && c.subclassId === 'champion' && c.level >= 7;
  const halfPb = Math.ceil(pb / 2);

  return SKILLS.map(([name, ab]) => {
    if (overrides[name] !== undefined) {
      // Manual override — take it as-is
      return { name, ability: ab, proficient: true, expertise: false, mod: overrides[name] };
    }

    const profLevel = profMap.get(name); // 'proficient' | 'expertise' | undefined
    const isProf = !!profLevel;
    const isExpertise = profLevel === 'expertise';

    let bonus = 0;
    if (isExpertise) bonus = pb * 2;
    else if (isProf) bonus = pb;
    else if (hasJoat) bonus = halfPb;
    else if (hasRemarkable && ['str','dex','con'].includes(ab)) bonus = halfPb;

    return {
      name,
      ability: ab,
      proficient: isProf || isExpertise,
      expertise: isExpertise,
      joat: !isProf && hasJoat,
      mod: abilityMod(scores[ab]) + bonus,
    };
  });
}

function getSavingThrows(c) {
  const cls = getClass(c.classId);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const fc = c.featChoices || {};

  // Base class saving throw proficiencies
  const profs = new Set(cls ? cls.savingThrows : []);

  // Multiclass: 5e rules — you don't gain new save profs from multiclassing
  // (they only come from your FIRST level in a class)
  // Exception: Resilient feat can add a save from any slot

  // Resilient feat (legacy single feat slot)
  if (c.feat === 'resilient' && fc.res_ability) profs.add(fc.res_ability);

  // Resilient from any ASI slot
  for (const choice of Object.values(c.asiChoices || {})) {
    if (choice.type === 'feat' && choice.featId === 'resilient' && choice.featChoices?.res_ability) {
      profs.add(choice.featChoices.res_ability);
    }
  }

  // Paladin: Aura of Devotion gives WIS immunity to charm, not save prof — skip
  // Dwarf: Dwarven Resilience = advantage on poison saves (handled in traits, not save mod)
  // Gnome: Gnomish Cunning = advantage on INT/WIS/CHA saves (advantage, not prof bonus)
  // These are advantage-based, not proficiency-based, so we note them in traits rather than adding to mod

  return ABILITIES.map(a => {
    const isProf = profs.has(a);
    return { ability: a, proficient: isProf, mod: abilityMod(scores[a]) + (isProf ? pb : 0) };
  });
}

// ============ Router ============
const Router = {
  async go(view, id = null) {
    if (view === "list") {
      state.view = "list";
      state.charList = await api.listCharacters();
      render();
    } else if (view === "create") {
      state.view = "wizard"; state.step = 0; state.editingId = null; state.character = blankCharacter();
      render();
    } else if (view === "edit") {
      const row = await api.getCharacter(id);
      state.view = "wizard"; state.step = 0; state.editingId = id; state.character = row.data;
      render();
    } else if (view === "levelup") {
      const rowLu = await api.getCharacter(id);
      state.view = "levelup"; state.editingId = id; state.character = rowLu.data;
      state.levelUpStep = 0; state.levelUpChoices = { _targetLevel: rowLu.data.level + 1 };
      render();
    } else if (view === "sheet") {
      const rowSh = await api.getCharacter(id);
      state.view = "sheet"; state.editingId = id; state.character = rowSh.data;
      render();
    } else if (view === "import") {
      state.view = "import";
      render();
      ImportPage.loadLibrary();
    }
  },
};

// ============ App actions (exposed on window for inline handlers) ============
const App = {
  goStep(n) { state.step = n; render(); },
  nextStep() { state.step = Math.min(STEP_NAMES.length - 1, state.step + 1); render(); },
  prevStep() { state.step = Math.max(0, state.step - 1); render(); },

  setName(v) { state.character.name = v; },
  setLevel(v) { state.character.level = Math.max(1, Math.min(20, parseInt(v) || 1)); render(); },

  selectRace(id) { state.character.raceId = id; state.character.halfElfChoices = []; if (state.editingId) api.saveCharacter(state.character, state.editingId); render(); },
  toggleHalfElfChoice(ab) {
    const arr = state.character.halfElfChoices;
    const i = arr.indexOf(ab);
    if (i >= 0) arr.splice(i, 1);
    else if (arr.length < 2) arr.push(ab);
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },

  selectClass(id) { state.character.classId = id; state.character.subclassId = null; state.character.classSkillChoices = []; if (state.editingId) api.saveCharacter(state.character, state.editingId); render(); },
  selectSubclass(id) { state.character.subclassId = id; if (state.editingId) api.saveCharacter(state.character, state.editingId); render(); },

  selectBackground(id) { state.character.backgroundId = id; if (state.editingId) api.saveCharacter(state.character, state.editingId); render(); },

  setAbilityMethod(m) { state.character.abilityMethod = m; state.character.baseScores = { str: 8, dex: 8, con: 8, int: 8, wis: 8, cha: 8 }; render(); },
  setStandardArraySlot(ability, value) {
    state.character.baseScores[ability] = parseInt(value) || 8; render();
  },
  setPointBuy(ability, delta) {
    const cur = state.character.baseScores[ability];
    const next = cur + delta;
    if (next < 8 || next > 15) return;
    const spent = ABILITIES.reduce((s, a) => s + POINT_BUY_COST[a === ability ? next : state.character.baseScores[a]], 0);
    if (spent > 27) return;
    state.character.baseScores[ability] = next; render();
  },
  setManualScore(ability, value) {
    state.character.baseScores[ability] = Math.max(1, Math.min(30, parseInt(value) || 10)); render();
  },

  toggleClassSkill(skill) {
    const arr = state.character.classSkillChoices;
    const i = arr.indexOf(skill);
    const max = classSkillCount(state.character);
    if (i >= 0) arr.splice(i, 1);
    else if (arr.length < max && !backgroundSkills(state.character).includes(skill)) arr.push(skill);
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  setFeat(id) { state.character.feat = id || null; state.character.featChoices = {}; render(); },
  setFeatChoice(key, val) {
    if (!state.character.featChoices) state.character.featChoices = {};
    state.character.featChoices[key] = val;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  setSubclassChoice(key, val) {
    if (!state.character.subclassChoices) state.character.subclassChoices = {};
    state.character.subclassChoices[key] = val;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  cycleAsiAbility(slotKey, ab) {
    const c = state.character;
    if (!c.asiChoices) c.asiChoices = {};
    if (!c.asiChoices[slotKey]) c.asiChoices[slotKey] = { type: 'asi' };
    const slot = c.asiChoices[slotKey];
    const scores = finalAbilityScores(c);
    const cur = scores[ab] || 10;
    if (cur >= 20) return;
    const count = (slot.ab1===ab?1:0)+(slot.ab2===ab?1:0);
    if (count === 0) {
      // Add +1: put in ab1 if empty, else ab2
      if (!slot.ab1) slot.ab1 = ab;
      else if (!slot.ab2) slot.ab2 = ab;
      else { slot.ab1 = ab; slot.ab2 = null; } // replace first
    } else if (count === 1) {
      // Upgrade to +2: set both ab1 and ab2 to this ability
      slot.ab1 = ab; slot.ab2 = ab;
    } else {
      // Already +2: clear both
      if (slot.ab1 === ab) slot.ab1 = null;
      if (slot.ab2 === ab) slot.ab2 = null;
    }
    if (state.editingId) api.saveCharacter(c, state.editingId);
    render();
  },
  addMulticlass(classId) {
    const c = state.character;
    if (!c.multiclasses) c.multiclasses = [];
    if (c.multiclasses.find(m => m.classId === classId)) return;
    c.multiclasses.push({ classId, level: 1, subclassId: null });
    // Adding a new class at level 1 adds 1 to total level
    c.level = (c.level || 1) + 1;
    if (state.editingId) api.saveCharacter(c, state.editingId);
    render();
  },
  removeMulticlass(classId) {
    const c = state.character;
    if (!c.multiclasses) return;
    const mc = c.multiclasses.find(m => m.classId === classId);
    if (mc) c.level = Math.max(1, (c.level || 1) - (mc.level || 1));
    c.multiclasses = c.multiclasses.filter(m => m.classId !== classId);
    if (state.editingId) api.saveCharacter(c, state.editingId);
    render();
  },
  setMulticlassLevel(classId, level) {
    if (!state.character.multiclasses) return;
    const c = state.character;
    const mc = c.multiclasses.find(m => m.classId === classId);
    if (!mc) return;
    const oldLevel = mc.level || 1;
    const newLevel = Math.max(1, parseInt(level) || 1);
    mc.level = newLevel;
    // Keep c.level (total) in sync: shift by the delta
    c.level = Math.max(newLevel + (getPrimaryLevel(c) || 1), (c.level || 1) + (newLevel - oldLevel));
    if (state.editingId) api.saveCharacter(c, state.editingId);
    render();
  },
  setMulticlassSubclass(classId, subclassId) {
    if (!state.character.multiclasses) return;
    const mc = state.character.multiclasses.find(m => m.classId === classId);
    if (mc) { mc.subclassId = subclassId || null; if (state.editingId) api.saveCharacter(state.character, state.editingId); render(); }
  },
  setAsiChoice(slotKey, field, val) {
    if (!state.character.asiChoices) state.character.asiChoices = {};
    if (!state.character.asiChoices[slotKey]) state.character.asiChoices[slotKey] = {};
    state.character.asiChoices[slotKey][field] = val;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  setAsiFeatChoice(slotKey, featField, val) {
    if (!state.character.asiChoices) state.character.asiChoices = {};
    if (!state.character.asiChoices[slotKey]) state.character.asiChoices[slotKey] = {};
    if (!state.character.asiChoices[slotKey].featChoices) state.character.asiChoices[slotKey].featChoices = {};
    state.character.asiChoices[slotKey].featChoices[featField] = val;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  toggleAsiFeatArray(slotKey, field, val, max) {
    if (!state.character.asiChoices) state.character.asiChoices = {};
    if (!state.character.asiChoices[slotKey]) state.character.asiChoices[slotKey] = {};
    if (!state.character.asiChoices[slotKey].featChoices) state.character.asiChoices[slotKey].featChoices = {};
    const arr = state.character.asiChoices[slotKey].featChoices[field] || [];
    const i = arr.indexOf(val);
    if (i >= 0) arr.splice(i, 1);
    else if (!max || arr.length < max) arr.push(val);
    state.character.asiChoices[slotKey].featChoices[field] = arr;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  toggleExpertise(key, skillName) {
    if (!state.character.subclassChoices) state.character.subclassChoices = {};
    const arr = state.character.subclassChoices[key] || [];
    const i = arr.indexOf(skillName);
    if (i >= 0) arr.splice(i, 1); else arr.push(skillName);
    state.character.subclassChoices[key] = arr;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },

  // Generic toggle for array-valued choices — avoids JSON.stringify in HTML attributes
  toggleSubclassArrayChoice(key, val, max) {
    if (!state.character.subclassChoices) state.character.subclassChoices = {};
    const arr = state.character.subclassChoices[key] || [];
    const i = arr.indexOf(val);
    if (i >= 0) arr.splice(i, 1);
    else if (!max || arr.length < max) arr.push(val);
    state.character.subclassChoices[key] = arr;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  toggleFeatArrayChoice(key, val, max) {
    if (!state.character.featChoices) state.character.featChoices = {};
    const arr = state.character.featChoices[key] || [];
    const i = arr.indexOf(val);
    if (i >= 0) arr.splice(i, 1);
    else if (!max || arr.length < max) arr.push(val);
    state.character.featChoices[key] = arr;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  toggleSubclassSpell(key, spellName, max) {
    if (!state.character.subclassChoices) state.character.subclassChoices = {};
    const arr = state.character.subclassChoices[key] || [];
    const i = arr.indexOf(spellName);
    if (i >= 0) arr.splice(i, 1);
    else if (arr.length < max) arr.push(spellName);
    state.character.subclassChoices[key] = arr;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },
  toggleFeatSpell(key, spellName) {
    if (!state.character.featChoices) state.character.featChoices = {};
    const arr = state.character.featChoices[key] || [];
    const i = arr.indexOf(spellName);
    if (i >= 0) arr.splice(i, 1); else arr.push(spellName);
    state.character.featChoices[key] = arr;
    if (state.editingId) api.saveCharacter(state.character, state.editingId);
    render();
  },

  setEquipmentChoice(v) { state.character.equipmentChoice = v; render(); },
  setArmor(v) { state.character.armorId = v || null; render(); },
  toggleShield() { state.character.shield = !state.character.shield; render(); },
  setExtraGear(v) { state.character.extraGear = v; },

  toggleCantrip(name) {
    const c = state.character;
    const cls = getClass(c.classId);
    const lvl = c.level;
    const max = (CANTRIPS_KNOWN[c.classId] || [])[lvl]
      || cls?.spellcasting?.cantripsAt1
      || (FULL_CASTERS.has(c.classId) ? 3 : 5);
    const arr = c.cantrips;
    const i = arr.indexOf(name);
    if (i >= 0) { arr.splice(i, 1); }
    else {
      // Bonus cantrips (magical secrets, magic initiate) don't count against cap
      const bonusNames = getChosenBonusSpellNames(c);
      const nonBonusCount = arr.filter(n => !bonusNames.has(n)).length;
      if (bonusNames.has(name) || nonBonusCount < max) arr.push(name);
    }
    render();
  },
  toggleSpell(name) {
    const c = state.character;
    const cls = getClass(c.classId);
    const lvl = c.level;
    const isPrepared = ["cleric","druid","paladin","wizard"].includes(c.classId);
    const max = isPrepared ? 999 : (SPELLS_KNOWN[c.classId] || [])[lvl] ?? 999;
    const arr = c.spellsKnown;
    const i = arr.indexOf(name);
    if (i >= 0) { arr.splice(i, 1); }
    else {
      // Bonus spells (patron, oath, domain, secrets) AND ritual spells don't count against cap
      const bonusNames = getChosenBonusSpellNames(c);
      const spell = DATA.spells.find(s => s.name === name);
      const isFree = bonusNames.has(name) || !!(spell?.ritual);
      const nonBonusCount = arr.filter(n => {
        const sp = DATA.spells.find(s => s.name === n);
        return !bonusNames.has(n) && !sp?.ritual;
      }).length;
      if (isFree || nonBonusCount < max) arr.push(name);
    }
    render();
  },
  setNotes(v) { state.character.notes = v; },

  // Spell slot tracking (used on the character sheet view)
  toggleSlot(levelKey, slotIndex) {
    const c = state.character;
    if (!c.spellSlots) c.spellSlots = {};
    const used = c.spellSlots[levelKey] || 0;
    const slotInfo = getEffectiveSpellSlots(c);
    if (!slotInfo) return;
    const slotDef = slotInfo.type === "pact"
      ? slotInfo.slots[0]
      : slotInfo.slots.find(s => s.level === parseInt(levelKey));
    if (!slotDef) return;
    if (slotIndex < used) c.spellSlots[levelKey] = slotIndex;
    else c.spellSlots[levelKey] = Math.min(slotIndex + 1, slotDef.max);
    api.saveCharacter(c, state.editingId);
    // Update pip classes in-place without re-render
    const card = document.getElementById('spell-slot-tracker');
    if (!card) return;
    card.querySelectorAll('.slot-row').forEach(row => {
      const pips = row.querySelectorAll('.slot-pip');
      if (!pips.length) return;
      const onclick = pips[0].getAttribute('onclick') || '';
      const keyMatch = onclick.match(/'([^']+)'/);
      if (!keyMatch) return;
      const k = keyMatch[1];
      const u = c.spellSlots[k] || 0;
      pips.forEach((p, i) => p.classList.toggle('used', i < u));
      const countEl = row.querySelector('.slot-count');
      if (countEl) countEl.textContent = `${pips.length - u} / ${pips.length}`;
    });
  },

  resetSlots() {
    const c = state.character;
    c.spellSlots = {};
    api.saveCharacter(c, state.editingId);
    const card = document.getElementById('spell-slot-tracker');
    if (!card) return;
    card.querySelectorAll('.slot-pip').forEach(p => p.classList.remove('used'));
    card.querySelectorAll('.slot-row').forEach(row => {
      const total = row.querySelectorAll('.slot-pip').length;
      const countEl = row.querySelector('.slot-count');
      if (countEl) countEl.textContent = `${total} / ${total}`;
    });
  },

  // ── HP tracking ──────────────────────────────────────────
  setCurrentHp(val) {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const v = Math.max(0, Math.min(max, parseInt(val) || 0));
    c.currentHp = v;
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    _updateVitals(c);
  },

  adjustHp(delta) {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const cur = c.currentHp ?? max;
    App.setCurrentHp(cur + delta);
  },

  // Temp HP — per 5e rules: doesn't stack (take higher), cleared on long rest only
  setTempHp(val) {
    const c = state.character;
    c.tempHp = Math.max(0, parseInt(val) || 0);
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    _updateVitals(c);
  },

  adjustTempHp(delta) {
    const c = state.character;
    App.setTempHp((c.tempHp || 0) + delta);
  },

  // Temp AC — shield of faith, cover, magic items, etc.
  setTempAc(val) {
    const c = state.character;
    c.tempAc = Math.max(0, parseInt(val) || 0);
    api.saveCharacter(c, state.editingId);
    _updateVitals(c);
  },

  adjustTempAc(delta) {
    const c = state.character;
    App.setTempAc((c.tempAc || 0) + delta);
  },

  // HP max override — lets user set their own HP when computed value is wrong
  setCastFilter(val) {
    state.character._castFilter = val;
    render(); // no save needed — it's a display-only filter
  },
  setDeathSave(type, val) {
    const c = state.character;
    if (!c.deathSaves) c.deathSaves = { successes: 0, failures: 0 };
    c.deathSaves[type] = Math.max(0, Math.min(3, parseInt(val)||0));
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
  },
  setManualMaxHp(val) {
    const c = state.character;
    const v = parseInt(val);
    // 0, negative, or NaN = clear the override (use auto-computed value)
    c.manualMaxHp = (isNaN(v) || v <= 0) ? null : v;
    if (c.manualMaxHp !== null && c.currentHp !== null && c.currentHp > c.manualMaxHp) {
      c.currentHp = c.manualMaxHp;
    }
    api.saveCharacter(c, state.editingId);
    // Re-render the HP tracker without disturbing focus on other inputs
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    _updateVitals(c);
  },

  // Skill overrides — let user manually set a skill modifier on the sheet
  setSkillOverride(skillName, val) {
    const c = state.character;
    if (!c.skillOverrides) c.skillOverrides = {};
    const v = parseInt(val);
    if (isNaN(v)) delete c.skillOverrides[skillName];
    else c.skillOverrides[skillName] = v;
    api.saveCharacter(c, state.editingId);
    // Re-render just the skills card
    const el = document.getElementById('skills-card');
    if (el) el.outerHTML = renderSkillsCard(c);
  },

  // ── Hit Dice ─────────────────────────────────────────────
  spendHitDie() {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const cur = c.currentHp ?? max;
    if (cur >= max) return;                     // already at full
    const availHD = c.level - (c.hitDiceUsed || 0);
    if (availHD <= 0) { alert("No hit dice remaining."); return; }
    const cls = getClass(c.classId);
    const die = cls ? cls.hitDie : 8;
    const scores = finalAbilityScores(c);
    const conMod = abilityMod(scores.con);
    const roll = Math.floor(Math.random() * die) + 1;
    const heal = Math.max(1, roll + conMod);
    c.currentHp = Math.min(max, cur + heal);
    c.hitDiceUsed = (c.hitDiceUsed || 0) + 1;
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById('hp-tracker');
    if (el) el.outerHTML = renderHpTracker(c);
    _updateVitals(c);
    // Show the roll result — find hd-msg in the newly rendered card
    const msg = document.getElementById('hd-msg');
    if (msg) {
      msg.textContent = `Rolled ${roll} + ${conMod} CON = +${heal} HP`;
      msg.style.opacity = '1';
      setTimeout(() => { msg.style.opacity = '0'; }, 3000);
    }
  },

  // ── Rests ─────────────────────────────────────────────────
  shortRest() {
    const c = state.character;
    if (!c.resources) c.resources = {};
    // Recover short-rest resources
    const shortRestRes = [
      ...getClassResources(c).filter(r => r.recharge === 'short' || r.recharge === 'both'),
      ...getRaceResources(c).filter(r => r.recharge === 'short' || r.recharge === 'both'),
    ];
    if (c.classId === "warlock") c.spellSlots = {};
    shortRestRes.forEach(r => { c.resources[r.id] = 0; });
    api.saveCharacter(c, state.editingId);
    const recovered = shortRestRes.map(r => r.name).join(", ");
    alert(`Short rest taken.\n\nRecovered: ${recovered || "none"}${c.classId === "warlock" ? ", Pact Magic slots" : ""}\n\nSpend hit dice to recover HP using the Roll Hit Die button.`);
    // Re-render resource card if visible
    const resEl = document.getElementById('class-resources');
    if (resEl) resEl.outerHTML = renderClassResources(c);
  },

  longRest() {
    const c = state.character;
    const max = computeHP(c) ?? 0;
    const hdRecovered = Math.max(1, Math.floor(c.level / 2));
    const slotInfo = getEffectiveSpellSlots(c);
    const hdLeft = c.level - (c.hitDiceUsed || 0);

    // All resources recover on long rest (long rest includes short rest benefits)
    const allResources = [...getClassResources(c), ...getRaceResources(c)].filter(r => r.max !== null);
    const shortOnlyRes = allResources.filter(r => r.recharge === 'short');
    const longRes = allResources.filter(r => r.recharge === 'long' || r.recharge === 'both');

    const lines = [
      `Long Rest — the following will be restored:`,
      `• HP fully restored to maximum (${max} HP)`,
      `• Hit Dice: recover ${hdRecovered} (you currently have ${hdLeft}/${c.level})`,
      `• Temp HP cleared`,
    ];
    if (slotInfo) {
      if (slotInfo.type === "pact") lines.push(`• Pact Magic slots restored`);
      else lines.push(`• All spell slots restored (${slotInfo.slots.map(s => `${s.max}× ${["","1st","2nd","3rd","4th","5th","6th","7th","8th","9th"][s.level]}`).join(", ")})`);
    }
    if (longRes.length) lines.push(`• Long-rest resources: ${longRes.map(r => r.name).join(", ")}`);
    if (shortOnlyRes.length) lines.push(`• Short-rest resources also restored: ${shortOnlyRes.map(r => r.name).join(", ")}`);

    if (!confirm(lines.join("\n"))) return;

    // Apply — restore ALL resources (long rest is a superset of short rest)
    c.currentHp = max;
    c.hitDiceUsed = Math.max(0, (c.hitDiceUsed || 0) - hdRecovered);
    c.spellSlots = {};
    c.tempHp = 0;
    if (!c.resources) c.resources = {};
    allResources.forEach(r => { c.resources[r.id] = 0; });
    // Warlocks also get pact slots back on short rest — already covered above
    api.saveCharacter(c, state.editingId);

    const hpEl = document.getElementById('hp-tracker');
    if (hpEl) hpEl.outerHTML = renderHpTracker(c);

    const resEl = document.getElementById('class-resources');
    if (resEl) resEl.outerHTML = renderClassResources(c);

    const spellCard = document.getElementById('spell-slot-tracker');
    if (spellCard) {
      spellCard.querySelectorAll('.slot-pip').forEach(p => p.classList.remove('used'));
      spellCard.querySelectorAll('.slot-row').forEach(row => {
        const total = row.querySelectorAll('.slot-pip').length;
        const countEl = row.querySelector('.slot-count');
        if (countEl) countEl.textContent = `${total} / ${total}`;
      });
    }

    _updateVitals(c);
  },

  spendResource(id, max) {
    const c = state.character;
    if (!c.resources) c.resources = {};
    const used = c.resources[id] || 0;
    if (used >= max) return;
    c.resources[id] = used + 1;
    api.saveCharacter(c, state.editingId);
    // Update pip in place
    const pip = document.querySelector(`.res-pip[data-res="${id}"][data-idx="${used}"]`);
    if (pip) pip.classList.add('used');
    const countEl = document.getElementById(`res-count-${id}`);
    if (countEl) countEl.textContent = `${max - (c.resources[id]||0)} / ${max}`;
  },

  restoreResource(id, max) {
    const c = state.character;
    if (!c.resources) c.resources = {};
    const used = c.resources[id] || 0;
    if (used <= 0) return;
    c.resources[id] = used - 1;
    api.saveCharacter(c, state.editingId);
    const pip = document.querySelector(`.res-pip[data-res="${id}"][data-idx="${used - 1}"]`);
    if (pip) pip.classList.remove('used');
    const countEl = document.getElementById(`res-count-${id}`);
    if (countEl) countEl.textContent = `${max - (c.resources[id]||0)} / ${max}`;
  },

  setResourceVal(id, val, max) {
    const c = state.character;
    if (!c.resources) c.resources = {};
    c.resources[id] = Math.max(0, Math.min(max, parseInt(val) || 0));
    api.saveCharacter(c, state.editingId);
    const el = document.getElementById(`res-card-${id.replace(/[^a-z0-9]/g,'')}`);
    if (el) {
      // re-render just that resource's pips
      el.querySelectorAll('.res-pip').forEach((p, i) => {
        p.classList.toggle('used', i < (c.resources[id] || 0));
      });
      const countEl = document.getElementById(`res-count-${id}`);
      if (countEl) countEl.textContent = `${max - (c.resources[id]||0)} / ${max}`;
    }
  },

  async save() {
    const c = state.character;
    if (!c.name.trim()) { alert("Give your character a name first."); return; }
    await api.saveCharacter(c, state.editingId);
    Router.go("list");
  },
  async deleteChar(id, ev) {
    ev.stopPropagation();
    if (!confirm("Delete this character permanently?")) return;
    await api.deleteCharacter(id);
    Router.go("list");
  },
};
window.App = App; window.Router = Router;

// Expose helpers needed by pdf-export.js
window._pdfHelpers = {
  get state()             { return state; },
  get DATA()              { return DATA; },
  get SUBCLASS_FEATURES() { return window._SUBCLASS_FEATURES || {}; },
  getRace,
  getClass,
  getBackground,
  finalAbilityScores,
  computeHP,
  computeAC,
  abilityMod,
  proficiencyBonus,
  fmtMod,
  getSkillRows,
  getSavingThrows,
  getClassResources,
  getRaceResources,
  getSpellSlots,
  ABILITIES,
  ABILITY_NAMES,
  FULL_CASTERS,
};

// ── Vitals bar live-update helper ──────────────────────────
function _updateVitals(c) {
  const hp = computeHP(c);
  const ac = computeAC(c);
  const tempHp = c.tempHp || 0;
  const tempAc = c.tempAc || 0;

  const hpEl = document.getElementById('vital-hp');
  if (hpEl) {
    hpEl.innerHTML = `
      ${c.currentHp ?? hp ?? "—"}<span style="font-size:13px;color:#888">/${hp ?? "—"}</span>
      ${tempHp > 0 ? `<span style="font-size:12px;color:#64b5f6;display:block;line-height:1.2">+${tempHp} tmp HP</span>` : ""}`;
  }
  const acEl = document.getElementById('vital-ac');
  if (acEl) {
    const totalAc = ac + tempAc;
    acEl.innerHTML = `${totalAc}${tempAc > 0 ? `<span style="font-size:12px;color:#81d4fa;display:block;line-height:1.2">+${tempAc} bonus</span>` : ""}`;
  }
}

// ============ Rendering ============
function render() {
  const app = document.getElementById("app");
  if (state.view === "list")    app.innerHTML = renderList();
  else if (state.view === "sheet")   app.innerHTML = renderSheet();
  else if (state.view === "levelup") app.innerHTML = renderLevelUp();
  else if (state.view === "import")  app.innerHTML = renderImportPage();
  else app.innerHTML = renderWizard();
}

function renderList() {
  if (!state.charList.length) {
    return `
      <h1>Your Characters</h1>
      <p class="subtitle">Nothing saved yet.</p>
      <div class="empty-state">
        <p>No characters yet. Start your legend.</p>
        <button class="btn btn--primary" onclick="Router.go('create')">+ New Character</button>
      </div>`;
  }
  return `
    <h1>Your Characters</h1>
    <p class="subtitle">${state.charList.length} saved</p>
    <div class="char-grid">
      ${state.charList.map(c => `
        <div class="char-card" onclick="Router.go('sheet', ${c.id})">
          <span class="level-badge">${c.level}</span>
          <h3>${escapeHtml(c.name)}</h3>
          <div class="meta">${labelOr(c.race_id, "races")} ${labelOr(c.class_id, "classes")}</div>
          <div class="meta">${labelOr(c.background_id, "backgrounds")}</div>
          <div class="card-actions">
            <button class="del-btn" onclick="event.stopPropagation(); Router.go('edit', ${c.id})" style="color:var(--gold);">Edit</button>
            <button class="del-btn" onclick="App.deleteChar(${c.id}, event)">Delete</button>
          </div>
        </div>
      `).join("")}
    </div>`;
}

function labelOr(id, coll) {
  if (!id) return "";
  const item = DATA[coll].find(x => x.id === id);
  return item ? item.name : id;
}
function escapeHtml(s) { return (s || "").replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m])); }

function renderWizard() {
  const steps = STEP_NAMES.map((name, i) => `
    <div class="step ${i === state.step ? "active" : i < state.step ? "done" : ""}" onclick="App.goStep(${i})">
      <span class="step-num">${i + 1}</span>${name}
    </div>`).join("");

  const stepRenderers = [
    renderBasics, renderRace, renderClass, renderBackground,
    renderAbilityScores, renderSkillsFeat, renderEquipment, renderSpells, renderReview,
  ];
  const content = stepRenderers[state.step]();

  return `
    <div class="wizard">
      <div class="steps">${steps}</div>
      <div class="panel">
        ${content}
        <div class="wizard-nav">
          <button class="btn" onclick="App.prevStep()" ${state.step === 0 ? "disabled" : ""}>&larr; Back</button>
          ${state.step === STEP_NAMES.length - 1
            ? `<button class="btn btn--primary" onclick="App.save()">Save Character</button>`
            : `<button class="btn btn--primary" onclick="App.nextStep()">Next &rarr;</button>`}
        </div>
      </div>
    </div>`;
}

function renderBasics() {
  const c = state.character;
  return `
    <h2>Basics</h2>
    <div class="field">
      <label>Character Name</label>
      <input type="text" value="${escapeHtml(c.name)}" oninput="App.setName(this.value)" placeholder="e.g. Sylvaine Thorn" />
    </div>
    <div class="field">
      <label>Level</label>
      <input type="text" style="max-width:100px" value="${c.level}" oninput="App.setLevel(this.value)" />
    </div>
    <div class="field">
      <label>Ability Score Method (used in Step 5)</label>
      <select onchange="App.setAbilityMethod(this.value)">
        <option value="standard" ${c.abilityMethod === "standard" ? "selected" : ""}>Standard Array (15,14,13,12,10,8)</option>
        <option value="pointbuy" ${c.abilityMethod === "pointbuy" ? "selected" : ""}>Point Buy (27 points)</option>
        <option value="manual" ${c.abilityMethod === "manual" ? "selected" : ""}>Manual / Rolled</option>
      </select>
    </div>`;
}

function renderRace() {
  const c = state.character;
  const race = getRace(c.raceId);
  const sc = c.subclassChoices || {};

  function skillPick(key, count, label) {
    const chosen = sc[key] || [];
    const atCap = chosen.length >= count;
    return `<div class="field" style="margin-top:12px;">
      <label>${label} (choose ${count})</label>
      <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:6px">
        ${SKILLS.map(([name]) => {
          const sel = chosen.includes(name);
          const dis = !sel && atCap;
          return `<span class="tag" style="cursor:${dis?"not-allowed":"pointer"};opacity:${dis?0.4:1};${sel?"background:var(--crimson);border-color:var(--crimson)":""}"
            ${dis?"":(`onclick="App.toggleSubclassArrayChoice('${key}','${name.replace(/'/g,"\\'")}',${count})"`)}">${name}</span>`;
        }).join("")}
      </div>
    </div>`;
  }

  // Group races by source book
  const GROUPS = {
    "Player's Handbook (2014)": ["human","variant-human","hill-dwarf","mountain-dwarf","high-elf","wood-elf","dark-elf","lightfoot-halfling","stout-halfling","forest-gnome","rock-gnome","half-elf","half-orc","dragonborn","tiefling"],
    "Player's Handbook (2024)": ["dwarf","elf","gnome","halfling","orc","aasimar","goliath","tiefling","ardling"],
    "Elemental Evil Player's Companion": ["genasi-air","genasi-earth","genasi-fire","genasi-water"],
    "Volo's Guide to Monsters": ["aasimar","firbolg","triton","bugbear","goblin","hobgoblin","kobold","yuan-ti","tabaxi","kenku"],
    "Mordenkainen's Tome of Foes": ["tortle","lizardfolk"],
    "Eberron: Rising from the Last War": ["changeling","shifter","warforged","kalashtar"],
    "Monsters of the Multiverse": ["goliath","firbolg","triton","bugbear","goblin","hobgoblin","kobold","yuan-ti","tabaxi","kenku","tortle","lizardfolk","aasimar"],
  };
  const allRaceIds = DATA.races.map(r => r.id);
  const grouped = {};
  const usedIds = new Set();
  for (const [grp, ids] of Object.entries(GROUPS)) {
    const found = ids.filter(id => allRaceIds.includes(id));
    if (found.length) { grouped[grp] = found; found.forEach(id => usedIds.add(id)); }
  }
  // catch any races not in a group
  const ungrouped = allRaceIds.filter(id => !usedIds.has(id));
  if (ungrouped.length) grouped["Other"] = ungrouped;

  const raceCards = Object.entries(grouped).map(([grpName, ids]) => `
    <div style="margin-bottom:18px">
      <div style="font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);margin-bottom:8px">${grpName}</div>
      <div class="option-grid">
        ${ids.map(id => {
          const r = DATA.races.find(r => r.id === id);
          if (!r) return '';
          const bonuses = Object.entries(r.abilityBonuses || {}).filter(([k]) => k !== "choose_two").map(([k,v]) => `${k.toUpperCase()} +${v}`).join(", ");
          return `<div class="option-card ${c.raceId === id ? "selected" : ""}" onclick="App.selectRace('${id}')">
            <div class="name">${r.name}</div>
            <div class="sub">${bonuses || "Flexible"} · ${r.speed} ft</div>
          </div>`;
        }).join("")}
      </div>
    </div>`).join("");

  return `
    <h2>Race / Species</h2>
    <p class="subtitle">Choose your character's ancestry. Options from both the 2014 and 2024 Player's Handbook are available.</p>
    ${raceCards}
    ${race ? `
      <div style="margin-top:16px;padding:14px;background:var(--ink-panel);border-radius:var(--radius);border:1px solid var(--border-dark)">
        <h3 style="margin:0 0 8px">${race.name} Traits</h3>
        <ul class="trait-list">${race.traits.map(t => `<li>${t}</li>`).join("")}</ul>
        ${race.abilityBonuses?.choose_two ? `
          <div class="field" style="margin-top:14px;">
            <label>Choose 2 abilities to raise by 1 (Half-Elf versatility)</label>
            <div class="option-grid">
              ${ABILITIES.filter(a => a !== "cha").map(a => `
                <div class="option-card ${c.halfElfChoices.includes(a) ? "selected" : ""}" onclick="App.toggleHalfElfChoice('${a}')">
                  <div class="name">${ABILITY_NAMES[a]}</div>
                </div>`).join("")}
            </div>
          </div>` : ""}
        ${c.raceId === "half-elf" ? skillPick("half_elf_skills", 2, "Half-Elf Skill Versatility — choose 2 bonus skill proficiencies") : ""}
        ${c.raceId === "variant-human" ? `<div class="field" style="margin-top:12px;"><label>Bonus Skill (Variant Human)</label><select onchange="App.setSubclassChoice('human_skill',this.value)"><option value="">— choose a skill —</option>${SKILLS.map(([n])=>`<option value="${n}" ${sc.human_skill===n?"selected":""}>${n}</option>`).join("")}</select></div>` : ""}
        ${c.raceId === "changeling" ? skillPick("changeling_skills", 2, "Changeling Instincts — choose 2 skills") : ""}
        ${c.raceId === "warforged" ? `<div class="field" style="margin-top:12px;"><label>Specialized Design — bonus skill</label><select onchange="App.setSubclassChoice('warforged_skill',this.value)"><option value="">— choose a skill —</option>${SKILLS.map(([n])=>`<option value="${n}" ${sc.warforged_skill===n?"selected":""}>${n}</option>`).join("")}</select></div>` : ""}
      </div>
    ` : ""}`;
}

// ============ Subclass Choices ============
// Handles bonus spells, skill picks, invocations, and other subclass-specific choices

// ============ Bonus Spell Pool ============
// Returns spells that don't count against the class spell cap —
// subclass bonus spells (patron, oath, domain, etc.) and Magical Secrets

function getBonusSpellPool(c) {
  const sc = c.subclassChoices || {};
  const fc = c.featChoices || {};
  const lvl = c.level;
  const pool = []; // { name, source, automatic, key, maxPick, level0ok }

  // Helper: add a batch of automatic spells (always prepared, no user choice needed)
  function autoSpells(names, source) {
    names.forEach(n => pool.push({ name: n, source, automatic: true }));
  }
  // Helper: add chosen spells (user picks from a list)
  function choiceSpells(key, names, source, maxPick, level0ok = false) {
    pool.push({ key, names, source, automatic: false, maxPick: maxPick || names.length, level0ok });
  }

  const sub = c.subclassId;

  // ── Paladin Oaths (automatic) ────────────────────────────
  if (sub === "devotion")  autoSpells(["Protection from Evil and Good","Sanctuary","Lesser Restoration","Zone of Truth","Beacon of Hope","Dispel Magic","Freedom of Movement","Guardian of Faith","Commune","Flame Strike"], "Oath of Devotion");
  if (sub === "ancients")  autoSpells(["Ensnaring Strike","Speak with Animals","Moonbeam","Misty Step","Plant Growth","Protection from Energy","Ice Storm","Stoneskin","Commune with Nature","Tree Stride"], "Oath of the Ancients");
  if (sub === "vengeance") autoSpells(["Bane","Hunter's Mark","Hold Person","Misty Step","Haste","Protection from Energy","Banishment","Dimension Door","Hold Monster","Scrying"], "Oath of Vengeance");

  // ── Warlock Patron Expanded Spells (automatic) ───────────
  if (sub === "archfey")       autoSpells(["Faerie Fire","Sleep","Calm Emotions","Phantasmal Force","Blink","Plant Growth","Dominate Beast","Greater Invisibility","Dominate Person","Seeming"], "Archfey Patron");
  if (sub === "fiend")         autoSpells(["Burning Hands","Command","Blindness/Deafness","Scorching Ray","Fireball","Stinking Cloud","Fire Shield","Wall of Fire","Flame Strike","Hallow"], "Fiend Patron");
  if (sub === "great-old-one") autoSpells(["Dissonant Whispers","Tasha's Hideous Laughter","Detect Thoughts","Phantasmal Force","Clairvoyance","Sending","Dominate Beast","Evard's Black Tentacles","Dominate Person","Telekinesis"], "Great Old One Patron");

  // ── Cleric Domain Spells (automatic) ────────────────────
  if (sub === "life")      autoSpells(["Bless","Cure Wounds","Lesser Restoration","Spiritual Weapon","Beacon of Hope","Revivify","Death Ward","Guardian of Faith","Mass Cure Wounds","Raise Dead"], "Life Domain");
  if (sub === "light")     autoSpells(["Burning Hands","Faerie Fire","Flaming Sphere","Scorching Ray","Daylight","Fireball","Guardian of Faith","Wall of Fire","Flame Strike","Scrying"], "Light Domain");
  if (sub === "knowledge") autoSpells(["Command","Identify","Augury","Suggestion","Nondetection","Speak with Dead","Arcane Eye","Confusion","Legend Lore","Scrying"], "Knowledge Domain");
  if (sub === "nature")    autoSpells(["Animal Friendship","Speak with Animals","Barkskin","Spike Growth","Plant Growth","Wind Wall","Dominate Beast","Grasping Vine","Insect Plague","Tree Stride"], "Nature Domain");
  if (sub === "tempest")   autoSpells(["Fog Cloud","Thunderwave","Gust of Wind","Shatter","Call Lightning","Sleet Storm","Control Water","Ice Storm","Destructive Wave","Insect Plague"], "Tempest Domain");
  if (sub === "trickery")  autoSpells(["Charm Person","Disguise Self","Mirror Image","Pass Without Trace","Blink","Dispel Magic","Dimension Door","Polymorph","Dominate Person","Modify Memory"], "Trickery Domain");
  if (sub === "war")       autoSpells(["Divine Favor","Shield of Faith","Magic Weapon","Spiritual Weapon","Crusader's Mantle","Dispel Magic","Freedom of Movement","Stoneskin","Flame Strike","Hold Monster"], "War Domain");
  if (sub === "death")     autoSpells(["False Life","Ray of Sickness","Blindness/Deafness","Ray of Enfeeblement","Animate Dead","Vampiric Touch","Blight","Death Ward","Antilife Shell","Cloudkill"], "Death Domain");
  if (sub === "fire")      autoSpells(["Burning Hands","Flaming Sphere","Fireball","Fire Shield","Flame Strike","Wall of Fire","Fire Storm","Incendiary Cloud","Meteor Swarm","True Resurrection"], "Fire Domain");
  if (sub === "air")       autoSpells(["Fog Cloud","Gust of Wind","Call Lightning","Ice Storm","Control Winds","Chain Lightning","Control Weather","Whirlwind"], "Air Domain");
  if (sub === "earth")     autoSpells(["Shillelagh","Spike Growth","Stone Shape","Stoneskin","Wall of Stone","Bones of the Earth","Move Earth","Earthquake"], "Earth Domain");
  if (sub === "water")     autoSpells(["Create or Destroy Water","Fog Cloud","Water Walk","Watery Sphere","Control Water","Wall of Ice","Whirlpool","Tsunami"], "Water Domain");

  // ── Druid Circle of the Land terrain spells ──────────────
  const terrainSpells = {
    arctic:    ["Hold Person","Spike Growth","Sleet Storm","Slow","Freedom of Movement","Ice Storm","Commune with Nature","Cone of Cold"],
    coast:     ["Mirror Image","Misty Step","Water Breathing","Water Walk","Control Water","Conjure Elemental","Conjure Fey","Scrying"],
    desert:    ["Blur","Silence","Create Food and Water","Protection from Energy","Blight","Hallucinatory Terrain","Insect Plague","Wall of Stone"],
    forest:    ["Barkskin","Spider Climb","Call Lightning","Plant Growth","Divination","Freedom of Movement","Commune with Nature","Tree Stride"],
    grassland: ["Invisibility","Pass Without Trace","Daylight","Haste","Divination","Dream","Commune with Nature","Hallucinatory Terrain"],
    mountain:  ["Spider Climb","Spike Growth","Lightning Bolt","Meld into Stone","Stone Shape","Stoneskin","Commune with Nature","Wall of Stone"],
    swamp:     ["Darkness","Melf's Acid Arrow","Stinking Cloud","Water Walk","Freedom of Movement","Locate Creature","Insect Plague","Scrying"],
    underdark: ["Spider Climb","Web","Gaseous Form","Greater Invisibility","Stone Shape","Stoneskin","Conjure Elemental","Etherealness"],
  };
  if (sub === "land" && sc.land_terrain && terrainSpells[sc.land_terrain]) {
    autoSpells(terrainSpells[sc.land_terrain], `Circle of the Land (${sc.land_terrain.charAt(0).toUpperCase()+sc.land_terrain.slice(1)})`);
  }

  // ── Bard Lore College — Additional Magical Secrets ───────
  if (sub === "lore" && lvl >= 6) {
    choiceSpells("lore_secrets", DATA.spells.filter(s=>s.level>=1).map(s=>s.name), "Lore College Additional Magical Secrets", 2);
  }

  // ── Bard Magical Secrets (levels 10, 14, 18) ────────────
  const msCount = getMagicalSecretsCount(c.classId, lvl);
  if (msCount > 0) {
    choiceSpells("magical_secrets", DATA.spells.map(s=>s.name), "Magical Secrets", msCount, true);
  }

  // ── Aberrant Dragonmark feat ─────────────────────────────
  if (c.feat === 'aberrant-dragonmark') {
    choiceSpells('ab_dmark_cantrip', DATA.spells.filter(s=>s.level===0&&s.classes.includes('sorcerer')).map(s=>s.name), 'Aberrant Dragonmark Cantrip', 1, true);
    choiceSpells('ab_dmark_spell',   DATA.spells.filter(s=>s.level===1&&s.classes.includes('sorcerer')).map(s=>s.name), 'Aberrant Dragonmark Spell (1/long rest)', 1);
  }

  // ── Artificer Initiate ────────────────────────────────────
  if (c.feat === 'artificer-initiate' && fc.ai_class) {
    choiceSpells('ai_cantrip', DATA.spells.filter(s=>s.level===0&&s.classes.includes('artificer')).map(s=>s.name), 'Artificer Initiate Cantrip', 1, true);
    choiceSpells('ai_spell',   DATA.spells.filter(s=>s.level===1&&s.classes.includes('artificer')).map(s=>s.name), 'Artificer Initiate Spell', 1);
  }

  // ── ASI slot: Aberrant Dragonmark ───────────────────────
  for (const [slotKey, choice] of Object.entries(c.asiChoices || {})) {
    if (!choice?.type || choice.type !== 'feat') continue;
    const sfc = choice.featChoices || {};
    if (choice.featId === 'aberrant-dragonmark') {
      const cantName = sfc.ab_dmark_cantrip;
      const spellName = sfc.ab_dmark_spell;
      if (cantName)  pool.push({ name: cantName,  source: 'Aberrant Dragonmark', automatic: true });
      if (spellName) pool.push({ name: spellName, source: 'Aberrant Dragonmark', automatic: true });
    }
  }

  // ── Magic Initiate feat (legacy single feat slot) ────────
  if (c.feat === "magic-initiate" && fc.mi_class) {
    const miCl = fc.mi_class;
    choiceSpells("mi_cantrips", DATA.spells.filter(s=>s.level===0 && s.classes.includes(miCl)).map(s=>s.name), `Magic Initiate Cantrips (${miCl})`, 2, true);
    choiceSpells("mi_spell",    DATA.spells.filter(s=>s.level===1 && s.classes.includes(miCl)).map(s=>s.name), `Magic Initiate Spell (${miCl})`, 1);
  }

  // ── Ritual Caster feat ───────────────────────────────────
  if (c.feat === "ritual-caster" && fc.rc_class) {
    choiceSpells("rc_spells", DATA.spells.filter(s => s.level <= 1 && s.ritual && s.classes.includes(fc.rc_class)).map(s => s.name), `Ritual Caster (${fc.rc_class})`, 2);
  }

  // ── Fey Touched feat ─────────────────────────────────────
  if (c.feat === "fey-touched") {
    autoSpells(["Misty Step"], "Fey Touched");
    if (fc.fey_spell) autoSpells([fc.fey_spell], "Fey Touched");
  }

  // ── Shadow Touched feat ──────────────────────────────────
  if (c.feat === "shadow-touched") {
    autoSpells(["Invisibility"], "Shadow Touched");
    if (fc.shadow_spell) autoSpells([fc.shadow_spell], "Shadow Touched");
  }

  // ── Telekinetic feat ─────────────────────────────────────
  if (c.feat === "telekinetic") autoSpells(["Mage Hand"], "Telekinetic");

  // ── Telepathic feat ──────────────────────────────────────
  if (c.feat === "telepathic") autoSpells(["Detect Thoughts"], "Telepathic");

  // ── Spell Sniper cantrip ─────────────────────────────────
  if (c.feat === "spell-sniper" && fc.sniper_cantrip) autoSpells([fc.sniper_cantrip], "Spell Sniper");

  // ── Eldritch Adept — invocations that grant spells ───────
  const eldritchInv = c.feat === "eldritch-adept" ? (fc.invocation || "") : "";
  if (eldritchInv.includes("Armor of Shadows"))    autoSpells(["Mage Armor"], "Eldritch Adept");
  if (eldritchInv.includes("Ascendant Step"))      autoSpells(["Levitate"], "Eldritch Adept");
  if (eldritchInv.includes("Beast Speech"))        autoSpells(["Speak with Animals"], "Eldritch Adept");
  if (eldritchInv.includes("Eldritch Sight"))      autoSpells(["Detect Magic"], "Eldritch Adept");
  if (eldritchInv.includes("Fiendish Vigor"))      autoSpells(["False Life"], "Eldritch Adept");
  if (eldritchInv.includes("Mask of Many Faces"))  autoSpells(["Disguise Self"], "Eldritch Adept");
  if (eldritchInv.includes("Misty Visions"))       autoSpells(["Silent Image"], "Eldritch Adept");
  if (eldritchInv.includes("One with Shadows"))    autoSpells(["Invisibility"], "Eldritch Adept");
  if (eldritchInv.includes("Undying Servitude"))   autoSpells(["Animate Dead"], "Eldritch Adept");
  if (eldritchInv.includes("Whispers of the Grave")) autoSpells(["Speak with Dead"], "Eldritch Adept");
  if (eldritchInv.includes("Visions of Distant Realms")) autoSpells(["Arcane Eye"], "Eldritch Adept");
  if (eldritchInv.includes("Witch Sight"))         autoSpells(["True Seeing"], "Eldritch Adept");
  // Agonizing Blast is a modifier to Eldritch Blast, not a new spell

  // ── ASI slot feats (Magic Initiate, Fey Touched, etc.) ──
  for (const [slotKey, choice] of Object.entries(c.asiChoices || {})) {
    if (!choice?.type || choice.type !== 'feat') continue;
    const sfc = choice.featChoices || {};

    if (choice.featId === 'magic-initiate' && sfc.mi_class) {
      const miCl = sfc.mi_class;
      const cantKey = `asi_mi_cant_${slotKey}`;
      const spKey   = `asi_mi_spell_${slotKey}`;
      // Store in featChoices under slot-specific keys to avoid collision
      const chCant = fc[cantKey] || (Array.isArray(sfc.mi_cantrips) ? sfc.mi_cantrips : []);
      const chSp   = fc[spKey]   || sfc.mi_spell || '';
      chCant.forEach(n => pool.push({ name: n, source: `Magic Initiate (${miCl})`, automatic: true }));
      if (chSp) pool.push({ name: chSp, source: `Magic Initiate (${miCl})`, automatic: true });
    }
    if (choice.featId === 'fey-touched') {
      pool.push({ name: 'Misty Step', source: 'Fey Touched', automatic: true });
      if (sfc.fey_spell) pool.push({ name: sfc.fey_spell, source: 'Fey Touched', automatic: true });
    }
    if (choice.featId === 'shadow-touched') {
      pool.push({ name: 'Invisibility', source: 'Shadow Touched', automatic: true });
      if (sfc.shadow_spell) pool.push({ name: sfc.shadow_spell, source: 'Shadow Touched', automatic: true });
    }
    if (choice.featId === 'telekinetic') pool.push({ name: 'Mage Hand', source: 'Telekinetic', automatic: true });
    if (choice.featId === 'telepathic')  pool.push({ name: 'Detect Thoughts', source: 'Telepathic', automatic: true });
    if (choice.featId === 'spell-sniper' && sfc.sniper_cantrip) pool.push({ name: sfc.sniper_cantrip, source: 'Spell Sniper', automatic: true });
    if (choice.featId === 'eldritch-adept') {
      const inv = sfc.invocation || '';
      if (inv.includes("Armor of Shadows"))  pool.push({ name: 'Mage Armor',        source: 'Eldritch Adept', automatic: true });
      if (inv.includes("Beast Speech"))      pool.push({ name: 'Speak with Animals', source: 'Eldritch Adept', automatic: true });
      if (inv.includes("Eldritch Sight"))    pool.push({ name: 'Detect Magic',       source: 'Eldritch Adept', automatic: true });
      if (inv.includes("Mask of Many Faces")) pool.push({ name: 'Disguise Self',     source: 'Eldritch Adept', automatic: true });
      if (inv.includes("Misty Visions"))     pool.push({ name: 'Silent Image',        source: 'Eldritch Adept', automatic: true });
    }
    if (choice.featId === 'ritual-caster' && sfc.rc_class) {
      // Show ritual spells chosen via ASI slot
      choiceSpells(`asi_rc_${slotKey}`, DATA.spells.filter(s=>s.level<=1&&s.ritual&&s.classes.includes(sfc.rc_class)).map(s=>s.name), `Ritual Caster (${sfc.rc_class})`, 2);
    }
  }

  // ── Racial innate spell-like abilities ───────────────────
  if (c.raceId === 'tiefling') {
    autoSpells(['Thaumaturgy'], 'Tiefling');
    if (lvl >= 3) autoSpells(['Hellish Rebuke'], 'Tiefling');
    if (lvl >= 5) autoSpells(['Darkness'], 'Tiefling');
  }
  if (c.raceId === 'dark-elf') {
    autoSpells(['Dancing Lights'], 'Drow');
    if (lvl >= 3) autoSpells(['Faerie Fire'], 'Drow');
    if (lvl >= 5) autoSpells(['Darkness'], 'Drow');
  }
  if (c.raceId === 'high-elf') {
    choiceSpells('high_elf_cantrip', DATA.spells.filter(s=>s.level===0&&s.classes.includes('wizard')).map(s=>s.name), 'High Elf Cantrip', 1, true);
  }
  if (c.raceId === 'forest-gnome') autoSpells(['Minor Illusion'], 'Forest Gnome');
  if (c.raceId === 'rock-gnome')   autoSpells(['Mending','Prestidigitation'], 'Rock Gnome');
  if (c.raceId === 'ardling') {
    autoSpells(['Thaumaturgy'], 'Ardling');
    if (lvl >= 3) autoSpells(['Aid'], 'Ardling');
  }
  if (c.raceId === 'aasimar') {
    autoSpells(['Light'], 'Aasimar');
    if (lvl >= 3) autoSpells(['Lesser Restoration'], 'Aasimar');
    if (lvl >= 5) autoSpells(['Daylight'], 'Aasimar');
  }
  if (c.raceId === 'genasi-fire') {
    autoSpells(['Produce Flame'], 'Fire Genasi');
    if (lvl >= 3) autoSpells(['Burning Hands'], 'Fire Genasi');
    if (lvl >= 5) autoSpells(['Flame Blade'], 'Fire Genasi');
  }
  if (c.raceId === 'genasi-air') {
    if (lvl >= 3) autoSpells(['Levitate'], 'Air Genasi');
    if (lvl >= 5) autoSpells(['Gust of Wind'], 'Air Genasi');
  }
  if (c.raceId === 'genasi-water') {
    autoSpells(['Acid Splash'], 'Water Genasi');
    if (lvl >= 3) autoSpells(['Create or Destroy Water'], 'Water Genasi');
    if (lvl >= 5) autoSpells(['Water Walk'], 'Water Genasi');
  }
  if (c.raceId === 'genasi-earth') {
    autoSpells(['Blade Ward'], 'Earth Genasi');
    if (lvl >= 3) autoSpells(['Shillelagh'], 'Earth Genasi');
    if (lvl >= 5) autoSpells(['Spike Growth'], 'Earth Genasi');
  }
  if (c.raceId === 'yuan-ti') {
    autoSpells(['Poison Spray'], 'Yuan-ti');
    if (lvl >= 3) autoSpells(['Animal Friendship'], 'Yuan-ti');
    if (lvl >= 5) autoSpells(['Suggestion'], 'Yuan-ti');
  }
  if (c.raceId === 'triton') {
    if (lvl >= 3) autoSpells(['Fog Cloud'], 'Triton');
    if (lvl >= 5) autoSpells(['Gust of Wind'], 'Triton');
    if (lvl >= 7) autoSpells(['Wall of Water'], 'Triton');
  }
  if (c.raceId === 'hobgoblin') {
    // Fey Gift (2024) — choose one spell from a list at level 3
    autoSpells(['Prestidigitation'], 'Hobgoblin');
  }
  if (c.raceId === 'kobold') {
    autoSpells(['Acid Splash'], 'Kobold');
    if (lvl >= 3) autoSpells(['Chromatic Orb'], 'Kobold');
    if (lvl >= 5) autoSpells(['Fear'], 'Kobold');
  }

  // ── Multiclass subclass spell lists ─────────────────────
  for (const mc of (c.multiclasses || [])) {
    if (!mc.subclassId || !mc.classId) continue;
    const mcSub = mc.subclassId;
    const mcLvl = mc.level || 1;
    // Cleric domain spells
    if (mc.classId === 'cleric') {
      if (mcSub==='life')      autoSpells(["Bless","Cure Wounds","Lesser Restoration","Spiritual Weapon","Beacon of Hope","Revivify","Death Ward","Guardian of Faith","Mass Cure Wounds","Raise Dead"].slice(0, Math.ceil(mcLvl/2)*2), "Life Domain");
      if (mcSub==='light')     autoSpells(["Burning Hands","Faerie Fire","Flaming Sphere","Scorching Ray","Daylight","Fireball","Guardian of Faith","Wall of Fire","Flame Strike","Scrying"].slice(0, Math.ceil(mcLvl/2)*2), "Light Domain");
      if (mcSub==='nature')    autoSpells(["Animal Friendship","Speak with Animals","Barkskin","Spike Growth","Plant Growth","Wind Wall","Dominate Beast","Grasping Vine","Insect Plague","Tree Stride"].slice(0, Math.ceil(mcLvl/2)*2), "Nature Domain");
      if (mcSub==='tempest')   autoSpells(["Fog Cloud","Thunderwave","Gust of Wind","Shatter","Call Lightning","Sleet Storm","Control Water","Ice Storm","Destructive Wave","Insect Plague"].slice(0, Math.ceil(mcLvl/2)*2), "Tempest Domain");
      if (mcSub==='trickery')  autoSpells(["Charm Person","Disguise Self","Mirror Image","Pass Without Trace","Blink","Dispel Magic","Dimension Door","Polymorph","Dominate Person","Modify Memory"].slice(0, Math.ceil(mcLvl/2)*2), "Trickery Domain");
      if (mcSub==='war')       autoSpells(["Divine Favor","Shield of Faith","Magic Weapon","Spiritual Weapon","Crusader's Mantle","Dispel Magic","Freedom of Movement","Stoneskin","Flame Strike","Hold Monster"].slice(0, Math.ceil(mcLvl/2)*2), "War Domain");
      if (mcSub==='knowledge') autoSpells(["Command","Identify","Augury","Suggestion","Nondetection","Speak with Dead","Arcane Eye","Confusion","Legend Lore","Scrying"].slice(0, Math.ceil(mcLvl/2)*2), "Knowledge Domain");
      if (mcSub==='death')     autoSpells(["False Life","Ray of Sickness","Blindness/Deafness","Ray of Enfeeblement","Animate Dead","Vampiric Touch","Blight","Death Ward","Antilife Shell","Cloudkill"].slice(0, Math.ceil(mcLvl/2)*2), "Death Domain");
      if (mcSub==='forge')     autoSpells(["Searing Smite","Shield of Faith","Magic Weapon","Warding Bond","Elemental Weapon","Protection from Energy","Fabricate","Wall of Fire","Animate Objects","Creation"].slice(0, Math.ceil(mcLvl/2)*2), "Forge Domain");
      if (mcSub==='grave')     autoSpells(["Bane","False Life","Gentle Repose","Ray of Enfeeblement","Revivify","Vampiric Touch","Blight","Death Ward","Antilife Shell","Raise Dead"].slice(0, Math.ceil(mcLvl/2)*2), "Grave Domain");
      if (mcSub==='twilight')  autoSpells(["Faerie Fire","Sleep","Moonbeam","See Invisibility","Aura of Vitality","Leomund's Tiny Hut","Aura of Life","Greater Invisibility","Circle of Power","Mislead"].slice(0, Math.ceil(mcLvl/2)*2), "Twilight Domain");
      if (mcSub==='arcana')    autoSpells(["Detect Magic","Magic Missile","Magic Weapon","Nystul's Magic Aura","Dispel Magic","Magic Circle","Arcane Eye","Leomund's Secret Chest","Planar Binding","Teleportation Circle"].slice(0, Math.ceil(mcLvl/2)*2), "Arcana Domain");
      if (mcSub==='order')     autoSpells(["Command","Heroism","Hold Person","Zone of Truth","Mass Healing Word","Slow","Compulsion","Locate Creature","Dominate Person","Hold Monster"].slice(0, Math.ceil(mcLvl/2)*2), "Order Domain");
      if (mcSub==='peace')     autoSpells(["Heroism","Sanctuary","Aid","Warding Bond","Beacon of Hope","Sending","Aura of Purity","Otiluke's Resilient Sphere","Greater Restoration","Rary's Telepathic Bond"].slice(0, Math.ceil(mcLvl/2)*2), "Peace Domain");
    }
    // Paladin oath spells
    if (mc.classId === 'paladin') {
      const OATH_SPELLS = {
        'devotion':  ["Protection from Evil and Good","Sanctuary","Lesser Restoration","Zone of Truth","Beacon of Hope","Dispel Magic","Freedom of Movement","Guardian of Faith","Commune","Flame Strike"],
        'ancients':  ["Ensnaring Strike","Speak with Animals","Moonbeam","Misty Step","Plant Growth","Protection from Energy","Ice Storm","Stoneskin","Commune with Nature","Tree Stride"],
        'vengeance': ["Bane","Hunter's Mark","Hold Person","Misty Step","Haste","Protection from Energy","Banishment","Dimension Door","Hold Monster","Scrying"],
        'conquest':  ["Armor of Agathys","Command","Hold Person","Spiritual Weapon","Bestow Curse","Fear","Dominate Beast","Stoneskin","Dominate Person","Cloud of Daggers"],
        'glory':     ["Guiding Bolt","Heroism","Enhance Ability","Warding Bond","Aura of Vitality","Protection from Energy","Compulsion","Freedom of Movement","Commune","Flame Strike"],
        'watchers':  ["Alarm","Detect Magic","Moonbeam","See Invisibility","Counterspell","Nondetection","Aura of Purity","Banishment","Hold Monster","Scrying"],
        'redemption':["Sanctuary","Sleep","Calm Emotions","Hold Person","Counterspell","Hypnotic Pattern","Otiluke's Resilient Sphere","Stoneskin","Hold Monster","Wall of Force"],
        'oathbreaker':["Hellish Rebuke","Inflict Wounds","Crown of Madness","Darkness","Animate Dead","Bestow Curse","Blight","Confusion","Contagion","Dominate Person"],
      };
      const oathList = OATH_SPELLS[mcSub] || [];
      autoSpells(oathList.slice(0, Math.ceil(mcLvl/2)*2), `${mcSub} Oath`);
    }
    // Warlock patron expanded spells
    if (mc.classId === 'warlock') {
      const PATRON_SPELLS = {
        'archfey':     ["Faerie Fire","Sleep","Calm Emotions","Phantasmal Force","Blink","Plant Growth","Dominate Beast","Greater Invisibility","Dominate Person","Seeming"],
        'fiend':       ["Burning Hands","Command","Blindness/Deafness","Scorching Ray","Fireball","Stinking Cloud","Fire Shield","Wall of Fire","Flame Strike","Hallow"],
        'great-old-one':["Dissonant Whispers","Tashas Hideous Laughter","Detect Thoughts","Phantasmal Force","Clairvoyance","Sending","Dominate Beast","Evard's Black Tentacles","Dominate Person","Telekinesis"],
        'hexblade':    ["Shield","Wrathful Smite","Blur","Branding Smite","Blink","Elemental Weapon","Phantasmal Killer","Staggering Smite","Banishing Smite","Cone of Cold"],
        'celestial':   ["Cure Wounds","Guiding Bolt","Flaming Sphere","Lesser Restoration","Daylight","Revivify","Guardian of Faith","Wall of Fire","Mass Cure Wounds","Flame Strike"],
        'undead':      ["False Life","Ray of Sickness","Blindness/Deafness","Phantasmal Force","Phantom Steed","Speak with Dead","Death Ward","Greater Invisibility","Antilife Shell","Cloudkill"],
        'fathomless':  ["Create or Destroy Water","Thunderwave","Gust of Wind","Shatter","Lightning Bolt","Sleet Storm","Control Water","Evard's Black Tentacles","Cone of Cold","Wall of Ice"],
        'genie':       ["Detect Evil and Good","Sanctuary","Phantasmal Force","Spike Growth","Create Food and Water","Tongues","Phantasmal Killer","Secret Chest","Creation","Wish"],
      };
      const patronList = PATRON_SPELLS[mcSub] || [];
      autoSpells(patronList.slice(0, Math.ceil(mcLvl/2)*2), `${mcSub} Patron`);
    }
    // Druid circle spells
    if (mc.classId === 'druid' && mcSub === 'land' && c.subclassChoices?.land_terrain) {
      // Land circle terrain spells are handled similarly to the primary
    }
  }

  return pool;
}

// Collect all bonus spell names that are already chosen (for cap exclusion)
function getChosenBonusSpellNames(c) {
  const pool = getBonusSpellPool(c);
  const names = new Set();
  const fc = c.featChoices || {};
  const sc = c.subclassChoices || {};

  pool.forEach(entry => {
    if (entry.automatic) {
      // Always-prepared spells are always in the bonus pool
      names.add(entry.name);
    } else {
      // All choice-based entries use toggleFeatSpell → stored in featChoices
      const chosen = fc[entry.key];
      if (Array.isArray(chosen)) chosen.forEach(n => names.add(n));
      else if (chosen && typeof chosen === 'string') names.add(chosen);
    }
  });
  return names;
}

function renderSubclassChoices(c) {
  const sc = c.subclassId;
  const sc_c = c.subclassChoices || {};
  const lvl = c.level;
  let html = "";

  // Helper: mini spell picker for subclass spells
  function subSpellPicker(key, spellNames, label, note) {
    const available = DATA.spells.filter(s => spellNames.includes(s.name));
    const chosen = sc_c[key] || spellNames; // subclass bonus spells are usually automatic
    return `<div style="margin-top:10px;padding:10px;background:var(--ink-panel-2);border-radius:8px;border:1px solid var(--border-dark)">
      <div style="font-size:12px;color:var(--gold);font-weight:600;margin-bottom:4px">${label}</div>
      ${note ? `<div style="font-size:11px;color:var(--text-muted);margin-bottom:6px">${note}</div>` : ""}
      <ul class="trait-list" style="margin:0">
        ${available.map(s => `<li><strong>${s.name}</strong> — ${s.summary}</li>`).join("")}
        ${spellNames.filter(n => !available.find(s => s.name===n)).map(n => `<li><strong>${n}</strong> — (import your sourcebook for full text)</li>`).join("")}
      </ul>
    </div>`;
  }

  // Helper: skill pick for subclass bonus skills
  function subSkillPick(key, skills, count, label) {
    const chosen = sc_c[key] || [];
    const atCap = chosen.length >= count;
    return `<div style="margin-top:10px;padding:10px;background:var(--ink-panel-2);border-radius:8px;border:1px solid var(--border-dark)">
      <div style="font-size:12px;color:var(--gold);font-weight:600;margin-bottom:4px">${label} (choose ${count})</div>
      <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:4px">
        ${skills.map(skill => {
          const sel = chosen.includes(skill);
          const dis = !sel && atCap;
          return `<span class="tag" style="cursor:${dis?"not-allowed":"pointer"};opacity:${dis?0.4:1};${sel?"background:var(--crimson);border-color:var(--crimson)":""}"
            ${dis?"":(`onclick="App.toggleSubclassArrayChoice('${key}','${skill.replace(/'/g,"\\'")}',${count})"`)}>
            ${skill}</span>`;
        }).join("")}
      </div>
    </div>`;
  }

  // Helper: free text choice
  function subTextChoice(key, label, placeholder) {
    return `<div style="margin-top:10px;" class="field">
      <label style="font-size:12px;color:var(--gold)">${label}</label>
      <input type="text" value="${escapeHtml(sc_c[key]||"")}" oninput="App.setSubclassChoice('${key}',this.value)" placeholder="${placeholder}" />
    </div>`;
  }

  // Helper: option pick (radio)
  function subOptionPick(key, options, label) {
    const chosen = sc_c[key] || "";
    return `<div style="margin-top:10px;padding:10px;background:var(--ink-panel-2);border-radius:8px;border:1px solid var(--border-dark)">
      <div style="font-size:12px;color:var(--gold);font-weight:600;margin-bottom:6px">${label}</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px">
        ${options.map(([val, lbl]) => `<span class="tag" style="cursor:pointer;${chosen===val?"background:var(--crimson);border-color:var(--crimson)":""}"
          onclick="App.setSubclassChoice('${key}','${val}')">${lbl}</span>`).join("")}
      </div>
    </div>`;
  }

  if (!sc) return "";

  html = `<div style="margin-top:16px;padding:14px;background:var(--ink-panel);border-radius:var(--radius);border:1px solid var(--gold)">
    <h3 style="color:var(--gold);font-size:14px;margin:0 0 8px">Subclass Choices</h3>`;

  switch (sc) {
    // ── Barbarian ────────────────────────────────────────────
    case "totem-warrior":
      html += subOptionPick("totem_spirit", [
        ["bear","Bear — resist all non-psychic damage while raging"],
        ["eagle","Eagle — Dash as bonus action, no opportunity attacks on you"],
        ["wolf"," Wolf — allies have advantage on melee attacks vs enemies near you"],
      ], "Totem Spirit (level 3)");
      if (lvl >= 6) html += subOptionPick("totem_aspect", [
        ["bear","Bear — carry double, ignore encumbrance"],
        ["eagle","Eagle — see 1 mile, spot hiding creatures"],
        ["wolf"," Wolf — track without penalty, move through difficult terrain"],
      ], "Aspect of the Beast (level 6)");
      if (lvl >= 14) html += subOptionPick("totem_attune", [
        ["bear","Bear — frightened creatures must attack you if able"],
        ["eagle","Eagle — fly speed equal to walking while raging"],
        ["wolf"," Wolf — knock prone after 15 ft charge (STR save)"],
      ], "Totemic Attunement (level 14)");
      break;

    // ── Bard ─────────────────────────────────────────────────
    case "lore":
      if (lvl >= 3) html += subSkillPick("lore_skills", SKILLS.map(([n])=>n), 3, "Bonus Proficiencies (3 skills of your choice)");
      if (lvl >= 6) html += subSpellPicker("lore_secrets", ["Counterspell","Hypnotic Pattern","Fireball","Haste","Greater Invisibility","Fly"], "Additional Magical Secrets (2 spells from any list)", "Choose any 2 spells from the options below or pick from the Spells step.");
      break;
    case "valor":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Bonus proficiencies: medium armor, shields, martial weapons.<br>✓ Combat Inspiration: your Bardic Inspiration can be added to damage or AC.<br>${lvl>=6?"✓ Extra Attack at level 6.":""}${lvl>=14?"<br>✓ Battle Magic: bonus action weapon attack after casting a spell.":""}</div>`;
      break;
    case "valor":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Bonus proficiencies: medium armor, shields, martial weapons.<br>✓ Combat Inspiration: your Bardic Inspiration can be added to damage or AC.<br>${lvl>=6?"✓ Extra Attack at level 6.":""}${lvl>=14?"<br>✓ Battle Magic: bonus action weapon attack after casting a spell.":""}</div>`;
      break;

    // ── Cleric Domains ───────────────────────────────────────
    case "knowledge":
      html += subSkillPick("know_langs", ["Elvish","Dwarvish","Draconic","Giant","Gnomish","Goblin","Halfling","Orc","Abyssal","Celestial","Deep Speech","Infernal","Primordial","Sylvan","Undercommon"], 2, "Bonus Languages (choose 2)");
      html += subSkillPick("know_skills", ["Arcana","History","Nature","Religion"], 2, "Bonus Skill Expertise — double proficiency (choose 2)");
      break;
    case "life":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus proficiency: heavy armor.</div>`;
      html += `<div style="margin-top:6px;font-size:13px;color:var(--text-muted)">Disciple of Life: healing spells restore extra HP = 2 + spell level.${lvl>=6?" Blessed Healer: when healing others, you also regain HP.":""}${lvl>=8?" Divine Strike: +1d8 radiant on weapon attacks.":""}</div>`;
      break;
    case "light":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus cantrip: Light. Warding Flare: impose disadvantage on attacks vs you (WIS mod uses/long rest).</div>`;
      html += `<div style="margin-top:6px;font-size:13px;color:var(--text-muted)">${lvl>=8?"Potent Spellcasting: add WIS mod to cantrip damage.":""}${lvl>=17?" Corona of Light: 60 ft bright sunlight aura.":""}</div>`;
      break;
    case "death":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus proficiency: martial weapons. Reaper: necromancy cantrips can affect two targets.</div>`;
      html += subOptionPick("death_cantrip", [
        ["toll-the-dead","Toll the Dead"],["chill-touch","Chill Touch"],
        ["spare-the-dying","Spare the Dying"],["poison-spray","Poison Spray"],
      ], "Reaper — choose one Cleric necromancy cantrip");
      html += `<div style="margin-top:6px;font-size:13px;color:var(--text-muted)">${lvl>=6?"Inescapable Destruction: necrotic damage ignores resistance.":""}${lvl>=8?" Divine Strike: +1d8 necrotic on weapon attacks.":""}${lvl>=17?" Improved Reaper: extend single-target necromancy spells to two targets.":""}</div>`;
      break;
    case "nature":
      html += subSkillPick("nature_skill", ["Animal Handling","Nature","Survival"], 1, "Bonus Skill Proficiency (choose 1)");
      html += subOptionPick("nature_cantrip", [
        ["druidcraft","Druidcraft"],["shillelagh","Shillelagh"],["produce-flame","Produce Flame"],
        ["thorn-whip","Thorn Whip"],["poison-spray","Poison Spray"],
      ], "Acolyte of Nature — bonus druid cantrip (choose 1)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">${lvl>=6?"Dampen Elements: reaction to grant resistance to acid/cold/fire/lightning/thunder.":""}${lvl>=8?" Divine Strike: +1d8 cold/fire/lightning on weapon attacks.":""}${lvl>=17?" Master of Nature: bonus action to command charmed beasts/plant creatures.":""}</div>`;
      break;
    case "trickery":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Blessing of the Trickster: grant advantage on Stealth (touch, 1 hour).</div>`;
      html += `<div style="margin-top:6px;font-size:13px;color:var(--text-muted)">${lvl>=6?"Channel Divinity: Invoke Duplicity — create an illusory duplicate for 1 minute.":""}${lvl>=8?" Divine Strike: +1d8 poison on weapon attacks.":""}${lvl>=17?" Improved Duplicity: four duplicates instead of one.":""}</div>`;
      break;
    case "war":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus proficiencies: martial weapons, heavy armor.</div>`;
      html += `<div style="margin-top:6px;font-size:13px;color:var(--text-muted)">War Priest: bonus action weapon attack (WIS mod uses/long rest).${lvl>=8?" Divine Strike: +1d8 weapon damage type.":""}${lvl>=17?" Avatar of Battle: resistance to B/P/S from nonmagical weapons.":""}</div>`;
      break;
    case "tempest":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus proficiencies: martial weapons, heavy armor.</div>`;
      html += `<div style="margin-top:6px;font-size:13px;color:var(--text-muted)">Wrath of the Storm: reaction when hit — 2d8 lightning or thunder (DEX save, WIS mod uses/long rest).${lvl>=6?" Thunderbolt Strike: when dealing lightning, push Large or smaller creatures 10 ft.":""}${lvl>=8?" Divine Strike: +1d8 thunder on weapon attacks.":""}${lvl>=17?" Stormborn: fly speed equal to walking when outdoors.":""}</div>`;
      break;
    // Elemental Evil domains (Princes of the Apocalypse / EEPC)
    case "air":
      html += subSpellPicker("air_domain_spells", ["Fog Cloud","Gust of Wind","Chain Lightning","Control Weather","Conjure Elemental"], "Air Domain Spells", "Always prepared.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus cantrip: Gust. Breath of the Sky (Channel Divinity): grant fly speed or suffocate a creature.</div>`;
      break;
    case "earth":
      html += subSpellPicker("earth_domain_spells", ["Shillelagh","Spike Growth","Stone Shape","Stoneskin","Wall of Stone"], "Earth Domain Spells", "Always prepared.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus cantrip: Magic Stone. Earthen Stride (Channel Divinity): move through stone/earth/mud for 1 minute.</div>`;
      break;
    case "fire":
      html += subSpellPicker("fire_domain_spells", ["Burning Hands","Flaming Sphere","Fireball","Fire Shield","Flame Strike"], "Fire Domain Spells (always prepared)", "These spells are always prepared and don't count against your limit.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus cantrip: Fire Bolt. Fiery Wrath (Channel Divinity): creatures within 30 ft make DEX save or take 2d8+WIS fire damage.</div>`;
      html += `<div style="margin-top:6px;font-size:13px;color:var(--text-muted)">${lvl>=6?"Cauterize: when dealing fire damage, also deal half that as healing to an ally within 30 ft.":""}${lvl>=8?" Divine Strike: +1d8 fire on weapon attacks.":""}</div>`;
      break;
    case "water":
      html += subSpellPicker("water_domain_spells", ["Create or Destroy Water","Fog Cloud","Water Walk","Watery Sphere","Control Water"], "Water Domain Spells", "Always prepared.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus cantrip: Shape Water. Blessing of the Tidebringer (Channel Divinity): push and slow creatures.</div>`;
      break;

    // ── Druid Circles ────────────────────────────────────────
    case "land":
      html += subOptionPick("land_terrain", [
        ["arctic","Arctic"],["coast","Coast"],["desert","Desert"],
        ["forest","Forest"],["grassland","Grassland"],["mountain","Mountain"],
        ["swamp"," Swamp"],["underdark"," Underdark"],
      ], "Circle of the Land — choose your terrain (grants bonus spells)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Bonus cantrip from your druid list.<br>✓ Natural Recovery: recover spell slots on short rest (up to half druid level in levels, max 5th).</div>`;
      break;
    case "moon":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Combat Wild Shape: Wild Shape as bonus action; spend spell slots to heal in beast form (1d8 HP per slot level).<br>✓ CR cap = 1 at level 2 (increases to level/3 at 6th).<br>${lvl>=6?"✓ Primal Strike: beast attacks count as magical.":""}${lvl>=10?"<br>✓ Elemental Wild Shape: 2 uses to become an elemental.":""}${lvl>=14?"<br>✓ Thousand Forms: cast Alter Self at will.":""}</div>`;
      break;

    // ── Fighter Archetypes ───────────────────────────────────
    case "champion":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Improved Critical: crit on 19–20 (18–20 at level 15).<br>${lvl>=7?"✓ Remarkable Athlete: add half prof to uninvested STR/DEX/CON checks; +STR mod to running jump.":""}${lvl>=10?"<br>✓ Additional Fighting Style: choose a second option.":""}${lvl>=18?"<br>✓ Survivor: regain 5 + CON mod HP at start of turn when below half.":""}</div>`;
      if (lvl >= 10) html += subOptionPick("champ_style2", [
        ["archery","Archery (+2 ranged attack)"],["defense","Defense (+1 AC in armor)"],
        ["dueling","Dueling (+2 damage 1-handed)"],["great-weapon","Great Weapon (+reroll 1s and 2s)"],
        ["protection","Protection (impose disadvantage on attack vs ally)"],["two-weapon","Two-Weapon (add mod to off-hand damage)"],
      ], "Additional Fighting Style (level 10)");
      break;
    case "battle-master":
      html += subSkillPick("bm_tool", ["Artisan's tools (one type)","Gaming set (one type)","Musical instrument (one type)"], 1, "Student of War — artisan tool proficiency");
      html += subOptionPick("bm_maneuver1", [
        ["commander","Commander's Strike"],["disarming","Disarming Attack"],["distracting","Distracting Strike"],
        ["evasive","Evasive Footwork"],["feinting","Feinting Attack"],["goading","Goading Attack"],
        ["lunging","Lunging Attack"],["maneuvering","Maneuvering Attack"],["menacing","Menacing Attack"],
        ["parry","Parry"],["precision","Precision Attack"],["pushing","Pushing Attack"],
        ["rally","Rally"],["riposte","Riposte"],["sweeping","Sweeping Attack"],["trip","Trip Attack"],
      ], "Maneuver 1 (choose one)");
      html += subOptionPick("bm_maneuver2", [["commander","Commander's Strike"],["disarming","Disarming Attack"],["distracting","Distracting Strike"],["evasive","Evasive Footwork"],["feinting","Feinting Attack"],["goading","Goading Attack"],["lunging","Lunging Attack"],["maneuvering","Maneuvering Attack"],["menacing","Menacing Attack"],["parry","Parry"],["precision","Precision Attack"],["pushing","Pushing Attack"],["rally","Rally"],["riposte","Riposte"],["sweeping","Sweeping Attack"],["trip","Trip Attack"]],"Maneuver 2 (choose one)");
      html += subOptionPick("bm_maneuver3", [["commander","Commander's Strike"],["disarming","Disarming Attack"],["distracting","Distracting Strike"],["evasive","Evasive Footwork"],["feinting","Feinting Attack"],["goading","Goading Attack"],["lunging","Lunging Attack"],["maneuvering","Maneuvering Attack"],["menacing","Menacing Attack"],["parry","Parry"],["precision","Precision Attack"],["pushing","Pushing Attack"],["rally","Rally"],["riposte","Riposte"],["sweeping","Sweeping Attack"],["trip","Trip Attack"]],"Maneuver 3 (choose one)");
      break;
    case "eldritch-knight":
    case "eldritch-knight-2024":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Spellcasting: Wizard spells (Intelligence). Mostly Abjuration and Evocation; 2 exceptions allowed (choose from Spells step). Weapon Bond: bond up to 2 weapons — they can't be disarmed and teleport to your hand as a bonus action.</div>`;
      break;
    case "cavalier":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus proficiency: Animal Handling or one language. Born to the Saddle: mount as bonus action, advantage on saves to not fall, land on feet when falling from mount.</div>`;
      html += subOptionPick("cavalier_prof", [
        ["animal-handling","Animal Handling (skill)"],
        ["lang-elvish","Elvish"],["lang-dwarvish","Dwarvish"],["lang-draconic","Draconic"],
        ["lang-giant","Giant"],["lang-orc","Orc"],["lang-infernal","Infernal"],
        ["lang-abyssal","Abyssal"],["lang-celestial","Celestial"],["lang-gnomish","Gnomish"],
        ["lang-goblin","Goblin"],["lang-halfling","Halfling"],["lang-primordial","Primordial"],
        ["lang-sylvan","Sylvan"],["lang-undercommon","Undercommon"],
      ], "Bonus Proficiency — choose one");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Unwavering Mark: when you hit, mark the creature — it has disadvantage on attacks vs others, and you can make a bonus attack if it attacks someone else (WIS mod uses/long rest).${lvl>=7?" Warding Maneuver (reaction): +1d8 AC to you or mount, reduce damage if still hit.":""}${lvl>=10?" Hold the Line: creatures provoke OA from you if they move 5+ ft, hit reduces speed to 0.":""}${lvl>=15?" Ferocious Charger: charge attack can knock prone.":""}${lvl>=18?" Vigilant Defender: OA at start of each creature's turn.":""}</div>`;
      break;
    case "arcane-archer":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Arcane Shot: 2 uses per short rest. When you hit with longbow/shortbow, apply one Arcane Shot option.</div>`;
      html += subOptionPick("aa_shot1", [
        ["banishing","Banishing Arrow"],["beguiling","Beguiling Arrow"],["bursting","Bursting Arrow"],
        ["enfeebling","Enfeebling Arrow"],["grasping","Grasping Arrow"],["piercing","Piercing Arrow"],
        ["seeking","Seeking Arrow"],["shadow","Shadow Arrow"],
      ], "Arcane Shot 1 (level 3)");
      html += subOptionPick("aa_shot2", [
        ["banishing","Banishing Arrow"],["beguiling","Beguiling Arrow"],["bursting","Bursting Arrow"],
        ["enfeebling","Enfeebling Arrow"],["grasping","Grasping Arrow"],["piercing","Piercing Arrow"],
        ["seeking","Seeking Arrow"],["shadow","Shadow Arrow"],
      ], "Arcane Shot 2 (level 3)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Magic Arrow: arrows you fire count as magical. Curving Shot (level 7): bonus action on miss to reroll against a different target.${lvl>=15?" Learn 2 more Arcane Shot options.":""}</div>`;
      break;
    case "samurai":
      html += subOptionPick("samurai_prof", [
        ["history","History"],["insight","Insight"],["performance","Performance"],["persuasion","Persuasion"],
      ], "Bonus Proficiency — choose one skill");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Fighting Spirit (3/long rest): bonus action — advantage on all weapon attacks until end of turn + temp HP.${lvl>=7?" Elegant Courtier: +WIS mod to Persuasion; WIS save proficiency.":""}${lvl>=10?" Tireless Spirit: regain 1 Fighting Spirit use at start of combat if empty.":""}${lvl>=15?" Rapid Strike: forgo advantage on one attack to make an extra attack.":""}${lvl>=18?" Strength Before Death: bonus turn when reduced to 0 HP.":""}</div>`;
      break;
    case "rune-knight":
      html += subOptionPick("rune1", [
        ["cloud","Cloud Rune (deception, misty step reaction)"],["fire","Fire Rune (restraining flames)"],
        ["frost","Frost Rune (strength, intimidation)"],["stone","Stone Rune (wisdom, charming gaze)"],
        ["hill","Hill Rune (resistance to blunt damage)"],["storm","Storm Rune (foresight, reaction advantage)"],
      ], "Rune 1 (level 3)");
      html += subOptionPick("rune2", [
        ["cloud","Cloud Rune"],["fire","Fire Rune"],["frost","Frost Rune"],
        ["stone","Stone Rune"],["hill","Hill Rune"],["storm","Storm Rune"],
      ], "Rune 2 (level 3)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Giant's Might (prof bonus/long rest): bonus action — grow Large, advantage on STR checks/saves, +1d6 damage.${lvl>=7?" Runic Shield (prof bonus/long rest): force attacker to reroll vs ally.":""}${lvl>=10?" Great Stature: +3d4 in height; Giant's Might grants +1d8.":""}${lvl>=15?" Master of Runes: invoke each rune twice per short rest.":""}${lvl>=18?" Runic Juggernaut: Huge size, +5 ft reach, +1d10 damage.":""}</div>`;
      break;
    case "psi-warrior":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Psionic Power (Psionic Energy dice = 2× prof bonus d6s): Protective Field (reduce damage), Psionic Strike (bonus damage after hit), Telekinetic Movement (move object/creature 30 ft).${lvl>=7?" Telekinetic Adept: Psionic Thrust (knock prone/push) and Hover (fly speed this turn).":""}${lvl>=10?" Guarded Mind: spend die to end charmed/frightened; resistance to psychic.":""}${lvl>=15?" Bulwark of Force: half cover for up to INT mod allies.":""}${lvl>=18?" Telekinetic Master: Telekinesis at will; bonus attack while concentrating.":""}</div>`;
      break;
    case "echo-knight":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Manifest Echo (bonus action): create a spectral duplicate — you can attack from its position. Unleash Incarnation (CON mod/long rest): echo makes simultaneous melee attack when you take extra attack.${lvl>=7?" Echo Avatar: see/hear through echo for 10 min/long rest.":""}${lvl>=10?" Shadow Martyr: redirect attack to echo (reaction).":""}${lvl>=15?" Reclaim Potential: gain 2d6+CON temp HP when echo destroyed.":""}${lvl>=18?" Legion of One: two echoes simultaneously; Unleash Incarnation recharges on short rest.":""}</div>`;
      break;
    case "brawler":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Unarmed Fighting Style: unarmed strikes deal 1d6 (1d8 if both hands free). Grappling: 2 free damage dice on grappled target. Bonus improvised weapon proficiency.${lvl>=7?" Dirty Fighting: bonus action to impose a condition when you hit an unarmed/improvised attack.":""}${lvl>=10?" Improvised Weapon Mastery: improvised weapons deal 2d6+STR.":""}${lvl>=15?" Improvised Combat Expert: attack twice with improvised weapons, carry objects as improvised shields.":""}</div>`;
      break;

    // ── Monk additional ──────────────────────────────────────
    case "astral-self":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Arms of the Astral Self (2 Ki, bonus action): manifest arms for 10 min — use WIS for attacks, extra range, bonus unarmed attack. Visage (3 Ki): advantage on Insight/Intimidation, darkvision, speak any language.${lvl>=11?" Body (5 Ki): fly speed, resist B/P/S.":""}${lvl>=17?" Awakened Astral Self: arms + visage + body simultaneously; extra attack with arms.":""}</div>`;
      break;
    case "mercy":
      html += subSkillPick("mercy_tool", ["Herbalism kit"], 1, "Bonus Proficiency: Herbalism Kit");
      html += subSkillPick("mercy_skill", ["Insight","Medicine"], 1, "Bonus Skill (choose 1)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Hand of Harm (1 Ki): deal +WIS mod necrotic on unarmed hit + impose poisoned. Hand of Healing (1 Ki): heal 1d6+WIS. Implements of Mercy: mask and herbalism kit.${lvl>=6?" Physician's Touch: Hands of Healing cure poison/disease; Hands of Harm add poisoned condition.":""}${lvl>=11?" Flurry of Healing and Harm: free Healing hands with Flurry; no Ki for Harm with Flurry.":""}${lvl>=17?" Hand of Ultimate Mercy: 5 Ki to revive a dead creature (≤ 24 hours) at 4d10+WIS HP.":""}</div>`;
      break;
    case "ascendant-dragon":
      html += subOptionPick("dragon_aspect", [
        ["black","Black/Copper — Acid"],["blue","Blue/Bronze — Lightning"],
        ["green","Green — Poison"],["red","Red/Gold/Brass — Fire"],["white","White/Silver — Cold"],
      ], "Draconic Aspect — choose your dragon type");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Dragon Strikes: Ki use adds 1d4 elemental damage. Wings Unfurled (2 Ki): fly speed = walking speed for 10 min.${lvl>=6?" Aspect of the Wyrm: reaction to grant resistance or frighten.":""}${lvl>=11?" Ascendant Aspect: blindsight 10 ft; unarmed strikes ignore resistance; extra breath weapon damage.":""}${lvl>=17?" Body of the Wyrm: fly at will; breath weapon is maximized.":""}</div>`;
      break;

    // ── Rogue additional ─────────────────────────────────────
    case "swashbuckler":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Fancy Footwork: melee attack vs creature → no OA from it until your next turn. Rakish Audacity: Sneak Attack when alone with a target (no ally needed, no disadvantage). +CHA mod to initiative.${lvl>=9?" Panache: Persuasion vs Insight to charm or taunt a creature.":""}${lvl>=13?" Elegant Maneuver: bonus action for advantage on next Acrobatics or Athletics.":""}${lvl>=17?" Master Duelist: if you miss, reroll once per short rest.":""}</div>`;
      break;
    case "phantom":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Whispers of the Dead: gain one skill/tool proficiency each short rest. Wails from the Grave (prof bonus/long rest): after Sneak Attack, deal half necrotic to another creature within 30 ft.${lvl>=9?" Tokens of the Departed: capture soul trinkets from dying creatures.":""}${lvl>=13?" Ghost Walk (3 uses/long rest): become ghostly for 10 min — hover, pass through objects, resistance to all damage.":""}${lvl>=17?" Death's Friend: one soul trinket always active; free Wails from the Grave use.":""}</div>`;
      break;

    // ── Sorcerer additional ──────────────────────────────────
    case "divine-soul":
      html += subOptionPick("divine_affinity", [
        ["good","Good — learn Cure Wounds, +CHA to heal"],
        ["evil","Evil — learn Inflict Wounds, immunity to charmed"],
        ["law","Law — learn Bless, +1d4 to saves for one creature"],
        ["chaos","Chaos — learn Bane, roll 1d4 on initiative (+ or − randomly)"],
        ["neutrality","Neutrality — learn Protection from Good and Evil, +1 AC vs one type"],
      ], "Divine Affinity — choose your celestial origin");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Divine Magic: access the cleric spell list. Favored by the Gods: add 2d4 to a failed save or attack roll (1/short rest).${lvl>=6?" Empowered Healing: spend 1 SP to reroll healing dice.":""}${lvl>=14?" Otherworldly Wings: sprout feathered or bat wings — fly speed = walking.":""}${lvl>=18?" Unearthly Recovery: regain half HP max (1/long rest) when below half HP.":""}</div>`;
      break;
    case "open-hand":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Open Hand Technique: after Flurry of Blows — push 15 ft, knock prone, or prevent reactions.<br>${lvl>=6?"✓ Wholeness of Body: heal 3× monk level HP (1/long rest).":""}${lvl>=11?"<br>✓ Tranquility: Sanctuary on yourself each long rest.":""}${lvl>=17?"<br>✓ Quivering Palm: set vibrations (3 ki) — later use action to deal massive damage or kill.":""}</div>`;
      break;
    case "shadow":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Shadow Arts: cast Darkness, Darkvision, Pass Without Trace, or Silence for 2 ki each. Minor Illusion cantrip free.<br>${lvl>=6?"✓ Shadow Step: teleport 60 ft between dim light/darkness (bonus action); advantage on first attack.":""}${lvl>=11?"<br>✓ Cloak of Shadows: become invisible in dim light/darkness as an action.":""}${lvl>=17?"<br>✓ Opportunist: reaction attack when nearby creature gets hit.":""}</div>`;
      break;
    case "four-elements":
      html += subOptionPick("element_disc1", [
        ["burning-hands","Burning Hands (Fangs of the Fire Snake)"],["feather-fall","Feather Fall (Clench of the North Wind)"],
        ["thunderwave","Thunderwave (Fist of Four Thunders)"],["fog-cloud","Fog Cloud (Mist Stance)"],
        ["shape-water","Shape Water (Shape the Flowing River)"],["gust","Gust of Wind (Rush of the Gale Spirits)"],
        ["earth-tremor","Earth Tremor (Sweeping Cinder Strike)"],
      ], "Elemental Discipline 1");
      html += subOptionPick("element_disc2", [["burning-hands","Burning Hands"],["feather-fall","Feather Fall"],["thunderwave","Thunderwave"],["fog-cloud","Fog Cloud"],["shape-water","Shape Water"],["gust","Gust of Wind"],["earth-tremor","Earth Tremor"]],"Elemental Discipline 2");
      break;

    // ── Paladin Oaths ────────────────────────────────────────
    case "devotion":
      html += subSpellPicker("oath_spells", ["Protection from Evil and Good","Sanctuary","Lesser Restoration","Zone of Truth","Beacon of Hope","Dispel Magic","Freedom of Movement","Guardian of Faith","Commune","Flame Strike"], "Oath of Devotion Spells (always prepared)", "These spells are always prepared and don't count against your prepared spell limit.");
      break;
    case "ancients":
      html += subSpellPicker("oath_spells", ["Ensnaring Strike","Speak with Animals","Moonbeam","Misty Step","Plant Growth","Protection from Energy","Ice Storm","Stoneskin","Commune with Nature","Tree Stride"], "Oath of the Ancients Spells (always prepared)", "Always prepared, don't count against limit.");
      break;
    case "vengeance":
      html += subSpellPicker("oath_spells", ["Bane","Hunter's Mark","Hold Person","Misty Step","Haste","Protection from Energy","Banishment","Dimension Door","Hold Monster","Scrying"], "Oath of Vengeance Spells (always prepared)", "Always prepared, don't count against limit.");
      break;

    // ── Ranger Archetypes ────────────────────────────────────
    case "hunter":
      html += subOptionPick("hunter_prey", [
        ["colossus","Colossus Slayer — +1d8 to one attack/turn vs a damaged target"],
        ["giant","Giant Killer — reaction attack vs Large+ creature that attacks you"],
        ["horde","Horde Breaker — one extra attack vs adjacent creature after attacking"],
      ], "Hunter's Prey (level 3)");
      if (lvl >= 7) html += subOptionPick("hunter_defense", [
        ["escape","Escape the Horde — no opportunity attacks while moving"],
        ["multidef","Multiattack Defense — +4 AC after being hit until your next turn"],
        ["steel","Steel Will — advantage vs being frightened"],
      ], "Defensive Tactics (level 7)");
      if (lvl >= 11) html += subOptionPick("hunter_multi", [
        ["volley","Volley — ranged attack vs all in a 10-ft radius"],
        ["whirlwind","Whirlwind Attack — melee attack vs each creature within reach"],
      ], "Multiattack (level 11)");
      break;
    case "beast-master":
      html += subOptionPick("beast_cr", [
        ["1/4","CR 1/4 beast (default)"],["1/2","CR 1/2 beast"],["1","CR 1 beast (level 4+)"],
      ], "Ranger's Companion — beast CR");
      html += subTextChoice("beast_name", "Companion name", "e.g. Shadow (wolf), Stonetalon (eagle)");
      break;

    // ── Rogue Archetypes ─────────────────────────────────────
    case "thief":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Fast Hands: bonus action to Sleight of Hand, Use Object, or thieves' tools.<br>✓ Second-Story Work: climb without extra cost; running jump + DEX mod.<br>${lvl>=9?"✓ Supreme Sneak: advantage on Stealth at half speed.":""}${lvl>=13?"<br>✓ Use Magic Device: ignore class/race/level requirements on magic items.":""}${lvl>=17?"<br>✓ Thief's Reflexes: two turns in round 1 (second at initiative -10).":""}</div>`;
      break;
    case "assassin":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Bonus proficiencies: disguise kit, poisoner's kit.<br>✓ Assassinate: advantage vs creatures that haven't acted; crits on surprised targets.<br>${lvl>=9?"✓ Infiltration Expertise: create false identities.":""}${lvl>=13?"<br>✓ Impostor: perfectly mimic another person after 3 hours' study.":""}${lvl>=17?"<br>✓ Death Strike: double damage on crits vs surprised targets (CON save negates).":""}</div>`;
      break;
    case "arcane-trickster":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Spellcasting: Wizard spells (Intelligence). Mostly Enchantment & Illusion; 2 exceptions allowed.<br>✓ Mage Hand Legerdemain: enhanced invisible Mage Hand for picking pockets, locks, and traps remotely.</div>`;
      break;

    // ── Sorcerer Origins ─────────────────────────────────────
    case "draconic":
      html += subOptionPick("dragon_type", [
        ["black","Black — Acid"],["blue","Blue — Lightning"],["brass","Brass — Fire"],
        ["bronze","Bronze — Lightning"],["copper","Copper — Acid"],["gold","Gold — Fire"],
        ["green","Green — Poison"],["red","Red — Fire"],["silver","Silver — Cold"],
        ["white","White — Cold"],
      ], "Dragon Ancestor (choose dragon type — determines breath weapon and resistance)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Draconic Resilience: HP max +1 per level; AC 13 + DEX when unarmored.<br>${lvl>=6?"✓ Elemental Affinity: add CHA mod to spells of your ancestor's damage type; 1 SP for resistance 1 hour.":""}${lvl>=14?"<br>✓ Dragon Wings: sprout wings as bonus action (fly speed = walking).":""}${lvl>=18?"<br>✓ Draconic Presence: 5 SP for aura of awe or fear 60 ft.":""}</div>`;
      break;
    case "wild-magic":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Wild Magic Surge: DM may ask you to roll d20 after casting — on 1, roll the Wild Magic Surge table.<br>✓ Tides of Chaos: advantage on one roll 1/long rest (may trigger surge).<br>${lvl>=6?"✓ Bend Luck: 2 SP to add or subtract 1d4 from another's roll (reaction).":""}${lvl>=14?"<br>✓ Controlled Chaos: roll twice on Wild Magic table, choose either result.":""}${lvl>=18?"<br>✓ Spell Bombardment: once per turn, maximize one damage die and add another.":""}</div>`;
      break;

    // ── Warlock Patrons ──────────────────────────────────────
    case "archfey":
      html += subSpellPicker("patron_spells", ["Faerie Fire","Sleep","Calm Emotions","Phantasmal Force","Blink","Plant Growth","Dominate Beast","Greater Invisibility","Dominate Person","Seeming"], "Expanded Spell List (always available)", "These spells are added to your warlock spell list.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Fey Presence: 10-ft cube charm or frighten (WIS save), 1/short rest.<br>${lvl>=6?"✓ Misty Escape: become invisible and teleport 60 ft when you take damage (reaction), 1/short rest.":""}${lvl>=10?"<br>✓ Beguiling Defenses: immune to charm; redirect charms back.":""}${lvl>=14?"<br>✓ Dark Delirium: charm or frighten a creature in a false reality (1/short rest).":""}</div>`;
      break;
    case "fiend":
      html += subSpellPicker("patron_spells", ["Burning Hands","Command","Blindness/Deafness","Scorching Ray","Fireball","Stinking Cloud","Fire Shield","Wall of Fire","Flame Strike","Hallow"], "Expanded Spell List (always available)", "Added to your warlock spell list.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Dark One's Blessing: gain CHA mod + warlock level temp HP when you reduce a creature to 0 HP.<br>${lvl>=6?"✓ Dark One's Own Luck: 1/short rest, add 1d10 to ability check or save.":""}${lvl>=10?"<br>✓ Fiendish Resilience: resistance to one damage type (chosen after rest).":""}${lvl>=14?"<br>✓ Hurl Through Hell: send a hit creature through hell for 10d10 psychic, 1/long rest.":""}</div>`;
      break;
    case "great-old-one":
      html += subSpellPicker("patron_spells", ["Dissonant Whispers","Tasha's Hideous Laughter","Detect Thoughts","Phantasmal Force","Clairvoyance","Sending","Dominate Beast","Evard's Black Tentacles","Dominate Person","Telekinesis"], "Expanded Spell List (always available)", "Added to your warlock spell list.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Awakened Mind: telepathically communicate with any creature within 30 ft that knows a language.<br>${lvl>=6?"✓ Entropic Ward: impose disadvantage on attack vs you; if miss, advantage on next attack vs it (1/short rest).":""}${lvl>=10?"<br>✓ Thought Shield: mind can't be read; resistance to psychic; attacker takes same psychic damage.":""}${lvl>=14?"<br>✓ Create Thrall: touch incapacitated humanoid to charm it indefinitely.":""}</div>`;
      break;

    // ── Wizard Schools ───────────────────────────────────────
    case "abjuration":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Abjuration Savant: half cost/time to copy Abjuration spells.<br>✓ Arcane Ward: ward absorbs damage (HP = 2× wizard level + INT mod); recharge by casting Abjuration spells.<br>${lvl>=6?"✓ Projected Ward: ward protects allies within 30 ft.":""}${lvl>=10?"<br>✓ Improved Abjuration: add proficiency bonus to Abjuration spell ability checks (counterspell, dispel).":""}${lvl>=14?"<br>✓ Spell Resistance: advantage on saves vs spells; resistance to spell damage.":""}</div>`;
      break;
    case "conjuration":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Conjuration Savant: half cost/time to copy Conjuration spells.<br>✓ Minor Conjuration: create a small nonliving object in an unoccupied space within 10 ft.<br>${lvl>=6?"✓ Benign Transposition: teleport 30 ft or swap with a willing creature (recharges on Conjuration cast).":""}${lvl>=10?"<br>✓ Focused Conjuration: concentration on Conjuration can't be broken by damage.":""}${lvl>=14?"<br>✓ Durable Summons: conjured creatures gain 30 temp HP.":""}</div>`;
      break;
    case "divination":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Divination Savant: half cost/time to copy Divination spells.<br>✓ Portent: roll 2 d20s after long rest; replace any d20 roll you or a visible creature makes with these (3 d20s at level 14).<br>${lvl>=6?"✓ Expert Divination: recover a lower-level slot when casting Divination of 2nd level+.":""}${lvl>=10?"<br>✓ The Third Eye: darkvision, ethereal sight, read any language, or see invisible (1/short rest).":""}${lvl>=14?"<br>✓ Greater Portent: three portent dice instead of two.":""}</div>`;
      break;
    case "enchantment":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Enchantment Savant: half cost/time to copy Enchantment spells.<br>✓ Hypnotic Gaze: charm and incapacitate a creature within 5 ft (WIS save; can re-attempt each turn).<br>${lvl>=6?"✓ Instinctive Charm: redirect attack to nearest other creature (WIS save, 1/long rest per creature).":""}${lvl>=10?"<br>✓ Split Enchantment: target a second creature with single-target Enchantment spells.":""}${lvl>=14?"<br>✓ Alter Memories: make charmed creatures forget the effect duration (INT save).":""}</div>`;
      break;
    case "evocation":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Evocation Savant: half cost/time to copy Evocation spells.<br>✓ Sculpt Spells: protect 1 + spell level creatures from your Evocation area spells (auto-succeed save, no damage).<br>${lvl>=6?"✓ Potent Cantrip: damaging cantrips deal half damage on a successful save.":""}${lvl>=10?"<br>✓ Empowered Evocation: add INT mod to damage rolls of Evocation spells.":""}${lvl>=14?"<br>✓ Overchannel: deal max damage with an Evocation spell of 5th level or lower (extra uses cost you necrotic).":""}</div>`;
      break;
    case "illusion":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Illusion Savant: half cost/time to copy Illusion spells.<br>✓ Improved Minor Illusion: Minor Illusion can produce both sound and image together.<br>${lvl>=6?"✓ Malleable Illusions: change a concentration Illusion spell's nature as an action.":""}${lvl>=10?"<br>✓ Illusory Self: interpose an illusion to make an attack miss (1/short rest, reaction).":""}${lvl>=14?"<br>✓ Illusory Reality: make one inanimate illusion object real for 1 minute per casting.":""}</div>`;
      break;
    case "necromancy":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Necromancy Savant: half cost/time to copy Necromancy spells.<br>✓ Grim Harvest: regain HP = 2× spell level (3× for Necromancy) when killing with a spell.<br>${lvl>=6?"✓ Undead Thralls: Animate Dead raises one extra creature; undead get +prof bonus damage and extra HP.":""}${lvl>=10?"<br>✓ Inured to Undeath: resistance to necrotic; HP max can't be reduced.":""}${lvl>=14?"<br>✓ Command Undead: charm an undead creature (INT save; mindless auto-fail).":""}</div>`;
      break;
    case "transmutation":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">✓ Transmutation Savant: half cost/time to copy Transmutation spells.<br>✓ Minor Alchemy: transmute a small object (wood/stone/iron/copper/silver) for 1 hour.<br>${lvl>=6?"✓ Transmuter's Stone: create a stone granting darkvision, speed, CON proficiency, or damage resistance.":""}${lvl>=10?"<br>✓ Shapechanger: cast Polymorph on yourself at will (beast form only, no slot).":""}${lvl>=14?"<br>✓ Master Transmuter: consume your stone for major transformation, panacea, raise dead, or restore youth.":""}</div>`;
      break;

    // ── Barbarian additional ─────────────────────────────────
    case "berserker":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Frenzy: when you rage, you can go into a frenzy — make a bonus action melee attack each turn, but suffer exhaustion when rage ends. Mindless Rage (level 6): can't be charmed/frightened while raging.</div>`;
      break;
    case "storm-herald":
      html += subOptionPick("storm_type", [
        ["arctic","Arctic — CON save or restrained by ice; at lvl 10 fly speed"],
        ["desert","Desert — fire damage aura; at lvl 10 fire immunity"],
        ["sea","Sea — lightning damage to attackers; at lvl 10 swim speed 30 ft"],
      ], "Storm Aura — choose your environment");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Storm Aura activates when you rage. Storm Soul (lvl 6): resistance and environmental benefit from your type. Shielding Storm (lvl 10): allies in aura share resistance. Raging Storm (lvl 14): powerful effect vs attacker.</div>`;
      break;
    case "beast":
      html += subOptionPick("beast_form", [
        ["claws","Claws — extra attack each turn; movement bonus"],
        ["fangs","Fangs — bite regains HP on hit"],
        ["tail","Tail — +1 AC; reaction attack when ally is hit"],
      ], "Bestial Soul — choose your manifestation (level 3)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Bestial Soul: your chosen feature improves at level 6. Infectious Fury (level 10): target must attack another creature (WIS save). Call the Hunt (level 14): allies share your rage benefits.</div>`;
      break;
    case "wild-magic-barb":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Magic Awareness: detect magic 1/long rest. Wild Surge: when you rage, roll a d8 — on a 1, trigger a random wild magic effect from the table. Bolstering Magic (level 6): touch to give 1d3 bonus to rolls or regain a spell slot. Unstable Backlash (level 10): reaction to trigger wild surge when damaged. Controlled Surge (level 14): roll twice on wild magic table, choose either.</div>`;
      break;
    case "zealot":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Divine Fury: while raging, first hit each turn deals +1d6 radiant/necrotic (choose once). Warrior of the Gods: raise dead/resurrection on you costs no material components. Fanatical Focus (level 6): 1/rage, reroll a failed save. Zealous Presence (level 10): 10 allies gain advantage on attacks and saves. Rage Beyond Death (level 14): while raging, reaching 0 HP doesn't knock you out.</div>`;
      break;
    case "battlerager":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Battlerager Armor: while raging in spiked armor — bonus action spike attack 1d4 piercing + STR. Reckless Abandon (level 6): when using Reckless Attack, gain temp HP. Battlerager Charge (level 10): Dash as bonus action while raging. Spiked Retribution (level 14): attacker takes 3 piercing when they hit you in melee while you're raging. Requires dwarf.</div>`;
      break;
    case "giant":
      html += subOptionPick("giant_origin", [
        ["cloud","Cloud Giant — INT/CHA; psychic damage, levitation"],
        ["fire","Fire Giant — STR/CON; fire damage, fire resistance"],
        ["frost","Frost Giant — STR/CON; cold damage, cold resistance"],
        ["hill","Hill Giant — STR/CON; extra carrying, prone enemies"],
        ["stone","Stone Giant — STR/CON; no ranged disadvantage, throw rocks"],
        ["storm","Storm Giant — STR/CHA; lightning damage, swim/fly"],
      ], "Giant Ancestry — choose your origin");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Giant's Power: learn Giant language; cast a cantrip based on ancestry. Giant's Havoc (lvl 3): bonus reach 10 ft and thrown weapon range while raging. Elemental Cleaver (lvl 6): attacks deal +1d6 elemental damage. Mighty Impel (lvl 10): throw a creature. Demiurgic Colossus (lvl 14): Huge while raging, greater reach and damage.</div>`;
      break;

    // ── Bard additional ─────────────────────────────────────
    case "glamour":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Mantle of Inspiration: bonus action, expend Bardic Inspiration — give temp HP (die + CHA mod) and free movement to allies within 60 ft. Enthralling Performance: 1-minute performance charms 1d3+CHA mod creatures for 1 hour. Mantle of Majesty (level 6): Command as bonus action each turn for 1 minute (1/long rest). Unbreakable Majesty (level 14): unearthly appearance — attackers must pass WIS save or redirect.</div>`;
      break;
    case "whispers":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Psychic Blades: spend Bardic Inspiration on weapon hit to deal extra psychic damage (= die roll). Words of Terror: 1-minute conversation frightens a creature (WIS save). Mantle of Whispers (level 6): capture a humanoid's shadow when they die to disguise yourself as them (1 hour). Shadow Lore (level 14): 8-hour charm on a creature that forgets it afterward.</div>`;
      break;
    case "eloquence":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Silver Tongue: minimum roll of 10 on Deception and Persuasion. Unsettling Words: bonus action, expend Bardic Inspiration — subtract the roll from one creature's next saving throw. Unfailing Inspiration (level 6): when a creature fails using your inspiration, they keep the die. Universal Speech (level 6): CHA mod creatures understand you in any language for 1 hour.</div>`;
      break;
    case "creation":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Mote of Potential: Bardic Inspiration die adds bonus effects (advantage on attack, enhanced failure roll, area effect on skill). Performance of Creation: action — create a non-magical object (up to Large, value ≤ 20× bard level gp) for CHA mod hours. Animating Performance (level 6): animate the created object as a construct companion. Creative Crescendo (level 14): create up to CHA mod objects simultaneously.</div>`;
      break;
    case "spirits":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Guiding Whispers: Guidance cantrip with 60 ft range. Spiritual Focus: ritual objects (candle, crystal ball, skull) serve as foci; +die roll bonus to damage/healing spells. Tales from Beyond: expend Bardic Inspiration to roll for a random Spirit Tale effect. Spirit Session (level 6): 1-hour ritual to temporarily prepare a divination or necromancy spell.</div>`;
      break;
    case "dance":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Dazzling Footwork: Tumble (leave a creature's space without OA) as a bonus action. Inspiring Movement: when you move 10+ ft, an ally within 60 ft can use their reaction to move. Tandem Footwork (level 3): when you roll initiative, give CHA mod allies +1d6 to theirs. Leading Evasion (level 6): share your Evasion feature with adjacent allies.</div>`;
      break;
    case "swords":
      html += subOptionPick("swords_style", [
        ["dueling","Dueling — +2 damage one-handed"],
        ["two-weapon","Two-Weapon Fighting — add ability mod to off-hand damage"],
      ], "Fighting Style (Swords Bard, level 3)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Blade Flourish (level 3): after attacking, spend Bardic Inspiration for Defensive, Slashing, or Mobile Flourish. Extra Attack (level 6). Master's Flourish (level 14): roll a d6 instead of spending Inspiration for Blade Flourish.</div>`;
      break;

    // ── Cleric additional ────────────────────────────────────
    case "forge":
      html += subSpellPicker("forge_domain_spells", ["Searing Smite","Shield of Faith","Magic Weapon","Warding Bond","Elemental Weapon","Protection from Energy","Fabricate","Wall of Fire","Animate Objects","Creation"], "Forge Domain Spells (always prepared)", "Don't count against your prepared spell limit.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus: heavy armor + smith's tools. Blessing of the Forge: touch one weapon or armor at long rest — +1 attack/damage or +1 AC until next long rest. Soul of the Forge (level 6): +1 AC in heavy armor, resistance to fire. Divine Strike (level 8): +1d8 fire damage on weapon attacks.</div>`;
      break;
    case "grave":
      html += subSpellPicker("grave_domain_spells", ["Bane","False Life","Gentle Repose","Ray of Enfeeblement","Revivify","Vampiric Touch","Blight","Death Ward","Antilife Shell","Raise Dead"], "Grave Domain Spells (always prepared)", "Don't count against your prepared spell limit.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Circle of Mortality: healing cantrips on dying creatures heal max. Learn Spare the Dying (30 ft range). Sentinel at Death's Door (level 6): reaction to turn crits into normal hits (WIS mod/long rest). Divine Strike (level 8): +1d8 necrotic on weapon attacks.</div>`;
      break;
    case "arcana":
      html += subSpellPicker("arcana_domain_spells", ["Detect Magic","Magic Missile","Magic Weapon","Nystul's Magic Aura","Dispel Magic","Magic Circle","Arcane Eye","Leomund's Secret Chest","Planar Binding","Teleportation Circle"], "Arcana Domain Spells (always prepared)", "Don't count against your prepared spell limit.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Arcane Initiate: learn two wizard cantrips. Channel Divinity: Arcane Abjuration — turn celestials, elementals, fey, and fiends. Spell Breaker (level 6): healing spells also dispel a spell of matching level on the target. Potent Spellcasting (level 8): add WIS mod to cleric cantrip damage.</div>`;
      break;
    case "twilight":
      html += subSpellPicker("twilight_domain_spells", ["Faerie Fire","Sleep","Moonbeam","See Invisibility","Aura of Vitality","Leomund's Tiny Hut","Aura of Life","Greater Invisibility","Circle of Power","Mislead"], "Twilight Domain Spells (always prepared)", "Don't count against your prepared spell limit.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus: martial weapons, heavy armor. Eyes of Night: darkvision 300 ft; share with allies (CHA mod creatures, 1/long rest or spend slot). Vigilant Blessing: grant advantage on initiative (touch). Channel Divinity: Twilight Sanctuary — 30 ft sphere of dim light; allies gain temp HP or lose charmed/frightened.</div>`;
      break;
    case "order":
      html += subSkillPick("order_skill", ["Intimidation","Persuasion"], 1, "Bonus Proficiency — Intimidation or Persuasion");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Voice of Authority: cast a spell on an ally → they can attack as a reaction. Embodiment of the Law (level 6): enchantment spells as bonus action (INT mod/long rest). Channel Divinity: Order's Demand — charm beasts/humanoids (level 2).</div>`;
      break;
    case "peace":
      html += subSkillPick("peace_skill", ["Insight","Performance","Persuasion"], 1, "Implement of Peace — choose one proficiency");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Emboldening Bond: link up to prof-bonus creatures; each adds 1d4 to rolls when near a bonded ally. Channel Divinity: Balm of Peace — move and heal without OAs. Protective Bond (level 6): bonded creatures can redirect damage to themselves.</div>`;
      break;
    case "death":
      html += subOptionPick("death_cantrip", [
        ["toll-the-dead","Toll the Dead"],["chill-touch","Chill Touch"],
        ["spare-the-dying","Spare the Dying"],["poison-spray","Poison Spray"],
      ], "Reaper — bonus necromancy cantrip");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Reaper: necromancy cantrips can affect two targets. Channel Divinity: Touch of Death — deal extra necrotic = 5 + 2× cleric level. Inescapable Destruction (level 6): necrotic ignores resistance. Divine Strike (level 8): +1d8 necrotic. Improved Reaper (level 17): extend single-target necromancy to 2 targets.</div>`;
      break;

    // ── Druid additional ─────────────────────────────────────
    case "dreams":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Balm of the Summer Court: pool of d6s (= druid level). Bonus action: spend up to WIS mod dice to heal a creature within 120 ft and restore speed if prone/grappled. Hearth of Moonlight and Shadow (level 6): sanctuary on long rests in the wild — concealed from divination, +CHA to Stealth. Hidden Paths (level 10): bonus action, teleport 60 ft (or reaction when grabbed). Walker in Dreams (level 14): long rest — cast Scrying, Dream, or Teleportation Circle free (1/long rest).</div>`;
      break;
    case "spores":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Halo of Spores: reaction when a creature moves within 10 ft — deal necrotic (CON save; 1d4 → 1d6 → 1d8 → 1d10 at levels 6/10/14). Symbiotic Entity: expend Wild Shape for 10 min — temp HP (2× druid level), spore damage +1 die, melee attacks deal +1d6 poison. Fungal Infestation (level 6): animate dying beasts/humanoids as zombies. Spreading Spores (level 10): bonus action to create 10-ft cube of spores while Symbiotic Entity is active.</div>`;
      break;
    case "stars":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Star Map: Guidance cantrip + Guiding Bolt 1/long rest without a slot. Starry Form: expend Wild Shape — choose Archer (bonus healing or ranged spell attack), Chalice (healing spells restore +1d8+WIS extra), or Dragon (concentration checks auto-succeed, starlight bonus). Cosmic Omen (level 6): roll after each long rest — Woe (−1d6 reaction) or Weal (+1d6 reaction). Twinkling Constellations (level 10): all three starry benefits simultaneously, plus fly 20 ft bonus action.</div>`;
      break;
    case "wildfire":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Summon Wildfire Spirit: expend Wild Shape — wildfire spirit (bonus action teleport 15 ft to spirit and back; deals 2d6 fire on creation). Enhanced Bond: +1d8 to fire damage or healing through spirit link. Cauterizing Flames (level 6): reaction when a creature dies within 60 ft — ghostly flame heals 2d10+WIS when extinguished. Blazing Revival (level 10): if you drop to 0 HP, spirit sacrifices itself to restore you to half HP.</div>`;
      break;
    case "shepherd":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Speech of the Woods: speak with beasts; learn Sylvan. Spirit Totem: bonus action — Bear (temp HP = 5 + druid level), Hawk (reaction attack-advantage for an ally), or Unicorn (+WIS to healing spells) spirit in 30-ft sphere. Mighty Summoner (level 6): summoned beasts/fey gain +2 HP per Hit Die and magical attacks. Guardian Spirit (level 10): summoned creatures in your sphere regain 1d8+5 HP at end of their turns. Faithful Summons (level 14): automatically summon 4 CR-2 beasts when incapacitated.</div>`;
      break;
    case "sea":
      html += subSpellPicker("sea_domain_spells", ["Fog Cloud","Thunderwave","Gust of Wind","Shatter","Tidal Wave","Wall of Water","Control Water","Watery Sphere","Conjure Elemental","Mass Cure Wounds"], "Circle of the Sea Spells (always prepared)", "Don't count against your prepared spell limit.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Wrath of the Sea (level 2): expend Wild Shape — aura of crashing waves for 1 min (CON save or pushed + cold damage). Aquatic Wild Shape (level 6): wild shape into beasts with swim speed, breathe water. Stormborn (level 10): fly speed equal to walk speed while outside in Wild Shape. Oceanic Gift (level 14): you and one companion gain aquatic Wild Shape ability.</div>`;
      break;

    // ── Monk additional ─────────────────────────────────────
    case "kensei":
      html += subSkillPick("kensei_melee", ["Shortsword","Longsword","Rapier","Scimitar","Handaxe","Battleaxe","Spear","Trident","War Pick","Warhammer","Flail","Glaive","Halberd","Pike","Lance","Greatsword"], 1, "Kensei Melee Weapon (choose 1)");
      html += subSkillPick("kensei_ranged", ["Shortbow","Longbow","Hand Crossbow","Light Crossbow","Heavy Crossbow"], 1, "Kensei Ranged Weapon (choose 1)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--text-muted)">Agile Parry: +2 AC when using Kensei weapon for unarmed strike. One with the Blade (level 6): Kensei weapons are magical, +1d6 damage for 1 Ki. Sharpen the Blade (level 11): +1/2/3 for 1/2/3 Ki. Unerring Accuracy (level 17): reroll missed monk weapon attacks.</div>`;
      break;
    case "long-death":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Touch of Death: when you reduce a creature to 0 HP with a melee attack, gain temp HP = monk level + WIS mod. Hour of Reaping (level 6): action — frighten all creatures within 30 ft (WIS save). Mastery of Death (level 11): spend 1 Ki when reduced to 0 HP to drop to 1 HP instead. Touch of the Long Death (level 17): action, spend 1–10 Ki — WIS save or take 2d10 necrotic per Ki point (half on save).</div>`;
      break;
    case "sun-soul":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Radiant Sun Bolt: ranged spell attack (30/60 ft) dealing 1d4 + DEX/STR radiant. Bonus action: spend 1 Ki for two bolts. Searing Arc Strike (level 6): spend 2–5 Ki after attacking to cast Burning Hands (1st level + 1 per extra Ki). Searing Sunburst (level 11): action — 20-ft burst of radiance (CON save), +2d6 per Ki spent (1–3). Sun Shield (level 17): bright light aura; reaction when hit in melee — 5 + WIS mod radiant to attacker.</div>`;
      break;
    case "drunken-master":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus: Performance proficiency and brewer's supplies. Drunken Technique: Flurry of Blows grants Disengage and +10 ft movement. Tipsy Sway (level 6): leap to your feet for 5 ft (not half speed); reaction to redirect an attacker to a different target (1 Ki). Drunkard's Luck (level 11): spend 2 Ki to gain advantage on any check or save with no advantage/disadvantage. Intoxicated Frenzy (level 17): Flurry of Blows can make up to 5 attacks total against different targets.</div>`;
      break;
    case "astral-self":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Arms of the Astral Self (2 Ki, bonus action): manifest astral arms for 10 min — use WIS for attacks, extra range, bonus unarmed strike on Attack action. Visage of the Astral Self (3 Ki): advantage on Insight/Intimidation, darkvision, understand and speak any language (1 min). Body of the Astral Self (level 11, 5 Ki): fly speed, resist B/P/S damage. Awakened Astral Self (level 17): all three features simultaneously; extra attack with astral arms.</div>`;
      break;
    case "mercy":
      html += subSkillPick("mercy_tool", ["Herbalism Kit"], 1, "Bonus Proficiency: Herbalism Kit (required)");
      html += subSkillPick("mercy_skill", ["Insight","Medicine"], 1, "Bonus Skill (choose 1)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Hand of Harm (1 Ki, once/turn): deal +1d6+WIS necrotic on an unarmed hit and impose poisoned until end of your next turn. Hand of Healing (1 Ki): heal 1d6 + WIS mod on touch. Physician's Touch (level 6): Healing Hand also cures disease/poison; Harming Hand also permanently poisons. Flurry of Healing and Harm (level 11): use both hands freely in Flurry of Blows at no extra Ki. Hand of Ultimate Mercy (level 17, 5 Ki): revive a creature that died within 24 hours at 4d10 + WIS HP.</div>`;
      break;
    case "ascendant-dragon":
      html += subOptionPick("dragon_aspect", [
        ["black","Black/Copper — Acid"],["blue","Blue/Bronze — Lightning"],
        ["green","Green — Poison"],["red","Red/Gold/Brass — Fire"],["white","White/Silver — Cold"],
      ], "Draconic Aspect — choose your dragon type");
      break;

    // ── Paladin additional ───────────────────────────────────
    case "conquest":
    case "redemption":
    case "glory":
    case "watchers":
    case "crown":
    case "open-sea":
    case "oath-of-glory":
    case "oathbreaker":
      html += subSpellPicker("oath_spells",
        {
          "conquest":["Armor of Agathys","Command","Hold Person","Spiritual Weapon","Bestow Curse","Fear","Dominate Beast","Stoneskin","Dominate Person","Cloud of Daggers"],
          "redemption":["Sanctuary","Sleep","Calm Emotions","Hold Person","Counterspell","Hypnotic Pattern","Otiluke's Resilient Sphere","Stoneskin","Hold Monster","Wall of Force"],
          "glory":["Guiding Bolt","Heroism","Enhance Ability","Warding Bond","Aura of Vitality","Protection from Energy","Compulsion","Freedom of Movement","Commune","Flame Strike"],
          "watchers":["Alarm","Detect Magic","Moonbeam","See Invisibility","Counterspell","Nondetection","Aura of Purity","Banishment","Hold Monster","Scrying"],
          "crown":["Command","Compelled Duel","Warding Bond","Zone of Truth","Aura of Vitality","Spirit Guardians","Banishment","Guardian of Faith","Circle of Power","Geas"],
          "oathbreaker":["Hellish Rebuke","Inflict Wounds","Crown of Madness","Darkness","Animate Dead","Bestow Curse","Blight","Confusion","Contagion","Dominate Person"],
          "open-sea":["Create or Destroy Water","Thunderwave","Misty Step","Shatter","Tidal Wave","Wind Wall","Control Water","Freedom of Movement","Commune with Nature","Maelstrom"],
          "oath-of-glory":["Guiding Bolt","Heroism","Enhance Ability","Warding Bond","Aura of Vitality","Protection from Energy","Compulsion","Freedom of Movement","Commune","Flame Strike"],
        }[c.subclassId] || [],
        `${c.subclassId.replace(/-/g,' ').replace(/\b\w/g,l=>l.toUpperCase())} Oath Spells (always prepared)`,
        "These spells are always prepared and don't count against your limit."
      );
      break;

    // ── Ranger additional ────────────────────────────────────
    case "gloom-stalker":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Dread Ambusher: +WIS mod to initiative; first round of combat — extra attack + 1d8 bonus damage. Umbral Sight: darkvision 60 ft (or +60 ft); invisible to darkvision while both in darkness. Iron Mind (level 7): WIS save proficiency (or INT/CHA if already have WIS). Stalker's Flurry (level 11): once per turn on a miss, make another attack immediately. Shadowy Dodge (level 15): reaction — impose disadvantage on an attack roll against you.</div>`;
      break;
    case "horizon-walker":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Detect Portal: action — sense planar portals within 1 mile (1/short rest). Planar Warrior: bonus action — next hit deals +1d8 force instead of weapon type (2d8 at level 11). Ethereal Step (level 7): bonus action — cast Etherealness on yourself until next turn (1/short rest). Distant Strike (level 11): teleport 10 ft before each attack; hitting two different creatures lets you attack a third. Spectral Defense (level 15): reaction when hit — resistance to all damage for that attack.</div>`;
      break;
    case "monster-slayer":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Hunter's Sense: action — learn one creature's immunities, resistances, and vulnerabilities within 60 ft (WIS mod/long rest). Slayer's Prey: bonus action — mark a creature; +1d6 damage on attacks vs it (changes on next bonus action). Supernatural Defense (level 7): add 1d6 to saves and grapple checks against the marked creature. Magic-User's Nemesis (level 11): reaction — prevent a creature within 60 ft from casting or teleporting (WIS save, 1/short rest). Slayer's Counter (level 15): reaction — attack the marked target when it forces you to save; auto-succeed if you hit.</div>`;
      break;
    case "fey-wanderer":
      html += subSkillPick("fey_skill", ["Deception","Performance","Persuasion"], 1, "Otherworldly Glamour — bonus skill proficiency (choose 1)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Dreadful Strikes: once per turn, +1d4 psychic damage on weapon hits (1d6 at level 11). Otherworldly Glamour: +WIS mod to Persuasion; proficiency in the chosen skill. Beguiling Twist (level 7): reaction when a creature within 120 ft resists charm/fear — redirect the effect to another creature (WIS save). Fey Reinforcements (level 11): Summon Fey once per long rest without a slot. Misty Wanderer (level 15): Misty Step free once per turn; bring a willing creature along.</div>`;
      break;
    case "swarmkeeper":
      html += subOptionPick("swarm_type", [
        ["insects","Insects — classic swarm, buzzing and biting"],
        ["birds","Birds — feathered flock around you"],
        ["pixies","Pixies — tiny fey, more fantastical"],
        ["bats","Bats — creatures of the night"],
      ], "Gathered Swarm — choose your swarm type (cosmetic)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Gathered Swarm: once per turn when you hit, choose — deal 1d6 piercing (becomes 1d8 at level 11), push target 15 ft (STR save), or move yourself 5 ft. Writhing Tide (level 7, WIS mod/long rest): bonus action — swarm carries you, fly 10 ft/turn for 1 min. Mighty Swarm (level 11): damage upgrades; push becomes 20 ft; half cover while flying. Swarming Dispersal (level 15): reaction on taking damage — go invisible, teleport 30 ft (1/short rest).</div>`;
      break;
    case "drakewarden":
      html += subOptionPick("drake_damage", [
        ["acid","Acid — black/copper dragon"],
        ["cold","Cold — white/silver dragon"],
        ["fire","Fire — red/gold/brass dragon"],
        ["lightning","Lightning — blue/bronze dragon"],
        ["poison","Poison — green dragon"],
      ], "Drake Companion Damage Type");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Draconic Gift: learn Draconic + Thaumaturgy cantrip. Drake Companion: bond with a drake (uses your proficiency; acts on your initiative). Bond of Fang and Scale (level 7): drake grows Large, you can ride it, +1d6 elemental damage. Drake's Breath (level 11): breath weapon — 30-ft cone or 60-ft line (8d6+Ki, 1/long rest or slot). Perfected Bond (level 15): Huge drake, magical attacks, reaction counterattack when you're hit.</div>`;
      break;
    case "beast-master-2024":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Primal Companion: bond with a Beast of the Land, Sea, or Sky (your choice). It uses your proficiency bonus; you command it as a bonus action. Exceptional Training (level 7): on your turn, the beast can use Dash, Disengage, Dodge, or Help as a bonus action. Bestial Fury (level 11): beast can make two attacks on your command. Share Spells (level 15): when you cast a spell targeting yourself, you can have it also target your beast.</div>`;
      break;

    // ── Rogue additional ─────────────────────────────────────
    case "inquisitive":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Ear for Deceit: minimum 8 on Insight checks. Eye for Detail: bonus action — Perception to spot hidden creatures or Investigation to find clues. Insightful Fighting: bonus action, Insight vs Deception — Sneak Attack without advantage (no disadvantage required) for 1 minute. Steady Eye (level 9): advantage on Perception and Investigation when moving half speed. Unerring Eye (level 13, WIS mod/long rest): sense illusions and disguises within 30 ft. Eye for Weakness (level 17): +3d6 Sneak Attack while Insightful Fighting is active.</div>`;
      break;
    case "mastermind":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Master of Intrigue: proficiency in disguise/forgery kits and two gaming sets; two extra languages; mimic accents. Master of Tactics: Help as a bonus action, range extended to 30 ft. Insightful Manipulator (level 9): 1 minute studying — learn 2 facts about a target. Misdirection (level 13): cause a creature to mistake another for you. Soul of Deceit (level 17): thoughts undetectable; appear truthful under divination magic.</div>`;
      break;
    case "scout":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Skirmisher: reaction when a creature ends its turn within 5 ft — move half speed without provoking OAs. Survivalist: proficiency (or double if already proficient) in Nature and Survival. Superior Mobility (level 9): +10 ft walk/climb/swim speed. Ambush Master (level 13): advantage on initiative; allies attacking your first-turn targets gain advantage. Sudden Strike (level 17): bonus action attack in Attack action; can Sneak Attack twice in same turn on different targets.</div>`;
      break;
    case "phantom":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Whispers of the Dead: gain one skill or tool proficiency each short/long rest (from the dead). Wails from the Grave (prof bonus/long rest): after Sneak Attack, deal half necrotic to a second creature within 30 ft. Tokens of the Departed (level 9): capture soul trinkets from nearby dying creatures to ask questions or gain advantage. Ghost Walk (level 13, 3/long rest): ghostly form for 10 min — hover, pass through objects, resist all damage. Death's Friend (level 17): one free soul trinket always; Wails from the Grave is free once per turn.</div>`;
      break;
    case "soulknife":
    case "soulknife-2024":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Psionic Power: pool of d6 dice (2× proficiency). Psi-Bolstered Knack: add a die to a failed INT/WIS/CHA check. Psychic Whispers: communicate telepathically for hours = die roll. Psychic Blades: manifest blades as free action — d6 psychic melee or ranged (20/60 ft), bonus action second blade. Soul Blades (level 9): Homing Strikes (reroll miss) or Psychic Teleportation (teleport die roll × 10 ft). Psychic Veil (level 13): invisibility for 1 hour (prof bonus/long rest). Rend Mind (level 17): advantage hit — WIS save or stunned until end of your next turn.</div>`;
      break;
    case "arcane-trickster-2024":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Spellcasting (PHB 2024 version): Wizard spells (INT). Mage Hand Legerdemain: enhanced Mage Hand for stealthy tasks. Magical Ambush (level 9): creatures have disadvantage on saves vs your spells if you're hidden. Versatile Trickster (level 13): bonus action to distract with Mage Hand, gaining advantage on attacks vs the target. Spell Thief (level 17): reaction when a creature casts a spell — attempt to steal it (INT save). See your character sheet for full details.</div>`;
      break;
    case "assassin-2024":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Assassinate (PHB 2024 version): advantage on creatures that haven't taken a turn yet; crit on surprised creatures. Infiltration Expertise: craft false identities over 7 days. Ambush Master (level 9): allies attacking your first-turn targets gain advantage. Impostor (level 13): copy another person's appearance perfectly. Death Strike (level 17): if you surprise a creature, it must make a CON save (DC 8 + DEX mod + prof) or take double damage from your attack.</div>`;
      break;

    // ── Sorcerer additional ──────────────────────────────────
    case "divine-soul":
      html += subOptionPick("divine_affinity", [
        ["good","Good — Cure Wounds + heal bonus"],
        ["evil","Evil — Inflict Wounds + charm immunity"],
        ["law","Law — Bless + ally save bonus"],
        ["chaos","Chaos — Bane + wild initiative"],
        ["neutrality","Neutrality — Protection from Good and Evil + AC bonus"],
      ], "Divine Affinity — choose your celestial lineage");
      break;
    case "shadow-magic":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Eyes of the Dark: darkvision 120 ft; spend 1 SP to cast Darkness (can see through your own). Strength of the Grave: reaction at 0 HP — CON save (DC = 5 + damage dealt) to drop to 1 HP instead (1/long rest, not vs radiant). Hound of Ill Omen (level 6, 3 SP): summon shadow hound — hunts a target, forces disadvantage on saves vs your spells. Shadow Walk (level 14): bonus action in dim light/darkness — teleport 120 ft. Umbral Form (level 18, 6 SP): become a shadow for 1 min — resist all non-force/radiant damage, pass through objects.</div>`;
      break;
    case "storm-sorcery":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Wind Speaker: speak, read, write Primordial. Tempestuous Magic: after casting a 1st+ level spell, fly 10 ft as bonus action (no OAs). Heart of the Storm (level 6): resistance to lightning and thunder; when casting lightning/thunder spell, creatures within 10 ft take half-sorcerer-level damage. Storm Guide: bonus action to control rain or wind within range. Storm's Fury (level 14): reaction when hit — deal lightning and push (STR save). Wind Soul (level 18): immune to lightning/thunder, fly 60 ft, share flying with nearby allies.</div>`;
      break;
    case "aberrant-mind":
      html += subSpellPicker("aberrant_spells", ["Arms of Hadar","Dissonant Whispers","Calm Emotions","Detect Thoughts","Hunger of Hadar","Sending","Clairvoyance","Telekinesis","Dominate Person","Rary's Telepathic Bond"], "Aberrant Mind Psionic Spells (always available)", "Added to your sorcerer spell list; can be replaced when you gain sorcerer levels.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Telepathic Speech: communicate telepathically with a creature you can see within 30 ft for 1 minute × sorcerer level. Psionic Sorcery (level 6): cast psionic spells using SP instead of spell slots (no V/S components). Psychic Defenses (level 6): resistance to psychic damage; advantage vs charmed/frightened. Revelation in Flesh (level 14, 1+ SP): see invisible/fly/swim/pass through objects. Warp Reality (level 18, 7 SP): 30-ft reality distortion aura for 1 minute.</div>`;
      break;
    case "clockwork-soul":
      html += subSpellPicker("clockwork_spells", ["Alarm","Expeditious Retreat","Aid","Lesser Restoration","Dispel Magic","Protection from Energy","Freedom of Movement","Summon Construct","Wall of Force","Hold Monster"], "Clockwork Soul Spells (always available)", "Added to your sorcerer spell list.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Restore Balance: reaction when a creature would roll with advantage or disadvantage — cancel it. Bastion of Law (level 6, 1–5 SP): give a creature a ward absorbing 1d8 damage per SP spent for 24 hours. Trance of Order (level 14): bonus action — 1 minute where attacks on you treat d20 rolls below 9 as 10. Clockwork Cavalcade (level 18, 1/long rest): repair objects, free dispel magic, restore up to 100 HP among creatures.</div>`;
      break;
    case "lunar-sorcery":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Moon Fire: Sacred Flame cantrip dealing radiant or necrotic (your choice). Lunar Embodiment: after each long rest, choose Full/Crescent/New moon — each grants different spells and bonus effects. Waxing and Waning (level 6, 1 SP): change lunar phase as bonus action; regain a spell slot (1d4 levels, max 3rd). Lunar Boons (level 14): phase spells cost 1 fewer SP. Lunar Empowerment (level 18): all three phase bonuses simultaneously; +10 damage once per turn.</div>`;
      break;

    // ── Warlock additional ───────────────────────────────────
    case "hexblade":
      html += subSpellPicker("patron_spells", ["Shield","Wrathful Smite","Blur","Branding Smite","Blink","Elemental Weapon","Phantasmal Killer","Staggering Smite","Banishing Smite","Cone of Cold"], "Hexblade Expanded Spells (always available)", "Added to your warlock spell list.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Hexblade's Curse (1/short rest): bonus action — curse a creature within 30 ft for 1 min; +prof to damage, crit on 19–20, regain HP when it dies. Hex Warrior: medium armor, shields, martial weapons; one weapon per long rest uses CHA for attacks (or always with pact weapon). Accursed Specter (level 6): raise a slain humanoid as a specter under your control for 24 hours. Armor of Hexes (level 10): cursed target hits you — 4+ on d6 means miss. Master of Hexes (level 14): transfer curse on kill.</div>`;
      break;
    case "undead":
      html += subSpellPicker("patron_spells", ["False Life","Ray of Sickness","Blindness/Deafness","Phantasmal Force","Phantom Steed","Speak with Dead","Death Ward","Greater Invisibility","Antilife Shell","Cloudkill"], "Undead Expanded Spells (always available)", "Added to your warlock spell list.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Form of Dread (prof bonus/long rest): bonus action, 1 min — temp HP, immunity to frightened, frighten an attacker (WIS save). Grave Touched (level 6): no food/water/air; once per turn, attacks deal necrotic + extra die. Necrotic Husk (level 10): resist necrotic; if reduced to 0 HP, drop to 1 HP instead and release a burst (1/long rest). Spirit Projection (level 14): soul leaves your body to act as a spirit — fly, possess creatures, pass through objects.</div>`;
      break;
    case "celestial":
      html += subSpellPicker("patron_spells", ["Cure Wounds","Guiding Bolt","Flaming Sphere","Lesser Restoration","Daylight","Revivify","Guardian of Faith","Wall of Fire","Mass Cure Wounds","Flame Strike"], "Celestial Expanded Spells (always available)", "Added to your warlock spell list.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bonus cantrips: Light, Sacred Flame (use CHA). Healing Light: pool of d6s = 1 + warlock level; bonus action to spend up to CHA mod dice to heal a creature within 60 ft. Radiant Soul (level 6): resist radiant; +CHA mod to one radiant or fire spell's damage. Celestial Resilience (level 10): temp HP for you and 5 allies on long rest. Searing Vengeance (level 14): radiant burst when you or an ally revives from 0 HP.</div>`;
      break;
    case "genie":
      html += subOptionPick("genie_type", [
        ["dao","Dao (Earth) — Bludgeoning damage, stone-themed features"],
        ["djinni","Djinni (Air) — Thunder damage, wind-themed features"],
        ["efreeti","Efreeti (Fire) — Fire damage, flame-themed features"],
        ["marid","Marid (Water) — Cold damage, water-themed features"],
      ], "Genie Patron Type");
      html += subSpellPicker("patron_spells", ["Detect Evil and Good","Sanctuary","Phantasmal Force","Spike Growth","Create Food and Water","Tongues","Phantasmal Killer","Secret Chest","Creation","Wish"], "Genie Expanded Spells (always available)", "Added to your warlock spell list. Your genie type also grants extra spells.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Genie's Vessel: magic vessel as focus; Bottled Respite — enter vessel for up to 4+CHA mod hours per long rest. Elemental Gift (level 6): resist your damage type; fly 30 ft as bonus action. Sanctuary Vessel (level 10): invite allies into vessel; short rests inside heal extra 1d8 per Hit Die. Limited Wish (level 14, 1/long rest): replicate any spell of 6th level or lower without concentration.</div>`;
      break;
    case "fathomless":
      html += subSpellPicker("patron_spells", ["Create or Destroy Water","Thunderwave","Gust of Wind","Shatter","Lightning Bolt","Sleet Storm","Control Water","Evard's Black Tentacles","Cone of Cold","Wall of Ice"], "Fathomless Expanded Spells (always available)", "Added to your warlock spell list.");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Tentacle of the Deeps (CHA mod/long rest): bonus action — 10-ft tentacle for 1 min; reaction attack 1d8 cold + slow 10 ft (STR save). Gift of the Sea: breathe water, swim speed 40 ft. Oceanic Soul (level 6): resist cold; underwater creatures understand you. Guardian Coil (level 6): tentacle reduces damage to you or a nearby ally by 1d8. Grasping Tentacles (level 10): Evard's Black Tentacles free 1/long rest; +CHA mod AC while concentrating. Fathomless Plunge (level 14): teleport up to 8 creatures to any plane you know (1/short rest).</div>`;
      break;

    // ── Wizard additional ────────────────────────────────────
    case "bladesinging":
      html += subSkillPick("bladesinging_prof", ["Acrobatics","Performance"], 1, "Bonus Skill Proficiency (Bladesinging, choose one)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Bladesong (2/short rest): +INT mod to AC, +10 speed, advantage on Acrobatics, +INT mod to concentration checks. Extra Attack (level 6): can replace one attack with a cantrip. Song of Defense (level 10): spend a spell slot to reduce incoming damage. Song of Victory (level 14): +INT mod to melee damage while Bladesong is active.</div>`;
      break;
    case "war-magic":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Arcane Deflection: reaction to gain +2 AC or +4 to a save — but can only cast cantrips next turn. Tactical Wit: +INT mod to initiative. Power Surge (level 6): store magical energy to add to spell damage. Durable Magic (level 10): +2 AC and saves while concentrating. Deflecting Shroud (level 14): Arcane Deflection bursts for force damage.</div>`;
      break;
    case "chronurgy":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Chronal Shift (2/long rest): reaction — force a creature to reroll a d20 and use either result. Temporal Awareness: add INT mod to initiative. Momentary Stasis (level 6): action to paralyze a creature (CON save). Arcane Abeyance (level 10): store a spell of 4th level or lower in a mote that lasts 1 hour. Convergent Future (level 14): reaction — decide the result of a d20 (counts as Chronal Shift use).</div>`;
      break;
    case "graviturgy":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Adjust Density: as an action, alter a creature's weight — halved (fly speed, jump distance ×2) or doubled (speed ÷2, resistance to knockback). Gravity Well (level 6): when you cast a spell on a creature, move it 5 ft to an unoccupied space. Violent Attraction (level 10): reaction — +2d10 force damage to an attack or falling. Event Horizon (level 14): reaction — creatures within 30 ft make STR save or can't move away and take force damage.</div>`;
      break;
    case "order-of-scribes":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Wizardly Quill: magical quill — write twice as fast, copy spells in half the time, erase your writing with a gesture. Awakened Spellbook: sentient book — rituals take no extra time, once per turn when casting a spell using a slot you can switch the damage type to match another spell in your book. Manifest Mind (level 6): bonus action — project your spellbook as a spectral mind within 300 ft and cast spells from its position. Master Scrivener (level 10): long rest — create a 1st or 2nd level spell scroll only you can cast (free action). One with the Word (level 14): reduce damage by 2× spell level by expunging that spell from book until long rest.</div>`;
      break;
    case "abjurer-2024":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Abjuration Savant (2024): halve time and cost to copy Abjuration spells. Arcane Ward: when you cast an Abjuration spell of 1st level or higher, gain a ward with HP = 2× spell level + INT mod. Ward absorbs damage before you take it. Projected Ward (level 6): use ward to protect an ally within 30 ft. Improved Abjuration (level 10): add prof bonus to ability checks on Abjuration spells. Spell Resistance (level 14): advantage on saves vs spells; resistance to spell damage.</div>`;
      break;
    case "evoker-2024":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Evocation Savant (2024): halve time and cost to copy Evocation spells. Potent Cantrip: creatures succeeding on saves vs your damage cantrips still take half damage. Sculpt Spells (level 6): choose up to 1+spell-level creatures to automatically succeed on saves vs Evocation spells and take no damage. Empowered Evocation (level 10): add INT mod to damage rolls of wizard Evocation spells. Overchannel (level 14): max damage on 1st–5th level Evocation spells (take increasing necrotic each subsequent time per long rest).</div>`;
      break;
    case "illusionist-2024":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Illusion Savant (2024): halve time and cost to copy Illusion spells. Improved Minor Illusion: cast Minor Illusion as a bonus action to create both a sound and an image. Malleable Illusions (level 6): action — change any detail of a concentration illusion spell without recasting. Illusory Self (level 10): reaction — create an illusory duplicate that causes an attack to miss you (1/short rest). Illusory Reality (level 14): once per casting — make one inanimate part of an illusion real for 1 minute.</div>`;
      break;
    case "chronurgy":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Chronal Shift (2/long rest): reaction — force a creature to reroll a d20 and use either result. Temporal Awareness: +INT mod to initiative rolls. Momentary Stasis (level 6, INT mod/long rest): action — incapacitate a Large or smaller creature until the end of your next turn or it takes damage (CON save). Arcane Abeyance (level 10): store a spell of 4th level or lower in a mote that lasts 1 hour (another creature can activate it). Convergent Future (level 14): reaction — declare a specific number before a creature rolls a d20; it uses that number instead (costs Chronal Shift use).</div>`;
      break;
    case "graviturgy":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Adjust Density: action — alter a creature's weight for 1 minute. Halved: fly speed, jump distance ×2. Doubled: speed ÷2, resistance to knockback. Gravity Well (level 6): when you cast a spell on a creature, move it 5 ft to an unoccupied space. Violent Attraction (level 10): reaction — add 2d10 force to an attack roll or use on a falling creature. Event Horizon (level 14): reaction — creatures within 30 ft must succeed on STR save or be unable to move away and take force damage.</div>`;
      break;
    case "war-magic":
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Arcane Deflection: reaction when hit or fail a save — +2 AC for that hit or +4 to that save (but can only cast cantrips until end of next turn). Tactical Wit: +INT mod to initiative. Power Surge (level 6): store magical energy (max INT mod surges); add surge to spell damage = half wizard level. Durable Magic (level 10): +2 to AC and all saving throws while maintaining concentration. Deflecting Shroud (level 14): Arcane Deflection also releases a burst — 1d6 × half wizard level force damage to up to 3 creatures within 60 ft.</div>`;
      break;
    case "battle-master-2024":
    case "bladesinging":
    case "war-magic":
    case "order-of-scribes":
      break; // already handled individually above

    // ── Artificer ────────────────────────────────────────────
    case "alchemist":
      html += subSkillPick("alch_tool", ["Alchemist's supplies"], 1, "Bonus Tool Proficiency: Alchemist's Supplies");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Experimental Elixir: create one free elixir per long rest (roll for effect or spend a spell slot to choose). Alchemical Savant (level 5): add INT mod to healing/acid/fire/necrotic/poison spells. Restorative Reagents (level 9): use Cure Wounds at will on yourself. Chemical Mastery (level 15): free Greater Restoration and Heal 1/long rest each.</div>`;
      break;
    case "armorer":
      html += subOptionPick("armorer_model", [
        ["guardian","Guardian — defensive, tanky; mailed fist strikes"],
        ["infiltrator","Infiltrator — stealth-focused; lightning launcher ranged attack"],
      ], "Armor Model (level 3)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Tools of the Trade: heavy armor + smith's tools proficiency. Armor Modifications: infuse armor helmet, chest, boots, and weapon separately. Perfected Armor (level 15): Guardian gets reaction pull; Infiltrator gets advantage trigger on attack.</div>`;
      break;
    case "artillerist":
      html += subSkillPick("artil_tool", ["Woodcarver's tools","Woodcarver's tools"], 1, "Bonus Tool Proficiency: Woodcarver's Tools");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Eldritch Cannon: 1-hour cannon — Flamethrower (15 ft cone fire), Force Ballista (ranged spell attack), or Protector (temp HP aura). Arcane Firearm (level 5): +1d8 to single-target artillery spells. Explosive Cannon (level 9): cannon deals 3d8 extra on destroy. Fortified Position (level 15): summon two cannons; allies in cannon range have half cover.</div>`;
      break;
    case "battle-smith":
      html += subSkillPick("bsmith_skill", ["History","Insight","Investigation","Perception","Persuasion","Arcana"], 1, "Bonus Proficiency (choose one skill)");
      html += `<div style="margin-top:8px;font-size:13px;color:var(--gold)">Battle Ready: martial weapon proficiency. Steel Defender: construct companion (HP = 2 + INT mod + 5× artificer level). Arcane Jolt (level 9): hit with weapon or steel defender → deal +2d6 force OR heal nearby creature 2d6. Improved Defender (level 15): steel defender +2 AC; Arcane Jolt becomes 4d6.</div>`;
      break;

    default:
      // All other subclasses — features show on the sheet via SUBCLASS_FEATURES
      break;
  }

  html += `</div>`;
  return html;
}

function renderClass() {
  const c = state.character;
  const cls = getClass(c.classId);
  const subclassChoicesHtml = cls && c.subclassId ? renderSubclassChoices(c) : "";

  const CLASS_GROUPS = {
    "Player's Handbook (2014 / 2024)": ["barbarian","bard","cleric","druid","fighter","monk","paladin","ranger","rogue","sorcerer","warlock","wizard"],
    "Tasha's Cauldron of Everything / Supplemental": ["artificer"],
  };

  const classCards = Object.entries(CLASS_GROUPS).map(([grpName, ids]) => {
    const found = ids.filter(id => DATA.classes.find(k => k.id === id));
    if (!found.length) return '';
    return `<div style="margin-bottom:18px">
      <div style="font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);margin-bottom:8px">${grpName}</div>
      <div class="option-grid">
        ${found.map(id => {
          const k = DATA.classes.find(k => k.id === id);
          if (!k) return '';
          return `<div class="option-card ${c.classId === k.id ? "selected" : ""}" onclick="App.selectClass('${k.id}')">
            <div class="name">${k.name}</div>
            <div class="sub">d${k.hitDie} · ${k.savingThrows.map(s => s.toUpperCase()).join("/")}</div>
          </div>`;
        }).join("")}
      </div>
    </div>`;
  }).join("");

  // Any classes not in a group (e.g. PDF imports)
  const groupedIds = new Set(Object.values(CLASS_GROUPS).flat());
  const extra = DATA.classes.filter(k => !groupedIds.has(k.id));
  const extraHtml = extra.length ? `<div style="margin-bottom:18px">
    <div style="font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);margin-bottom:8px">Imported / Homebrew</div>
    <div class="option-grid">
      ${extra.map(k => `<div class="option-card ${c.classId === k.id ? "selected" : ""}" onclick="App.selectClass('${k.id}')">
        <div class="name">${k.name}</div>
        <div class="sub">d${k.hitDie} · ${k.savingThrows.map(s => s.toUpperCase()).join("/")}</div>
      </div>`).join("")}
    </div>
  </div>` : '';

  return `
    <h2>Class</h2>
    ${classCards}${extraHtml}
    ${cls ? `
      <h3 style="margin-top:8px;">Starting Equipment</h3>
      <ul class="trait-list">${cls.startingEquipment.map(e => `<li>${e}</li>`).join("")}</ul>
      ${cls.subclasses.length ? `
        <div class="field" style="margin-top:14px;">
          <label>Subclass ${c.level < cls.subclassLevel ? `(chosen at level ${cls.subclassLevel} — optional to pre-select)` : ""}</label>
          <select onchange="App.selectSubclass(this.value)">
            <option value="">— none selected —</option>
            ${cls.subclasses.map(s => `<option value="${s.id}" ${c.subclassId === s.id ? "selected" : ""}>${s.name}</option>`).join("")}
          </select>
        </div>` : ""}
      ${subclassChoicesHtml}
    ` : ""}

    <!-- Multiclassing -->
    ${c.level < 2 ? '' : `
    <div style="margin-top:24px;border-top:1px solid var(--border-dark);padding-top:16px">
      <h3 style="color:var(--gold);font-size:14px;margin-bottom:8px">Multiclassing</h3>
      <p class="subtitle" style="margin-bottom:12px">Add additional classes. Your level on the Basics step is your total character level shared across all classes.</p>
      ${(c.multiclasses || []).map(mc => {
        const mCls = getClass(mc.classId);
        const mcSubLevel = mCls?.subclassLevel || 3;
        const canPickSubclass = mc.level >= mcSubLevel;
        const mcSubclassChoicesHtml = mc.subclassId ? (() => {
          const tempC = { ...c, classId: mc.classId, subclassId: mc.subclassId, level: mc.level };
          try { return renderSubclassChoices(tempC); } catch(e) { return ''; }
        })() : '';
        return `<div style="padding:12px;background:var(--ink-panel);border-radius:8px;border:1px solid var(--border-dark);margin-bottom:8px">
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <strong style="color:var(--text-light);min-width:100px">${mCls?.name || mc.classId}</strong>
            <div class="field" style="margin:0;flex:0 0 auto">
              <label style="font-size:11px">Levels</label>
              <input type="number" min="1" max="20" value="${mc.level}" style="width:60px"
                onchange="App.setMulticlassLevel('${mc.classId}',this.value)" />
            </div>
            ${mCls?.subclasses?.length ? `<div class="field" style="margin:0;flex:1">
              <label style="font-size:11px">Subclass ${canPickSubclass ? '' : `(unlocks at ${mc.classId} level ${mcSubLevel})`}</label>
              <select ${canPickSubclass ? '' : 'disabled'} onchange="App.setMulticlassSubclass('${mc.classId}',this.value)">
                <option value="">— none —</option>
                ${mCls.subclasses.map(s => `<option value="${s.id}" ${mc.subclassId===s.id?"selected":""}>${s.name}</option>`).join("")}
              </select>
            </div>` : ""}
            <button class="btn" onclick="App.removeMulticlass('${mc.classId}')" style="background:var(--crimson);border-color:var(--crimson);flex:0 0 auto">Remove</button>
          </div>
          ${mcSubclassChoicesHtml}
        </div>`;
      }).join("")}
      <div style="display:flex;gap:8px;align-items:center;margin-top:8px">
        <select id="mc-add-select" style="flex:1">
          <option value="">— add a class —</option>
          ${DATA.classes.filter(k => k.id !== c.classId && !(c.multiclasses||[]).find(m=>m.classId===k.id)).map(k =>
            `<option value="${k.id}">${k.name}</option>`).join("")}
        </select>
        <button class="btn" onclick="const s=document.getElementById('mc-add-select');if(s.value)App.addMulticlass(s.value)">Add</button>
      </div>
    </div>`}
  `;
}

function renderBackground() {
  const c = state.character;
  const bg = getBackground(c.backgroundId);
  return `
    <h2>Background</h2>
    <div class="option-grid">
      ${DATA.backgrounds.map(b => `
        <div class="option-card ${c.backgroundId === b.id ? "selected" : ""}" onclick="App.selectBackground('${b.id}')">
          <div class="name">${b.name}</div>
          <div class="sub">${b.skillProficiencies.join(", ")}</div>
        </div>`).join("")}
    </div>
    ${bg ? `
      <h3 style="margin-top:20px;">${bg.name} Feature</h3>
      <p style="font-size:14px;color:var(--text-muted)">${bg.feature}</p>
      <h3>Equipment</h3>
      <ul class="trait-list">${bg.equipment.map(e => `<li>${e}</li>`).join("")}</ul>
    ` : ""}`;
}

function renderAbilityScores() {
  const c = state.character;
  const scores = finalAbilityScores(c);
  let body = "";
  if (c.abilityMethod === "standard") {
    const used = ABILITIES.map(a => c.baseScores[a]);
    body = `
      <p class="standard-array-pool">Assign each value once: ${STANDARD_ARRAY.join(", ")}</p>
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <select onchange="App.setStandardArraySlot('${a}', this.value)">
              ${STANDARD_ARRAY.map(v => `<option value="${v}" ${c.baseScores[a] === v ? "selected" : ""}>${v}</option>`).join("")}
            </select>
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  } else if (c.abilityMethod === "pointbuy") {
    const spent = ABILITIES.reduce((s, a) => s + POINT_BUY_COST[c.baseScores[a]], 0);
    body = `
      <p class="standard-array-pool">Points spent: ${spent} / 27</p>
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <div>
              <button class="btn" style="padding:4px 10px" onclick="App.setPointBuy('${a}', -1)">−</button>
              <span style="font-family:var(--font-mono);font-size:20px;margin:0 8px;">${c.baseScores[a]}</span>
              <button class="btn" style="padding:4px 10px" onclick="App.setPointBuy('${a}', 1)">+</button>
            </div>
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  } else {
    body = `
      <div class="ability-grid">
        ${ABILITIES.map(a => `
          <div class="ability-box">
            <div class="ab-name">${a}</div>
            <input type="text" value="${c.baseScores[a]}" oninput="App.setManualScore('${a}', this.value)" />
            <div class="ab-mod">${fmtMod(abilityMod(scores[a]))} final: ${scores[a]}</div>
          </div>`).join("")}
      </div>`;
  }
  return `<h2>Ability Scores</h2><p class="subtitle">Base score, before racial bonuses are applied (shown as "final").</p>${body}`;
}

function renderFeatOptions(c) {
  const feat = DATA.feats.find(f => f.id === c.feat);
  if (!feat) return "";
  const fc = c.featChoices || {};
  const allSpells = DATA.spells;
  const scores = finalAbilityScores(c);

  // Helper: mini spell picker
  function miniSpellPicker(key, level, classes, maxPick, label) {
    const pool = allSpells.filter(s => s.level === level && (classes.length === 0 || classes.some(cl => s.classes.includes(cl))));
    const chosen = fc[key] || [];
    const atCap = chosen.length >= maxPick;
    return `<div class="field" style="margin-top:8px;">
      <label>${label} (choose ${maxPick}${maxPick>1?" — chosen: "+chosen.length+"/"+maxPick:""})</label>
      <div class="spell-list" style="max-height:260px;overflow-y:auto;">
        ${pool.map(s => {
          const sel = chosen.includes(s.name);
          const dis = !sel && atCap;
          return `<div class="spell-row ${sel?"selected":""} ${dis?"spell-disabled":""}"
            onclick="${dis?"":("App.toggleFeatSpell('"+key+"','"+s.name.replace(/'/g,"\\'")+"')")}"
            style="padding:6px 10px;">
            <span class="sname" style="font-size:13px">${s.name}</span>
            <span class="slevel" style="font-size:11px">${s.school} · Lvl ${s.level}</span>
            <div class="ssum">${s.summary}</div>
          </div>`;
        }).join("") || "<p class='dim'>No spells found for this filter.</p>"}
      </div>
    </div>`;
  }

  // Helper: skill picker
  function skillPicker(key, count, label) {
    const chosen = fc[key] || [];
    const atCap = chosen.length >= count;
    return `<div class="field" style="margin-top:8px;">
      <label>${label} (choose ${count})</label>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;">
        ${SKILLS.map(([name]) => {
          const sel = chosen.includes(name);
          const dis = !sel && atCap;
          return `<span class="tag" style="cursor:${dis?"not-allowed":"pointer"};opacity:${dis?0.4:1};${sel?"background:var(--crimson);border-color:var(--crimson)":""}"
            ${dis?"":(`onclick="App.toggleFeatArrayChoice('${key}','${name.replace(/'/g,"\\'")}',${count})"`)}>
            ${name}
          </span>`;
        }).join("")}
      </div>
    </div>`;
  }

  // Helper: ability score pick
  function abPicker(key, label, allowed) {
    const chosen = fc[key] || "";
    const opts = allowed || ABILITIES;
    return `<div class="field" style="margin-top:8px;">
      <label>${label}</label>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;">
        ${opts.map(a => `<span class="tag" style="cursor:pointer;${chosen===a?"background:var(--crimson);border-color:var(--crimson)":""}"
          onclick="App.setFeatChoice('${key}','${a}')">${ABILITY_NAMES[a]}</span>`).join("")}
      </div>
    </div>`;
  }

  // Helper: class pick for spell list
  function classPicker(key, label) {
    const chosen = fc[key] || "";
    const casterClasses = ["bard","cleric","druid","paladin","ranger","sorcerer","warlock","wizard"];
    return `<div class="field" style="margin-top:8px;">
      <label>${label}</label>
      <select onchange="App.setFeatChoice('${key}',this.value)">
        <option value="">— pick a class —</option>
        ${casterClasses.map(cl => `<option value="${cl}" ${chosen===cl?"selected":""}>${cl.charAt(0).toUpperCase()+cl.slice(1)}</option>`).join("")}
      </select>
    </div>`;
  }

  let html = `<div class="feat-options">
    <p style="font-size:13px;color:var(--text-muted);margin:8px 0 4px">${feat.summary}</p>`;

  switch (feat.id) {
    case "magic-initiate": {
      const cl = fc["mi_class"] || "";
      const cantripPool = cl ? allSpells.filter(s => s.level===0 && s.classes.includes(cl)) : [];
      const spellPool   = cl ? allSpells.filter(s => s.level===1 && s.classes.includes(cl)) : [];
      html += classPicker("mi_class", "Choose a class for your spells");
      if (cl) {
        html += miniSpellPicker("mi_cantrips", 0, [cl], 2, "Choose 2 cantrips");
        html += miniSpellPicker("mi_spell", 1, [cl], 1, "Choose 1 1st-level spell (cast once per long rest)");
      }
      break;
    }
    case "ritual-caster": {
      const cl = fc["rc_class"] || "";
      html += classPicker("rc_class", "Choose a class for ritual spells (INT or WIS ≥ 13 required)");
      if (cl) html += `<p style="font-size:12px;color:var(--text-muted);margin-top:6px">You gain a ritual book with two 1st-level ritual spells from the ${cl} list. Add ritual spells as you find them.</p>`;
      break;
    }
    case "war-caster":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">Passive: advantage on CON saves for concentration; somatic components with hands full; cast spells as opportunity attacks.</p>`;
      break;
    case "eldritch-adept": {
      const INVOCATIONS = [
        "Agonizing Blast (requires Eldritch Blast)",
        "Armor of Shadows — cast Mage Armor on yourself at will",
        "Ascendant Step (level 9) — cast Levitate on yourself at will",
        "Beast Speech — cast Speak with Animals at will",
        "Beguiling Influence — proficiency in Deception and Persuasion",
        "Devil's Sight — see normally in darkness (magical and nonmagical) to 120 ft",
        "Eldritch Mind — advantage on CON saves to maintain concentration",
        "Eldritch Sight — cast Detect Magic at will, without expending a spell slot",
        "Eyes of the Rune Keeper — read all writing",
        "Fiendish Vigor — cast False Life on yourself at will (1st-level version)",
        "Gaze of Two Minds — see/hear through a willing creature's senses as an action",
        "Gift of the Depths (level 5) — breathe underwater, swim speed, Water Breathing 1/long rest",
        "Gift of the Ever-Living Ones — maximize healing rolls from your pact familiar",
        "Grasp of Hadar (requires Eldritch Blast) — pull one creature hit 10 ft closer",
        "Investment of the Chain Master — enhance your pact familiar",
        "Lance of Lethargy (requires Eldritch Blast) — reduce speed of one target by 10 ft",
        "Mask of Many Faces — cast Disguise Self at will",
        "Misty Visions — cast Silent Image at will",
        "One with Shadows (level 5) — become invisible in dim light or darkness (action)",
        "Repelling Blast (requires Eldritch Blast) — push creatures hit 10 ft away",
        "Thirsting Blade (level 5, Pact of the Blade) — attack twice with pact weapon",
        "Tomb of Levistus (level 5) — reaction to encase yourself in ice (take cold damage, gain temp HP)",
        "Undying Servitude (level 5) — cast Animate Dead once per long rest",
        "Visions of Distant Realms (level 15) — cast Arcane Eye at will",
        "Whispers of the Grave (level 9) — cast Speak with Dead at will",
        "Witch Sight (level 15) — see the true form of shapechangers and creatures disguised by magic",
      ];
      const chosen = fc["invocation"] || "";
      html += `<div class="field" style="margin-top:8px;">
        <label>Choose one Eldritch Invocation</label>
        <select onchange="App.setFeatChoice('invocation',this.value)">
          <option value="">— choose an invocation —</option>
          ${INVOCATIONS.map(inv => `<option value="${inv}" ${chosen===inv?"selected":""}>${inv}</option>`).join("")}
        </select>
        ${chosen ? `<p style="font-size:12px;color:var(--text-muted);margin-top:6px">Chosen: <strong style="color:var(--gold)">${chosen.split("—")[0].trim()}</strong></p>` : ""}
      </div>`;
      break;
    }
    case "fey-teleportation": {
      html += abPicker("fey_tele_ability", "+1 to INT or CHA", ['int','cha']);
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">Learn Sylvan. Misty Step 1/short rest without a slot.</p>`;
      break;
    }
    case "fey-touched": {
      html += abPicker("fey_ability", "+1 to INT, WIS, or CHA", ['int','wis','cha']);
      const feySchools = DATA.spells.filter(s => s.level === 1 && (s.school === "Divination" || s.school === "Enchantment"));
      const chosenFey = fc["fey_spell"] || "";
      html += `<div class="field" style="margin-top:8px;">
        <label>Choose one 1st-level Divination or Enchantment spell</label>
        <select onchange="App.setFeatChoice('fey_spell',this.value)">
          <option value="">— choose —</option>
          ${feySchools.map(s => `<option value="${s.name}" ${chosenFey===s.name?"selected":""}>${s.name} (${s.school})</option>`).join("")}
        </select>
        <p style="font-size:11px;color:var(--text-muted);margin-top:4px">You also get Misty Step (both cast 1/long rest without a slot).</p>
      </div>`;
      break;
    }
    case "shadow-touched": {
      html += abPicker("shadow_ability", "+1 to INT, WIS, or CHA", ['int','wis','cha']);
      const shadowSchools = DATA.spells.filter(s => s.level === 1 && (s.school === "Illusion" || s.school === "Necromancy"));
      const chosenShadow = fc["shadow_spell"] || "";
      html += `<div class="field" style="margin-top:8px;">
        <label>Choose one 1st-level Illusion or Necromancy spell</label>
        <select onchange="App.setFeatChoice('shadow_spell',this.value)">
          <option value="">— choose —</option>
          ${shadowSchools.map(s => `<option value="${s.name}" ${chosenShadow===s.name?"selected":""}>${s.name} (${s.school})</option>`).join("")}
        </select>
        <p style="font-size:11px;color:var(--text-muted);margin-top:4px">You also get Invisibility (both cast 1/long rest without a slot).</p>
      </div>`;
      break;
    }
    case "telekinetic":
      html += abPicker("tk_ability", "+1 to INT, WIS, or CHA", ['int','wis','cha']);
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">Mage Hand (invisible). Bonus action to shove a creature within 30 ft 5 ft in any direction (STR save).</p>`;
      break;
    case "telepathic":
      html += abPicker("tp_ability", "+1 to INT, WIS, or CHA", ['int','wis','cha']);
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">Telepathic communication within 60 ft. Detect Thoughts 1/long rest without a slot.</p>`;
      break;
    case "metamagic-adept": {
      const metamagics = ["Careful Spell","Distant Spell","Empowered Spell","Extended Spell","Heightened Spell","Quickened Spell","Seeking Spell","Subtle Spell","Transmuted Spell","Twinned Spell"];
      const chosenMM = fc["metamagics"] || [];
      html += `<div class="field" style="margin-top:8px;"><label>Choose 2 Metamagic options</label>
        <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:6px">
          ${metamagics.map(m => { const sel=chosenMM.includes(m),dis=!sel&&chosenMM.length>=2;
            return `<span class="tag" style="cursor:${dis?"not-allowed":"pointer"};opacity:${dis?0.4:1};${sel?"background:var(--crimson);border-color:var(--crimson)":""}"
              ${dis?"":(`onclick="App.toggleFeatArrayChoice('metamagics','${m}',2)"`)}">${m}</span>`;
          }).join("")}
        </div></div>`;
      break;
    }
    case "martial-adept": {
      const maneuvers = ["Commander's Strike","Disarming Attack","Distracting Strike","Evasive Footwork","Feinting Attack","Goading Attack","Lunging Attack","Maneuvering Attack","Menacing Attack","Parry","Precision Attack","Pushing Attack","Rally","Riposte","Sweeping Attack","Trip Attack"];
      const chosenM = fc["adept_maneuvers"] || [];
      html += `<div class="field" style="margin-top:8px;"><label>Choose 2 Battle Master maneuvers</label>
        <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:6px">
          ${maneuvers.map(m => { const sel=chosenM.includes(m),dis=!sel&&chosenM.length>=2;
            return `<span class="tag" style="cursor:${dis?"not-allowed":"pointer"};opacity:${dis?0.4:1};${sel?"background:var(--crimson);border-color:var(--crimson)":""}"
              ${dis?"":(`onclick="App.toggleFeatArrayChoice('adept_maneuvers','${m}',2)"`)}">${m}</span>`;
          }).join("")}
        </div></div>`;
      break;
    }
    case "elemental-adept": {
      const dmgTypes = ["Acid","Cold","Fire","Lightning","Thunder"];
      const chosenEl = fc["element_type"] || "";
      html += `<div class="field" style="margin-top:8px;"><label>Choose a damage type</label>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
          ${dmgTypes.map(t => `<span class="tag" style="cursor:pointer;${chosenEl===t?"background:var(--crimson);border-color:var(--crimson)":""}"
            onclick="App.setFeatChoice('element_type','${t}')">${t}</span>`).join("")}
        </div></div>`;
      break;
    }
    case "spell-sniper": {
      const attackCantrips = DATA.spells.filter(s => s.level === 0 && s.summary.toLowerCase().includes("attack"));
      const chosenSS = fc["sniper_cantrip"] || "";
      html += `<div class="field" style="margin-top:8px;"><label>Choose one attack cantrip from any class list</label>
        <select onchange="App.setFeatChoice('sniper_cantrip',this.value)">
          <option value="">— choose —</option>
          ${attackCantrips.map(s => `<option value="${s.name}" ${chosenSS===s.name?"selected":""}>${s.name}</option>`).join("")}
        </select></div>
      <p style="font-size:12px;color:var(--gold);margin-top:6px">Spell attack range doubled. Ignore half and three-quarters cover.</p>`;
      break;
    }
    case "resilient":
      html += abPicker("res_ability", "Choose an ability to gain +1 and saving throw proficiency", ABILITIES);
      break;
    case "skilled": {
      const chosen = fc["skilled_picks"] || [];
      const atCap = chosen.length >= 3;
      html += `<div class="field" style="margin-top:8px;"><label>Choose 3 skills or tools</label>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;">
          ${[...SKILLS.map(([n])=>n),"Thieves' tools","Artisan's tools","Musical instrument","Navigator's tools","Herbalism kit","Poisoner's kit"].map(name => {
            const sel = chosen.includes(name);
            const dis = !sel && atCap;
            return `<span class="tag" style="cursor:${dis?"not-allowed":"pointer"};opacity:${dis?0.4:1};${sel?"background:var(--crimson);border-color:var(--crimson)":""}"
              ${dis?"":(`onclick="App.toggleFeatArrayChoice('skilled_picks','${name.replace(/'/g,"\\'")}',3)"`)}>
              ${name}</span>`;
          }).join("")}
        </div></div>`;
      break;
    }
    case "keen-mind":
    case "linguist":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 INT applied automatically. Note languages gained:</p>
        <div class="field" style="margin-top:6px;"><input type="text" value="${fc["lang_notes"]||""}" oninput="App.setFeatChoice('lang_notes',this.value)" placeholder="e.g. Elvish, Draconic" /></div>`;
      break;
    case "actor":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 CHA applied automatically to your ability scores. Advantage on Deception/Performance to impersonate; mimic voices.</p>`;
      break;
    case "empathic":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 WIS applied automatically. Grants Insight proficiency.</p>`;
      break;
    case "gunner":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 DEX applied automatically. Proficiency with firearms; ignore loading; no melee penalty on ranged attacks.</p>`;
      break;
    case "durable":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 CON applied automatically. When you spend a Hit Die on a short rest, you always regain at least 2× your CON mod HP.</p>`;
      break;
    case "heavy-armor-master":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 STR applied automatically. In heavy armor, reduce B/P/S damage from non-magical attacks by 3.</p>`;
      break;
    case "athlete":
    case "lightly-armored":
    case "piercer":
    case "slasher":
    case "revenant-blade":
    case "weapon-master":
      html += abPicker("stat_boost", "+1 to Strength or Dexterity", ['str','dex']);
      break;
    case "moderately-armored":
      html += abPicker("stat_boost", "+1 to Strength or Dexterity", ['str','dex']);
      break;
    case "heavily-armored":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 STR applied automatically. Gain heavy armor proficiency.</p>`;
      break;
    case "crusher":
    case "tavern-brawler":
      html += abPicker("brawler_stat", "+1 to Strength or Constitution", ['str','con']);
      break;
    case "chef":
      html += abPicker("chef_stat", "+1 to Constitution or Wisdom", ['con','wis']);
      break;
    case "fade-away":
      html += abPicker("fade_stat", "+1 to Dexterity or Intelligence", ['dex','int']);
      break;
    case "second-chance":
      html += abPicker("second_stat", "+1 to Dexterity, Constitution, or Charisma", ['dex','con','cha']);
      break;
    case "gift-of-the-gem-dragon":
      html += abPicker("gem_stat", "+1 to Intelligence, Wisdom, or Charisma", ['int','wis','cha']);
      break;
    case "flash-recall":
      html += abPicker("flash_stat", "+1 to your spellcasting ability (INT, WIS, or CHA)", ['int','wis','cha']);
      break;
    case "boon-of-irresistible-offense":
      html += abPicker("boon_off_stat", "+1 to Strength or Dexterity", ['str','dex']);
      break;
    case "wonder-maker":
      html += abPicker("stat_boost", "+1 to Dexterity or Intelligence", ['dex','int']);
      break;
    case "alert":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+5 Initiative applied automatically to your initiative on the sheet. Can't be surprised. Unseen attackers gain no advantage.</p>`;
      break;
    case "mobile":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+10 ft speed applied automatically to your Speed on the sheet. Difficult terrain doesn't slow your Dash. No opportunity attacks from creatures you attack.</p>`;
      break;
    case "tough":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+2 HP per character level applied automatically to your HP max on the sheet (retroactive).</p>`;
      break;
    case "boon-of-fortitude":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+40 HP maximum applied automatically to your HP max on the sheet.</p>`;
      break;
    case "boon-of-speed":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+30 ft speed applied automatically to your Speed on the sheet.</p>`;
      break;
    case "dual-wielder":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 AC while wielding two weapons (applied automatically). Can use non-light weapons for two-weapon fighting.</p>`;
      break;
    case "observant":
      html += abPicker("obs_ability", "+1 to Intelligence or Wisdom", ['int','wis']);
      html += `<p style="font-size:12px;color:var(--text-muted);margin-top:4px">Also grants +5 to passive Perception and passive Investigation.</p>`;
      break;
    case "sentinel":
    case "sharpshooter":
    case "great-weapon-master":
    case "polearm-master":
    case "lucky":
    case "skulker":
    case "grappler":
    case "crossbow-expert":
    case "defensive-duelist":
    case "shield-master":
    case "savage-attacker":
    case "mounted-combatant":
    case "charger":
    case "inspiring-leader":
    case "dungeon-delver":
    case "poisoner":
    case "fighting-initiate":
    case "medium-armor-master":
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">All benefits are passive — no additional choices needed.</p>`;
      break;
    default:
      html += `<p style="font-size:12px;color:var(--text-muted);margin-top:6px">Apply any choices from this feat manually using your rulebook.</p>`;
  }

  html += `</div>`;
  return html;
}

// Renders feat sub-options for a specific ASI slot, storing choices in asiChoices[slotKey].featChoices
function renderFeatOptionsForSlot(c, slotKey, slotChoice) {
  const feat = DATA.feats.find(f => f.id === slotChoice.featId);
  if (!feat) return '';
  const fc = slotChoice.featChoices || {};

  // All setters use App.setAsiFeatChoice(slotKey, field, value)
  // All array toggles use App.toggleAsiFeatArray(slotKey, field, value, max)

  function abPick(field, label, allowed) {
    const chosen = fc[field] || '';
    const opts = allowed || ABILITIES;
    return `<div class="field" style="margin-top:6px">
      <label style="font-size:11px">${label}</label>
      <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:4px">
        ${opts.map(a => `<span class="tag" style="cursor:pointer;${chosen===a?'background:var(--crimson);border-color:var(--crimson)':''}"
          onclick="App.setAsiFeatChoice('${slotKey}','${field}','${a}')">${ABILITY_NAMES[a]}</span>`).join('')}
      </div>
    </div>`;
  }

  let html = `<div style="padding:10px;background:var(--ink-panel-2);border-radius:8px;margin-top:8px;font-size:12px;color:var(--text-muted)">${feat.summary}</div>`;

  switch (feat.id) {
    case 'aberrant-dragonmark': {
      const cantPool = DATA.spells.filter(s => s.level===0 && s.classes.includes('sorcerer'));
      const spPool   = DATA.spells.filter(s => s.level===1 && s.classes.includes('sorcerer'));
      const chCant   = fc['ab_dmark_cantrip'] || '';
      const chSp     = fc['ab_dmark_spell'] || '';
      html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">+1 CON applied automatically.</p>
        <div class="field" style="margin-top:6px">
          <label style="font-size:11px">Choose one sorcerer cantrip</label>
          <select onchange="App.setAsiFeatChoice('${slotKey}','ab_dmark_cantrip',this.value)">
            <option value="">— choose —</option>
            ${cantPool.map(s => `<option value="${s.name}" ${chCant===s.name?'selected':''}>${s.name}</option>`).join('')}
          </select>
        </div>
        <div class="field" style="margin-top:6px">
          <label style="font-size:11px">Choose one 1st-level sorcerer spell (cast 1/long rest, CON spellcasting)</label>
          <select onchange="App.setAsiFeatChoice('${slotKey}','ab_dmark_spell',this.value)">
            <option value="">— choose —</option>
            ${spPool.map(s => `<option value="${s.name}" ${chSp===s.name?'selected':''}>${s.name}</option>`).join('')}
          </select>
        </div>
        <p style="font-size:11px;color:var(--text-muted);margin-top:4px">Each time you cast this spell, roll 1d6. On a 1, take 1d6 psychic damage.</p>`;
      break;
    }
    case 'artificer-initiate': {
      const cantPool = DATA.spells.filter(s => s.level===0 && s.classes.includes('artificer'));
      const spPool   = DATA.spells.filter(s => s.level===1 && s.classes.includes('artificer'));
      const chCant   = fc['ai_cantrip'] || '';
      const chSp     = fc['ai_spell'] || '';
      html += `<div class="field" style="margin-top:6px">
          <label style="font-size:11px">Choose one artificer cantrip</label>
          <select onchange="App.setAsiFeatChoice('${slotKey}','ai_cantrip',this.value)">
            <option value="">— choose —</option>
            ${cantPool.map(s => `<option value="${s.name}" ${chCant===s.name?'selected':''}>${s.name}</option>`).join('')}
          </select>
        </div>
        <div class="field" style="margin-top:6px">
          <label style="font-size:11px">Choose one 1st-level artificer spell (cast 1/long rest)</label>
          <select onchange="App.setAsiFeatChoice('${slotKey}','ai_spell',this.value)">
            <option value="">— choose —</option>
            ${spPool.map(s => `<option value="${s.name}" ${chSp===s.name?'selected':''}>${s.name}</option>`).join('')}
          </select>
        </div>`;
      break;
    }
    case 'resilient':          html += abPick('res_ability', '+1 to which ability? (also gain save proficiency)', ABILITIES); break;
    case 'observant':
      html += abPick('obs_ability', '+1 to INT or WIS', ['int','wis']);
      html += `<p style="font-size:11px;color:var(--text-muted);margin-top:4px">Also +5 to passive Perception and Investigation.</p>`;
      break;
    case 'telekinetic':        html += abPick('tk_ability', '+1 to INT, WIS, or CHA', ['int','wis','cha']); break;
    case 'telepathic':         html += abPick('tp_ability', '+1 to INT, WIS, or CHA', ['int','wis','cha']); break;
    case 'actor':              html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 CHA applied automatically. Advantage on Deception/Performance to impersonate.</p>`; break;
    case 'empathic':           html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 WIS applied automatically. Grants Insight proficiency.</p>`; break;
    case 'gunner':             html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 DEX applied automatically. Firearm proficiency, no melee penalty.</p>`; break;
    case 'durable':            html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 CON applied automatically. Minimum Hit Die recovery = 2× CON mod.</p>`; break;
    case 'keen-mind':
    case 'linguist':           html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 INT applied automatically.</p>`; break;
    case 'alert':              html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+5 Initiative applied automatically. Can't be surprised.</p>`; break;
    case 'mobile':             html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+10 ft Speed applied automatically.</p>`; break;
    case 'tough':              html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+2 HP per level applied automatically to HP max.</p>`; break;
    case 'boon-of-fortitude':  html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+40 HP max applied automatically.</p>`; break;
    case 'boon-of-speed':      html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+30 ft Speed applied automatically.</p>`; break;
    case 'dual-wielder':       html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 AC while dual-wielding (applied automatically).</p>`; break;
    case 'athlete':
    case 'lightly-armored':
    case 'piercer':
    case 'slasher':
    case 'revenant-blade':
    case 'weapon-master':      html += abPick('stat_boost', '+1 to Strength or Dexterity', ['str','dex']); break;
    case 'moderately-armored': html += abPick('stat_boost', '+1 to Strength or Dexterity', ['str','dex']); break;
    case 'heavily-armored':
    case 'heavy-armor-master': html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 STR applied automatically.</p>`; break;
    case 'crusher':
    case 'tavern-brawler':     html += abPick('brawler_stat', '+1 to Strength or Constitution', ['str','con']); break;
    case 'chef':               html += abPick('chef_stat', '+1 to Constitution or Wisdom', ['con','wis']); break;
    case 'fade-away':          html += abPick('fade_stat', '+1 to Dexterity or Intelligence', ['dex','int']); break;
    case 'second-chance':      html += abPick('second_stat', '+1 to Dexterity, Constitution, or Charisma', ['dex','con','cha']); break;
    case 'gift-of-the-gem-dragon': html += abPick('gem_stat', '+1 to INT, WIS, or CHA', ['int','wis','cha']); break;
    case 'flash-recall':       html += abPick('flash_stat', '+1 to your spellcasting ability (INT, WIS, or CHA)', ['int','wis','cha']); break;
    case 'boon-of-irresistible-offense': html += abPick('boon_off_stat', '+1 to Strength or Dexterity', ['str','dex']); break;
    case 'wonder-maker':       html += abPick('stat_boost', '+1 to Dexterity or Intelligence', ['dex','int']); break;
    case 'elemental-adept': {
      const chosen = fc['element_type'] || '';
      html += `<div class="field" style="margin-top:6px"><label style="font-size:11px">Choose a damage type</label>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:4px">
          ${["Acid","Cold","Fire","Lightning","Thunder"].map(t =>
            `<span class="tag" style="cursor:pointer;${chosen===t?'background:var(--crimson);border-color:var(--crimson)':''}"
              onclick="App.setAsiFeatChoice('${slotKey}','element_type','${t}')">${t}</span>`).join('')}
        </div></div>`;
      break;
    }
    case 'eldritch-adept': {
      const INVOCATIONS = [
        "Agonizing Blast (requires Eldritch Blast)",
        "Armor of Shadows — cast Mage Armor on yourself at will",
        "Ascendant Step (level 9) — cast Levitate on yourself at will",
        "Beast Speech — cast Speak with Animals at will",
        "Beguiling Influence — proficiency in Deception and Persuasion",
        "Devil's Sight — see normally in darkness to 120 ft",
        "Eldritch Mind — advantage on CON saves to maintain concentration",
        "Eldritch Sight — cast Detect Magic at will",
        "Eyes of the Rune Keeper — read all writing",
        "Fiendish Vigor — cast False Life on yourself at will",
        "Gaze of Two Minds — see/hear through a willing creature's senses",
        "Gift of the Depths (level 5) — breathe underwater, Water Breathing 1/long rest",
        "Grasp of Hadar (requires Eldritch Blast) — pull hit creature 10 ft closer",
        "Lance of Lethargy (requires Eldritch Blast) — reduce target speed by 10 ft",
        "Mask of Many Faces — cast Disguise Self at will",
        "Misty Visions — cast Silent Image at will",
        "One with Shadows (level 5) — become invisible in dim light or darkness",
        "Repelling Blast (requires Eldritch Blast) — push creatures hit 10 ft away",
        "Thirsting Blade (level 5, Pact of the Blade) — attack twice with pact weapon",
        "Whispers of the Grave (level 9) — cast Speak with Dead at will",
        "Witch Sight (level 15) — see true forms of shapechangers",
      ];
      const chosen = fc['invocation'] || '';
      html += `<div class="field" style="margin-top:6px">
        <label style="font-size:11px">Choose one Eldritch Invocation</label>
        <select onchange="App.setAsiFeatChoice('${slotKey}','invocation',this.value)">
          <option value="">— choose an invocation —</option>
          ${INVOCATIONS.map(inv => `<option value="${inv}" ${chosen===inv?'selected':''}>${inv}</option>`).join('')}
        </select>
        ${chosen ? `<p style="font-size:11px;color:var(--gold);margin-top:4px">Chosen: ${chosen.split('—')[0].trim()}</p>` : ''}
      </div>`;
      break;
    }
    case 'magic-initiate': {
      const cl = fc['mi_class'] || '';
      html += `<div class="field" style="margin-top:6px">
        <label style="font-size:11px">Choose a class</label>
        <select onchange="App.setAsiFeatChoice('${slotKey}','mi_class',this.value)">
          <option value="">— pick a class —</option>
          ${["bard","cleric","druid","paladin","ranger","sorcerer","warlock","wizard"].map(k =>
            `<option value="${k}" ${cl===k?'selected':''}>${k.charAt(0).toUpperCase()+k.slice(1)}</option>`).join('')}
        </select>
      </div>`;
      if (cl) {
        const cantrips = DATA.spells.filter(s => s.level===0 && s.classes.includes(cl));
        const spells1  = DATA.spells.filter(s => s.level===1 && s.classes.includes(cl));
        const chCant = Array.isArray(fc['mi_cantrips']) ? fc['mi_cantrips'] : [];
        const chSp   = fc['mi_spell'] || '';
        html += `<div style="margin-top:8px;font-size:11px;color:var(--gold)">Choose 2 cantrips (${chCant.length}/2):</div>
          <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">
            ${cantrips.map(s => {
              const sel = chCant.includes(s.name);
              const dis = !sel && chCant.length >= 2;
              return `<span class="tag" style="font-size:11px;cursor:${dis?'not-allowed':'pointer'};opacity:${dis?0.4:1};${sel?'background:var(--crimson);border-color:var(--crimson)':''}"
                ${dis ? '' : `onclick="App.toggleAsiFeatArray('${slotKey}','mi_cantrips','${s.name.replace(/'/g,"\\'")}',2)"`}>${s.name}</span>`;
            }).join('')}
          </div>
          <div style="margin-top:8px;font-size:11px;color:var(--gold)">Choose 1 first-level spell (cast once per long rest):</div>
          <select style="margin-top:4px;width:100%" onchange="App.setAsiFeatChoice('${slotKey}','mi_spell',this.value)">
            <option value="">— choose —</option>
            ${spells1.map(s => `<option value="${s.name}" ${chSp===s.name?'selected':''}>${s.name}</option>`).join('')}
          </select>`;
      }
      break;
    }
    case 'ritual-caster': {
      const cl = fc['rc_class'] || '';
      html += `<div class="field" style="margin-top:6px">
        <label style="font-size:11px">Choose a class for ritual spells</label>
        <select onchange="App.setAsiFeatChoice('${slotKey}','rc_class',this.value)">
          <option value="">— pick a class —</option>
          ${["bard","cleric","druid","paladin","ranger","sorcerer","warlock","wizard"].map(k =>
            `<option value="${k}" ${cl===k?'selected':''}>${k.charAt(0).toUpperCase()+k.slice(1)}</option>`).join('')}
        </select>
      </div>`;
      if (cl) html += `<p style="font-size:11px;color:var(--text-muted);margin-top:6px">Ritual book with 2 level-1 ritual spells from the ${cl} list. Choose them in the Bonus Spells section of the Spells step.</p>`;
      break;
    }
    case 'fey-teleportation': {
      html += abPick('fey_tele_ability', '+1 to INT or CHA', ['int','cha']);
      html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">Learn Sylvan. Gain Misty Step 1/short rest (no slot required). INT or CHA is your spellcasting ability for it.</p>`;
      break;
    }
    case 'elven-accuracy': {
      html += abPick('ea_ability', '+1 to DEX, INT, WIS, or CHA', ['dex','int','wis','cha']);
      html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">When you have advantage on attacks using your chosen ability, reroll one die and use the higher result.</p>`;
      break;
    }
    case 'squat-nimbleness': {
      html += abPick('sn_ability', '+1 to STR or DEX', ['str','dex']);
      const snSkill = fc['sn_skill'] || '';
      html += `<div class="field" style="margin-top:6px"><label style="font-size:11px">Choose Athletics or Acrobatics proficiency</label>
        <div style="display:flex;gap:6px;margin-top:4px">
          ${['Athletics','Acrobatics'].map(s => `<span class="tag" style="cursor:pointer;${snSkill===s?'background:var(--crimson);border-color:var(--crimson)':''}" onclick="App.setAsiFeatChoice('${slotKey}','sn_skill','${s}')">${s}</span>`).join('')}
        </div></div>`;
      break;
    }
    case 'orcish-fury': {
      html += abPick('of_ability', '+1 to STR or CON', ['str','con']);
      html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 weapon die when you hit. Reaction at 0 HP: make one weapon attack.</p>`;
      break;
    }
    case 'flames-of-phlegethos': {
      html += abPick('fp_ability', '+1 to INT or CHA', ['int','cha']);
      html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">Reroll 1s on fire damage. After casting fire spell: flame wreath for 1 min (attacks deal +1d4 fire).</p>`;
      break;
    }
    case 'infernal-constitution':
      html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">+1 CON applied automatically. Resistance to cold and poison. Advantage on poison saves.</p>`;
      break;
    case 'dragon-hide': {
      html += abPick('dh_ability', '+1 to STR, CON, or CHA', ['str','con','cha']);
      html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">Retractable claws: 1d4 slashing unarmed. Unarmored AC = 13 + DEX.</p>`;
      break;
    }
    case 'prodigy': {
      const chosenSkill = fc['prodigy_skill'] || '';
      html += `<div class="field" style="margin-top:6px"><label style="font-size:11px">Choose one skill for double proficiency</label>
        <select onchange="App.setAsiFeatChoice('${slotKey}','prodigy_skill',this.value)">
          <option value="">— choose —</option>
          ${SKILLS.map(([n]) => `<option value="${n}" ${chosenSkill===n?'selected':''}>${n}</option>`).join('')}
        </select></div>
      <p style="font-size:11px;color:var(--gold);margin-top:4px">Also gain one tool proficiency and one language (note below).</p>`;
      break;
    }
    case 'dragonborn-heritage':
      html += abPick('dbh_ability', '+1 to STR or CHA', ['str','cha']);
      html += `<p style="font-size:11px;color:var(--gold);margin-top:4px">Breath weapon +1 die. Resistance to your draconic damage type.</p>`;
      break;
    case 'fey-touched': {
      html += abPick('fey_ability', '+1 to INT, WIS, or CHA', ['int','wis','cha']);
      const schools = DATA.spells.filter(s => s.level===1 && (s.school==='Divination'||s.school==='Enchantment'));
      const chosen = fc['fey_spell'] || '';
      html += `<div class="field" style="margin-top:6px">
        <label style="font-size:11px">Choose one 1st-level Divination or Enchantment spell (cast 1/long rest)</label>
        <select onchange="App.setAsiFeatChoice('${slotKey}','fey_spell',this.value)">
          <option value="">— choose —</option>
          ${schools.map(s => `<option value="${s.name}" ${chosen===s.name?'selected':''}>${s.name} (${s.school})</option>`).join('')}
        </select>
        <p style="font-size:11px;color:var(--text-muted);margin-top:4px">Also grants Misty Step 1/long rest.</p>
      </div>`;
      break;
    }
    case 'shadow-touched': {
      html += abPick('shadow_ability', '+1 to INT, WIS, or CHA', ['int','wis','cha']);
      const schools = DATA.spells.filter(s => s.level===1 && (s.school==='Illusion'||s.school==='Necromancy'));
      const chosen = fc['shadow_spell'] || '';
      html += `<div class="field" style="margin-top:6px">
        <label style="font-size:11px">Choose one 1st-level Illusion or Necromancy spell (cast 1/long rest)</label>
        <select onchange="App.setAsiFeatChoice('${slotKey}','shadow_spell',this.value)">
          <option value="">— choose —</option>
          ${schools.map(s => `<option value="${s.name}" ${chosen===s.name?'selected':''}>${s.name} (${s.school})</option>`).join('')}
        </select>
        <p style="font-size:11px;color:var(--text-muted);margin-top:4px">Also grants Invisibility 1/long rest.</p>
      </div>`;
      break;
    }
    case 'metamagic-adept': {
      const opts = ["Careful Spell","Distant Spell","Empowered Spell","Extended Spell","Heightened Spell","Quickened Spell","Seeking Spell","Subtle Spell","Transmuted Spell","Twinned Spell"];
      const chosen = Array.isArray(fc['metamagics']) ? fc['metamagics'] : [];
      html += `<div class="field" style="margin-top:6px"><label style="font-size:11px">Choose 2 Metamagic options (${chosen.length}/2)</label>
        <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">
          ${opts.map(m => { const sel=chosen.includes(m),dis=!sel&&chosen.length>=2;
            return `<span class="tag" style="font-size:11px;cursor:${dis?'not-allowed':'pointer'};opacity:${dis?0.4:1};${sel?'background:var(--crimson);border-color:var(--crimson)':''}"
              ${dis?'':(`onclick="App.toggleAsiFeatArray('${slotKey}','metamagics','${m}',2)"`)}">${m}</span>`;
          }).join('')}
        </div></div>`;
      break;
    }
    case 'martial-adept': {
      const opts = ["Commander's Strike","Disarming Attack","Distracting Strike","Evasive Footwork","Feinting Attack","Goading Attack","Lunging Attack","Maneuvering Attack","Menacing Attack","Parry","Precision Attack","Pushing Attack","Rally","Riposte","Sweeping Attack","Trip Attack"];
      const chosen = Array.isArray(fc['adept_maneuvers']) ? fc['adept_maneuvers'] : [];
      html += `<div class="field" style="margin-top:6px"><label style="font-size:11px">Choose 2 Battle Master maneuvers (${chosen.length}/2)</label>
        <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">
          ${opts.map(m => { const sel=chosen.includes(m),dis=!sel&&chosen.length>=2;
            return `<span class="tag" style="font-size:11px;cursor:${dis?'not-allowed':'pointer'};opacity:${dis?0.4:1};${sel?'background:var(--crimson);border-color:var(--crimson)':''}"
              ${dis?'':(`onclick="App.toggleAsiFeatArray('${slotKey}','adept_maneuvers','${m.replace(/'/g,"\\'")}',2)"`)}">${m}</span>`;
          }).join('')}
        </div></div>`;
      break;
    }
    case 'skilled': {
      const opts = [...SKILLS.map(([n])=>n),"Thieves' tools","Artisan's tools","Musical instrument","Navigator's tools","Herbalism kit","Poisoner's kit"];
      const chosen = Array.isArray(fc['skilled_picks']) ? fc['skilled_picks'] : [];
      html += `<div class="field" style="margin-top:6px"><label style="font-size:11px">Choose 3 skills or tools (${chosen.length}/3)</label>
        <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">
          ${opts.map(name => { const sel=chosen.includes(name),dis=!sel&&chosen.length>=3;
            return `<span class="tag" style="font-size:11px;cursor:${dis?'not-allowed':'pointer'};opacity:${dis?0.4:1};${sel?'background:var(--crimson);border-color:var(--crimson)':''}"
              ${dis?'':(`onclick="App.toggleAsiFeatArray('${slotKey}','skilled_picks','${name.replace(/'/g,"\\'")}',3)"`)}">${name}</span>`;
          }).join('')}
        </div></div>`;
      break;
    }
    case 'spell-sniper': {
      const attackCantrips = DATA.spells.filter(s => s.level===0 && s.summary.toLowerCase().includes('attack'));
      const chosen = fc['sniper_cantrip'] || '';
      html += `<div class="field" style="margin-top:6px">
        <label style="font-size:11px">Choose one attack cantrip from any class</label>
        <select onchange="App.setAsiFeatChoice('${slotKey}','sniper_cantrip',this.value)">
          <option value="">— choose —</option>
          ${attackCantrips.map(s => `<option value="${s.name}" ${chosen===s.name?'selected':''}>${s.name}</option>`).join('')}
        </select>
        <p style="font-size:11px;color:var(--text-muted);margin-top:4px">Doubles attack spell range. Ignore half and three-quarters cover.</p>
      </div>`;
      break;
    }
    default:
      if (['alert','lucky','tough','mobile','sentinel','polearm-master','great-weapon-master','sharpshooter','dual-wielder','war-caster','grappler','skulker','charger'].includes(feat.id)) {
        html += `<p style="font-size:12px;color:var(--gold);margin-top:6px">All benefits are passive — no additional choices needed.</p>`;
      } else {
        html += `<p style="font-size:12px;color:var(--text-muted);margin-top:6px">Apply any choices from this feat using your rulebook.</p>`;
      }
  }
  return html;
}
function renderSkillsFeat() {
  const c = state.character;
  const cls = getClass(c.classId);
  const bg = getBackground(c.backgroundId);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);
  const bgSkills = bg ? bg.skillProficiencies : [];
  const max = cls ? (cls.skillChoices?.count || 2) : 0;
  const classSkillOptions = cls?.skillChoices?.options || [];
  // If the class has no options (e.g. PDF import didn't capture them) OR says "Any",
  // treat ALL skills as eligible so nothing is greyed out
  const openSelection = !classSkillOptions.length
    || classSkillOptions.some(o => /any/i.test(o));

  return `
    <h2>Skill Proficiencies</h2>
    <p class="subtitle">
      ${bg ? `${bg.name} grants: ${bgSkills.join(", ")}. ` : ""}
      ${cls
        ? openSelection
          ? `Choose any ${max} skills for ${cls.name}.`
          : `Choose ${max} class skills from: ${classSkillOptions.join(", ")}.`
        : "Pick a class first."}
      ${c.classSkillChoices.length}/${max} chosen.
    </p>
    <div>
      ${SKILLS.map(([name, ab]) => {
        const fromBg = bgSkills.includes(name);
        const chosen = c.classSkillChoices.includes(name);
        const atMax = c.classSkillChoices.length >= max && !chosen;
        // Eligible: from bg (always on), or class allows it, or open selection
        const eligible = !fromBg && (openSelection || classSkillOptions.includes(name));
        const proficient = fromBg || chosen;
        const mod = abilityMod(scores[ab]) + (proficient ? pb : 0);
        return `
          <div class="skill-row">
            <input type="checkbox"
              ${fromBg ? "checked disabled" : ""}
              ${!fromBg && eligible && !atMax ? `onclick="App.toggleClassSkill('${name}')"` : ""}
              ${chosen ? "checked" : ""}
              ${!fromBg && (!eligible || atMax) && !chosen ? "disabled" : ""}
            />
            <span style="${!fromBg && !eligible ? "color:var(--text-muted)" : ""}">
              ${name} <span style="color:var(--text-muted);font-size:12px;">(${ab.toUpperCase()})</span>
            </span>
            <span class="skill-mod">${fmtMod(mod)}</span>
          </div>`;
      }).join("")}
    </div>
    <div style="margin-top:24px;">
      ${(() => {
        const lvl = c.level;
        const asiLevels = ASI_LEVELS[c.classId] || [4,8,12,16,19];
        const eligible = asiLevels.filter(l => l <= lvl);

        // Racial bonus slots — Variant Human gets a feat at level 1
        const racialSlots = [];
        if (c.raceId === 'variant-human') racialSlots.push({ key: 'vh_1', label: 'Level 1 — Variant Human Racial Feat' });

        const allSlots = [
          ...racialSlots,
          ...eligible.map(l => ({ key: String(l), label: `Level ${l} — ASI or Feat` })),
        ];

        if (!allSlots.length) {
          return `<div style="color:var(--text-muted);font-size:13px;padding:12px;background:var(--ink-panel);border-radius:8px">
            No ASI/Feat slots yet — first one unlocks at level ${asiLevels[0] || 4}.
          </div>`;
        }

        return `<h3 style="color:var(--gold);margin-bottom:12px">Ability Score Improvements & Feats</h3>
          <p class="subtitle" style="margin-bottom:16px">Each slot lets you either increase ability scores <em>or</em> take a feat. Your character has <strong>${allSlots.length}</strong> slot${allSlots.length>1?'s':''} at level ${lvl}.</p>
          ${allSlots.map(({ key, label }) => {
            const isRacial = key.startsWith('vh_');
            const choice = (c.asiChoices || {})[key] || {};
            const scores = finalAbilityScores(c);
            return `<div style="margin-bottom:20px;padding:16px;background:var(--ink-panel);border-radius:10px;border:1px solid ${choice.type?'var(--gold)':'var(--border-dark)'}">
              <div style="font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--gold);margin-bottom:10px">
                ${label}
              </div>
              <div style="display:flex;gap:8px;margin-bottom:12px">
                ${isRacial ? `
                  <button class="btn ${choice.type==='feat'?'btn--primary':''}" onclick="App.setAsiChoice('${key}','type','feat')" style="flex:1">
                    Feat
                  </button>` : `
                  <button class="btn ${choice.type==='asi'?'btn--primary':''}" onclick="App.setAsiChoice('${key}','type','asi')" style="flex:1">
                    Ability Score Improvement
                  </button>
                  <button class="btn ${choice.type==='feat'?'btn--primary':''}" onclick="App.setAsiChoice('${key}','type','feat')" style="flex:1">
                    Feat
                  </button>`}
              </div>

              ${choice.type === 'asi' ? `
                <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px">+2 to one ability, or +1 to two abilities (max 20). Click once for +1, twice for +2.</p>
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
                  ${ABILITIES.map(a => {
                    const cur = scores[a] || 10;
                    const ab1 = choice.ab1, ab2 = choice.ab2;
                    const countForThis = (ab1===a?1:0)+(ab2===a?1:0);
                    const atMax = cur >= 20;
                    const newVal = Math.min(20, cur + countForThis);
                    // Toggle: 0→ab1, if ab1=a→ab2=a (for +2), if ab2=a clear ab2
                    const onclick = atMax ? '' : `App.setAsiChoice('${key}','_ab_toggle_${a}',${countForThis})`;
                    return `<div style="padding:10px;background:var(--ink-panel-2);border-radius:8px;border:2px solid ${countForThis>0?'var(--gold)':'var(--border-dark)'};cursor:${atMax?'not-allowed':'pointer'};opacity:${atMax?0.5:1};text-align:center"
                      onclick="${atMax?'':(`App.cycleAsiAbility('${key}','${a}')`)}">
                      <div style="font-size:11px;color:var(--text-muted)">${ABILITY_NAMES[a]}</div>
                      <div style="font-size:18px;font-weight:700;color:${countForThis>0?'var(--gold)':'var(--text-light)'}">${cur}${countForThis>0?` +${countForThis}`:''}</div>
                      <div style="font-size:11px;color:var(--text-muted)">${countForThis>0?`→ ${newVal}`:''}</div>
                      ${countForThis===2?'<div style="font-size:9px;color:var(--gold)">+2</div>':countForThis===1?'<div style="font-size:9px;color:var(--gold)">+1</div>':''}
                    </div>`;
                  }).join('')}
                </div>
                <p style="font-size:11px;color:var(--text-muted);margin-top:6px">Click an ability to add +1. Click again to upgrade to +2. Click a third time to clear.</p>` : ''}

              ${choice.type === 'feat' ? `
                <p style="font-size:12px;color:var(--text-muted);margin-bottom:8px">Choose a feat:</p>
                <select style="width:100%;margin-bottom:${choice.featId?'10px':'0'}" onchange="App.setAsiChoice('${key}','featId',this.value)">
                  <option value="">— choose a feat —</option>
                  ${DATA.feats.map(f => `<option value="${f.id}" ${choice.featId===f.id?'selected':''}>${f.name} — ${f.summary.slice(0,60)}...</option>`).join('')}
                </select>
                ${choice.featId ? renderFeatOptionsForSlot(c, key, choice) : ''}
              ` : ''}
            </div>`;
          }).join('')}`;
      })()}
    </div>
    ${(() => {
      // Expertise pickers for Bard (level 3+) and Rogue (level 1+)
      const lvl = c.level;
      const sc = c.subclassChoices || {};
      const allProfSkills = [...allProficientSkills(c)];
      if (!allProfSkills.length) return "";

      function expertisePicker(key, count, label) {
        const chosen = sc[key] || [];
        const atCap = chosen.length >= count;
        return `<div style="margin-top:12px;padding:12px;background:var(--ink-panel-2);border-radius:8px;border:1px solid var(--gold)">
          <div style="font-size:12px;color:var(--gold);font-weight:600;margin-bottom:4px">${label} (${chosen.length}/${count})</div>
          <div style="font-size:11px;color:var(--text-muted);margin-bottom:8px">Choose from skills you're proficient in. Expertise doubles your proficiency bonus.</div>
          <div style="display:flex;flex-wrap:wrap;gap:5px">
            ${allProfSkills.map(name => {
              const sel = chosen.includes(name);
              const dis = !sel && atCap;
              return `<span class="tag" style="cursor:${dis?"not-allowed":"pointer"};opacity:${dis?0.4:1};${sel?"background:var(--gold);color:var(--dark);border-color:var(--gold)":""}"
                ${dis?"":(`onclick="App.toggleExpertise('${key}','${name.replace(/'/g,"\\'")}')"`)}>${name}</span>`;
            }).join("")}
          </div>
        </div>`;
      }

      let expertiseHtml = "";
      if (c.classId === "bard" && lvl >= 3) {
        expertiseHtml += expertisePicker("bard_expertise_1", 2, "Expertise (Bard level 3) — choose 2 skills");
        if (lvl >= 10) expertiseHtml += expertisePicker("bard_expertise_2", 2, "Expertise (Bard level 10) — choose 2 more skills");
      }
      if (c.classId === "rogue") {
        expertiseHtml += expertisePicker("rogue_expertise_1", 2, "Expertise (Rogue level 1) — choose 2 skills" + (allProfSkills.length < 2 ? " (pick class skills above first)" : ""));
        if (lvl >= 6) expertiseHtml += expertisePicker("rogue_expertise_2", 2, "Expertise (Rogue level 6) — choose 2 more skills");
      }
      return expertiseHtml ? `<div style="margin-top:16px"><h3 style="color:var(--gold);font-size:14px">Expertise</h3>${expertiseHtml}</div>` : "";
    })()}
  `;
}

function renderEquipment() {
  const c = state.character;
  const cls = getClass(c.classId);
  const bg = getBackground(c.backgroundId);
  return `
    <h2>Equipment</h2>
    ${cls ? `<h3>${cls.name} Starting Gear</h3><ul class="trait-list">${cls.startingEquipment.map(e => `<li>${e}</li>`).join("")}</ul>` : ""}
    ${bg ? `<h3>${bg.name} Gear</h3><ul class="trait-list">${bg.equipment.map(e => `<li>${e}</li>`).join("")}</ul>` : ""}
    <div class="field">
      <label>Armor Worn (affects AC)</label>
      <select onchange="App.setArmor(this.value)">
        <option value="">— none / unarmored —</option>
        ${DATA.equipment.armor.filter(a => a.category !== "Shield").map(a => `<option value="${a.name}" ${c.armorId === a.name ? "selected" : ""}>${a.name} (AC ${a.baseAC}${a.addDex ? " + Dex" : ""}${a.dexCap != null && a.dexCap !== null ? ` max ${a.dexCap}` : ""})</option>`).join("")}
      </select>
    </div>
    <div class="field">
      <label><input type="checkbox" ${c.shield ? "checked" : ""} onclick="App.toggleShield()" style="width:auto;margin-right:8px;" />Carrying a Shield (+2 AC)</label>
    </div>
    <div class="field">
      <label>Additional Gear / Weapons (free text)</label>
      <input type="text" value="${escapeHtml(c.extraGear)}" oninput="App.setExtraGear(this.value)" placeholder="e.g. Longsword, 2x potion of healing, 50gp" />
    </div>`;
}

function renderSpells() {
  const c = state.character;
  const cls = getClass(c.classId);
  const CASTER_ABILITY_WIZ = {
    bard:"cha",cleric:"wis",druid:"wis",paladin:"cha",
    ranger:"wis",sorcerer:"cha",warlock:"cha",wizard:"int",artificer:"int",
  };
  const slotInfo = getEffectiveSpellSlots(c);
  const castingClasses = getCastingClasses(c);
  // The class that drives cantrip/spell counts: the highest-level casting class
  const mainCaster = castingClasses[0] || null;
  const scAbility = mainCaster ? mainCaster.ability
                  : (cls?.spellcasting?.ability || CASTER_ABILITY_WIZ[c.classId] || null);
  const isCaster = !!(slotInfo || scAbility);
  if (!cls || !isCaster) {
    return '<h2>Spells</h2><p class="subtitle">' + (cls ? cls.name : "This class") + " doesn't use the standard spell list — skip ahead.</p>";
  }

  // Counts come from the main casting class at ITS level, not total character level
  const casterClassId = mainCaster ? mainCaster.classId : c.classId;
  const lvl = mainCaster ? mainCaster.level : getPrimaryLevel(c);
  const casterCls = getClass(casterClassId) || cls;
  const maxCantrips = (CANTRIPS_KNOWN[casterClassId] || [])[lvl] || casterCls?.spellcasting?.cantripsAt1 || (FULL_CASTERS.has(casterClassId) ? 3 : 0);
  const isKnownCaster = !!SPELLS_KNOWN[casterClassId];
  const isPreparedCaster = ["cleric","druid","paladin","wizard"].includes(casterClassId);
  const maxSpells = isKnownCaster ? ((SPELLS_KNOWN[casterClassId] || [])[lvl] || null) : null;
  const maxSpellLevel = slotInfo
    ? (slotInfo.type === "pact" ? slotInfo.slots[0].level : Math.max(...slotInfo.slots.map(s => s.level)))
    : Math.min(9, Math.ceil(lvl / 2));

  // Spell list draws from EVERY casting class the character has
  const castingIds = castingClasses.length ? castingClasses.map(e => e.classId) : [cls.id];
  const classTaggedCount = DATA.spells.filter(s => castingIds.some(id => s.classes.includes(id))).length;
  const allSpells = DATA.spells.filter(s =>
    castingIds.some(id => s.classes.includes(id)) || s.classes.length === 0 || classTaggedCount < 5
  );
  const cantrips = allSpells.filter(s => s.level === 0).sort((a,b) => a.name.localeCompare(b.name));
  const leveled  = allSpells.filter(s => s.level >= 1 && s.level <= maxSpellLevel)
    .sort((a,b) => a.level - b.level || a.name.localeCompare(b.name));

  const ordinals = ["","1st","2nd","3rd","4th","5th","6th","7th","8th","9th"];
  const byLevel = {};
  for (const s of leveled) { if (!byLevel[s.level]) byLevel[s.level] = []; byLevel[s.level].push(s); }

  const bonusNamesForCap = getChosenBonusSpellNames(c);
  // Only count non-bonus, non-ritual spells against the cap
  const nonCapSpellCount = c.spellsKnown.filter(name => {
    const sp = DATA.spells.find(s => s.name === name);
    return !bonusNamesForCap.has(name) && !sp?.ritual;
  }).length;
  const atCantripCap = c.cantrips.length >= maxCantrips;
  const atSpellCap   = maxSpells !== null && nonCapSpellCount >= maxSpells;

  function spellRow(s, selected, disabled, clickFn) {
    const onclick = disabled ? "" : ("App." + clickFn + "('" + s.name.replace(/'/g, "\\'") + "')");
    const ritualBadge = s.ritual ? '<span style="font-size:10px;color:#a5d6a7;border:1px solid #a5d6a7;border-radius:4px;padding:0 4px;margin-left:4px">Ritual</span>' : '';
    const ctColor = s.castingTime === 'bonus' ? '#ffd54f' : s.castingTime === 'reaction' ? '#ef9a9a' : '';
    const ctBadge = s.castingTime && s.castingTime !== 'action'
      ? `<span style="font-size:10px;color:${ctColor};border:1px solid ${ctColor};border-radius:4px;padding:0 4px;margin-left:4px">${s.castingTime === 'bonus' ? 'Bonus' : 'Reaction'}</span>`
      : '';
    return '<div class="spell-row' + (selected ? " selected" : "") + (disabled ? " spell-disabled" : "") + '"'
      + (onclick ? (' onclick="' + onclick + '"') : "")
      + '><span class="sname">' + s.name + ritualBadge + ctBadge + '</span><span class="slevel">' + s.school + '</span>'
      + '<div class="ssum">' + s.summary + '</div></div>';
  }

  const leveledHtml = Object.keys(byLevel).sort((a,b)=>a-b).map(lvlKey => {
    let slotNote = "";
    if (slotInfo && slotInfo.type !== "pact") {
      const slot = slotInfo.slots.find(s => s.level === parseInt(lvlKey));
      if (slot) slotNote = '<span style="font-size:12px;color:var(--text-muted);margin-left:8px;">' + slot.max + ' slots</span>';
    }
    const rows = byLevel[lvlKey].map(s => {
      const selected = c.spellsKnown.includes(s.name);
      // Ritual spells and bonus spells are always selectable — never count against cap
      const isFree = !!(s.ritual) || bonusNamesForCap.has(s.name);
      const disabled = !selected && atSpellCap && !isFree;
      return spellRow(s, selected, disabled, "toggleSpell");
    }).join("");
    return '<div class="spell-level-header"><span>' + ordinals[lvlKey] + '-Level Spells</span>' + slotNote + '</div>'
      + '<div class="spell-list" style="margin-bottom:8px;">' + rows + '</div>';
  }).join("") || '<p class="subtitle">No matching spells in the library yet.</p>';

  const freeSpellCount = c.spellsKnown.length - nonCapSpellCount;
  const spellLabel = maxSpells !== null
    ? (nonCapSpellCount + " / " + maxSpells + " known" + (freeSpellCount > 0 ? ` <span style="color:var(--text-muted);font-size:12px">(+${freeSpellCount} ritual/bonus, free)</span>` : ""))
    : isPreparedCaster ? (c.spellsKnown.length + " prepared (no hard cap)") : (c.spellsKnown.length + " selected");

  const cantripRows = cantrips.map(s => spellRow(s, c.cantrips.includes(s.name), !c.cantrips.includes(s.name) && atCantripCap, "toggleCantrip")).join("")
    || '<p class="subtitle">No cantrips in library for this class.</p>';

  // ── Bonus Spells Section (don't count against class cap) ─
  const bonusPool = getBonusSpellPool(c);
  const fcStore = c.featChoices || {};
  const scStore = c.subclassChoices || {};

  const bonusHtml = bonusPool.length ? (() => {
    let html = '<div style="margin-top:24px;border-top:2px solid var(--gold);padding-top:16px;">'
      + '<h3 style="color:var(--gold)">Bonus Spells <span style="font-size:13px;font-weight:400;color:var(--text-muted)">— don\'t count against your spell cap</span></h3>'
      + '<p class="subtitle">These spells come from your subclass, patron, oaths, or feats. They\'re always available and don\'t use your class spell slots.</p>';

    bonusPool.forEach(entry => {
      if (entry.automatic) {
        // Always-prepared — show as list with toggle to add to "active" spells
        const spellData = DATA.spells.filter(s => s.name === entry.name);
        const sp = spellData[0];
        const inList = c.spellsKnown.includes(entry.name) || c.cantrips.includes(entry.name);
        html += `<div style="margin-top:12px">
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--gold);margin-bottom:6px">${entry.source}</div>
          ${sp ? `<div class="spell-row ${inList?"selected":""}" onclick="App.${sp.level===0?"toggleCantrip":"toggleSpell"}('${sp.name.replace(/'/g,"\\'")}')">
            <span class="sname">${sp.name}</span>
            <span class="slevel">${sp.school} · ${sp.level===0?"Cantrip":`Lvl ${sp.level}`}</span>
            <div class="ssum">${sp.summary}</div>
          </div>` : `<div class="spell-row"><span class="sname">${entry.name}</span><div class="ssum dim">Import your sourcebook for details</div></div>`}
        </div>`;
      } else {
        // All user-chosen bonus spells are stored via toggleFeatSpell → featChoices
        const chosen = Array.isArray(fcStore[entry.key]) ? fcStore[entry.key] : (fcStore[entry.key] ? [fcStore[entry.key]] : []);
        const isSinglePick = entry.maxPick === 1;
        const atCap = chosen.length >= entry.maxPick;

        const available = DATA.spells.filter(s =>
          entry.names.includes(s.name) &&
          (entry.level0ok ? true : s.level >= 1) &&
          (s.level === 0 || s.level <= maxSpellLevel)
        );
        const grouped = {};
        available.forEach(s => {
          const g = s.level === 0 ? "Cantrips" : `Level ${s.level}`;
          if (!grouped[g]) grouped[g] = [];
          grouped[g].push(s);
        });

        html += `<div style="margin-top:16px">
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--gold);margin-bottom:4px">
            ${entry.source} (${chosen.length} / ${entry.maxPick})
            ${atCap ? '<span style="color:var(--gold)"> ✓ All chosen</span>' : ''}
          </div>
          <div style="max-height:320px;overflow-y:auto;display:flex;flex-direction:column;gap:4px">
            ${Object.entries(grouped).map(([grpLabel, spells]) => `
              <div style="font-size:11px;color:var(--text-muted);padding:4px 0 2px;border-bottom:1px solid var(--border-dark)">${grpLabel}</div>
              ${spells.map(s => {
                const sel = chosen.includes(s.name);
                const dis = !sel && atCap;
                const ritTag = s.ritual ? '<span style="font-size:10px;color:#a5d6a7;border:1px solid #a5d6a7;border-radius:4px;padding:0 4px;margin-left:4px">Ritual</span>' : '';
                const toggleFn = isSinglePick
                  ? `App.setFeatChoice('${entry.key}','${s.name.replace(/'/g,"\\'")}')` 
                  : `App.toggleFeatSpell('${entry.key}','${s.name.replace(/'/g,"\\'")}')`;
                return `<div class="spell-row ${sel?"selected":""} ${dis?"spell-disabled":""}" ${dis?"":('onclick="'+toggleFn+'"')}>
                  <span class="sname">${s.name}${ritTag}</span>
                  <span class="slevel">${s.school} · ${s.level===0?"Cantrip":`Lvl ${s.level}`}</span>
                  <div class="ssum">${s.summary}</div>
                </div>`;
              }).join("")}`).join("")}
          </div>
        </div>`;
      }
    });

    html += '</div>';
    return html;
  })() : "";

  return '<h2>Spells</h2>'
    + '<p class="subtitle">' + cls.name + ' casts using <strong>' + ABILITY_NAMES[scAbility] + '</strong>. '
    + 'Showing up to level ' + maxSpellLevel + ' spells. '
    + (isPreparedCaster ? "Prepared caster — select what you would prepare today." : "") + '</p>'
    + '<h3>Cantrips (' + c.cantrips.length + ' / ' + maxCantrips + ')</h3>'
    + (atCantripCap ? '<p class="subtitle" style="color:var(--gold)">✓ Cantrip cap reached for level ' + lvl + '. You can still add bonus cantrips below.</p>' : "")
    + '<div class="spell-list" style="margin-bottom:20px;">' + cantripRows + '</div>'
    + '<h3>Spells Known / Prepared (' + spellLabel + ')</h3>'
    + (atSpellCap ? '<p class="subtitle" style="color:var(--gold)">✓ Spell cap reached. Deselect to swap, or add bonus spells below.</p>' : "")
    + leveledHtml
    + bonusHtml;
}

function renderReview() {
  const c = state.character;
  const race = getRace(c.raceId), cls = getClass(c.classId), bg = getBackground(c.backgroundId);
  const scores = finalAbilityScores(c);
  const hp = computeHP(c), ac = computeAC(c), pb = proficiencyBonus(c.level);
  const subclass = cls && cls.subclasses.find(s => s.id === c.subclassId);
  return `
    <h2>Review &amp; Save</h2>
    <div class="summary-grid">
      <div class="summary-block">
        <h3>Identity</h3>
        <div class="stat-line"><span>Name</span><span>${escapeHtml(c.name) || "—"}</span></div>
        <div class="stat-line"><span>Race</span><span>${race ? race.name : "—"}</span></div>
        <div class="stat-line"><span>Class</span><span>${cls ? cls.name : "—"}${subclass ? ` (${subclass.name})` : ""}</span></div>
        <div class="stat-line"><span>Background</span><span>${bg ? bg.name : "—"}</span></div>
        <div class="stat-line"><span>Level</span><span>${c.level}</span></div>
        <div class="stat-line"><span>Proficiency Bonus</span><span>${fmtMod(pb)}</span></div>
      </div>
      <div class="summary-block">
        <h3>Combat</h3>
        <div class="stat-line"><span>Hit Points</span><span>${hp ?? "—"}</span></div>
        <div class="stat-line"><span>Armor Class</span><span>${ac}</span></div>
        <div class="stat-line"><span>Speed</span><span>${race ? race.speed : "—"} ft</span></div>
        <div class="stat-line"><span>Hit Die</span><span>${cls ? `d${cls.hitDie}` : "—"}</span></div>
      </div>
      <div class="summary-block">
        <h3>Ability Scores</h3>
        ${ABILITIES.map(a => `<div class="stat-line"><span>${ABILITY_NAMES[a]}</span><span>${scores[a]} (${fmtMod(abilityMod(scores[a]))})</span></div>`).join("")}
      </div>
      <div class="summary-block">
        <h3>Proficient Skills</h3>
        ${[...allProficientSkills(c)].map(s => `<span class="tag">${s}</span>`).join("") || "<span class='subtitle'>None chosen</span>"}
        ${c.feat ? `<h3 style="margin-top:14px;">Feat</h3><span class="tag">${DATA.feats.find(f => f.id === c.feat)?.name}</span>` : ""}
      </div>
    </div>
    <div class="field" style="margin-top:20px;">
      <label>Notes</label>
      <input type="text" value="${escapeHtml(c.notes)}" oninput="App.setNotes(this.value)" placeholder="Personality, backstory, allies, plot hooks..." />
    </div>`;
}

// ─── Level Up Actions ───────────────────────────────────────
const LevelUp = {
  setChoice(key, val) { state.levelUpChoices[key] = val; render(); },
  // Choose which class receives this level. Resets class-specific choices.
  setLevelClass(classId) {
    const ch = state.levelUpChoices;
    if (ch.levelClass === classId) return;
    ch.levelClass = classId;
    // Clear choices that belonged to the previously selected class
    ['asi_type','asi_ab1','asi_ab2','feat_id','feat_choices','subclass_id',
     'fighting_style_1','expertise_keys','invocations','metamagic','pact_boon']
      .forEach(k => delete ch[k]);
    render();
  },
  toggleMulticlass(classId) {
    const c = state.character;
    if (!c.multiclasses) c.multiclasses = [];
    const idx = c.multiclasses.findIndex(m => m.classId === classId);
    if (idx >= 0) {
      c.multiclasses.splice(idx, 1);
    } else {
      c.multiclasses.push({ classId, level: 1, subclassId: null });
    }
    // DON'T touch c.level here — confirm() will set c.level = _targetLevel
    render();
  },
  setMulticlassLevel(classId, val) {
    const c = state.character;
    const mc = (c.multiclasses || []).find(m => m.classId === classId);
    if (mc) { mc.level = Math.max(1, parseInt(val) || 1); render(); }
  },
  setMulticlassSubclass(classId, subId) {
    const c = state.character;
    const mc = (c.multiclasses || []).find(m => m.classId === classId);
    if (mc) { mc.subclassId = subId || null; render(); }
  },
  toggleChoice(key, val, max) {
    if (!state.levelUpChoices[key]) state.levelUpChoices[key] = [];
    const arr = state.levelUpChoices[key];
    const i = arr.indexOf(val);
    if (i >= 0) arr.splice(i, 1);
    else if (!max || arr.length < max) arr.push(val);
    render();
  },
  cycleAb(ab) {
    const ch = state.levelUpChoices;
    const count = (ch.asi_ab1===ab?1:0)+(ch.asi_ab2===ab?1:0);
    if (count === 0) {
      // +1: put in first empty slot
      if (!ch.asi_ab1) ch.asi_ab1 = ab;
      else if (!ch.asi_ab2) ch.asi_ab2 = ab;
      else { ch.asi_ab1 = ab; ch.asi_ab2 = null; }
    } else if (count === 1) {
      // Upgrade to +2: fill both slots with this ability
      ch.asi_ab1 = ab; ch.asi_ab2 = ab;
    } else {
      // Clear both
      if (ch.asi_ab1 === ab) ch.asi_ab1 = null;
      if (ch.asi_ab2 === ab) ch.asi_ab2 = null;
    }
    render();
  },
  async confirm() {
    const c = state.character;
    const choices = state.levelUpChoices || {};
    const targetLevel = choices._targetLevel || (c.level + 1);
    if (!c.multiclasses) c.multiclasses = [];

    // Which class is gaining this level
    const lvlClassId = choices.levelClass || c.classId;
    const isPrimary  = lvlClassId === c.classId;

    // Apply the level to the right class
    if (!isPrimary) {
      const mc = c.multiclasses.find(m => m.classId === lvlClassId);
      if (mc) mc.level = (mc.level || 0) + 1;
      else c.multiclasses.push({ classId: lvlClassId, level: 1, subclassId: null });
    }
    // Total level always advances by one; primary level is derived as total - sum(mc)
    c.level = targetLevel;

    const classNewLevel = isPrimary
      ? getPrimaryLevel(c)
      : (c.multiclasses.find(m => m.classId === lvlClassId)?.level || 1);

    // ASI or Feat — keyed by total level so it stays unique across the character
    if (choices.asi_type === 'feat' && choices.feat_id) {
      if (!c.asiChoices) c.asiChoices = {};
      c.asiChoices[String(targetLevel)] = { type:'feat', featId:choices.feat_id, featChoices:choices.feat_choices||{} };
      if (!c.feat) { c.feat = choices.feat_id; c.featChoices = choices.feat_choices||{}; }
    } else if (choices.asi_type === 'asi') {
      if (!c.asiChoices) c.asiChoices = {};
      const ab1 = choices.asi_ab1, ab2 = choices.asi_ab2;
      c.asiChoices[String(targetLevel)] = { type:'asi', ab1:ab1||null, ab2:ab2||null };
      if (ab1) c.baseScores[ab1] = Math.min(20, (c.baseScores[ab1]||10) + (ab1===ab2?2:1));
      if (ab2 && ab2 !== ab1) c.baseScores[ab2] = Math.min(20, (c.baseScores[ab2]||10) + 1);
    }

    // Subclass goes to whichever class was levelled
    if (choices.subclass_id) {
      if (isPrimary) c.subclassId = choices.subclass_id;
      else {
        const mc = c.multiclasses.find(m => m.classId === lvlClassId);
        if (mc) mc.subclassId = choices.subclass_id;
      }
    }

    // Other class choices
    if (!c.subclassChoices) c.subclassChoices = {};
    if (choices.fighting_style_1 && !c.subclassChoices.fighting_style_1)
      c.subclassChoices.fighting_style_1 = choices.fighting_style_1;
    if (choices.expertise_keys?.length) {
      const expKey = lvlClassId === 'rogue'
        ? (classNewLevel <= 1 ? 'rogue_expertise_1' : 'rogue_expertise_2')
        : (classNewLevel <= 6 ? 'bard_expertise_1' : 'bard_expertise_2');
      c.subclassChoices[expKey] = choices.expertise_keys;
    }
    if (choices.invocations?.length)
      c.subclassChoices.invocations = [...(c.subclassChoices.invocations||[]), ...choices.invocations];
    if (choices.metamagic?.length)
      c.subclassChoices.metamagic = [...(c.subclassChoices.metamagic||[]), ...choices.metamagic];
    if (choices.pact_boon) c.subclassChoices.pact_boon = choices.pact_boon;

    // HP uses the hit die of the class that gained the level
    const lvlCls = getClass(lvlClassId);
    const hitDie = lvlCls?.hitDie || 8;
    const conMod = abilityMod(finalAbilityScores(c).con);
    const hpGain = Math.max(1, Math.floor(hitDie/2) + 1 + conMod);
    const prevMax = (c.manualMaxHp != null && c.manualMaxHp > 0)
      ? c.manualMaxHp
      : (computeHP({ ...c, level: targetLevel - 1, manualMaxHp: null }) || 0);
    c.manualMaxHp = prevMax + hpGain;

    // Level history
    if (!c.levelHistory) c.levelHistory = [];
    c.levelHistory.push({
      level: targetLevel,
      leveledClass: lvlClassId,
      classLevel: classNewLevel,
      hitDie,
      hpGain,
      multiclasses: c.multiclasses.map(m=>({...m})),
      choices: {...choices},
      timestamp: Date.now(),
    });

    await api.saveCharacter(c, state.editingId);
    state.levelUpChoices = {};
    Router.go('sheet', state.editingId);
  },

};
window.LevelUp = LevelUp;

// ─── Level Up Renderer ──────────────────────────────────────
function renderLevelUp() {
  const c = state.character;
  const choices = state.levelUpChoices || {};
  // Stable target total level, captured when the screen opened
  const newLevel = choices._targetLevel || (c.level + 1);

  if (newLevel > 20) {
    return `<div style="max-width:700px;margin:60px auto;padding:0 20px;text-align:center">
      <h2 style="color:var(--gold)">Maximum Level Reached</h2>
      <p style="color:var(--text-muted);margin:16px 0">Your character is already at level 20.</p>
      <button class="btn" onclick="Router.go('sheet','${state.editingId}')">← Back to Sheet</button>
    </div>`;
  }

  // Which class receives this level (defaults to the primary class)
  const lvlClassId  = choices.levelClass || c.classId;
  const isPrimary   = lvlClassId === c.classId;
  const lvlCls      = getClass(lvlClassId);
  const existingMC  = (c.multiclasses || []).find(m => m.classId === lvlClassId);
  // That class's level AFTER this level-up
  const classNewLevel = isPrimary ? getPrimaryLevel(c) + 1 : (existingMC?.level || 0) + 1;
  // Subclass currently attached to the class being levelled
  const lvlSubclassId = isPrimary ? c.subclassId : (existingMC?.subclassId || null);

  const cls = lvlCls; // downstream code refers to `cls` for the levelling class
  const unlocks = getLevelUnlocks(lvlClassId, classNewLevel, lvlSubclassId);
  const asi = ASI_LEVELS[lvlClassId]?.includes(classNewLevel);
  const hitDie = lvlCls?.hitDie || 8;
  const scores = finalAbilityScores(c);
  const conMod = abilityMod(scores.con);
  const avgHpGain = Math.max(1, Math.floor(hitDie / 2) + 1 + conMod);

  // Validate completeness for confirm button
  let complete = true;
  for (const u of unlocks) {
    if (u.type === 'asi_or_feat' && !choices.asi_type) { complete = false; break; }
    if (u.type === 'asi_or_feat' && choices.asi_type === 'feat' && !choices.feat_id) { complete = false; break; }
    if (u.type === 'subclass' && !choices.subclass_id) { complete = false; break; }
    if (u.type === 'expertise' && !choices.expertise_keys?.length) { complete = false; }
    if (u.type === 'choice' && u.multi && !(choices[u.key]?.length >= u.multi)) { complete = false; }
    if (u.type === 'choice' && !u.multi && !choices[u.key]) { complete = false; }
  }
  if (unlocks.length === 0) complete = true;

  const allSkills = SKILLS.map(([n]) => n);
  const allProfSkills = [...allProficientSkills(c)];

  // Preview of the class spread after confirming
  const previewSpread = (() => {
    const parts = [];
    const primAfter = isPrimary ? getPrimaryLevel(c) + 1 : getPrimaryLevel(c);
    parts.push(`${getClass(c.classId)?.name || c.classId} ${primAfter}`);
    for (const m of (c.multiclasses || [])) {
      const lv = m.classId === lvlClassId ? m.level + 1 : m.level;
      parts.push(`${getClass(m.classId)?.name || m.classId} ${lv}`);
    }
    if (!isPrimary && !existingMC) parts.push(`${lvlCls?.name || lvlClassId} 1`);
    return parts.join(' / ');
  })();

  // Class picker: primary, existing multiclasses, then any other class
  const classPicker = `<div class="levelup-card">
    <div class="levelup-unlock-label">Step 1</div>
    <h3 class="levelup-feature-name">Which class gains this level?</h3>
    <p class="levelup-feature-desc">Your hit die, features, and unlocks all come from the class you pick here.</p>
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px">
      ${[{ id: c.classId, lv: getPrimaryLevel(c), tag: '' },
         ...(c.multiclasses || []).map(m => ({ id: m.classId, lv: m.level, tag: '' }))]
        .map(e => {
          const k = getClass(e.id);
          const sel = e.id === lvlClassId;
          return `<button class="btn ${sel ? 'btn--primary' : ''}" onclick="LevelUp.setLevelClass('${e.id}')">
            ${k?.name || e.id} ${e.lv} → ${e.lv + 1} <span style="opacity:.7">(d${k?.hitDie || 8})</span>
          </button>`;
        }).join('')}
    </div>
    <details ${!isPrimary && !existingMC ? 'open' : ''}>
      <summary style="cursor:pointer;font-size:12px;color:var(--gold)">Take a level in a new class (multiclass)</summary>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
        ${DATA.classes
          .filter(k => k.id !== c.classId && !(c.multiclasses || []).some(m => m.classId === k.id))
          .map(k => `<button class="btn ${lvlClassId === k.id ? 'btn--primary' : ''}"
            onclick="LevelUp.setLevelClass('${k.id}')">+ ${k.name} <span style="opacity:.7">(d${k.hitDie})</span></button>`).join('')}
      </div>
    </details>
    <div style="margin-top:10px;padding:8px 10px;background:var(--ink-panel-2);border-radius:8px;font-size:12px">
      <span style="color:var(--text-muted)">After confirm (total level ${newLevel}):</span>
      <span style="color:var(--gold);font-weight:600">${previewSpread}</span>
    </div>
  </div>`;

  let body = `<div class="levelup-header">
    <div class="levelup-badge">${newLevel}</div>
    <div>
      <h2 style="color:var(--gold);margin:0">Level ${newLevel} — ${lvlCls?.name || 'Character'} ${classNewLevel}</h2>
      <div style="color:var(--text-muted);font-size:14px">${previewSpread} · ${c.name}</div>
    </div>
  </div>

  ${classPicker}

  <div class="levelup-hp-card">
    <div class="levelup-hp-icon">HP</div>
    <div>
      <div style="font-size:15px;font-weight:600">Hit Points increase</div>
      <div style="font-size:13px;color:var(--text-muted);margin-top:2px">
        Average: <strong style="color:var(--gold)">+${avgHpGain}</strong> HP
        (${lvlCls?.name || 'class'} d${hitDie} → average ${Math.floor(hitDie/2)+1}, ${conMod >= 0 ? '+' : ''}${conMod} CON)
      </div>
      <div style="font-size:12px;color:var(--text-muted);margin-top:4px">
        Max HP increases by ${avgHpGain} on confirm, using the hit die of the class you selected above. Or roll manually and use the HP override on your sheet.
      </div>
    </div>
  </div>`;

  // Render each unlock
  for (const u of unlocks) {

    if (u.type === 'passive') {
      body += `<div class="levelup-card levelup-card--passive">
        <div class="levelup-unlock-label">New Feature</div>
        <h3 class="levelup-feature-name">${u.label}</h3>
        <p class="levelup-feature-desc">${u.detail}</p>
      </div>`;
    }

    if (u.type === 'subclass') {
      const subcls = cls?.subclasses || [];
      body += `<div class="levelup-card">
        <div class="levelup-unlock-label">Choose Subclass</div>
        <h3 class="levelup-feature-name">${u.label}</h3>
        <p class="levelup-feature-desc">${u.detail}</p>
        <div class="levelup-options">
          ${subcls.map(s => `<div class="levelup-option ${choices.subclass_id===s.id?'selected':''}"
            onclick="LevelUp.setChoice('subclass_id','${s.id}')">
            <div style="font-weight:600">${s.name}</div>
          </div>`).join('')}
        </div>
      </div>`;
    }

    if (u.type === 'asi_or_feat') {
      body += `<div class="levelup-card">
        <div class="levelup-unlock-label">Ability Score Improvement or Feat</div>
        <div class="levelup-tab-row">
          <button class="levelup-tab ${choices.asi_type==='asi'?'active':''}" onclick="LevelUp.setChoice('asi_type','asi')">Ability Score Improvement</button>
          <button class="levelup-tab ${choices.asi_type==='feat'?'active':''}" onclick="LevelUp.setChoice('asi_type','feat')">Feat</button>
        </div>

        ${choices.asi_type === 'asi' ? `
          <p style="font-size:13px;color:var(--text-muted);margin-bottom:12px">Click once for +1. Click the same ability again for +2. Click a third time to clear.</p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            ${['str','dex','con','int','wis','cha'].map(a => {
              const cur = scores[a] || 10;
              const ab1 = choices.asi_ab1, ab2 = choices.asi_ab2;
              const countForThis = (ab1===a?1:0)+(ab2===a?1:0);
              const newVal = Math.min(20, cur + countForThis);
              const atMax = cur >= 20;
              return `<div class="asi-ability-row ${countForThis>0?'asi-selected':''} ${atMax?'asi-maxed':''}"
                style="cursor:${atMax?'not-allowed':'pointer'};opacity:${atMax?0.5:1}"
                onclick="${atMax?'':(`LevelUp.cycleAb('${a}')`)}"
              >
                <div style="font-weight:600">${ABILITY_NAMES[a]}</div>
                <div style="font-family:var(--font-mono);font-size:18px;color:${countForThis>0?'var(--gold)':'var(--text-light)'}">${cur}${countForThis>0?` +${countForThis} = ${newVal}`:''}</div>
                ${atMax ? '<div style="font-size:11px;color:var(--text-muted)">Maximum (20)</div>' : countForThis===2?'<div style="font-size:11px;color:var(--gold)">+2 — click to clear</div>':countForThis===1?'<div style="font-size:11px;color:var(--gold)">+1 — click again for +2</div>':'<div style="font-size:11px;color:var(--text-muted)">Click to add +1</div>'}
              </div>`;
            }).join('')}
          </div>` : ''}

        ${choices.asi_type === 'feat' ? `
          <p style="font-size:13px;color:var(--text-muted);margin-bottom:10px">Choose a feat:</p>
          <div style="display:grid;gap:6px;max-height:380px;overflow-y:auto">
            ${DATA.feats.map(f => `<div class="levelup-option ${choices.feat_id===f.id?'selected':''}"
              onclick="LevelUp.setChoice('feat_id','${f.id}')">
              <div style="font-weight:600">${f.name}</div>
              <div style="font-size:12px;color:var(--text-muted);margin-top:2px">${f.summary}</div>
            </div>`).join('')}
          </div>
          ${choices.feat_id ? `<div style="margin-top:12px;padding:12px;background:var(--ink-panel);border-radius:8px;border:1px solid var(--border-dark)">
            <div style="font-size:12px;color:var(--gold);margin-bottom:6px">Feat options</div>
            ${renderFeatOptionsForLevelUp(choices.feat_id, choices)}
          </div>` : ''}
        ` : ''}
      </div>`;
    }

    if (u.type === 'expertise') {
      const chosen = choices.expertise_keys || [];
      const pool = allProfSkills.length ? allProfSkills : allSkills;
      body += `<div class="levelup-card">
        <div class="levelup-unlock-label">${u.label}</div>
        <p class="levelup-feature-desc">${u.detail}</p>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
          ${pool.map(name => {
            const sel = chosen.includes(name);
            const dis = !sel && chosen.length >= 2;
            return `<span class="tag ${sel?'tag--selected':''}" style="cursor:${dis?'not-allowed':'pointer'};opacity:${dis?0.4:1}"
              ${dis?'':(`onclick="LevelUp.toggleChoice('expertise_keys','${name}',2)"`)}">${name}</span>`;
          }).join('')}
        </div>
      </div>`;
    }

    if (u.type === 'choice') {
      const chosen = u.multi ? (choices[u.key] || []) : choices[u.key];
      const atCap = u.multi && chosen?.length >= u.multi;
      body += `<div class="levelup-card">
        <div class="levelup-unlock-label">${u.label}</div>
        <p class="levelup-feature-desc">${u.detail}</p>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
          ${(u.options || []).map(opt => {
            const sel = u.multi ? (chosen||[]).includes(opt) : chosen===opt;
            const dis = !sel && atCap;
            const clickFn = u.multi
              ? `LevelUp.toggleChoice('${u.key}','${opt.replace(/'/g,"\\'")}',${u.multi})`
              : `LevelUp.setChoice('${u.key}','${opt.replace(/'/g,"\\'")}')`;
            return `<span class="tag ${sel?'tag--selected':''}" style="cursor:${dis?'not-allowed':'pointer'};opacity:${dis?0.4:1}"
              ${dis?'':(`onclick="${clickFn}"`)}>
              ${opt}
            </span>`;
          }).join('')}
        </div>
      </div>`;
    }
  }

  if (unlocks.length === 0) {
    body += `<div class="levelup-card levelup-card--passive">
      <div class="levelup-unlock-label">Feature</div>
      <h3 class="levelup-feature-name">Level ${newLevel} — Automatic Improvements</h3>
      <p class="levelup-feature-desc">This level improves your hit points, spell slots, and existing class features. No additional choices needed.</p>
    </div>`;
  }


  return `<div class="levelup-view">
    <div class="sheet-toolbar" style="margin-bottom:0">
      <button class="btn" onclick="Router.go('sheet','${state.editingId}')">← Back to Sheet</button>
    </div>
    <div class="levelup-body">
      ${body}
      <div class="levelup-footer">
        <button class="btn" onclick="Router.go('sheet','${state.editingId}')">Cancel</button>
        <button class="btn btn--primary ${complete?'':'btn--disabled'}"
          onclick="${complete?"LevelUp.confirm()":""}"
          title="${complete?'Confirm level up':'Complete all choices above first'}">
          ${complete ? `Confirm — Reach Level ${newLevel} →` : 'Complete all choices above'}
        </button>
      </div>
    </div>
  </div>`;
}

// Subset of renderFeatOptions for use in the level-up flow
function renderFeatOptionsForLevelUp(featId, choices) {
  const fc = choices;
  const feat = DATA.feats.find(f => f.id === featId);
  if (!feat) return '';

  // Reuse the same logic as renderFeatOptions but store into choices via LevelUp.setChoice
  switch(featId) {
    case 'magic-initiate': {
      const casterClasses = ["bard","cleric","druid","paladin","ranger","sorcerer","warlock","wizard"];
      const cl = fc.mi_class || '';
      return `<select onchange="LevelUp.setChoice('mi_class',this.value)" style="margin-bottom:8px">
          <option value="">— choose a class —</option>
          ${casterClasses.map(c => `<option value="${c}" ${cl===c?'selected':''}>${c.charAt(0).toUpperCase()+c.slice(1)}</option>`).join('')}
        </select>
        ${cl ? `<div style="margin-top:8px;font-size:12px;color:var(--text-muted)">Visit Edit Character → Spells to pick your Magic Initiate cantrips and spell after leveling up.</div>` : ''}`;
    }
    case 'resilient':
      return ABILITIES.map(a => `<span class="tag ${fc.res_ability===a?'tag--selected':''}" style="cursor:pointer"
        onclick="LevelUp.setChoice('res_ability','${a}')">${ABILITY_NAMES[a]}</span>`).join(' ');
    case 'skilled': {
      const chosen = fc.skilled_picks || [];
      return [...SKILLS.map(([n])=>n),"Thieves' tools","Artisan's tools","Musical instrument"].map(name => {
        const sel = chosen.includes(name);
        const dis = !sel && chosen.length >= 3;
        return `<span class="tag ${sel?'tag--selected':''}" style="cursor:${dis?'not-allowed':'pointer'};opacity:${dis?0.4:1}"
          ${dis?'':(`onclick="LevelUp.toggleChoice('skilled_picks','${name.replace(/'/g,"\\'")}',3)"`)}">${name}</span>`;
      }).join(' ');
    }
    case 'actor':
    case 'alert':
    case 'lucky':
    case 'tough':
    case 'mobile':
    case 'war-caster':
    case 'sentinel':
    case 'sharpshooter':
    case 'great-weapon-master':
    case 'polearm-master':
    case 'dual-wielder':
      return `<p style="font-size:12px;color:var(--gold)">✓ All benefits are passive — no choices needed.</p>`;
    default:
      return `<p style="font-size:12px;color:var(--text-muted)">Visit Edit Character to configure additional choices for this feat.</p>`;
  }
}

// Build the resource list for a given class at a given level (used for multiclass resources)
function buildClassResourceTable(classId, lvl, scores) {
  if (!scores) scores = { str:10,dex:10,con:10,int:10,wis:10,cha:10 };
  const wisMod = abilityMod(scores.wis), chaMod = abilityMod(scores.cha);
  const strMod = abilityMod(scores.str), conMod = abilityMod(scores.con);
  const intMod = abilityMod(scores.int), dexMod = abilityMod(scores.dex);
  const pb = proficiencyBonus(lvl);

  switch (classId) {
    case 'barbarian': return [
      { id:'rage', name:'Rage', max:[2,2,3,3,3,4,4,4,4,4,4,5,5,5,5,5,6,6,6,null][lvl-1]??6, recharge:'long', icon:'', desc:`+2 damage, resistance to B/P/S while raging.` },
    ];
    case 'bard': return [
      { id:'bardic', name:'Bardic Inspiration', max:Math.max(1,chaMod), recharge:lvl>=5?'short':'long', icon:'', desc:`d${lvl>=15?12:lvl>=10?10:lvl>=5?8:6} inspiration die.` },
    ];
    case 'cleric': return [
      { id:'channel', name:'Channel Divinity', max:lvl>=18?3:lvl>=6?2:1, recharge:'short', icon:'', desc:'Turn Undead and domain-specific Channel Divinity options.' },
    ];
    case 'druid': return [
      { id:'wildshape', name:'Wild Shape', max:2, recharge:'short', icon:'', desc:`CR ${lvl>=8?'1':lvl>=4?'0.5':'0.25'} beast forms. ${lvl>=4?'Can swim.':''} ${lvl>=8?'Can fly.':''}` },
    ];
    case 'fighter': return [
      { id:'secondwind', name:'Second Wind', max:1, recharge:'short', icon:'', desc:`Heal 1d10 + ${lvl} HP as a bonus action.` },
      ...(lvl>=2 ? [{ id:'actionsurge', name:'Action Surge', max:lvl>=17?2:1, recharge:'short', icon:'', desc:'Take one additional action this turn.' }] : []),
    ];
    case 'monk': {
      const ki = lvl;
      return [{ id:'ki', name:'Ki Points', max:ki, recharge:'short', icon:'', desc:`Flurry of Blows (2 Ki), Patient Defense (1 Ki), Step of the Wind (1 Ki). Unarmed: ${lvl>=17?'1d10':lvl>=11?'1d8':lvl>=5?'1d6':lvl>=3?'1d4':'1d4'}.` }];
    }
    case 'paladin': {
      const loh = lvl * 5;
      return [
        { id:'loh', name:'Lay on Hands', max:loh, recharge:'long', icon:'', desc:`Restore up to ${loh} HP total (pool).` },
        ...(lvl>=2 ? [{ id:'divsmite', name:'Divine Smite', max:null, recharge:null, icon:'', desc:'Expend spell slots to deal 2d8+1d8/slot radiant bonus damage on a hit.' }] : []),
        ...(lvl>=2 ? [{ id:'channel-pal', name:'Channel Divinity', max:1, recharge:'short', icon:'', desc:'Sacred Weapon, Turn the Unholy, or subclass option.' }] : []),
      ];
    }
    case 'ranger': return lvl>=2 ? [
      { id:'hunter', name:'Hunter\'s Mark', max:null, recharge:null, icon:'', desc:'1/short rest (or spell slot). +1d6 damage vs marked target.' },
    ] : [];
    case 'rogue': return [
      { id:'sneak', name:'Sneak Attack', max:null, recharge:null, icon:'', desc:`${Math.ceil(lvl/2)}d6 extra damage once per turn when you have advantage or an ally is adjacent.`, passive:true },
      ...(lvl>=2 ? [{ id:'cunning', name:'Cunning Action', max:null, recharge:null, icon:'', desc:'Bonus action: Dash, Disengage, or Hide.', passive:true }] : []),
    ];
    case 'sorcerer': {
      const sp = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21][lvl-1]??4;
      return [{ id:'sorcpts', name:'Sorcery Points', max:sp, recharge:'long', icon:'', desc:`Flexible Magic: create spell slots or fuel metamagic.` }];
    }
    case 'warlock': {
      const slots = lvl>=17?4:lvl>=11?3:lvl>=2?2:1;
      const slotLvl = lvl>=17?5:lvl>=15?5:lvl>=13?5:lvl>=11?5:lvl>=9?5:lvl>=7?4:lvl>=5?3:lvl>=3?2:1;
      return [{ id:'pact', name:'Pact Magic', max:slots, recharge:'short', icon:'', desc:`${slots} slot(s) of level ${slotLvl}. Recharge on short or long rest.` }];
    }
    case 'wizard': return [
      { id:'arcane-recovery', name:'Arcane Recovery', max:1, recharge:'long', icon:'', desc:`Regain up to ${Math.ceil(lvl/2)} levels of spell slots on a short rest.` },
    ];
    case 'artificer': return [
      { id:'infuse', name:'Infuse Items', max:Math.floor(lvl/2), recharge:'long', icon:'', desc:`Infuse up to ${Math.floor(lvl/2)} items simultaneously.` },
    ];
    default: return [];
  }
}

function getClassResources(c) {
  const lvl = getPrimaryLevel(c);   // primary class level for resource scaling
  const totalLvl = c.level;         // total for proficiency and features that use total
  const scores = finalAbilityScores(c);
  const wisMod = abilityMod(scores.wis);
  const chaMod = abilityMod(scores.cha);
  const strMod = abilityMod(scores.str);
  const conMod = abilityMod(scores.con);
  const intMod = abilityMod(scores.int);

  const table = {
    barbarian: [
      { id:'rage', name:'Rage', max: [2,2,3,3,3,4,4,4,4,4,4,5,5,5,5,5,6,6,6,null][lvl-1] ?? 6,
        recharge:'long', icon:'',
        desc:'On your turn, enter rage as a bonus action. Lasts 1 minute. +2 damage (scales), resistance to B/P/S, advantage on STR checks/saves.' },
    ],
    bard: [
      { id:'bardic', name:'Bardic Inspiration', max: Math.max(1, chaMod),
        recharge: lvl >= 5 ? 'short' : 'long', icon:'',
        desc:`Grant a d${[6,6,6,6,8,8,8,10,10,10,12,12,12,12,12,12,12,12,12,12][lvl-1] ?? 12} Bardic Inspiration to an ally who can add it to one attack, check, or save within 10 min.` },
    ],
    cleric: [
      { id:'channel', name:'Channel Divinity', max: lvl >= 18 ? 3 : lvl >= 6 ? 2 : 1,
        recharge:'short', icon:'', desc:'Use a Channel Divinity option granted by your domain or Turn Undead.' },
    ],
    druid: [
      { id:'wildshape', name:'Wild Shape', max: 2, recharge:'short', icon:'',
        desc:`Transform into beasts CR ≤ ${Math.floor(lvl/3)} for up to ${Math.floor(lvl/2)} hours. Uses recover on short or long rest.` },
    ],
    fighter: [
      { id:'actionsurge', name:'Action Surge', max: lvl >= 17 ? 2 : 1,
        recharge:'short', icon:'', desc:'On your turn, take one additional action. Recover on short or long rest.' },
      { id:'secondwind', name:'Second Wind', max: 1, recharge:'short', icon:'',
        desc:`Bonus action: regain 1d10 + ${lvl} HP. Recover on short or long rest.` },
      ...(c.subclassId === 'battle-master' ? [
        { id:'superiority', name:'Superiority Dice', max: lvl >= 15 ? 6 : lvl >= 7 ? 5 : lvl >= 3 ? 4 : 0,
          recharge:'short', icon:'', desc:`d${lvl >= 18 ? 12 : lvl >= 10 ? 10 : 8} dice for Battle Master maneuvers. Recover on short or long rest.` }
      ] : []),
    ],
    monk: () => {
      const ki = lvl;
      return [
        { id:'ki', name:'Ki Points', max: ki, recharge:'short', icon:'',
          desc:`Spend to power monk abilities: Flurry of Blows (1), Patient Defense (1), Step of the Wind (1), Stunning Strike (1), etc. Recover on short or long rest.` },
        { id:'deflect', name:'Deflect Missiles', max: 1, recharge:'short', icon:'',
          desc:'Reaction: reduce ranged weapon damage by 1d10 + DEX + monk level. If reduced to 0, catch and throw it (costs 1 Ki).' },
        ...(lvl >= 4 ? [{ id:'slowfall', name:'Slow Fall', max: 1, recharge:'short', icon:'',
          desc:'Reaction: reduce falling damage by 5 × monk level.' }] : []),
        ...(lvl >= 5 ? [{ id:'stunning', name:'Stunning Strike', max: null, recharge: null, icon:'',
          desc:`After hitting with a melee attack, spend 1 Ki (DC ${8+proficiencyBonus(lvl)+wisMod} CON save or stunned until end of your next turn).` }] : []),
        ...(lvl >= 7 ? [{ id:'evasion', name:'Evasion', max: null, recharge: null, icon:'',
          desc:'When a DEX save halves damage, you take none on success and half on fail.' }] : []),
        ...(lvl >= 9 ? [{ id:'unarmored4', name:'Unarmored Movement', max: null, recharge: null, icon:'',
          desc:`Speed +${[0,0,10,10,10,15,15,15,15,20,20,20,20,25,25,25,25,30,30,30][lvl-1] || 30}ft; at 9th can run on walls/water at end of turn.` }] : []),
      ];
    },
    paladin: [
      { id:'layonhands', name:'Lay on Hands', max: lvl * 5, recharge:'long', icon:'',
        desc:`Pool of ${lvl * 5} HP. Use action to restore HP from pool, or spend 5 HP to cure one disease or poison.` },
      { id:'channel_pal', name:'Channel Divinity', max: 1, recharge:'short', icon:'',
        desc:'Use a Channel Divinity option from your Sacred Oath (e.g. Sacred Weapon, Vow of Enmity).' },
      ...(lvl >= 2 ? [{ id:'divsmite', name:'Divine Smite', max: null, recharge: null, icon:'',
        desc:'When you hit with a melee weapon, expend a spell slot to deal 2d8 radiant (+1d8 per slot level above 1st, +1d8 vs undead/fiends, max 5d8).' }] : []),
    ],
    ranger: [
      ...(lvl >= 1 ? [{ id:'favored', name:"Favored Enemy", max: null, recharge: null, icon:'',
        desc:`Advantage on Survival checks to track, and on INT checks to recall info about: your chosen enemy types.` }] : []),
    ],
    rogue: [
      { id:'cunning', name:'Cunning Action', max: null, recharge: null, icon:'',
        desc:'Bonus action each turn: Dash, Disengage, or Hide.' },
      ...(lvl >= 5 ? [{ id:'uncanny', name:'Uncanny Dodge', max: null, recharge: null, icon:'',
        desc:'Reaction when an attacker you can see hits you: halve the damage.' }] : []),
      ...(lvl >= 7 ? [{ id:'evasion_r', name:'Evasion', max: null, recharge: null, icon:'',
        desc:'When a DEX save halves damage, you take none on success and half on fail.' }] : []),
      ...(lvl >= 11 ? [{ id:'reliable', name:'Reliable Talent', max: null, recharge: null, icon:'',
        desc:'When you make an ability check with proficiency, treat d20 rolls of 9 or below as 10.' }] : []),
      ...(c.subclassId === 'thief' && lvl >= 17 ? [{ id:'thiefsreflexes', name:"Thief's Reflexes", max: null, recharge: null, icon:'',
        desc:'Take two turns in first round of combat (second at initiative −10).' }] : []),
    ],
    sorcerer: [
      { id:'sorcery', name:'Sorcery Points', max: lvl, recharge:'long', icon:'',
        desc:'Spend to create spell slots (Flexible Casting), or use Metamagic options: Careful (1), Distant (1), Empowered (1), Extended (1), Heightened (3), Quickened (2), Subtle (1), Twinned (varies).' },
      ...(c.subclassId === 'wild-magic' ? [
        { id:'tideschaos', name:'Tides of Chaos', max: 1, recharge:'long', icon:'',
          desc:'Gain advantage on one attack roll, ability check, or saving throw. Recover on long rest (or after a Wild Magic Surge).' },
      ] : []),
    ],
    warlock: [
      { id:'eldritch', name:'Eldritch Invocations', max: null, recharge: null, icon:'',
        desc:`You know ${Math.min(8,[0,2,2,3,4,4,5,6,6,7,7,7,8,8,8,8,8,8,8,8][lvl-1]||2)} invocations. Their benefits are always active unless they cost a spell slot.` },
    ],
    wizard: [
      { id:'arcane_rec', name:'Arcane Recovery', max: 1, recharge:'long', icon:'',
        desc:`Once per long rest (during a short rest): recover spell slots totaling up to ${Math.ceil(lvl/2)} levels combined (no slot above 5th).` },
    ],
    artificer: [
      { id:'infusions', name:'Infuse Item', max: Math.floor(lvl/2), recharge:'long', icon:'',
        desc:`Infuse up to ${Math.floor(lvl/2)} items with magical properties from your list of known infusions. Infusions last until you die or re-infuse.` },
    ],
  };

  const entry = table[c.classId];
  if (!entry) return [];
  const resources = typeof entry === 'function' ? entry() : [...entry];

  // Add resources from multiclasses, scaled to THEIR level (not the primary class level)
  for (const mc of (c.multiclasses || [])) {
    const mcEntry = table[mc.classId];
    if (!mcEntry) continue;
    // Temporarily recalculate with mc.level as the active level
    const mcLvl = mc.level || 1;
    const mcScores = finalAbilityScores(c);
    const mcWis = abilityMod(mcScores.wis), mcCha = abilityMod(mcScores.cha);
    const mcStr = abilityMod(mcScores.str), mcCon = abilityMod(mcScores.con);
    const mcInt = abilityMod(mcScores.int);
    // Build mc-level resource table inline
    const mcTable = buildClassResourceTable(mc.classId, mcLvl, mcScores);
    const mcResources = mcTable || [];
    const mcClsName = getClass(mc.classId)?.name || mc.classId;
    mcResources.forEach(r => {
      resources.push({ ...r, id: `mc_${mc.classId}_${r.id}`, name: `${r.name} (${mcClsName})` });
    });
  }

  return resources;
}

function getRaceResources(c) {
  const lvl = c.level;
  const resources = [];

  if (c.raceId === 'dragonborn') {
    const die = lvl >= 16 ? '5d6' : lvl >= 11 ? '4d6' : lvl >= 6 ? '3d6' : '2d6';
    resources.push({ id:'breath', name:'Breath Weapon', max: 1, recharge:'short', icon:'',
      desc:`Exhale destructive energy in a 15 ft cone or 30 ft line. Each creature makes a DEX/CON save (DC ${8+proficiencyBonus(lvl)+Math.max(0,Math.floor((10-10)/2))}) or takes ${die} damage.` });
  }
  if (c.raceId === 'half-orc') {
    resources.push({ id:'relentless', name:'Relentless Endurance', max: 1, recharge:'long', icon:'',
      desc:'When reduced to 0 HP but not killed, drop to 1 HP instead. Once per long rest.' });
  }
  if (c.raceId === 'lightfoot-halfling' || c.raceId === 'stout-halfling') {
    resources.push({ id:'lucky_race', name:'Lucky', max: null, recharge: null, icon:'',
      desc:'When you roll a 1 on a d20 for an attack, check, or save, reroll and use the new result.' });
  }
  if (c.raceId === 'high-elf') {
    resources.push({ id:'elf_cantrip', name:'High Elf Cantrip', max: null, recharge: null, icon:'',
      desc:'You know one wizard cantrip (Intelligence-based) from your High Elf heritage.' });
  }
  if (c.raceId === 'hill-dwarf' || c.raceId === 'mountain-dwarf') {
    resources.push({ id:'stonecunning', name:'Stonecunning', max: null, recharge: null, icon:'',
      desc:'Whenever you make an INT (History) check about stonework, add double your proficiency bonus.' });
    resources.push({ id:'dwarven_resilience', name:'Dwarven Resilience', max: null, recharge: null, icon:'',
      desc:'Advantage on saving throws vs poison, and resistance to poison damage.' });
  }
  if (c.raceId === 'tiefling') {
    resources.push({ id:'hellish_reb', name:'Hellish Rebuke', max: 1, recharge:'long', icon:'',
      desc:'Once per long rest (at 3rd level+): cast hellish rebuke as a 2nd-level spell (reaction, target takes 3d10 fire on failed DEX save).' });
    resources.push({ id:'darkness_tief', name:'Darkness', max: 1, recharge:'long', icon:'',
      desc:'Once per long rest (at 5th level+): cast darkness. No material components.' });
  }
  if (c.raceId === 'forest-gnome') {
    resources.push({ id:'speak_beasts', name:'Speak with Beasts', max: null, recharge: null, icon:'',
      desc:'Communicate simple ideas to Small or smaller beasts. They can convey simple information back.' });
  }
  if (c.raceId === 'half-elf') {
    resources.push({ id:'skill_vers', name:'Skill Versatility', max: null, recharge: null, icon:'',
      desc:'Proficiency in two additional skills of your choice from your Half-Elf heritage.' });
  }

  return resources;
}

function renderClassResources(c) {
  const classRes = getClassResources(c);
  const raceRes  = getRaceResources(c);
  const all = [...classRes, ...raceRes];
  if (!all.length) return `<div id="class-resources"></div>`;

  if (!c.resources) c.resources = {};

  const renderResource = (r) => {
    if (r.max === null) {
      // Passive feature — just informational, no pips
      return `
        <div class="res-block res-block--passive">
          <div class="res-header">
            <span class="res-name">${r.name}</span>
            <span class="res-recharge dim" style="font-size:11px">${r.recharge ? `(${r.recharge} rest)` : 'passive'}</span>
          </div>
          <div class="res-desc">${r.desc}</div>
        </div>`;
    }

    const used = c.resources[r.id] || 0;
    const remaining = r.max - used;
    const safeId = r.id.replace(/[^a-z0-9_]/g, '');

    // Use pips for small pools (≤20), numeric input for larger ones
    const usePips = r.max <= 20;
    const pipsHtml = usePips ? `
      <div class="res-pips" id="res-card-${safeId}">
        ${Array.from({ length: r.max }, (_, i) => `
          <span class="res-pip ${i < used ? 'used' : ''}"
            data-res="${r.id}" data-idx="${i}"
            onclick="${i < used ? `App.restoreResource('${r.id}',${r.max})` : `App.spendResource('${r.id}',${r.max})`}"
            title="${i < used ? 'Click to restore' : 'Click to spend'}"></span>
        `).join('')}
      </div>` : `
      <div class="res-numeric" id="res-card-${safeId}">
        <button class="btn hp-adj" onclick="App.restoreResource('${r.id}',${r.max})">+</button>
        <input type="text" class="temp-hp-input active" value="${remaining}"
          onchange="App.setResourceVal('${r.id}', ${r.max} - parseInt(this.value||0), ${r.max})"
          title="Remaining ${r.name}" style="width:50px" />
        <button class="btn hp-adj" onclick="App.spendResource('${r.id}',${r.max})">−</button>
      </div>`;

    return `
      <div class="res-block">
        <div class="res-header">
          <span class="res-name">${r.name}</span>
          <span class="res-count-wrap">
            <span id="res-count-${r.id}" class="res-count">${remaining} / ${r.max}</span>
            <span class="res-recharge dim">${r.recharge === 'short' ? ' short' : r.recharge === 'both' ? '/ rest' : ' long'}</span>
          </span>
        </div>
        ${pipsHtml}
        <div class="res-desc">${r.desc}</div>
      </div>`;
  };

  const classHtml = classRes.length ? classRes.map(renderResource).join('') : '';
  const raceHtml  = raceRes.length  ? raceRes.map(renderResource).join('')  : '';

  return `
    <div id="class-resources" class="sheet-card">
      <h3 class="sheet-card-title">Class &amp; Race Resources</h3>
      ${classHtml}
      ${raceHtml ? `<div style="border-top:1px solid var(--border-dark);margin-top:8px;padding-top:8px">${raceHtml}</div>` : ''}
    </div>`;
}

// ============ HP Tracker ============

function renderHpTracker(c) {
  const max = computeHP(c) ?? 0;
  const cur = c.currentHp ?? max;
  const cls = getClass(c.classId);
  const die = cls ? cls.hitDie : 8;
  const hdTotal = c.level;
  const hdUsed = c.hitDiceUsed || 0;
  const hdLeft = hdTotal - hdUsed;
  const pct = max > 0 ? Math.round((cur / max) * 100) : 0;
  const barColor = pct > 50 ? '#4caf50' : pct > 25 ? '#e6a817' : 'var(--crimson)';
  const tempHp = c.tempHp || 0;

  return `
    <div id="hp-tracker" class="sheet-card">
      <h3 class="sheet-card-title">Hit Points &amp; Rests</h3>

      <div class="hp-main">
        <div class="hp-bar-wrap">
          <div class="hp-bar" style="width:${pct}%;background:${barColor}"></div>
        </div>
        <div class="hp-controls">
          <button class="btn hp-adj" onclick="App.adjustHp(-1)" title="Take 1 damage">−</button>
          <div class="hp-display">
            <input type="number" id="cur-hp-input" class="hp-input" value="${cur}"
              min="0" max="${max}"
              onblur="App.setCurrentHp(this.value)"
              onkeydown="if(event.key==='Enter'){App.setCurrentHp(this.value);this.blur()}" />
            <span class="hp-sep">/</span>
            <input type="number" id="max-hp-input" class="hp-input hp-max-input" value="${max}"
              min="1"
              title="Type to override max HP. Delete all and press Enter to reset to auto-calculated."
              onblur="App.setManualMaxHp(this.value)"
              onkeydown="if(event.key==='Enter'){App.setManualMaxHp(this.value);this.blur()}"
              style="width:56px;font-size:20px;color:${c.manualMaxHp ? 'var(--gold)' : 'var(--text-muted)'};background:transparent;border:none;border-bottom:2px solid ${c.manualMaxHp ? 'var(--gold)' : 'var(--border-dark)'};text-align:center;cursor:text" />
          </div>
          <button class="btn hp-adj" onclick="App.adjustHp(1)" title="Heal 1">+</button>
        </div>
        <div class="hp-label" style="display:flex;align-items:center;gap:8px">
          <span>Current / Max HP</span>
          ${c.manualMaxHp
            ? `<span style="color:var(--gold);font-size:10px">(manual — <a href="#" style="color:var(--gold)" onclick="event.preventDefault();App.setManualMaxHp(0)">reset to auto</a>)</span>`
            : `<span style="font-size:10px;opacity:.5">click max to override</span>`}
        </div>
      </div>

      <div class="temp-hp-row">
        <div class="temp-hp-label">
          
          <span>Temp HP</span>
        </div>
        <div class="temp-hp-controls">
          <button class="btn hp-adj" onclick="App.adjustTempHp(-1)" title="Remove 1 temp HP">−</button>
          <input type="text" class="temp-hp-input ${tempHp > 0 ? 'active' : ''}"
            value="${tempHp}"
            onchange="App.setTempHp(this.value)"
            onkeydown="if(event.key==='Enter')App.setTempHp(this.value)"
            title="Temporary hit points don't stack — take the higher value" />
          <button class="btn hp-adj" onclick="App.adjustTempHp(1)" title="Add 1 temp HP">+</button>
        </div>
      </div>

      <div class="hd-row">
        <div class="hd-info">
          <span class="hd-count">${hdLeft}<span style="font-size:13px;color:var(--text-muted)">/${hdTotal}</span></span>
          <span class="hd-label">d${die} Hit Dice</span>
        </div>
        <button class="btn btn--primary" onclick="App.spendHitDie()"
          ${cur >= max || hdLeft <= 0 ? "disabled" : ""}
          style="font-size:13px;padding:8px 14px">
          Roll Hit Die
        </button>
      </div>
      <div id="hd-msg" style="font-size:13px;color:var(--gold);min-height:18px;margin-top:4px;transition:opacity .5s;opacity:0"></div>

      <div class="rest-buttons">
        <button class="btn" onclick="App.shortRest()" style="flex:1">Short Rest</button>
        <button class="btn btn--primary" onclick="App.longRest()" style="flex:1">Long Rest</button>
      </div>

      <!-- Death Saves -->
      ${cur !== null && cur <= 0 ? `
      <div style="margin-top:12px;padding:10px;background:var(--ink-panel-2);border-radius:8px;border:2px solid var(--crimson)">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--crimson);margin-bottom:8px;font-weight:700">Death Saving Throws</div>
        <div style="display:flex;gap:20px">
          <div>
            <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">Successes</div>
            <div style="display:flex;gap:4px">
              ${[0,1,2].map(i => `<span style="width:18px;height:18px;border-radius:50%;border:2px solid #4caf50;background:${(c.deathSaves?.successes||0)>i?'#4caf50':'transparent'};cursor:pointer;display:inline-block"
                onclick="App.setDeathSave('successes',${(c.deathSaves?.successes||0)===i+1?i:i+1})"></span>`).join('')}
            </div>
          </div>
          <div>
            <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">Failures</div>
            <div style="display:flex;gap:4px">
              ${[0,1,2].map(i => `<span style="width:18px;height:18px;border-radius:50%;border:2px solid var(--crimson);background:${(c.deathSaves?.failures||0)>i?'var(--crimson)':'transparent'};cursor:pointer;display:inline-block"
                onclick="App.setDeathSave('failures',${(c.deathSaves?.failures||0)===i+1?i:i+1})"></span>`).join('')}
            </div>
          </div>
        </div>
        <div style="font-size:11px;color:var(--text-muted);margin-top:6px">3 successes = stable. 3 failures = dead. Natural 20 = regain 1 HP.</div>
      </div>` : ''}
    </div>`;
}

// ============ Spell Slot Tracker ============

function renderSpellSlotTracker(c, slotInfo) {
  const slots = c.spellSlots || {};

  if (slotInfo.type === "pact") {
    const s = slotInfo.slots[0];
    const used = slots["pact"] || 0;
    const pips = Array.from({ length: s.max }, (_, i) => `
      <span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('pact', ${i})" title="${i < used ? "Click to restore" : "Click to use"}"></span>
    `).join("");
    return `
      <div id="spell-slot-tracker" class="sheet-card">
        <h3 class="sheet-card-title">Pact Magic Slots</h3>
        <div class="slot-row">
          <span class="slot-label">Level ${s.level}</span>
          <div class="slot-pips">${pips}</div>
          <span class="slot-count">${s.max - used} / ${s.max}</span>
        </div>
        <p class="dim" style="font-size:12px;margin:8px 0 0">Pact slots recover on a short or long rest.</p>
      </div>`;
  }

  const ordinals = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th"];
  const rows = slotInfo.slots.map(s => {
    const key = String(s.level);
    const used = slots[key] || 0;
    const pips = Array.from({ length: s.max }, (_, i) => `
      <span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('${key}', ${i})" title="${i < used ? "Click to restore" : "Click to use"}"></span>
    `).join("");
    return `
      <div class="slot-row">
        <span class="slot-label">${ordinals[s.level - 1]}</span>
        <div class="slot-pips">${pips}</div>
        <span class="slot-count">${s.max - used} / ${s.max}</span>
      </div>`;
  }).join("");

  return `
    <div id="spell-slot-tracker" class="sheet-card">
      <h3 class="sheet-card-title">Spell Slots</h3>
      ${rows}
    </div>`;
}

function renderSkillsCard(c) {
  const skillData = getSkillRows(c);
  const overrides = c.skillOverrides || {};
  const ppercep = 10 + (overrides["Perception"] ?? (skillData.find(s => s.name === "Perception")?.mod || 0));

  return `<div id="skills-card" class="sheet-card">
    <h3 class="sheet-card-title">Skills <span style="font-size:10px;color:var(--text-muted);font-weight:400">— click modifier to edit</span></h3>
    <div class="prof-row" style="border-bottom:1px solid var(--border-dark);padding-bottom:8px;margin-bottom:6px;">
      <span></span><span>Passive Perception</span><span class="prof-mod">${ppercep}</span>
    </div>
    ${skillData.map(s => {
      const finalMod = overrides[s.name] !== undefined ? overrides[s.name] : s.mod;
      const isOverridden = overrides[s.name] !== undefined;
      const dotHtml = s.expertise
        ? `<span class="prof-dot on" title="Expertise — double proficiency bonus" style="outline:2px solid var(--gold);outline-offset:1px"></span>`
        : s.proficient
          ? `<span class="prof-dot on" title="Proficient"></span>`
          : s.joat
            ? `<span class="prof-dot" title="Jack of All Trades — half proficiency" style="background:rgba(201,162,39,0.25);border-color:var(--gold)"></span>`
            : `<span class="prof-dot"></span>`;
      const label = s.expertise ? ' <span style="font-size:9px;color:var(--gold);font-weight:700">EXP</span>'
                  : s.joat      ? ' <span style="font-size:9px;color:var(--text-muted)">½</span>' : '';
      const modColor = isOverridden ? "var(--gold)" : s.expertise ? "var(--gold)" : "var(--text-muted)";
      return `<div class="prof-row">
        ${dotHtml}
        <span>${s.name} <span class="dim">(${s.ability.toUpperCase()})</span>${label}</span>
        <span class="prof-mod skill-editable">
          <input type="text" class="skill-override-input ${isOverridden ? "overridden" : ""}"
            value="${fmtMod(finalMod)}"
            onchange="App.setSkillOverride('${s.name}', this.value.replace('+',''))"
            onkeydown="if(event.key==='Enter')this.blur()"
            title="${isOverridden ? "Manual override" : s.expertise ? "Expertise (double prof)" : s.joat ? "Jack of All Trades (½ prof)" : "Calculated — click to override"}"
            style="width:38px;text-align:right;background:transparent;border:none;border-bottom:1px solid ${isOverridden ? "var(--gold)" : "transparent"};color:${modColor};font-family:var(--font-mono);font-size:13px;cursor:text;" />
        </span>
      </div>`;
    }).join("")}
  </div>`;
}

// Returns the features/proficiencies granted when multiclassing INTO a class (5e rules)
function getMCLevel1Features(classId) {
  const MC_ENTRY = {
    barbarian: ['Proficiencies: shields, simple weapons, martial weapons, medium armor', 'Rage (uses = 2 at 1st), Unarmored Defense (10 + DEX + CON)'],
    bard:      ['Proficiencies: light armor, one musical instrument', 'Bardic Inspiration (d6), Spellcasting (CHA)'],
    cleric:    ['Proficiencies: light armor, medium armor, shields', 'Spellcasting (WIS)'],
    druid:     ['Proficiencies: light armor, medium armor, shields (non-metal), herbalism kit', 'Spellcasting (WIS)'],
    fighter:   ['Proficiencies: light armor, medium armor, shields, simple weapons, martial weapons', 'Second Wind (1d10+fighter level), Fighting Style'],
    monk:      ['Proficiencies: simple weapons, shortswords', 'Martial Arts (1d4 unarmed), Unarmored Defense (10 + DEX + WIS), Ki'],
    paladin:   ['Proficiencies: light armor, medium armor, shields, simple weapons, martial weapons', 'Lay on Hands (5 × paladin level HP pool), Divine Sense'],
    ranger:    ['Proficiencies: light armor, medium armor, shields, simple weapons, martial weapons', 'Favored Enemy, Natural Explorer, Spellcasting (WIS)'],
    rogue:     ['Proficiencies: light armor, simple weapons, hand crossbows, longswords, rapiers, shortswords, thieves\' tools', 'Expertise (2 skills), Sneak Attack (1d6), Thieves\' Cant'],
    sorcerer:  ['Spellcasting (CHA) — slot table is multiclass table', 'Sorcerous Origin subclass feature at 1st sorcerer level'],
    warlock:   ['Proficiencies: light armor, simple weapons', 'Pact Magic (CHA) — separate short-rest slots', 'Eldritch Invocations at warlock 2'],
    wizard:    ['Spellcasting (INT) — slot table is multiclass table', 'Arcane Recovery (recover spell slots on short rest)'],
    artificer: ['Proficiencies: light armor, medium armor, shields, thieves\' tools, tinker\'s tools', 'Magical Tinkering, Spellcasting (INT)'],
  };
  return MC_ENTRY[classId] || [`Multiclass into ${classId}: see PHB for entry features`];
}

function renderSheet() {
  const c = state.character;
  const race = getRace(c.raceId), cls = getClass(c.classId), bg = getBackground(c.backgroundId);
  const subclass = cls && cls.subclasses.find(s => s.id === c.subclassId);
  const feat = c.feat && DATA.feats.find(f => f.id === c.feat);
  const scores = finalAbilityScores(c);
  const pb = proficiencyBonus(c.level);          // total level drives proficiency bonus
  const primaryLvl = getPrimaryLevel(c);          // primary class level for class features
  const hp = computeHP(c), ac = computeAC(c);
  const initiative = abilityMod(scores.dex) + (computeFeatBonuses(c).initiative || 0);
  const speed = (race ? race.speed : 30) + (computeFeatBonuses(c).speed || 0);
  const skillRows = getSkillRows(c);
  const saves = getSavingThrows(c);
  const perception = skillRows.find(s => s.name === "Perception");
  const passivePerception = 10 + (perception ? perception.mod : 0);

  // SUBCLASS_FEATURES is now a module-scope const (defined below renderSheet) — reference it here
  const SUBCLASS_FEATURES = {
    // Barbarian
    "berserker": [
      { level: 3,  name: "Frenzy", desc: "While raging, you can go into a frenzy. You can make a single melee weapon attack as a bonus action on each turn. When your rage ends you suffer one level of exhaustion." },
      { level: 6,  name: "Mindless Rage", desc: "You can't be charmed or frightened while raging. Effects already active are suspended for the duration." },
      { level: 10, name: "Intimidating Presence", desc: "Use an action to frighten one creature within 30 ft. They make a Wisdom save (DC 8 + prof + Cha mod) or be frightened until end of your next turn. Recharges on long rest." },
      { level: 14, name: "Retaliation", desc: "When you take damage from a creature within 5 ft, you can use your reaction to make a melee weapon attack against that creature." },
    ],
    "totem-warrior": [
      { level: 3,  name: "Spirit Seeker", desc: "Cast beast sense and speak with animals as rituals." },
      { level: 3,  name: "Totem Spirit", desc: "Choose Bear (resist all damage except psychic while raging), Eagle (Dash as bonus action, enemies have disadvantage on opportunity attacks), or Wolf (allies have advantage on melee attacks against enemies adjacent to you)." },
      { level: 6,  name: "Aspect of the Beast", desc: "Bear: carry twice normal, double max load. Eagle: see up to 1 mile clearly, spot hidden creatures. Wolf: track at a fast pace without penalty, and pass through difficult terrain easily." },
      { level: 10, name: "Spirit Walker", desc: "Cast commune with nature as a ritual." },
      { level: 14, name: "Totemic Attunement", desc: "Bear: frightened creatures attack you in melee if able. Eagle: fly speed equal to walking while raging. Wolf: if you move 15 ft toward an enemy, knock them prone if they fail a Strength save." },
    ],
    // Bard
    "lore": [
      { level: 3,  name: "Bonus Proficiencies", desc: "Proficiency in three skills of your choice." },
      { level: 3,  name: "Cutting Words", desc: "Reaction to use a Bardic Inspiration die to subtract the result from a creature's attack roll, ability check, or damage roll." },
      { level: 6,  name: "Additional Magical Secrets", desc: "Learn two spells from any class spell list." },
      { level: 14, name: "Peerless Skill", desc: "When making an ability check, spend a Bardic Inspiration die and add the result to your check." },
    ],
    "valor": [
      { level: 3,  name: "Bonus Proficiencies", desc: "Proficiency with medium armor, shields, and martial weapons." },
      { level: 3,  name: "Combat Inspiration", desc: "Creatures with your Bardic Inspiration can add the die to weapon damage rolls or AC against an attack." },
      { level: 6,  name: "Extra Attack", desc: "Attack twice when you take the Attack action." },
      { level: 14, name: "Battle Magic", desc: "After casting a bard spell, you can use a bonus action to make a weapon attack." },
    ],
    // Cleric domains
    "life": [
      { level: 1,  name: "Bonus Proficiency", desc: "Heavy armor proficiency." },
      { level: 1,  name: "Disciple of Life", desc: "Your healing spells restore additional HP equal to 2 + the spell's level." },
      { level: 2,  name: "Channel Divinity: Preserve Life", desc: "Restore HP equal to 5 × cleric level among any creatures within 30 ft (up to half their HP max each)." },
      { level: 6,  name: "Blessed Healer", desc: "When you cast a healing spell on another creature, you regain HP equal to 2 + the spell's level." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 radiant damage on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Supreme Healing", desc: "Instead of rolling dice for healing spells, use the maximum number for each die." },
    ],
    "light": [
      { level: 1,  name: "Bonus Cantrip", desc: "You learn the light cantrip." },
      { level: 1,  name: "Warding Flare", desc: "When a creature attacks you, use your reaction to impose disadvantage (equal to Wis mod uses per long rest)." },
      { level: 2,  name: "Channel Divinity: Radiance of the Dawn", desc: "Dispel magical darkness within 30 ft and deal 2d10 + cleric level radiant damage to hostile creatures (Con save for half)." },
      { level: 6,  name: "Improved Flare", desc: "You can use Warding Flare to protect other creatures within 30 ft." },
      { level: 8,  name: "Potent Spellcasting", desc: "Add Wisdom modifier to cantrip damage rolls." },
      { level: 17, name: "Corona of Light", desc: "Activate as an action: 60 ft radius bright light, sunlight. Enemies have disadvantage on saves against spells dealing fire or radiant damage." },
    ],
    "knowledge": [
      { level: 1,  name: "Blessings of Knowledge", desc: "Learn two languages and proficiency in two skills from: Arcana, History, Nature, Religion (double proficiency bonus on those)." },
      { level: 2,  name: "Channel Divinity: Knowledge of the Ages", desc: "Gain proficiency in any skill or tool for 10 minutes." },
      { level: 6,  name: "Channel Divinity: Read Thoughts", desc: "Read a creature's surface thoughts (Wis save) and cast suggestion without a slot once." },
      { level: 8,  name: "Potent Spellcasting", desc: "Add Wisdom modifier to cantrip damage rolls." },
      { level: 17, name: "Visions of the Past", desc: "Spend 1 minute meditating to see visions of the recent past of an object or location." },
    ],
    "tempest": [
      { level: 1,  name: "Bonus Proficiencies", desc: "Martial weapons and heavy armor." },
      { level: 1,  name: "Wrath of the Storm", desc: "Reaction when hit by an attacker within 5 ft: deal 2d8 lightning or thunder damage (Dex save halves). Uses = Wis mod per long rest." },
      { level: 2,  name: "Channel Divinity: Destructive Wrath", desc: "Maximize lightning or thunder damage instead of rolling." },
      { level: 6,  name: "Thunderbolt Strike", desc: "When you deal lightning damage to a Large or smaller creature, push it 10 ft away." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 thunder damage on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Stormborn", desc: "Flying speed equal to walking speed when not underground or indoors." },
    ],
    "trickery": [
      { level: 1,  name: "Blessing of the Trickster", desc: "Touch a willing creature (not yourself) to give it advantage on Dexterity (Stealth) checks for 1 hour." },
      { level: 2,  name: "Channel Divinity: Invoke Duplicity", desc: "Create an illusion of yourself for 1 minute; you can cast spells as if from its space; allies get advantage when you and the illusion flank an enemy." },
      { level: 6,  name: "Channel Divinity: Cloak of Shadows", desc: "Use channel divinity to become invisible until end of next turn or you attack or cast a spell." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 poison damage on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Improved Duplicity", desc: "Create four duplicates instead of one with Invoke Duplicity; move any number of them up to 30 ft as a bonus action." },
    ],
    "war": [
      { level: 1,  name: "Bonus Proficiencies", desc: "Martial weapons and heavy armor." },
      { level: 1,  name: "War Priest", desc: "When you use the Attack action, you can make one weapon attack as a bonus action (uses = Wis mod per long rest)." },
      { level: 2,  name: "Channel Divinity: Guided Strike", desc: "Add +10 to an attack roll (after seeing the d20 but before knowing if it hits)." },
      { level: 6,  name: "Channel Divinity: War God's Blessing", desc: "Reaction to give an ally within 30 ft a +10 to their attack roll." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 damage (matching weapon type) on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Avatar of Battle", desc: "Resistance to bludgeoning, piercing, and slashing damage from nonmagical weapons." },
    ],
    "nature": [
      { level: 1,  name: "Acolyte of Nature", desc: "Learn one druid cantrip and proficiency in one of: Animal Handling, Nature, or Survival." },
      { level: 1,  name: "Bonus Proficiency", desc: "Heavy armor proficiency." },
      { level: 2,  name: "Channel Divinity: Charm Animals and Plants", desc: "Charm beasts and plant creatures within 30 ft (Wis save) for 1 minute." },
      { level: 6,  name: "Dampen Elements", desc: "Reaction when you or an ally within 30 ft takes acid, cold, fire, lightning, or thunder damage: grant resistance to the trigger damage." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 cold, fire, or lightning damage on one weapon attack per turn (2d8 at 14th level)." },
      { level: 17, name: "Master of Nature", desc: "Command charmed animals and plants as a bonus action." },
    ],
    // Druid
    "land": [
      { level: 2,  name: "Bonus Cantrip", desc: "Learn one druid cantrip of your choice." },
      { level: 2,  name: "Natural Recovery", desc: "Once per short rest, recover spell slots totaling up to half your druid level (rounded up), none above 5th level." },
      { level: 3,  name: "Circle Spells", desc: "Gain bonus spells based on your chosen terrain (arctic, coast, desert, forest, grassland, mountain, swamp, or Underdark)." },
      { level: 6,  name: "Land's Stride", desc: "Moving through nonmagical difficult terrain costs no extra movement. Advantage on saves vs plants created by magic." },
      { level: 10, name: "Nature's Ward", desc: "Immune to disease and poison; can't be charmed or frightened by elementals or fey." },
      { level: 14, name: "Nature's Sanctuary", desc: "When a beast or plant attacks you, it makes a Wis save or must choose a different target (fails = immune for 24 hours)." },
    ],
    "moon": [
      { level: 2,  name: "Combat Wild Shape", desc: "Wild Shape as a bonus action; spend spell slots while in beast form to regain HP (1d8 per slot level)." },
      { level: 2,  name: "Circle Forms", desc: "Wild Shape into beasts with CR up to 1 (CR = level/3 from 6th level) — including those with swim or fly speeds from 8th level." },
      { level: 6,  name: "Primal Strike", desc: "Beast form attacks count as magical for overcoming resistance." },
      { level: 10, name: "Elemental Wild Shape", desc: "Use two Wild Shape uses to transform into an air, earth, fire, or water elemental." },
      { level: 14, name: "Thousand Forms", desc: "Cast alter self at will." },
    ],
    // Fighter
    "champion": [
      { level: 3,  name: "Improved Critical", desc: "Weapon attacks score a critical hit on a roll of 19 or 20." },
      { level: 7,  name: "Remarkable Athlete", desc: "Add half proficiency bonus (round up) to Strength, Dexterity, or Constitution checks not already using proficiency. Running long jump distance increases by Str mod." },
      { level: 10, name: "Additional Fighting Style", desc: "Choose a second Fighting Style option." },
      { level: 15, name: "Superior Critical", desc: "Weapon attacks score a critical hit on a roll of 18–20." },
      { level: 18, name: "Survivor", desc: "At the start of your turn, regain HP equal to 5 + Con mod if you have fewer than half your max HP (as long as you have at least 1 HP)." },
    ],
    "battle-master": [
      { level: 3,  name: "Combat Superiority", desc: "Learn 3 maneuvers (4 at 7th, 5 at 10th, 6 at 15th). Gain 4 superiority dice (d8, increasing to d10 at 10th and d12 at 18th). Dice recharge on short or long rest." },
      { level: 3,  name: "Student of War", desc: "Proficiency with one artisan's tool of your choice." },
      { level: 7,  name: "Know Your Enemy", desc: "Spend 1 minute observing a creature to learn two comparative traits (Str, Dex, Con, AC, HP, class levels, or Fighter levels)." },
      { level: 15, name: "Relentless", desc: "If you have no superiority dice left when you roll initiative, regain one." },
    ],
    "eldritch-knight": [
      { level: 3,  name: "Spellcasting", desc: "Cast wizard spells (Intelligence). Learn spells from Abjuration and Evocation schools (two exceptions allowed). Spell slots recharge on long rest." },
      { level: 3,  name: "Weapon Bond", desc: "Ritual bond with up to two weapons. Bonded weapons can't be disarmed; teleport them to your hand as a bonus action." },
      { level: 7,  name: "War Magic", desc: "When you cast a cantrip, make one weapon attack as a bonus action." },
      { level: 10, name: "Eldritch Strike", desc: "When you hit with a weapon attack, the target has disadvantage on its next save against your spells until end of your next turn." },
      { level: 15, name: "Arcane Charge", desc: "When you use Action Surge, teleport up to 30 ft to an unoccupied space you can see before or after the extra action." },
      { level: 18, name: "Improved War Magic", desc: "When you use your action to cast a spell, make one weapon attack as a bonus action." },
    ],
    // Monk
    "open-hand": [
      { level: 3,  name: "Open Hand Technique", desc: "After hitting with a Flurry of Blows attack: push target 15 ft (Str save), knock prone (Dex save), or prevent reactions until start of your next turn." },
      { level: 6,  name: "Wholeness of Body", desc: "Restore HP equal to 3 × monk level as an action once per long rest." },
      { level: 11, name: "Tranquility", desc: "Cast sanctuary on yourself before each long rest. Effect lasts until you start a short or long rest." },
      { level: 17, name: "Quivering Palm", desc: "Set vibrations in a creature with an unarmed strike (3 ki). Within 30 days, use action to deal 10d10 damage or reduce to 0 HP (Con save halves; stunned instead on success). One creature at a time." },
    ],
    "shadow": [
      { level: 3,  name: "Shadow Arts", desc: "Cast darkness, darkvision, pass without trace, or silence for 2 ki (no spell slots). Also learn minor illusion." },
      { level: 6,  name: "Shadow Step", desc: "Bonus action: teleport up to 60 ft from one area of dim light or darkness to another. Advantage on first melee attack this turn." },
      { level: 11, name: "Cloak of Shadows", desc: "When in dim light or darkness, use action to become invisible. Ends on attack, casting, or bright light." },
      { level: 17, name: "Opportunist", desc: "Reaction: make an unarmed strike against a creature within 5 ft when another creature hits it with a melee attack." },
    ],
    "four-elements": [
      { level: 3,  name: "Disciple of the Elements", desc: "Learn two elemental disciplines — ki-powered abilities mimicking spells, using your monk's ki and save DC." },
      { level: 6,  name: "Additional Disciplines", desc: "Learn one more elemental discipline." },
      { level: 11, name: "Additional Disciplines", desc: "Learn one more elemental discipline. Can spend 3 ki to increase a discipline's effect when casting at 3rd level or higher." },
      { level: 17, name: "Additional Disciplines", desc: "Learn one more elemental discipline. Can spend 4 ki to increase a discipline's effect when casting at 4th level or higher." },
    ],
    // Paladin
    "devotion": [
      { level: 3,  name: "Sacred Weapon", desc: "Imbue a weapon with positive energy for 1 minute (Channel Divinity): add Cha mod to attack rolls; weapon emits bright light 20 ft, dim 20 ft." },
      { level: 3,  name: "Turn the Unholy", desc: "Channel Divinity: fiends and undead within 30 ft make a Wis save or are turned for 1 minute." },
      { level: 7,  name: "Aura of Devotion", desc: "You and friendly creatures within 10 ft can't be charmed while you are conscious (30 ft at 18th level)." },
      { level: 15, name: "Purity of Spirit", desc: "Always under effects of protection from evil and good." },
      { level: 20, name: "Holy Nimbus", desc: "Aura of sunlight (30 ft) for 1 minute: start of each enemy's turn in the aura deals 10 radiant damage; advantage on saves vs spells by fiends and undead. 1/long rest." },
    ],
    "ancients": [
      { level: 3,  name: "Nature's Wrath", desc: "Channel Divinity: conjure spectral vines to restrain a creature within 10 ft (Str or Dex save)." },
      { level: 3,  name: "Turn the Faithless", desc: "Channel Divinity: fey and fiends within 30 ft make a Wis save or are turned for 1 minute." },
      { level: 7,  name: "Aura of Warding", desc: "You and friendly creatures within 10 ft have resistance to spell damage (30 ft at 18th level)." },
      { level: 15, name: "Undying Sentinel", desc: "When you would drop to 0 HP, drop to 1 HP instead (1/long rest). Also no longer age." },
      { level: 20, name: "Elder Champion", desc: "Transform for 1 minute (1/long rest): regain 10 HP at start of each turn, spells cost 1 less action, enemies within 10 ft must use extra action to save against your paladin spells. "},
    ],
    "vengeance": [
      { level: 3,  name: "Abjure Enemy", desc: "Channel Divinity: one creature within 60 ft makes Wis save. Fiend/undead at disadvantage. On fail: frightened and speed 0 for 1 minute. On success: halved speed." },
      { level: 3,  name: "Vow of Enmity", desc: "Channel Divinity: advantage on attacks against one creature within 10 ft for 1 minute." },
      { level: 7,  name: "Relentless Avenger", desc: "When you hit with an opportunity attack, move up to half your speed immediately after (doesn't provoke opportunity attacks)." },
      { level: 15, name: "Soul of Vengeance", desc: "When a creature under your Vow of Enmity makes an attack, use your reaction to make a weapon attack against it." },
      { level: 20, name: "Avenging Angel", desc: "Transform for 1 hour (1/long rest): fly speed 60 ft; aura of menace 30 ft (Wis save or frightened, disadvantage on saves vs you until no longer frightened)." },
    ],
    // Ranger
    "hunter": [
      { level: 3,  name: "Hunter's Prey", desc: "Choose one: Colossus Slayer (+1d8 on one attack/turn vs damaged foe), Giant Killer (reaction attack against Large+ that attacks you), or Horde Breaker (attack a second adjacent creature once per turn)." },
      { level: 7,  name: "Defensive Tactics", desc: "Choose one: Escape the Horde (no opportunity attacks while moving), Multiattack Defense (+4 AC after being hit until start of next turn), Steel Will (advantage vs frightened)." },
      { level: 11, name: "Multiattack", desc: "Choose one: Volley (ranged attack against all creatures in a 10 ft radius point) or Whirlwind Attack (melee attack against each creature within reach)." },
      { level: 15, name: "Superior Hunter's Defense", desc: "Choose one: Evasion (Dex save — take no damage on success, half on fail), Stand Against the Tide (reaction to redirect a missed melee attack to another creature), or Uncanny Dodge (reaction to halve an attack's damage)." },
    ],
    "beast-master": [
      { level: 3,  name: "Ranger's Companion", desc: "Bond with a beast CR ≤ 1/4 of ranger level (min 1/4). It acts on your initiative; uses your proficiency bonus; obeys your commands." },
      { level: 7,  name: "Exceptional Training", desc: "Bonus action to command companion to Dash, Disengage, Dodge, or Help. Its attacks count as magical." },
      { level: 11, name: "Bestial Fury", desc: "Companion can make two attacks when you command it to attack." },
      { level: 15, name: "Share Spells", desc: "Spells you cast on yourself also affect your companion if it's within 30 ft." },
    ],
    // Rogue
    "thief": [
      { level: 3,  name: "Fast Hands", desc: "Use the bonus action from Cunning Action to use a Sleight of Hand check, Use an Object, or use thieves' tools." },
      { level: 3,  name: "Second-Story Work", desc: "Climbing no longer costs extra movement. Running jump distance increases by Dex mod." },
      { level: 9,  name: "Supreme Sneak", desc: "Advantage on Stealth checks when moving at half speed." },
      { level: 13, name: "Use Magic Device", desc: "Ignore class, race, and level requirements on magic items." },
      { level: 17, name: "Thief's Reflexes", desc: "Take two turns in the first round of combat; second turn at initiative − 10." },
    ],
    "assassin": [
      { level: 3,  name: "Bonus Proficiencies", desc: "Proficiency with disguise kit and poisoner's kit." },
      { level: 3,  name: "Assassinate", desc: "Advantage on attacks against creatures that haven't taken a turn yet. Any hit against a surprised creature is a critical hit." },
      { level: 9,  name: "Infiltration Expertise", desc: "Spend 7 days and 25 gp to create a false identity supported by documents." },
      { level: 13, name: "Impostor", desc: "Unerringly mimic another person's speech, writing, and behavior after studying them for 3 hours." },
      { level: 17, name: "Death Strike", desc: "On a critical hit against a surprised creature, double the damage (Con save DC 8 + Prof + Dex mod negates)." },
    ],
    "arcane-trickster": [
      { level: 3,  name: "Spellcasting", desc: "Cast wizard spells (Intelligence). Enchantment and Illusion spells only (two exceptions). Spell slots recharge on long rest." },
      { level: 3,  name: "Mage Hand Legerdemain", desc: "Enhanced Mage Hand: invisible; can stow/retrieve items from pockets, pick locks, and disarm traps remotely; contested by Perception vs Sleight of Hand." },
      { level: 9,  name: "Magical Ambush", desc: "When you cast a spell while hidden, the target has disadvantage on its saving throw." },
      { level: 13, name: "Versatile Trickster", desc: "Use bonus action to distract a creature with Mage Hand: advantage on attack rolls vs it until end of your turn." },
      { level: 17, name: "Spell Thief", desc: "Reaction after failing a save vs a spell: steal it. Caster makes an ability check vs DC 10 + spell level; on fail, you lose the spell memory but can cast it once using the caster's ability within 8 hours." },
    ],
    // Sorcerer
    "draconic": [
      { level: 1,  name: "Dragon Ancestor", desc: "Choose a dragon type; learn its language; gain advantage on Charisma checks vs dragons of that type." },
      { level: 1,  name: "Draconic Resilience", desc: "HP max increases by 1 per sorcerer level. When not wearing armor, AC = 13 + Dex mod." },
      { level: 6,  name: "Elemental Affinity", desc: "Add Cha mod to spells dealing ancestor's damage type. Spend 1 sorcery point for resistance to that type for 1 hour." },
      { level: 14, name: "Dragon Wings", desc: "Sprout dragon wings as a bonus action, gaining flying speed equal to your walking speed." },
      { level: 18, name: "Draconic Presence", desc: "Spend 5 sorcery points to radiate awe or fear (60 ft) for 1 minute: creatures in the aura make a Wis save or are charmed/frightened." },
    ],
    "wild-magic": [
      { level: 1,  name: "Wild Magic Surge", desc: "When you cast a level 1+ sorcerer spell, the DM can ask you to roll a d20. On a 1, roll on the Wild Magic Surge table." },
      { level: 1,  name: "Tides of Chaos", desc: "Gain advantage on one attack, check, or save. Recharges on long rest (or immediately after a Wild Magic Surge)." },
      { level: 6,  name: "Bend Luck", desc: "Spend 2 sorcery points (reaction) to add or subtract 1d4 from another creature's attack, check, or save." },
      { level: 14, name: "Controlled Chaos", desc: "Whenever you roll on the Wild Magic Surge table, roll twice and use either result." },
      { level: 18, name: "Spell Bombardment", desc: "Once per turn, when you roll maximum on a damage die, add another die of the same type to the damage." },
    ],
    // Warlock
    "archfey": [
      { level: 1,  name: "Fey Presence", desc: "Action (1/short rest): creatures in a 10 ft cube make a Wis save or become charmed or frightened until end of your next turn." },
      { level: 6,  name: "Misty Escape", desc: "Reaction when you take damage: turn invisible and teleport up to 60 ft. Ends at start of your next turn." },
      { level: 10, name: "Beguiling Defenses", desc: "Immune to being charmed. When a creature tries to charm you, you can use your reaction to turn the charm back on them." },
      { level: 14, name: "Dark Delirium", desc: "Action (1/short rest): charm or frighten a creature for 1 minute; each turn it thinks it's in a different location; Wis save at end of each of its turns." },
    ],
    "fiend": [
      { level: 1,  name: "Dark One's Blessing", desc: "When you reduce a hostile creature to 0 HP, gain temp HP = Cha mod + warlock level (minimum 1)." },
      { level: 6,  name: "Dark One's Own Luck", desc: "Add 1d10 to one ability check or save per short or long rest." },
      { level: 10, name: "Fiendish Resilience", desc: "Choose a damage type after a short or long rest to become resistant to it (not bludgeoning, piercing, or slashing from magical weapons)." },
      { level: 14, name: "Hurl Through Hell", desc: "When you hit a creature, send it through hell until end of your next turn: it takes 10d10 psychic damage on return. 1/long rest." },
    ],
    "great-old-one": [
      { level: 1,  name: "Awakened Mind", desc: "Telepathically communicate with any creature within 30 ft that can understand a language." },
      { level: 6,  name: "Entropic Ward", desc: "Reaction: impose disadvantage on an attack roll against you. If it misses, gain advantage on your next attack vs it. 1/short rest." },
      { level: 10, name: "Thought Shield", desc: "Others can't read your mind. Resistance to psychic damage. When you take psychic damage, the attacker takes the same amount." },
      { level: 14, name: "Create Thrall", desc: "Touch an incapacitated humanoid to charm it indefinitely (no saves). Telepathic link while on the same plane." },
    ],
    // Wizard
    "abjuration": [
      { level: 2,  name: "Abjuration Savant", desc: "Half gold and time cost to copy Abjuration spells into spellbook." },
      { level: 2,  name: "Arcane Ward", desc: "Casting an Abjuration spell creates a ward with HP = 2× wizard level + Int mod. Ward absorbs damage first; recharge by casting Abjuration spells (recharge = 2× spell level)." },
      { level: 6,  name: "Projected Ward", desc: "Reaction: Arcane Ward absorbs damage for an ally within 30 ft." },
      { level: 10, name: "Improved Abjuration", desc: "Add proficiency bonus to ability checks made as part of Abjuration spells (e.g., counterspell, dispel magic)." },
      { level: 14, name: "Spell Resistance", desc: "Advantage on saves vs spells. Resistance to spell damage." },
    ],
    "conjuration": [
      { level: 2,  name: "Conjuration Savant", desc: "Half gold and time cost to copy Conjuration spells into spellbook." },
      { level: 2,  name: "Minor Conjuration", desc: "Create a small object in an unoccupied space within 10 ft as an action. Object disappears after 1 hour or when you use this again." },
      { level: 6,  name: "Benign Transposition", desc: "Teleport up to 30 ft to an unoccupied space, or swap places with a willing Small/Medium creature. Recharges on long rest or when casting a Conjuration spell." },
      { level: 10, name: "Focused Conjuration", desc: "While concentrating on a Conjuration spell, your concentration can't be broken by taking damage." },
      { level: 14, name: "Durable Summons", desc: "Creatures you conjure gain 30 temporary hit points." },
    ],
    "divination": [
      { level: 2,  name: "Divination Savant", desc: "Half gold and time cost to copy Divination spells." },
      { level: 2,  name: "Portent", desc: "Roll two d20s after each long rest; replace any d20 roll made by you or a creature you can see with one of these results (before the roll)." },
      { level: 6,  name: "Expert Divination", desc: "When you cast a Divination spell of 2nd level or higher, regain one spent spell slot of a lower level." },
      { level: 10, name: "The Third Eye", desc: "Action (1/short rest): gain darkvision 60 ft, see the Ethereal Plane 60 ft, read any language, or see invisible creatures 10 ft." },
      { level: 14, name: "Greater Portent", desc: "Roll three d20s for Portent instead of two." },
    ],
    "enchantment": [
      { level: 2,  name: "Enchantment Savant", desc: "Half gold and time cost to copy Enchantment spells." },
      { level: 2,  name: "Hypnotic Gaze", desc: "Action: charm and incapacitate a creature within 5 ft while maintaining (Wis save). Unlimited use but requires action/concentration each turn." },
      { level: 6,  name: "Instinctive Charm", desc: "Reaction when attacked: redirect the attacker to attack the nearest other creature (Wis save negates; immune for 24 hours on success). 1/long rest vs same target." },
      { level: 10, name: "Split Enchantment", desc: "Cast a single-target Enchantment spell and target a second creature with it for free." },
      { level: 14, name: "Alter Memories", desc: "When you charm a creature with an Enchantment spell, you can make it forget the duration of the effect (Int save)." },
    ],
    "evocation": [
      { level: 2,  name: "Evocation Savant", desc: "Half gold and time cost to copy Evocation spells." },
      { level: 2,  name: "Sculpt Spells", desc: "Create pockets of safety in your Evocation spells: choose a number of creatures equal to 1 + spell level; they automatically succeed on the save and take no damage." },
      { level: 6,  name: "Potent Cantrip", desc: "Your damaging cantrips deal half damage on a successful save." },
      { level: 10, name: "Empowered Evocation", desc: "Add Intelligence modifier to damage rolls of any Evocation spell you cast." },
      { level: 14, name: "Overchannel", desc: "Deal maximum damage with a wizard Evocation spell of 5th level or lower. Each use after the first (per long rest) deals 2d12 necrotic damage to you, increasing by 2d12 per extra use." },
    ],
    "illusion": [
      { level: 2,  name: "Illusion Savant", desc: "Half gold and time cost to copy Illusion spells." },
      { level: 2,  name: "Improved Minor Illusion", desc: "Learn minor illusion (or another cantrip if already known). Can create both sound and image with a single casting." },
      { level: 6,  name: "Malleable Illusions", desc: "When concentrating on an Illusion spell, use an action to change the nature of the illusion (per the spell's allowed effects)." },
      { level: 10, name: "Illusory Self", desc: "Reaction when attacked: interpose an illusion to cause the attack to miss. Recharges on short or long rest." },
      { level: 14, name: "Illusory Reality", desc: "Once per casting: after casting an Illusion spell, make one inanimate non-damaging object in the illusion real for 1 minute." },
    ],
    "necromancy": [
      { level: 2,  name: "Necromancy Savant", desc: "Half gold and time cost to copy Necromancy spells." },
      { level: 2,  name: "Grim Harvest", desc: "When you kill a creature with a spell, regain HP equal to twice the spell's level (or 3× for Necromancy spells). Doesn't apply to undead or constructs." },
      { level: 6,  name: "Undead Thralls", desc: "Animate Dead adds one extra corpse/skeleton per casting. Undead you create gain bonus HP (= wizard level) and add your proficiency bonus to damage rolls." },
      { level: 10, name: "Inured to Undeath", desc: "Resistance to necrotic damage. Maximum HP can't be reduced." },
      { level: 14, name: "Command Undead", desc: "Action: charm an undead creature (Int save; advantage if Int ≥ 8). Mindless undead auto-fail. Lasts until you use this again or the target succeeds on its save." },
    ],
    "transmutation": [
      { level: 2,  name: "Transmutation Savant", desc: "Half gold and time cost to copy Transmutation spells." },
      { level: 2,  name: "Minor Alchemy", desc: "Transform one Small or larger non-magical object from one material into another (wood, stone, iron, copper, silver). Reverts after 1 hour or when concentration breaks." },
      { level: 6,  name: "Transmuter's Stone", desc: "Spend 8 hours creating a stone that grants one of: darkvision 60 ft, +10 speed, proficiency in Con saves, or resistance to acid/cold/fire/lightning/thunder. Only one stone at a time." },
      { level: 10, name: "Shapechanger", desc: "Cast polymorph on yourself at will without expending a spell slot; only into beast form." },
      { level: 14, name: "Master Transmuter", desc: "As an action, consume the Transmuter's Stone to choose one: major transformation, panacea (remove all curses/diseases/poisons and restore HP to max), restore life (cast raise dead without a spell slot), restore youth." },
    ],
    // Bard — Tasha's/Xanathar's
    "glamour": [
      { level: 3,  name: "Mantle of Inspiration", desc: "Bonus action: expend one Bardic Inspiration die to give allies within 60 ft temp HP (= die + CHA mod) and movement without opportunity attacks." },
      { level: 3,  name: "Enthralling Performance", desc: "Perform for 1 minute: WIS save or 1d3+CHA mod creatures are charmed for 1 hour (stunned while you're visible)." },
      { level: 6,  name: "Mantle of Majesty", desc: "Cast Command as a bonus action each turn for 1 minute (1/long rest). Creatures charmed by you auto-fail the save." },
      { level: 14, name: "Unbreakable Majesty", desc: "Bonus action: assume an unearthly appearance for 1 minute (1/short rest). Attacks against you require WIS save or redirect to another target." },
    ],
    "swords": [
      { level: 3,  name: "Bonus Proficiencies", desc: "Medium armor and scimitar proficiency." },
      { level: 3,  name: "Fighting Style", desc: "Choose Dueling or Two-Weapon Fighting." },
      { level: 3,  name: "Blade Flourish", desc: "When you take the Attack action, gain +10 speed. On hit, you can spend Bardic Inspiration to perform a Defensive, Slashing, or Mobile Flourish." },
      { level: 6,  name: "Extra Attack", desc: "Attack twice when you use the Attack action." },
      { level: 14, name: "Master's Flourish", desc: "When you use a Blade Flourish, you can roll a d6 instead of expending a Bardic Inspiration die." },
    ],
    "whispers": [
      { level: 3,  name: "Psychic Blades", desc: "Once per turn when you hit with a weapon attack, spend one Bardic Inspiration die to deal extra psychic damage = die roll." },
      { level: 3,  name: "Words of Terror", desc: "1 minute conversation: creature makes WIS save or is frightened for 1 hour (no visible trigger)." },
      { level: 6,  name: "Mantle of Whispers", desc: "Reaction when a humanoid dies within 30 ft: capture its shadow. Use it as an action to disguise yourself as that person for 1 hour." },
      { level: 14, name: "Shadow Lore", desc: "Whisper to a creature within 30 ft: WIS save (at disadvantage) or it's frightened and obedient for 8 hours, forgetting afterward." },
    ],
    "eloquence": [
      { level: 3,  name: "Silver Tongue", desc: "Minimum of 10 on Deception and Persuasion checks (after modifiers)." },
      { level: 3,  name: "Unsettling Words", desc: "Bonus action: expend a Bardic Inspiration die — one creature within 60 ft subtracts the roll from its next saving throw before your next turn." },
      { level: 6,  name: "Unfailing Inspiration", desc: "When a creature uses your Bardic Inspiration but fails, they keep the die." },
      { level: 6,  name: "Universal Speech", desc: "Spend 1 hour speaking: up to CHA mod creatures understand you in any language for 1 hour. Uses/long rest." },
      { level: 14, name: "Infectious Inspiration", desc: "Reaction when a creature succeeds using your Bardic Inspiration: give another creature (within 60 ft) a free Bardic Inspiration die." },
    ],
    "creation": [
      { level: 3,  name: "Mote of Potential", desc: "Bardic Inspiration adds bonus when used: attack rolls = advantage, saving throws = 2× rolled on a 1, skill checks = create a 5-ft effect." },
      { level: 3,  name: "Performance of Creation", desc: "Action: create one non-magical object of up to Large size (worth ≤ 20× bard level gp) for CHA mod hours. Size increases at higher levels." },
      { level: 6,  name: "Animating Performance", desc: "Animate a Large or smaller non-magical object within 30 ft for 1 hour. It obeys your commands, has stat block adjustments, and can attack." },
      { level: 14, name: "Creative Crescendo", desc: "Performance of Creation can create up to CHA mod objects simultaneously; size cap increases to Huge." },
    ],
    "spirits": [
      { level: 3,  name: "Guiding Whispers", desc: "Learn the Guidance cantrip (range 60 ft)." },
      { level: 3,  name: "Spiritual Focus", desc: "Use a candle, crystal ball, skull, spirit board, or tarokka deck as a spellcasting focus. Damage spells deal +die roll bonus damage when cast through it (2nd level+)." },
      { level: 3,  name: "Tales from Beyond", desc: "Expend one Bardic Inspiration to roll on the Spirit Tales table — roll the die to determine effect used as a bonus action." },
      { level: 6,  name: "Spirit Session", desc: "1-hour ritual (CHA mod creatures): contact spirits. You temporarily add one divination or necromancy spell (appropriate level) to your prepared spells." },
      { level: 14, name: "Mystical Connection", desc: "Roll twice when rolling on the Spirit Tales table and choose either result." },
    ],
    // Druid — Tasha's
    "spores": [
      { level: 2,  name: "Halo of Spores", desc: "Reaction when a creature you can see moves within 10 ft: deal 1d4 necrotic (CON save negates). Damage scales: 1d4→1d6→1d8→1d10 at levels 6/10/14." },
      { level: 2,  name: "Symbiotic Entity", desc: "Expend Wild Shape to awaken spores for 10 minutes: +2× druid level temp HP, Halo of Spores extra die, melee attacks deal +1d6 poison." },
      { level: 6,  name: "Fungal Infestation", desc: "Reaction when a beast or humanoid (Medium/Small) dies within 10 ft: rise it as a zombie under your control for 1 hour." },
      { level: 10, name: "Spreading Spores", desc: "Symbiotic Entity active: create a 10-ft cube of spores at 60 ft range (bonus action). Creatures entering or starting there must save or take halo damage. Concentration." },
      { level: 14, name: "Fungal Body", desc: "Immune to blinded, deafened, frightened, poisoned. Critical hits become normal hits." },
    ],
    "stars": [
      { level: 2,  name: "Star Map", desc: "Create a star map (lost/replaced with 1 hour ritual). Have Guidance cantrip; cast Guiding Bolt once per long rest without a slot." },
      { level: 2,  name: "Starry Form", desc: "Expend Wild Shape to radiate starlight for 10 minutes: choose Archer (bonus action ranged spell attack 1d8+WIS for healing), Chalice (healing spells restore 1d8+WIS extra), or Dragon (Concentration checks automatic success, starlight bonus action)." },
      { level: 6,  name: "Cosmic Omen", desc: "Long rest: roll a die — odd = Woe (reaction to give −1d6 to attack rolls and saves), even = Weal (reaction to give +1d6). Uses/long rest." },
      { level: 10, name: "Twinkling Constellations", desc: "Starry Form: all three constellation benefits simultaneously, and you can fly 20 ft as bonus action." },
      { level: 14, name: "Full of Stars", desc: "Starry Form: resistance to bludgeoning, piercing, and slashing damage; can move through other creatures/objects as difficult terrain." },
    ],
    "wildfire": [
      { level: 2,  name: "Enhanced Bond", desc: "Spells that deal fire damage or restore HP have +1d8 to their rolls when cast via wildfire spirit or through your link to it." },
      { level: 2,  name: "Summon Wildfire Spirit", desc: "Expend Wild Shape to summon a Wildfire Spirit (uses your druid level). Bonus action: teleport up to 15 ft to the spirit and back. Spirit acts on your initiative." },
      { level: 6,  name: "Cauterizing Flames", desc: "Reaction when a creature (ally or enemy) within 60 ft dies: create a ghostly flame at its space for 1 minute. You or ally can use reaction to extinguish it and heal = 2d10 + WIS mod." },
      { level: 10, name: "Blazing Revival", desc: "Wildfire spirit: if you drop to 0 HP, it can sacrifice itself — you regain half your HP, spirit disappears." },
      { level: 14, name: "Blazing Revival (Improved)", desc: "Wildfire Spirit gains immunity to fire and resistance to cold. You can resummon it for 1 spell slot of 5th or lower." },
    ],
    "shepherd": [
      { level: 2,  name: "Speech of the Woods", desc: "Speak with beasts. Learn Sylvan." },
      { level: 2,  name: "Spirit Totem", desc: "Bonus action: summon a totem for 1 minute in a 30-ft sphere. Bear = temp HP; Hawk = reaction to grant advantage on an attack; Unicorn = add WIS to healing spells." },
      { level: 6,  name: "Mighty Summoner", desc: "Beasts and fey you summon gain +2 HP per Hit Die and their attacks count as magical." },
      { level: 10, name: "Guardian Spirit", desc: "Beasts and fey you summoned regain 1d8 + 5 HP at end of their turns if within 30 ft of you." },
      { level: 14, name: "Faithful Summons", desc: "When incapacitated or dying: automatically summon 4 beasts (CR 2 or lower) that protect you until you stabilize, then disappear." },
    ],
    "dreams": [
      { level: 2,  name: "Balm of the Summer Court", desc: "Pool of d6s = druid level. Bonus action: spend up to WIS mod dice to heal a creature within 120 ft (+ restore speed for 1 turn if prone/grappled)." },
      { level: 6,  name: "Hearth of Moonlight and Shadow", desc: "Long rest in the wild: 30-ft radius sanctuary. Dim light, concealed from divination, difficult to track (CHA check vs passive Perception DC)." },
      { level: 10, name: "Hidden Paths", desc: "Bonus action (or reaction when grabbed/hit): teleport yourself or a willing creature 60 ft." },
      { level: 14, name: "Walker in Dreams", desc: "Long rest: cast Scrying, Dream, or Teleportation Circle without a slot (no material). Target must be a place or creature you know. 1/long rest." },
    ],
    // Cleric — Tasha's
    "arcana": [
      { level: 1,  name: "Arcane Initiate", desc: "Learn two wizard cantrips. Proficiency in the Arcana skill." },
      { level: 2,  name: "Channel Divinity: Arcane Abjuration", desc: "Turn celestials, elementals, fey, and fiends — same as Turn Undead. At level 5, destroy creatures with low CR." },
      { level: 6,  name: "Spell Breaker", desc: "When healing an ally with a spell, also dispel one magical effect of that spell's level or lower on them." },
      { level: 8,  name: "Potent Spellcasting", desc: "Add Wisdom modifier to cleric cantrip damage." },
      { level: 17, name: "Arcane Mastery", desc: "Learn one spell from each of the following levels not already on the cleric list: 6th, 7th, 8th, and 9th. These are always prepared." },
    ],
    "forge": [
      { level: 1,  name: "Bonus Proficiencies", desc: "Heavy armor and smith's tools proficiency." },
      { level: 1,  name: "Blessing of the Forge", desc: "Touch a nonmagical weapon or piece of armor at end of each long rest: +1 to attack/damage (weapon) or +1 AC (armor) until next long rest." },
      { level: 2,  name: "Channel Divinity: Artisan's Blessing", desc: "1-hour ritual: create one nonmagical item of metal worth up to 100 gp." },
      { level: 6,  name: "Soul of the Forge", desc: "+1 AC in heavy armor. Resistance to fire. Proficiency: smith's tools (if not already)." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 fire damage on one weapon attack per turn (2d8 at 14th)." },
      { level: 17, name: "Saint of Forge and Fire", desc: "Immune to fire. While in heavy armor: resistant to B/P/S from nonmagical attacks." },
    ],
    "grave": [
      { level: 1,  name: "Circle of Mortality", desc: "Healing cantrips on dying creatures (at 0 HP) heal maximum HP. Learn Spare the Dying cantrip (30 ft range)." },
      { level: 2,  name: "Channel Divinity: Path to the Grave", desc: "Action: curse a creature within 30 ft — next time it takes damage before your next turn, the damage is doubled." },
      { level: 6,  name: "Sentinel at Death's Door", desc: "Reaction within 30 ft: turn a crit into a normal hit. Uses = WIS mod per long rest." },
      { level: 8,  name: "Potent Spellcasting", desc: "Add Wisdom modifier to cleric cantrip damage." },
      { level: 17, name: "Keeper of Souls", desc: "Reaction when a creature dies within 60 ft: channel its life force. Heal you or an ally within 60 ft HP equal to the dead creature's Hit Dice." },
    ],
    "order": [
      { level: 1,  name: "Bonus Proficiencies", desc: "Heavy armor and Intimidation or Persuasion (choose one)." },
      { level: 1,  name: "Voice of Authority", desc: "When you cast a spell (1st level+) on an ally, they can use their reaction to make one weapon attack as a bonus action." },
      { level: 2,  name: "Channel Divinity: Order's Demand", desc: "Charm beasts and humanoids in 30 ft (WIS save). While charmed, they can't attack you, and you can choose their reactions." },
      { level: 6,  name: "Embodiment of the Law", desc: "Cast enchantment spells as a bonus action if 1st level or higher once per turn. Uses/long rest." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 psychic damage on one weapon attack per turn (2d8 at 14th)." },
      { level: 17, name: "Order's Wrath", desc: "When you use Divine Strike, and the target is cursed by your Order's Demand, deal extra 3d8 psychic damage on that attack." },
    ],
    "peace": [
      { level: 1,  name: "Implement of Peace", desc: "Proficiency in Insight, Performance, or Persuasion (choose one)." },
      { level: 1,  name: "Emboldening Bond", desc: "Bonus action: bond proficiency bonus creatures within 30 ft together for 10 minutes. Each can add 1d4 to an attack, check, or save if another bonded creature is within 30 ft." },
      { level: 2,  name: "Channel Divinity: Balm of Peace", desc: "Move up to speed without provoking OAs; heal each creature you pass within 5 ft for 2d6 + WIS mod." },
      { level: 6,  name: "Protective Bond", desc: "Bonded creatures can use their reaction when another bonded creature takes damage: halve the damage and take the other half themselves (teleporting if needed)." },
      { level: 8,  name: "Potent Spellcasting", desc: "Add Wisdom modifier to cleric cantrip damage." },
      { level: 17, name: "Expansive Bond", desc: "Emboldening Bond works at any range on the same plane. Protective Bond also grants resistance to damage before halving." },
    ],
    "twilight": [
      { level: 1,  name: "Bonus Proficiencies", desc: "Martial weapons and heavy armor." },
      { level: 1,  name: "Eyes of Night", desc: "Darkvision 300 ft. Bonus action: share with CHA mod creatures within 10 ft for 1 hour. 1/long rest (or expend spell slot)." },
      { level: 2,  name: "Channel Divinity: Twilight Sanctuary", desc: "Create a 30-ft-radius sphere of dim light for 1 minute. Allies who end their turn inside gain either temp HP (d6 + cleric level) or end the charmed or frightened condition." },
      { level: 6,  name: "Steps of Night", desc: "Bonus action in dim light or darkness: fly speed equal to walking speed for 1 minute. WIS mod uses/long rest." },
      { level: 8,  name: "Divine Strike", desc: "+1d8 radiant or necrotic damage on one weapon attack per turn (2d8 at 14th)." },
      { level: 17, name: "Twilight Shroud", desc: "Allies in your Twilight Sanctuary gain half cover (+2 AC and DEX saves)." },
    ],
    // Fighter — Xanathar's/Tasha's
    "arcane-archer": [
      { level: 3,  name: "Arcane Shot", desc: "2 uses/short rest. When you hit with a longbow or shortbow, apply one Arcane Shot option (banishing, grasping, etc.) instead of normal damage." },
      { level: 3,  name: "Magic Arrow", desc: "When you fire an arrow, make it magical for that shot (no material needed). Bypasses resistance to nonmagical attacks." },
      { level: 7,  name: "Curving Shot", desc: "Bonus action when you miss: reroll that attack against a different target within 60 ft of the original." },
      { level: 15, name: "Ever-Ready Shot", desc: "Start of each combat: if you haven't expended an Arcane Shot use, regain one." },
    ],
    "cavalier": [
      { level: 3,  name: "Bonus Proficiency", desc: "Animal Handling or one language." },
      { level: 3,  name: "Born to the Saddle", desc: "Advantage on saves to not fall off a mount; mount up as a bonus action; fall from a mount and land on your feet (if not incapacitated)." },
      { level: 3,  name: "Unwavering Mark", desc: "When you hit a creature, mark it. Until start of your next turn: it has disadvantage on attacks vs targets other than you. If it attacks someone else, you can make a bonus action melee attack vs it (+WIS mod damage)." },
      { level: 7,  name: "Warding Maneuver", desc: "Reaction when you or your mount is hit: add 1d8 to the target's AC. If it still hits, reduce the damage by 1d8 + CON mod." },
      { level: 10, name: "Hold the Line", desc: "Creatures provoke opportunity attacks from you if they move 5 ft or more within your reach. On hit: their speed = 0 for the rest of turn." },
      { level: 15, name: "Ferocious Charger", desc: "Moving 10 ft in a line and hitting: creature makes STR save or is knocked prone (1 extra attack roll of damage bonus on prone)." },
      { level: 18, name: "Vigilant Defender", desc: "Can make opportunity attacks at the start of each creature's turn (one OA per creature per round)." },
    ],
    "samurai": [
      { level: 3,  name: "Bonus Proficiency", desc: "Choose a skill (History, Insight, Performance, or Persuasion) or one language." },
      { level: 3,  name: "Fighting Spirit", desc: "Bonus action (3/long rest): advantage on all weapon attacks until end of turn + 5 temp HP (increases to 10 at level 10, 15 at level 15)." },
      { level: 7,  name: "Elegant Courtier", desc: "+WIS mod to Persuasion checks. Proficiency in WIS saves (or another save if already proficient)." },
      { level: 10, name: "Tireless Spirit", desc: "If you have no Fighting Spirit uses at start of combat, regain 1 use." },
      { level: 15, name: "Rapid Strike", desc: "Forgo advantage on one attack: make one additional attack in that action (each only on one target per attack)." },
      { level: 18, name: "Strength Before Death", desc: "Reaction when reduced to 0 HP: interrupt the turn and take a full bonus turn. HP stays at 0 until end of this bonus turn, then you fall unconscious." },
    ],
    "rune-knight": [
      { level: 3,  name: "Bonus Proficiencies", desc: "Smith's tools. Learn Giant language." },
      { level: 3,  name: "Rune Carver", desc: "Etch magical runes onto objects. Learn 2 runes at level 3 (more at higher levels). Rune options: Cloud, Stone, Hill, Storm, Fire, Frost, etc." },
      { level: 3,  name: "Giant's Might", desc: "Bonus action: grow to Large size (or larger if already Large) for 1 minute. Advantage on STR checks/saves; add 1d6 to STR melee or thrown weapon attacks. Uses = proficiency bonus/long rest." },
      { level: 7,  name: "Runic Shield", desc: "Reaction when a creature is hit within 60 ft: force the attacker to reroll and use the lower result. Uses = proficiency bonus/long rest." },
      { level: 10, name: "Great Stature", desc: "Runes increase your height by 3d4 inches. Giant's Might deals +1d8 instead of +1d6." },
      { level: 15, name: "Master of Runes", desc: "Invoke each rune twice per short or long rest (instead of once)." },
      { level: 18, name: "Runic Juggernaut", desc: "Giant's Might makes you Huge (or Gargantuan if Large). Reach increases by 5 ft. Extra 1d10 weapon damage." },
    ],
    // Monk — Xanathar's/Tasha's
    "kensei": [
      { level: 3,  name: "Path of the Kensei", desc: "Choose 2 weapons as Kensei weapons (1 melee, 1 ranged). They're monk weapons; ranged Kensei: bonus action to make your unarmed strike deal +1d4 on one hit if you made a ranged attack this turn." },
      { level: 3,  name: "Agile Parry", desc: "If you use a Kensei melee weapon for an unarmed strike, gain +2 AC until start of next turn." },
      { level: 6,  name: "Kensei's Shot", desc: "Bonus action: ranged attacks deal +1d4 damage until end of turn." },
      { level: 6,  name: "One with the Blade", desc: "Kensei weapons count as magical. Spend 1 Ki when hitting: +1d6 damage." },
      { level: 11, name: "Sharpen the Blade", desc: "Bonus action: spend 1–3 Ki for +1/2/3 bonus to attack and damage with Kensei weapon for 1 minute." },
      { level: 17, name: "Unerring Accuracy", desc: "Once per turn when you miss with a monk weapon attack, reroll." },
    ],
    "sun-soul": [
      { level: 3,  name: "Radiant Sun Bolt", desc: "Ranged spell attack (30/60 ft) dealing 1d4 + DEX/STR radiant damage. Spend 1 Ki as a bonus action to make two radiant sun bolts." },
      { level: 6,  name: "Searing Arc Strike", desc: "Spend 2–5 Ki after attacking: cast Burning Hands at 1st level + 1 level per extra Ki." },
      { level: 11, name: "Searing Sunburst", desc: "Action: create a 20-ft radius burst of radiance (60 ft range). CON save or take 2d6 radiant. Spend 1–3 Ki for +2d6 per point." },
      { level: 17, name: "Sun Shield", desc: "Bright light sheds from you 30 ft (dim 30 ft further). Reaction when hit in melee: deal 5 + WIS mod radiant damage." },
    ],
    "long-death": [
      { level: 3,  name: "Touch of Death", desc: "When you reduce a creature to 0 HP with a melee attack, gain temp HP = your monk level + WIS mod." },
      { level: 6,  name: "Hour of Reaping", desc: "Action: frighten all creatures within 30 ft (WIS save)." },
      { level: 11, name: "Mastery of Death", desc: "When reduced to 0 HP, spend 1 Ki to drop to 1 HP instead." },
      { level: 17, name: "Touch of the Long Death", desc: "Action: touch a creature and spend 1–10 Ki. WIS save or take 2d10 necrotic per Ki spent (half on success)." },
    ],
    "drunken-master": [
      { level: 3,  name: "Bonus Proficiency", desc: "Performance. Proficiency with brewer's supplies." },
      { level: 3,  name: "Drunken Technique", desc: "Flurry of Blows grants Disengage. Move an extra 10 ft when you use Flurry of Blows." },
      { level: 6,  name: "Tipsy Sway", desc: "Leap to Your Feet: standing from prone costs 5 ft instead of half speed. Redirect Attack (reaction 1 Ki): when missed by melee, redirect attacker to hit another target." },
      { level: 11, name: "Drunkard's Luck", desc: "When you make a check, save, or attack — if you have no advantages/disadvantages — spend 2 Ki to gain advantage." },
      { level: 17, name: "Intoxicated Frenzy", desc: "Flurry of Blows: make up to 3 additional attacks (5 total), each against a different target." },
    ],
    // Paladin — Tasha's
    "watchers": [
      { level: 3,  name: "Abjure the Extraplanar", desc: "Channel Divinity: turn aberrations, celestials, elementals, fey, and fiends within 30 ft (WIS save)." },
      { level: 3,  name: "Watcher's Will", desc: "Channel Divinity: advantage on INT, WIS, and CHA saves for you and friendly creatures within 30 ft for 1 minute." },
      { level: 7,  name: "Aura of the Sentinel", desc: "You and friendly creatures within 10 ft gain bonus to initiative = your WIS modifier (extends to 30 ft at level 18)." },
      { level: 15, name: "Vigilant Rebuke", desc: "Reaction when you or a creature you can see succeeds on an INT, WIS, or CHA save: deal 2d8+CHA mod force damage to the creature that caused the save." },
      { level: 20, name: "Mortal Bulwark", desc: "1/long rest, 1 minute: truesight 120 ft; advantage on attacks vs aberrations, celestials, elementals, fey, fiends; banish them on hit (CHA save)." },
    ],
    // Ranger — Tasha's/Xanathar's
    "swarmkeeper": [
      { level: 3,  name: "Gathered Swarm", desc: "Swarm surrounds you. Once per turn when you hit: choose one effect — deal 1d6 piercing damage, push target 15 ft (STR save), move you 5 ft toward or away from the target." },
      { level: 7,  name: "Writhing Tide", desc: "Bonus action: swarm carries you — fly 10 ft per turn for 1 minute. WIS mod/long rest." },
      { level: 11, name: "Mighty Swarm", desc: "Gathered Swarm damage increases to 1d8. Push distance increases to 20 ft. When carried by Writhing Tide, you have half cover." },
      { level: 15, name: "Swarming Dispersal", desc: "Reaction when you take damage: become invisible and teleport up to 30 ft. Swarm distracts attackers. 1/short rest." },
    ],
    "drakewarden": [
      { level: 3,  name: "Draconic Gift", desc: "Learn Draconic. Learn the Thaumaturgy cantrip." },
      { level: 3,  name: "Drake Companion", desc: "Bond with a drake (Intelligence 5). It uses your proficiency bonus; acts on your initiative; gains HP scaling with ranger level. Choose acid, cold, fire, lightning, or poison damage type." },
      { level: 7,  name: "Bond of Fang and Scale", desc: "Drake grows to Large. You can ride it. Drake gains resistance to its damage type. Drake deals an extra 1d6 of its type on hit." },
      { level: 11, name: "Drake's Breath", desc: "Action (or command drake): breathe weapon — 30 ft cone or 60 ft line, 8d6 damage (DEX save half). 1/long rest or spend 3rd+ spell slot." },
      { level: 15, name: "Perfected Bond", desc: "Drake becomes Huge. Its attacks are magical. Reaction when you're hit: drake uses its reaction to make an attack against your attacker." },
    ],
    "horizon-walker": [
      { level: 3,  name: "Detect Portal", desc: "Detect portals within 1 mile (concentration, 1 minute). 1/short rest." },
      { level: 3,  name: "Planar Warrior", desc: "Bonus action: choose target within 30 ft — your next hit against it this turn deals +1d8 force damage (instead of weapon type). Doubles to 2d8 at level 11." },
      { level: 7,  name: "Ethereal Step", desc: "Bonus action: cast Etherealness on yourself until start of next turn. 1/short rest." },
      { level: 11, name: "Distant Strike", desc: "Attack action: teleport 10 ft before each attack. If you attack two different creatures, make one extra attack against a third." },
      { level: 15, name: "Spectral Defense", desc: "Reaction when hit: resistance to all damage for that attack." },
    ],
    "monster-slayer": [
      { level: 3,  name: "Hunter's Sense", desc: "Action: learn creature's immunities, resistances, and vulnerabilities within 60 ft. WIS mod/long rest." },
      { level: 3,  name: "Slayer's Prey", desc: "Bonus action: mark a creature. Once per turn extra 1d6 damage against it with attacks. Changes on next bonus action." },
      { level: 7,  name: "Supernatural Defense", desc: "When a marked creature forces you to make a save or to grapple check, add 1d6." },
      { level: 11, name: "Magic-User's Nemesis", desc: "Reaction when a creature within 60 ft casts a spell or teleports: prevent it (WIS save). 1/short rest." },
      { level: 15, name: "Slayer's Counter", desc: "Reaction when Slayer's Prey target forces you to save: make one attack against it. If the attack hits, auto-succeed on the save." },
    ],
    // Rogue — Xanathar's  
    "scout": [
      { level: 3,  name: "Skirmisher", desc: "Reaction when a creature ends its turn within 5 ft: move up to half speed without provoking opportunity attacks." },
      { level: 3,  name: "Survivalist", desc: "Proficiency (or double if already proficient) in Nature and Survival." },
      { level: 9,  name: "Superior Mobility", desc: "+10 ft walking, climbing, and swimming speed." },
      { level: 13, name: "Ambush Master", desc: "Advantage on initiative rolls. On first turn of combat, allies who attack targets within 5 ft of you gain advantage." },
      { level: 17, name: "Sudden Strike", desc: "When you take the Attack action, make one extra attack as a bonus action. Sneak Attack can apply to this attack even if you already Sneak Attacked this turn (a different target)." },
    ],
    // Sorcerer — Xanathar's
    "divine-soul": [
      { level: 1,  name: "Divine Magic", desc: "Access the cleric spell list in addition to the sorcerer list. Choose an affinity (Good/Evil/Law/Chaos/Neutrality) — learn a bonus spell and gain a passive benefit." },
      { level: 1,  name: "Favored by the Gods", desc: "Reaction when you fail a saving throw or miss an attack: add 2d4 to the roll. 1/short rest." },
      { level: 6,  name: "Empowered Healing", desc: "When you or an ally within 5 ft rolls dice to heal with a spell, spend 1 Sorcery Point to reroll any number of dice (once per spell)." },
      { level: 14, name: "Otherworldly Wings", desc: "Bonus action: sprout feathered or bat wings — fly speed = walking speed. Can be dismissed as a bonus action." },
      { level: 18, name: "Unearthly Recovery", desc: "Bonus action when below half HP: regain HP equal to half your max HP. 1/long rest." },
    ],
    "shadow-magic": [
      { level: 1,  name: "Eyes of the Dark", desc: "Darkvision 120 ft. Spend 1 Sorcery Point: cast Darkness (can see through your own Darkness)." },
      { level: 1,  name: "Strength of the Grave", desc: "Reaction when reduced to 0 HP by damage: make CON save (DC = 5 + damage dealt). On success, drop to 1 HP instead. Radiant damage fails automatically. 1/long rest." },
      { level: 6,  name: "Hound of Ill Omen", desc: "Spend 3 Sorcery Points: summon a shadow hound targeting one creature within 120 ft. Target has disadvantage on saves vs your spells. Hound can move and attack." },
      { level: 14, name: "Shadow Walk", desc: "Bonus action in dim light or darkness: teleport up to 120 ft to another dim/dark space you can see." },
      { level: 18, name: "Umbral Form", desc: "Spend 6 Sorcery Points: become a shadow for 1 minute — resistance to all non-force/radiant damage, move through objects, immune to light." },
    ],
    // Warlock — Tasha's/Xanathar's
    "fathomless": [
      { level: 1,  name: "Tentacle of the Deeps", desc: "Bonus action: conjure a 10-ft tentacle (CHA mod/long rest) for 1 minute: reaction attack for 1d8 cold + slow 10 ft (STR save)." },
      { level: 1,  name: "Gift of the Sea", desc: "Breathe underwater. Swimming speed 40 ft." },
      { level: 6,  name: "Oceanic Soul", desc: "Resistance to cold. Underwater creatures understand you telepathically." },
      { level: 6,  name: "Guardian Coil", desc: "Tentacle of the Deeps reaction: reduce damage to you or an ally within 10 ft by 1d8." },
      { level: 10, name: "Grasping Tentacles", desc: "Cast Evard's Black Tentacles freely 1/long rest. While concentration is maintained, add your CHA mod to your AC." },
      { level: 14, name: "Fathomless Plunge", desc: "Action: teleport up to 8 willing creatures within 30 ft to an unoccupied space on any plane you know. 1/short rest." },
    ],
    // Wizard — Tasha's/Xanathar's
    "bladesinging": [
      { level: 2,  name: "Training in War and Song", desc: "Light armor proficiency and one one-handed melee weapon proficiency. Learn the Performance skill." },
      { level: 2,  name: "Bladesong", desc: "Bonus action (2/short rest): Bladesong for 1 minute — +INT mod to AC; walking speed +10; advantage on Acrobatics; concentration checks have +INT mod bonus." },
      { level: 6,  name: "Extra Attack", desc: "Attack twice when you use the Attack action. Can substitute one attack for a cantrip." },
      { level: 10, name: "Song of Defense", desc: "Reaction when hit while Bladesong is active: expend a spell slot to reduce damage by 5 per slot level." },
      { level: 14, name: "Song of Victory", desc: "While Bladesong is active: +INT mod to melee weapon attack damage." },
    ],
    "war-magic": [
      { level: 2,  name: "Arcane Deflection", desc: "Reaction when hit or fail a save: gain +2 AC for that attack or +4 to the save. Until end of next turn, only cantrips." },
      { level: 2,  name: "Tactical Wit", desc: "Add INT modifier to initiative rolls." },
      { level: 6,  name: "Power Surge", desc: "Store power surges (max INT mod). When you cast Counterspell or Dispel Magic, store a surge. When you deal damage with a wizard spell, spend a surge for extra damage = half your wizard level." },
      { level: 10, name: "Durable Magic", desc: "+2 AC and all saves while maintaining concentration." },
      { level: 14, name: "Deflecting Shroud", desc: "Arcane Deflection releases a burst: 1d6 × half your wizard level force damage to up to 3 creatures within 60 ft." },
    ],
    "order-of-scribes": [
      { level: 2,  name: "Wizardly Quill", desc: "Bonus action: conjure a magical quill. Write twice as fast. Copying spells costs half the usual time. Can erase your quill's writing with a gesture." },
      { level: 2,  name: "Awakened Spellbook", desc: "Your spellbook gains sentience. Ritual spells take no extra time. When you cast spells using slots, switch the damage type to match a different spell in your book (1/turn)." },
      { level: 6,  name: "Manifest Mind", desc: "Bonus action: project your spellbook as a mind-manifestation within 300 ft. You can cast spells from its position. Concentration spells still originate from you." },
      { level: 10, name: "Master Scrivener", desc: "Long rest: create a spell scroll of a 1st or 2nd level spell from your book. It's a free action to use, and only you can cast it." },
      { level: 14, name: "One with the Word", desc: "When you take damage while Manifest Mind is active: reduce damage by 2× spell level (expunge that spell from your book until long rest). 1/long rest." },
    ],
  };

  // Make SUBCLASS_FEATURES available to pdf-export.js
  window._SUBCLASS_FEATURES = SUBCLASS_FEATURES;

  const featuresList = [
    ...(race ? race.traits : []),
    ...(bg ? [bg.feature] : []),
    ...(feat ? [`${feat.name}: ${feat.summary}`] : []),
    // Multiclass entries with all entry features
    ...((c.multiclasses || []).map(mc => {
      const mCls = getClass(mc.classId);
      const mSub = mc.subclassId ? mCls?.subclasses?.find(s => s.id === mc.subclassId) : null;
      const mcFeatures = getMCLevel1Features(mc.classId);
      const lines = [`Multiclass: ${mCls?.name || mc.classId} ${mc.level}${mSub ? ` — ${mSub.name}` : ''}`];
      lines.push(...mcFeatures.map(f => `  [${mCls?.name}] ${f}`));
      return lines;
    })).flat(),
  ];

  // Feat sub-choices shown in features — collect all, deduplicate by feat
  const featChoiceLines = (() => {
    const fc = c.featChoices || {};
    const lines = [];
    const shownFeats = new Set(); // prevent duplicates

    function addFeatLines(featId, fChoices, label) {
      if (shownFeats.has(featId + label)) return;
      shownFeats.add(featId + label);
      const prefix = label ? `${label}: ` : '';
      if (featId === 'magic-initiate' && fChoices.mi_class) {
        lines.push(`${prefix}Magic Initiate (${fChoices.mi_class}) — cantrips: ${(fChoices.mi_cantrips||[]).join(', ')||'none chosen'}; spell: ${fChoices.mi_spell||'none chosen'}`);
      } else if (featId === 'eldritch-adept' && fChoices.invocation) {
        lines.push(`${prefix}Eldritch Invocation: ${fChoices.invocation.split('—')[0].trim()}`);
      } else if (featId === 'resilient' && fChoices.res_ability)  {
        lines.push(`${prefix}Resilient: +1 ${ABILITY_NAMES[fChoices.res_ability]}, proficiency in ${ABILITY_NAMES[fChoices.res_ability]} saves`);
      } else if (featId === 'skilled' && fChoices.skilled_picks?.length) {
        lines.push(`${prefix}Skilled: proficient in ${fChoices.skilled_picks.join(', ')}`);
      } else if (featId === 'observant' && fChoices.obs_ability) {
        lines.push(`${prefix}Observant: +1 ${ABILITY_NAMES[fChoices.obs_ability]}`);
      } else if (featId === 'ritual-caster' && fChoices.rc_class) {
        lines.push(`${prefix}Ritual Caster (${fChoices.rc_class}): ritual spellbook`);
      } else if (featId === 'fey-touched') {
        const ab = fChoices.fey_ability ? `+1 ${ABILITY_NAMES[fChoices.fey_ability]}; ` : '';
        lines.push(`${prefix}Fey Touched: ${ab}Misty Step + ${fChoices.fey_spell||'?'} 1/long rest`);
      } else if (featId === 'shadow-touched') {
        const ab = fChoices.shadow_ability ? `+1 ${ABILITY_NAMES[fChoices.shadow_ability]}; ` : '';
        lines.push(`${prefix}Shadow Touched: ${ab}Invisibility + ${fChoices.shadow_spell||'?'} 1/long rest`);
      } else if (featId === 'telekinetic' && fChoices.tk_ability) {
        lines.push(`${prefix}Telekinetic: +1 ${ABILITY_NAMES[fChoices.tk_ability]}, enhanced Mage Hand`);
      } else if (featId === 'telepathic' && fChoices.tp_ability) {
        lines.push(`${prefix}Telepathic: +1 ${ABILITY_NAMES[fChoices.tp_ability]}, 60 ft telepathy`);
      } else if (featId === 'metamagic-adept' && fChoices.metamagics?.length) {
        lines.push(`${prefix}Metamagic Adept: ${fChoices.metamagics.join(', ')}`);
      } else if (featId === 'martial-adept' && fChoices.adept_maneuvers?.length) {
        lines.push(`${prefix}Martial Adept: ${fChoices.adept_maneuvers.join(', ')}`);
      } else if (featId === 'elemental-adept' && fChoices.element_type) {
        lines.push(`${prefix}Elemental Adept: ${fChoices.element_type}`);
      } else if (featId === 'spell-sniper' && fChoices.sniper_cantrip) {
        lines.push(`${prefix}Spell Sniper cantrip: ${fChoices.sniper_cantrip}`);
      } else if (featId === 'aberrant-dragonmark') {
        const cant = fChoices.ab_dmark_cantrip || '?';
        const sp = fChoices.ab_dmark_spell || '?';
        lines.push(`${prefix}Aberrant Dragonmark: +1 CON, cantrip: ${cant}, spell: ${sp}`);
      } else if (featId && !['alert','lucky','tough','mobile','sentinel','polearm-master','great-weapon-master','sharpshooter','dual-wielder','war-caster','charger','savage-attacker'].includes(featId)) {
        const f = DATA.feats.find(f => f.id === featId);
        if (f) lines.push(`${prefix}${f.name}: ${f.summary.slice(0,70)}${f.summary.length>70?'…':''}`);
      }
    }

    // Legacy single feat
    if (feat) addFeatLines(feat.id, fc, null);

    // All ASI slot feats
    for (const [slotKey, choice] of Object.entries(c.asiChoices || {})) {
      if (choice?.type === 'feat' && choice.featId) {
        const slotFeat = DATA.feats.find(f => f.id === choice.featId);
        const label = slotKey.startsWith('vh') ? `Racial Feat (${slotFeat?.name||choice.featId})` : `Level ${slotKey} Feat (${slotFeat?.name||choice.featId})`;
        addFeatLines(choice.featId, choice.featChoices || {}, label);
      }
    }

    return lines;
  })();

  // Subclass choices shown in features
  const subclassChoiceLines = (() => {
    const sc = c.subclassChoices || {};
    const lines = [];
    if (sc.totem_spirit) lines.push(`Totem Spirit: ${sc.totem_spirit.charAt(0).toUpperCase()+sc.totem_spirit.slice(1)}`);
    if (sc.totem_aspect) lines.push(`Aspect of the Beast: ${sc.totem_aspect.charAt(0).toUpperCase()+sc.totem_aspect.slice(1)}`);
    if (sc.land_terrain) lines.push(`Circle of the Land: ${sc.land_terrain.charAt(0).toUpperCase()+sc.land_terrain.slice(1)}`);
    if (sc.dragon_type) lines.push(`Dragon Ancestor: ${sc.dragon_type.charAt(0).toUpperCase()+sc.dragon_type.slice(1)}`);
    if (sc.hunter_prey) lines.push(`Hunter's Prey: ${sc.hunter_prey}`);
    if (sc.hunter_defense) lines.push(`Defensive Tactics: ${sc.hunter_defense}`);
    if (sc.hunter_multi) lines.push(`Multiattack: ${sc.hunter_multi}`);
    if (sc.nature_skill?.length) lines.push(`Nature Domain skill: ${sc.nature_skill.join(", ")}`);
    if (sc.nature_cantrip) lines.push(`Acolyte of Nature cantrip: ${sc.nature_cantrip}`);
    if (sc.know_skills?.length) lines.push(`Knowledge Domain expertise: ${sc.know_skills.join(", ")}`);
    if (sc.lore_skills?.length) lines.push(`Lore College bonus skills: ${sc.lore_skills.join(", ")}`);
    if (sc.bm_maneuver1) lines.push(`Maneuver: ${sc.bm_maneuver1}, ${sc.bm_maneuver2||"?"}, ${sc.bm_maneuver3||"?"}`);
    if (sc.beast_name) lines.push(`Animal Companion: ${sc.beast_name} (CR ${sc.beast_cr||"1/4"})`);
    return lines;
  })();

  // Magical Secrets — show on sheet with spell names
  const magicalSecretsLine = (() => {
    const ms = c.featChoices?.magical_secrets || [];
    if (!ms.length || c.classId !== "bard") return null;
    return `Magical Secrets: ${ms.join(", ")}`;
  })();

  // Subclass features — rich grouped display
  const subclassFeatures = (() => {
    if (!subclass) return "";
    const builtIn = SUBCLASS_FEATURES[subclass.id];
    const available = builtIn ? builtIn.filter(f => f.level <= primaryLvl) : [];

    return `
      <div style="margin-top:12px">
        <h4 class="sheet-subhead" style="margin-top:0">${subclass.name}</h4>
        ${available.length ? available.map(f => `
          <div class="feature-block">
            <div class="feature-name">${f.name} <span class="dim" style="font-size:11px;font-weight:400">(level ${f.level})</span></div>
            <div class="feature-desc">${f.desc}</div>
          </div>`).join("") : `<p class="dim" style="font-size:13px">Feature details not available — refer to your sourcebook.</p>`}
      </div>`;
  })();

  const extraFeatures = [...featChoiceLines, ...subclassChoiceLines, ...(magicalSecretsLine ? [magicalSecretsLine] : [])];

  const featuresSection = `
    <div class="sheet-card">
      <h3 class="sheet-card-title">Features &amp; Traits</h3>
      ${featuresList.length ? `<ul class="sheet-list" style="margin-bottom:${subclassFeatures||extraFeatures.length ? "14px" : "0"}">${featuresList.map(t => `<li>${t}</li>`).join("")}</ul>` : ""}
      ${extraFeatures.length ? `<ul class="sheet-list" style="margin-bottom:${subclassFeatures ? "14px" : "0"}">${extraFeatures.map(t => `<li style="color:var(--gold)">${t}</li>`).join("")}</ul>` : ""}
      ${subclassFeatures}

      <!-- Multiclass subclass features -->
      ${(c.multiclasses || []).filter(mc => mc.subclassId).map(mc => {
        const mCls = getClass(mc.classId);
        const mSub = mCls?.subclasses?.find(s => s.id === mc.subclassId);
        const builtInMC = SUBCLASS_FEATURES[mc.subclassId];
        const availMC = builtInMC ? builtInMC.filter(f => f.level <= mc.level) : [];
        if (!availMC.length) return '';
        return `<div style="margin-top:16px">
          <div style="font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--gold);margin-bottom:8px">${mCls?.name} — ${mSub?.name || mc.subclassId}</div>
          ${availMC.map(f => `<div class="feature-entry"><div class="feature-name">${f.name}</div><div class="feature-desc">${f.desc}</div></div>`).join('')}
        </div>`;
      }).join('')}
      ${!featuresList.length && !subclassFeatures && !extraFeatures.length ? `<p class="dim">None recorded.</p>` : ""}
    </div>`;

  // ── Weapon attack computation ─────────────────────────────
  const strMod = abilityMod(scores.str);
  const dexMod = abilityMod(scores.dex);

  // Gather all weapons from the data library for lookup
  const weaponLib = DATA.equipment?.weapons || [];

  // Build a list of weapons the character is carrying, parsed from all gear sources
  const allGearText = [
    ...(cls ? cls.startingEquipment : []),
    ...(bg ? bg.equipment : []),
    c.extraGear || "",
  ].join(", ").toLowerCase();

  // Collect proficient weapon categories
  const profWeapons = (cls?.weaponProficiencies || []).map(p => p.toLowerCase());
  function isProficientWith(weapon) {
    const cat = (weapon.category || "").toLowerCase();
    const name = (weapon.name || "").toLowerCase();
    return profWeapons.some(p =>
      p.includes("simple") && cat.includes("simple") ||
      p.includes("martial") && cat.includes("martial") ||
      p === name
    );
  }

  // Match weapons from gear text against weapon library
  const equippedWeapons = weaponLib.filter(w =>
    allGearText.includes(w.name.toLowerCase())
  );

  function weaponAttackBonus(weapon) {
    const props = (weapon.properties || []).map(p => p.toLowerCase());
    const isRanged = weapon.category?.toLowerCase().includes("ranged");
    const isFinesse = props.some(p => p.includes("finesse"));
    const prof = isProficientWith(weapon) ? pb : 0;
    let abilityMd;
    if (isFinesse) abilityMd = Math.max(strMod, dexMod);
    else if (isRanged) abilityMd = dexMod;
    else abilityMd = strMod;
    return { bonus: prof + abilityMd, abilityMod: abilityMd, prof };
  }

  function weaponDamage(weapon) {
    const props = (weapon.properties || []).map(p => p.toLowerCase());
    const isRanged = weapon.category?.toLowerCase().includes("ranged");
    const isFinesse = props.some(p => p.includes("finesse"));
    let abilityMd;
    if (isFinesse) abilityMd = Math.max(strMod, dexMod);
    else if (isRanged) abilityMd = dexMod;
    else abilityMd = strMod;
    const modStr = abilityMd !== 0 ? ` ${fmtMod(abilityMd)}` : "";
    return `${weapon.damage}${modStr}`;
  }

  const weaponSection = `
    <div class="sheet-card">
      <h3 class="sheet-card-title">Equipment &amp; Weapons</h3>
      ${equippedWeapons.length ? `
        <div class="weapon-table">
          <div class="weapon-header">
            <span>Weapon</span><span>Attack</span><span>Damage</span><span>Type</span>
          </div>
          ${equippedWeapons.map(w => {
            const { bonus } = weaponAttackBonus(w);
            const props = (w.properties || []).map(p => p.toLowerCase());
            const isVersatile = props.find(p => p.startsWith("versatile"));
            const versatileDmg = isVersatile ? isVersatile.match(/\(([^)]+)\)/)?.[1] : null;
            const dmgType = w.damage?.split(" ").slice(1).join(" ") || "";
            const dmgDice = w.damage?.split(" ")[0] || "";
            const abilityMd = weaponAttackBonus(w).abilityMod;
            const modStr = abilityMd !== 0 ? ` ${fmtMod(abilityMd)}` : "";
            return `
              <div class="weapon-row">
                <span class="weapon-name">
                  ${w.name}
                  ${isProficientWith(w) ? '<span class="wpn-badge prof">Prof</span>' : '<span class="wpn-badge">No Prof</span>'}
                </span>
                <span class="weapon-atk">${fmtMod(bonus)}</span>
                <span class="weapon-dmg">${dmgDice}${modStr}${versatileDmg ? ` <span class="dim">(${versatileDmg}${modStr} 2H)</span>` : ""}</span>
                <span class="weapon-type dim">${dmgType}</span>
              </div>`;
          }).join("")}
        </div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:10px">
          Weapons detected from your gear. Add weapons in the Edit step under "Additional Gear."
        </div>
      ` : `<p class="dim" style="font-size:13px;margin:0 0 10px">No weapons detected. Add them in Edit → Equipment (e.g. "Longsword, Dagger").</p>`}
      ${[
        ...(cls ? cls.startingEquipment : []),
        ...(bg ? bg.equipment : []),
        ...(c.armorId ? [`Armor: ${c.armorId}`] : []),
        ...(c.shield ? ["Shield (+2 AC)"] : []),
        ...(c.extraGear ? [c.extraGear] : []),
      ].length ? `
        <h4 class="sheet-subhead">All Gear</h4>
        <ul class="sheet-list">
          ${[
            ...(cls ? cls.startingEquipment : []),
            ...(bg ? bg.equipment : []),
            ...(c.armorId ? [`Armor: ${c.armorId}`] : []),
            ...(c.shield ? ["Shield (+2 AC)"] : []),
            ...(c.extraGear ? [c.extraGear] : []),
          ].map(t => `<li>${t}</li>`).join("")}
        </ul>` : ""}
    </div>`;

  // Fallback spellcasting ability per class for when PDF import didn't capture it
  const CASTER_ABILITY = {
    bard: "cha", cleric: "wis", druid: "wis", paladin: "cha",
    ranger: "wis", sorcerer: "cha", warlock: "cha", wizard: "int",
    artificer: "int",
  };

  const spellSection = (() => {
    const slotInfo = getEffectiveSpellSlots(c);
    const castingClasses = getCastingClasses(c);
    const mainCaster = castingClasses[0] || null;
    const scAbility = mainCaster ? mainCaster.ability
                    : (cls?.spellcasting?.ability || CASTER_ABILITY[c.classId] || null);
    const isCaster = !!(slotInfo || scAbility);
    if (!isCaster) return "";

    const abMod = scAbility ? abilityMod(scores[scAbility]) : 0;
    const saveDC = 8 + pb + abMod;
    const atkBonus = pb + abMod;

    // With more than one casting class each has its own DC / attack bonus
    const perClassDC = castingClasses.length > 1
      ? castingClasses.map(e => {
          const m = abilityMod(scores[e.ability]);
          const nm = getClass(e.classId)?.name || e.classId;
          return `${nm} (${e.ability.toUpperCase()}): DC ${8 + pb + m}, atk ${fmtMod(pb + m)}`;
        }).join(' &nbsp;·&nbsp; ')
      : '';

    // Action type filter (stored in character temp state — not persisted)
    const castFilter = c._castFilter || 'all'; // 'all' | 'action' | 'bonus' | 'reaction'

    // Merge all spell sources into one unified list
    const bonusNames = getChosenBonusSpellNames(c);
    const allChosenSpellNames = new Set([
      ...c.cantrips,
      ...c.spellsKnown,
      ...bonusNames,
    ]);

    // Separate chosen spells into cantrips and leveled, applying cast filter
    const allSpellData = DATA.spells.filter(s => allChosenSpellNames.has(s.name));
    const filterFn = s => castFilter === 'all' || (s.castingTime || 'action') === castFilter;
    const cantrips = allSpellData.filter(s => s.level === 0 && filterFn(s));
    const known = allSpellData.filter(s => s.level >= 1 && filterFn(s)).sort((a,b) => a.level - b.level || a.name.localeCompare(b.name));

    // Tag sources for display — build a map from spell name to source label
    const spellSourceMap = new Map();
    getBonusSpellPool(c).forEach(entry => {
      const label = entry.source;
      if (entry.automatic) {
        spellSourceMap.set(entry.name, label);
      } else {
        const chosen = c.featChoices?.[entry.key];
        const arr = Array.isArray(chosen) ? chosen : (chosen ? [chosen] : []);
        arr.forEach(n => { if (!spellSourceMap.has(n)) spellSourceMap.set(n, label); });
      }
    });

    function spellTag(s) {
      const src = spellSourceMap.get(s.name);
      const srcBadge = src ? (() => {
        const color = src.includes('Magical Secrets') ? 'var(--gold)'
                    : src.includes('Magic Initiate') ? '#81d4fa'
                    : src.includes('Patron') || src.includes('Oath') || src.includes('Domain') || src.includes('Circle') ? '#ce93d8'
                    : src.includes('Ritual') ? '#a5d6a7'
                    : '#a89fc0';
        return ` <span style="font-size:10px;color:${color};border:1px solid ${color};border-radius:4px;padding:0 4px">${src}</span>`;
      })() : '';
      const ctColor = s.castingTime === 'bonus' ? '#ffd54f' : s.castingTime === 'reaction' ? '#ef9a9a' : '';
      const ctBadge = s.castingTime && s.castingTime !== 'action'
        ? ` <span style="font-size:10px;color:${ctColor};border:1px solid ${ctColor};border-radius:4px;padding:0 4px">${s.castingTime === 'bonus' ? 'Bonus Action' : 'Reaction'}</span>`
        : '';
      return srcBadge + ctBadge;
    }

    // Slot tracker rows rendered inline inside the card
    const slotsHtml = (() => {
      if (!slotInfo) return "";
      const slots = c.spellSlots || {};
      const ordinals = ["1st","2nd","3rd","4th","5th","6th","7th","8th","9th"];
      if (slotInfo.type === "pact") {
        const s = slotInfo.slots[0];
        const used = slots["pact"] || 0;
        const pips = Array.from({ length: s.max }, (_, i) =>
          `<span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('pact',${i})" title="${i < used ? "Restore slot" : "Use slot"}"></span>`
        ).join("");
        // Spells castable with pact slots
        const pactSpells = [...known].filter(sp => sp.level <= s.level);
        return `
          <div style="margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--border-dark)">
            <div style="font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--text-muted);margin-bottom:8px">Pact Magic Slots (level ${s.level}) · short/long rest</div>
            <div class="slot-row">
              <span class="slot-label" style="font-weight:600;color:var(--text-light)">Lvl ${s.level}</span>
              <div class="slot-pips">${pips}</div>
              <span class="slot-count" style="font-size:14px;font-weight:700;color:var(--gold)">${s.max - used} / ${s.max}</span>
            </div>
            ${pactSpells.length ? `<div style="font-size:11px;color:var(--text-muted);margin-top:6px">Castable: ${pactSpells.map(sp=>`<span style="color:var(--text-light)">${sp.name}</span>`).join(", ")}</div>` : ""}
          </div>`;
      }

      // Group known spells by level for cross-referencing
      const spellsByLevel = {};
      [...known, ...cantrips].forEach(sp => {
        if (!spellsByLevel[sp.level]) spellsByLevel[sp.level] = [];
        spellsByLevel[sp.level].push(sp);
      });

      return `
        <div style="margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--border-dark)">
          <div style="font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:var(--text-muted);margin-bottom:10px">Spell Slots · long rest</div>
          ${slotInfo.slots.map(s => {
            const key = String(s.level);
            const used = slots[key] || 0;
            const remaining = s.max - used;
            const pips = Array.from({ length: s.max }, (_, i) =>
              `<span class="slot-pip ${i < used ? "used" : ""}" onclick="App.toggleSlot('${key}',${i})" title="${i < used ? "Click to restore" : "Click to use"}"></span>`
            ).join("");
            // Spells the character knows at exactly this level
            const spellsAtLevel = spellsByLevel[s.level] || [];
            return `
              <div class="slot-row" style="align-items:flex-start;padding:6px 0">
                <span class="slot-label" style="font-weight:600;color:var(--text-light);min-width:40px;padding-top:2px">${ordinals[s.level - 1]}</span>
                <div style="flex:1">
                  <div style="display:flex;align-items:center;gap:8px;margin-bottom:${spellsAtLevel.length ? "5px" : "0"}">
                    <div class="slot-pips">${pips}</div>
                    <span class="slot-count" style="font-size:14px;font-weight:700;color:${remaining > 0 ? "var(--gold)" : "var(--crimson)"}">
                      ${remaining} / ${s.max}
                    </span>
                  </div>
                  ${spellsAtLevel.length ? `<div style="font-size:11px;color:var(--text-muted);line-height:1.6">
                    ${spellsAtLevel.map(sp => `<span style="color:var(--text-light)">${sp.name}</span>${spellTag(sp)}`).join(" · ")}
                  </div>` : `<div style="font-size:11px;color:var(--text-muted);font-style:italic">No spells known at this level yet</div>`}
                </div>
              </div>`;
          }).join("")}
        </div>`;
    })();

    return `
      <div class="sheet-card" id="spell-slot-tracker">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:8px">
          <h3 class="sheet-card-title" style="margin:0">Spellcasting</h3>
          <div style="display:flex;gap:4px">
            ${['all','action','bonus','reaction'].map(f => `
              <button class="btn" style="font-size:11px;padding:3px 8px;${castFilter===f?'background:var(--gold);color:var(--dark);border-color:var(--gold)':''}"
                onclick="App.setCastFilter('${f}')">
                ${f === 'all' ? 'All' : f === 'bonus' ? 'Bonus' : f.charAt(0).toUpperCase()+f.slice(1)}
              </button>`).join('')}
          </div>
        </div>
        <div class="spell-meta-row" style="margin-bottom:12px">
          <div><span class="sheet-label">Ability</span><span class="sheet-value">${scAbility ? ABILITY_NAMES[scAbility] : "—"}</span></div>
          <div><span class="sheet-label">Save DC</span><span class="sheet-value">${saveDC}</span></div>
          <div><span class="sheet-label">Atk Bonus</span><span class="sheet-value">${fmtMod(atkBonus)}</span></div>
        </div>
        ${perClassDC ? `<div style="font-size:11px;color:var(--text-muted);margin:-6px 0 10px">${perClassDC}</div>` : ''}
        <div style="display:none">
        </div>
        ${slotsHtml}
        ${cantrips.length ? `<h4 class="sheet-subhead">Cantrips</h4><ul class="sheet-list">${cantrips.map(s => `<li><strong>${s.name}</strong>${spellTag(s)} <span class="dim">— ${s.summary}</span></li>`).join("")}</ul>` : ""}
        ${!slotInfo && known.length ? `<h4 class="sheet-subhead">Spells Known / Prepared</h4><ul class="sheet-list">${known.map(s => `<li><strong>${s.name}</strong>${spellTag(s)} <span class="dim">(Lvl ${s.level}) — ${s.summary}</span></li>`).join("")}</ul>` : ""}
        ${(() => {
          // Show ritual spells available to this character (known/prepared that are rituals)
          const ritualSpells = [...cantrips, ...known].filter(s => s.ritual);
          if (!ritualSpells.length) return "";
          return `<h4 class="sheet-subhead" style="color:#a5d6a7">Rituals Available</h4>
            <p style="font-size:11px;color:var(--text-muted);margin:-4px 0 6px">These spells can be cast as rituals — 10 extra minutes, no spell slot consumed.</p>
            <ul class="sheet-list">${ritualSpells.map(s => `<li><strong>${s.name}</strong>${spellTag(s)} <span class="dim">(Lvl ${s.level}) — ${s.summary}</span></li>`).join("")}</ul>`;
        })()}
      </div>`;
  })();

  return `
    <div class="sheet">
      <div class="sheet-toolbar">
        <button class="btn" onclick="Router.go('list')">&larr; Back to Characters</button>
        <div style="display:flex;gap:10px">
          <button class="btn" onclick="ExportPDF.export()" title="Download as PDF">⬇ Export PDF</button>
          <button class="btn btn--levelup" onclick="Router.go('levelup', ${state.editingId})" title="Gain a level">⬆ Level Up</button>
          <button class="btn btn--primary" onclick="Router.go('edit', ${state.editingId})">Edit Character</button>
        </div>
      </div>

      <div class="sheet-banner">
        <div class="sheet-avatar">${(c.name || "?").trim().charAt(0).toUpperCase()}</div>
        <div class="sheet-banner-text">
          <h1>${escapeHtml(c.name) || "Unnamed"}</h1>
          <div class="sheet-subtitle">
            Level ${c.level} ${race ? race.name : "—"} ${getClassLevelString(c)}${subclass ? ` (${subclass.name})` : ""}
          </div>
          <div class="sheet-subtitle dim">${bg ? bg.name : "No background"}</div>
        </div>
      </div>

      <div class="sheet-vitals">
        <div class="vital-box vital-box--interactive">
          <span class="vital-num" id="vital-ac">${computeAC(c) + (c.tempAc || 0)}${(c.tempAc || 0) > 0 ? `<span style="font-size:12px;color:#81d4fa;display:block;line-height:1.2">+${c.tempAc} bonus</span>` : ""}</span>
          <span class="vital-label">Armor Class</span>
          <div class="vital-mini-controls">
            <button class="vital-adj" onclick="App.adjustTempAc(-1)" title="Remove AC bonus">−</button>
            <span class="vital-adj-label">tmp AC</span>
            <button class="vital-adj" onclick="App.adjustTempAc(1)" title="Add AC bonus">+</button>
          </div>
        </div>
        <div class="vital-box">
          <span class="vital-num" id="vital-hp" style="font-size:18px">
            ${c.currentHp ?? hp ?? "—"}<span style="font-size:13px;color:#888">/${hp ?? "—"}</span>
            ${(c.tempHp || 0) > 0 ? `<span style="font-size:12px;color:#64b5f6;display:block;line-height:1.2">+${c.tempHp} tmp HP</span>` : ""}
          </span>
          <span class="vital-label">Hit Points</span>
        </div>
        <div class="vital-box" style="flex:2;text-align:left">
          <span class="vital-num" style="font-size:14px">${getClassLevelString(c)}</span>
          <span class="vital-label">Class / Level</span>
        </div>
        <div class="vital-box"><span class="vital-num">${fmtMod(initiative)}</span><span class="vital-label">Initiative</span></div>
        <div class="vital-box"><span class="vital-num">${speed}</span><span class="vital-label">Speed</span></div>
        <div class="vital-box"><span class="vital-num">${cls ? `d${cls.hitDie}` : "—"}</span><span class="vital-label">Hit Die</span></div>
        <div class="vital-box"><span class="vital-num">${fmtMod(pb)}</span><span class="vital-label">Proficiency</span></div>
      </div>

      <div class="sheet-grid">

        <!-- Col 1: Ability Scores / Saves / Skills -->
        <div class="sheet-col">
          <div class="sheet-card">
            <h3 class="sheet-card-title">Ability Scores</h3>
            <div class="ability-hex-grid">
              ${ABILITIES.map(a => `
                <div class="ability-hex">
                  <div class="hex-ability">${a.toUpperCase()}</div>
                  <div class="hex-mod">${fmtMod(abilityMod(scores[a]))}</div>
                  <div class="hex-score">${scores[a]}</div>
                </div>`).join("")}
            </div>
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">Saving Throws</h3>
            ${saves.map(s => `
              <div class="prof-row">
                <span class="prof-dot ${s.proficient ? "on" : ""}"></span>
                <span>${ABILITY_NAMES[s.ability]}</span>
                <span class="prof-mod">${fmtMod(s.mod)}</span>
              </div>`).join("")}
          </div>

          ${renderSkillsCard(c)}
        </div>

        <!-- Col 2: HP / Class Resources / Equipment & Weapons -->
        <div class="sheet-col sheet-col--mid">
          ${renderHpTracker(c)}
          ${renderClassResources(c)}
          ${weaponSection}
        </div>

        <!-- Col 3: Spellcasting / Features / Notes -->
        <div class="sheet-col sheet-col--right">
          ${spellSection}
          ${featuresSection}
          ${c.notes ? `
          <div class="sheet-card">
            <h3 class="sheet-card-title">Notes</h3>
            <p>${escapeHtml(c.notes)}</p>
          </div>` : ""}
        </div>

      </div>
    </div>`;
}

// ============ PDF Import Page ============

function renderImportPage() {
  return `
    <div class="import-page">
      <div class="import-header">
        <h1>Import Source Material</h1>
        <p class="subtitle">Load PDFs from your computer — all processing happens locally in your browser. No internet, no API key, nothing leaves your machine. Select as many PDFs as you like at once.</p>
      </div>

      <div class="import-grid">
        <div class="import-upload-panel">
          <div class="sheet-card" style="margin-bottom:16px">
            <h3 class="sheet-card-title">🔒 100% Local Processing</h3>
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:24px">✅</span>
              <div>
                <strong style="color:#4caf50">Ready — no setup needed</strong>
                <div class="dim" style="font-size:12px;margin-top:2px">PDF text is extracted in your browser using Mozilla's pdf.js. Parsed data is saved to your local server only.</div>
              </div>
            </div>
          </div>

          <div class="sheet-card">
            <h3 class="sheet-card-title">📄 Load PDFs</h3>
            <div class="drop-zone" id="dropZone"
              ondragover="event.preventDefault(); this.classList.add('drag-over')"
              ondragleave="this.classList.remove('drag-over')"
              ondrop="ImportPage.handleDrop(event)">
              <div class="drop-icon">⬆</div>
              <div>Drag &amp; drop PDFs here</div>
              <div style="color:var(--text-muted);font-size:13px;margin:6px 0">or</div>
              <button class="btn" onclick="document.getElementById('pdfInput').click()">Browse files</button>
              <input type="file" id="pdfInput" accept=".pdf" multiple style="display:none" onchange="ImportPage.handleFileSelect(this)" />
            </div>
            <div id="fileQueue" style="margin-top:10px;display:flex;flex-direction:column;gap:6px;"></div>
            <button class="btn btn--primary" style="width:100%;margin-top:12px" id="importBtn" onclick="ImportPage.runImport()" disabled>
              Extract &amp; Import All
            </button>
          </div>

          <div id="importStatus" style="margin-top:16px"></div>

          <div class="sheet-card" style="margin-top:16px">
            <h3 class="sheet-card-title">i What gets extracted</h3>
            <p class="dim" style="font-size:13px;margin:0">The parser recognises D&amp;D 5e formatting to pull out races, classes &amp; subclasses, backgrounds, feats, and spells. Results vary by PDF quality — digital-native PDFs extract best. Scanned/image PDFs won't work. Review the library after import and remove anything garbled.</p>
          </div>
        </div>

        <div>
          <div class="sheet-card">
            <h3 class="sheet-card-title"> Imported Content Library</h3>
            <p style="font-size:13px;color:var(--text-muted);margin-top:0">Everything below is available in the character creator. Click × to remove an entry.</p>
            <div id="libraryContent"><p class="dim">Loading…</p></div>
          </div>
        </div>
      </div>
    </div>`;
}

const ImportPage = {
  _files: [],   // array of File objects

  async loadLibrary() {
    const el = document.getElementById('libraryContent');
    if (!el) return;
    try {
      const lib = await (await fetch('/api/import/library')).json();
      const types = ['races','classes','backgrounds','feats','spells'];
      const sections = types.map(type => {
        const items = lib[type] || [];
        if (!items.length) return '';
        return `
          <div style="margin-bottom:14px">
            <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--gold);margin-bottom:6px">${type} (${items.length})</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px">
              ${items.map(it => `
                <span class="tag" style="display:inline-flex;align-items:center;gap:4px">
                  ${escapeHtml(it.name)}
                  <span style="cursor:pointer;color:var(--crimson);font-size:12px" onclick="ImportPage.remove('${type}', '${escapeHtml(it.id || it.name)}')">×</span>
                </span>`).join('')}
            </div>
          </div>`;
      }).filter(Boolean).join('');
      const eqItems = lib.equipment || [];
      const eqSection = eqItems.length ? `
        <div>
          <div style="font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--gold);margin-bottom:6px">equipment (${eqItems.length})</div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${eqItems.map(it => `<span class="tag">${escapeHtml(it.name)}</span>`).join('')}
          </div>
        </div>` : '';
      el.innerHTML = sections + eqSection || '<p class="dim">No custom content imported yet.</p>';
    } catch (e) {
      el.innerHTML = '<p class="dim">Could not load library.</p>';
    }
  },

  handleDrop(e) {
    e.preventDefault();
    document.getElementById('dropZone').classList.remove('drag-over');
    const files = [...e.dataTransfer.files].filter(f => f.type === 'application/pdf');
    if (!files.length) { this._globalStatus('error', 'Only PDF files are supported.'); return; }
    this._addFiles(files);
  },

  handleFileSelect(input) {
    const files = [...input.files];
    if (files.length) this._addFiles(files);
    input.value = ''; // reset so same file can be re-added if needed
  },

  _addFiles(newFiles) {
    // Deduplicate by name
    const existing = new Set(this._files.map(f => f.name));
    const toAdd = newFiles.filter(f => !existing.has(f.name));
    this._files.push(...toAdd);
    this._renderQueue();
    document.getElementById('importBtn').disabled = this._files.length === 0;
  },

  removeFile(name) {
    this._files = this._files.filter(f => f.name !== name);
    this._renderQueue();
    document.getElementById('importBtn').disabled = this._files.length === 0;
  },

  _renderQueue() {
    const el = document.getElementById('fileQueue');
    if (!el) return;
    if (!this._files.length) { el.innerHTML = ''; return; }
    el.innerHTML = this._files.map(f => `
      <div class="queue-row" id="qrow-${CSS.escape(f.name)}">
        <span class="queue-icon">📄</span>
        <span class="queue-name">${escapeHtml(f.name)}</span>
        <span class="queue-size">${(f.size / 1024 / 1024).toFixed(1)} MB</span>
        <span class="queue-status" id="qstatus-${CSS.escape(f.name)}"></span>
        <button class="queue-remove" onclick="ImportPage.removeFile('${escapeHtml(f.name)}')" title="Remove">×</button>
      </div>`).join('');
  },

  _setRowStatus(name, html) {
    const el = document.getElementById(`qstatus-${CSS.escape(name)}`);
    if (el) el.innerHTML = html;
  },

  async runImport() {
    if (!this._files.length) return;

    // Load parser once
    if (!window.DnDPDFParser) {
      this._globalStatus('info', '⏳ Loading pdf.js library…');
      await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = '/pdf-parser.js';
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      });
    }

    const btn = document.getElementById('importBtn');
    btn.disabled = true;

    const totals = { added: {}, updated: {} };
    let succeeded = 0, failed = 0;

    // Process sequentially so we don't flood memory with huge PDFs
    for (const file of this._files) {
      this._setRowStatus(file.name, '<span style="color:var(--gold)">⏳ reading…</span>');
      btn.textContent = `Processing ${succeeded + failed + 1} / ${this._files.length}…`;

      try {
        const result = await window.DnDPDFParser.extractDnDContent(
          file,
          (stage, cur, total) => {
            const msgs = { loading:'loading…', reading:`page ${cur}/${total}`, parsing:'parsing…', done:'saving…' };
            this._setRowStatus(file.name, `<span style="color:var(--gold)">⏳ ${msgs[stage] || stage}</span>`);
          }
        );

        const res = await fetch('/api/import/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(result),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Save failed');

        // Accumulate totals
        for (const type of ['races','classes','backgrounds','feats','spells']) {
          totals.added[type] = (totals.added[type] || 0) + (data.counts.added[type] || 0);
          totals.updated[type] = (totals.updated[type] || 0) + (data.counts.updated[type] || 0);
        }

        const addedCount = Object.values(data.counts.added || {}).reduce((s, v) => s + (v || 0), 0);
        this._setRowStatus(file.name, `<span style="color:#4caf50">✅ +${addedCount} items</span>`);
        succeeded++;
      } catch (err) {
        this._setRowStatus(file.name, `<span style="color:var(--crimson)" title="${escapeHtml(err.message)}">❌ failed</span>`);
        failed++;
      }
    }

    btn.textContent = 'Extract & Import All';
    btn.disabled = false;

    // Summary
    const lines = [];
    for (const type of ['races','classes','backgrounds','feats','spells']) {
      const a = totals.added[type] || 0, u = totals.updated[type] || 0;
      if (a || u) lines.push(`${type}: +${a} new, ${u} updated`);
    }
    const summaryColor = failed === 0 ? '#4caf50' : succeeded === 0 ? 'var(--crimson)' : 'var(--gold)';
    this._globalStatus(failed === 0 ? 'success' : 'info', `
      <strong style="color:${summaryColor}">
        ${succeeded === this._files.length ? '✅ All done' : `✅ ${succeeded} done, ❌ ${failed} failed`}
      </strong><br>
      ${lines.join('<br>') || 'No new content found across these PDFs.'}
    `);

    DATA = await api.getData();
    this.loadLibrary();
  },

  _globalStatus(type, html) {
    const el = document.getElementById('importStatus');
    if (!el) return;
    const borderColor = type === 'error' ? 'var(--crimson)' : type === 'success' ? '#4caf50' : 'var(--border-dark)';
    el.innerHTML = `<div style="padding:14px;border-radius:var(--radius);background:var(--ink-panel);border:1px solid ${borderColor};">${html}</div>`;
  },

  async remove(type, id) {
    if (!confirm(`Remove "${id}" from the custom library?`)) return;
    await fetch(`/api/import/library/${type}/${encodeURIComponent(id)}`, { method: 'DELETE' });
    DATA = await api.getData();
    this.loadLibrary();
  },
};

window.ImportPage = ImportPage;

// ============ Boot ============
(async function init() {
  DATA = await api.getData();
  Router.go("list");
})();
