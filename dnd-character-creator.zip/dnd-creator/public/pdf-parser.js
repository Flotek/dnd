// ============================================================
// D&D 5e PDF Parser — runs entirely in the browser using pdf.js
// No data leaves the machine. No API key needed.
// ============================================================

const PDFJS_VERSION = '3.11.174';
const PDFJS_CDN = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_VERSION}`;

let pdfjsLib = null;

async function loadPdfJs() {
  if (pdfjsLib) return pdfjsLib;
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = `${PDFJS_CDN}/pdf.min.js`;
    script.onload = () => {
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = `${PDFJS_CDN}/pdf.worker.min.js`;
      pdfjsLib = window.pdfjsLib;
      resolve(pdfjsLib);
    };
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

// ── Text extraction ────────────────────────────────────────
async function extractTextFromPDF(file, onProgress) {
  const lib = await loadPdfJs();
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await lib.getDocument({ data: arrayBuffer }).promise;
  const totalPages = pdf.numPages;
  const pages = [];

  for (let i = 1; i <= totalPages; i++) {
    if (onProgress) onProgress(i, totalPages);
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    // Join items preserving rough layout — items on same Y get joined, new Y = newline
    let lastY = null;
    let line = [];
    const lines = [];
    for (const item of content.items) {
      const y = Math.round(item.transform[5]);
      if (lastY !== null && Math.abs(y - lastY) > 2) {
        if (line.length) lines.push(line.join(' ').trim());
        line = [];
      }
      line.push(item.str);
      lastY = y;
    }
    if (line.length) lines.push(line.join(' ').trim());
    pages.push(lines.filter(l => l.length > 0));
  }

  return pages;
}

// ── Utility helpers ────────────────────────────────────────
function slugify(str) {
  return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

function joinPages(pages) {
  return pages.map(p => p.join('\n')).join('\n');
}

// ── Pattern constants ──────────────────────────────────────
const ABILITY_NAMES_LIST = ['Strength', 'Dexterity', 'Constitution', 'Intelligence', 'Wisdom', 'Charisma'];
const ABILITY_SHORT = { strength: 'str', dexterity: 'dex', constitution: 'con', intelligence: 'int', wisdom: 'wis', charisma: 'cha' };
const SPELL_SCHOOLS = ['Abjuration', 'Conjuration', 'Divination', 'Enchantment', 'Evocation', 'Illusion', 'Necromancy', 'Transmutation'];
const CLASS_NAMES = ['Artificer', 'Barbarian', 'Bard', 'Blood Hunter', 'Cleric', 'Druid', 'Fighter', 'Monk', 'Paladin', 'Ranger', 'Rogue', 'Sorcerer', 'Warlock', 'Wizard'];
const SKILL_NAMES = ['Acrobatics', 'Animal Handling', 'Arcana', 'Athletics', 'Deception', 'History', 'Insight', 'Intimidation', 'Investigation', 'Medicine', 'Nature', 'Perception', 'Performance', 'Persuasion', 'Religion', 'Sleight of Hand', 'Stealth', 'Survival'];

// ── Race parser ────────────────────────────────────────────
function parseRaces(text) {
  const races = [];
  // Match race blocks: look for "X Traits" or "X Features" headers followed by trait list
  const raceBlockRe = /^([A-Z][a-zA-Z ,'\-]+)\n(?:[\s\S]*?)(?=Ability Score Increase\.)([\s\S]*?)(?=\n(?:[A-Z][A-Z\s]{4,}|Chapter|\f))/gm;

  // Simpler approach: find "Ability Score Increase." blocks and work backwards/forwards
  const asiRe = /([^\n]{2,60})\n[\s\S]{0,400}?Ability Score Increase\.([\s\S]{0,1200}?)(?=\n[A-Z][A-Z\s]{5,}|\n\n[A-Z][a-z]|\Z)/g;

  let match;
  const seen = new Set();

  // Look for racial trait blocks more directly
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // Look for "Ability Score Increase." line
    if (/^Ability Score Increase\./.test(line)) {
      // Try to find the race name by looking backward for a short header
      let raceName = '';
      for (let j = i - 1; j >= Math.max(0, i - 8); j--) {
        const prev = lines[j].trim();
        if (prev && prev.length < 50 && /^[A-Z]/.test(prev) && !/[.:]$/.test(prev) && !/^(As a|Your|You|The|This|In|At)/.test(prev)) {
          raceName = prev;
          break;
        }
      }
      if (!raceName || seen.has(raceName)) continue;
      seen.add(raceName);

      // Collect the block of traits
      const blockLines = [];
      for (let k = i; k < Math.min(lines.length, i + 60); k++) {
        const bl = lines[k].trim();
        // Stop if we hit another major header
        if (k > i + 2 && /^[A-Z][A-Z\s]{6,}$/.test(bl)) break;
        blockLines.push(bl);
      }
      const block = blockLines.join('\n');

      const race = {
        id: slugify(raceName),
        name: raceName,
        size: 'Medium',
        speed: 30,
        abilityBonuses: {},
        traits: [],
        languages: ['Common'],
      };

      // Parse ability bonuses
      const asiLine = block.match(/Ability Score Increase\.\s*([^.]+\.)/);
      if (asiLine) {
        const asiText = asiLine[1];
        const bonusMatches = asiText.matchAll(/(\+\d+)\s+(?:to\s+)?(?:your\s+)?([A-Za-z]+)(?:\s+score)?/g);
        for (const bm of bonusMatches) {
          const bonus = parseInt(bm[1]);
          const ability = ABILITY_SHORT[bm[2].toLowerCase()];
          if (ability) race.abilityBonuses[ability] = bonus;
        }
        // "increases by 2" / "increases by 1" pattern
        const incMatches = asiText.matchAll(/([A-Z][a-z]+)(?:\s+score)?\s+(?:score\s+)?increases?\s+by\s+(\d+)/gi);
        for (const im of incMatches) {
          const ability = ABILITY_SHORT[im[1].toLowerCase()];
          if (ability) race.abilityBonuses[ability] = parseInt(im[2]);
        }
      }

      // Speed
      const speedMatch = block.match(/Speed\.\s*(?:Your\s+)?(?:base\s+)?(?:walking\s+)?speed\s+is\s+(\d+)/i);
      if (speedMatch) race.speed = parseInt(speedMatch[1]);

      // Size
      if (/Size\.\s*(?:You are\s+)?Small/i.test(block)) race.size = 'Small';
      else if (/Size\.\s*(?:You are\s+)?Large/i.test(block)) race.size = 'Large';

      // Traits — find "TraitName. Description" patterns
      const traitRe = /^([A-Z][a-zA-Z ,']+)\.\s+(.{10,200})/gm;
      let tm;
      while ((tm = traitRe.exec(block)) !== null) {
        const name = tm[1].trim();
        const desc = tm[2].trim();
        if (['Ability Score Increase', 'Age', 'Alignment', 'Size', 'Speed', 'Languages'].includes(name)) continue;
        race.traits.push(`${name}: ${desc}`);
      }

      // Languages
      const langMatch = block.match(/Languages\.\s*([^.]+\.)/i);
      if (langMatch) {
        const langs = langMatch[1].match(/[A-Z][a-z]+/g) || [];
        race.languages = langs.filter(l => l !== 'You' && l !== 'Your' && l.length > 2);
        if (!race.languages.includes('Common')) race.languages.unshift('Common');
      }

      if (race.id && race.traits.length > 0) races.push(race);
    }
  }

  return races;
}

// ── Subclass parser ────────────────────────────────────────
function parseSubclasses(text) {
  // Returns { className: [{ id, name }] }
  const result = {};

  // Patterns like "Oath of X", "Path of X", "School of X", "Way of X", "Circle of X",
  // "College of X", "Domain", "Patron", "Origin", "Archetype", "Bloodline"
  const subclassHeaderRe = /^((?:Oath|Path|School|Way|Circle|College|Order|Domain|Pact of|Aspect of|Subschool|Tradition|Scion|Monastic Tradition|Sacred Oath|Divine Domain|Otherworldly Patron|Sorcerous Origin|Roguish Archetype|Martial Archetype|Primal Path|Druidic Circle|Bard College|Ranger Archetype|Arcane Tradition|Warlock Patron|Fighter|Paladin|Ranger|Rogue|Monk|Sorcerer|Warlock|Barbarian|Druid|Wizard|Cleric|Bard)\s+(?:of\s+)?(?:the\s+)?[A-Z][a-zA-Z ,'\-]+)/gm;

  // Simpler: look for "X Archetype", "X Tradition", etc. then find the parent class
  const subRe = /^([A-Z][a-zA-Z ,'\-]{4,60})\n[\s\S]{0,300}?(?:subclass|archetype|tradition|oath|path|circle|college|patron|origin)\s+(?:for|of|option)?\s+(?:the\s+)?([a-zA-Z]+)/gim;

  // Most reliable: find class-level feature tables and subclass names within them
  // Look for "Subclass Feature" or similar, or "X features" tables
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    // Look for patterns like "Arcane Tradition" or "Oath of Devotion" as standalone headers
    const subMatch = line.match(/^((?:Oath|Path|School|Way|Circle|College|Domain|Pact|Aspect|Tradition|Subschool|Martial Archetype|Sacred Oath|Divine Domain|Otherworldly Patron|Sorcerous Origin|Roguish Archetype|Primal Path|Druidic Circle|Bard College|Ranger Archetype|Arcane Tradition|Monastic Tradition)\s+(?:of\s+)?(?:the\s+)?[A-Z][a-zA-Z ,']+)$/);
    if (subMatch) {
      const subName = subMatch[1].trim();
      // Look nearby for the parent class
      const contextLines = lines.slice(Math.max(0, i - 20), i + 20).join(' ');
      let parentClass = null;
      for (const cls of CLASS_NAMES) {
        if (new RegExp(cls, 'i').test(contextLines)) {
          parentClass = cls.toLowerCase();
          break;
        }
      }
      if (!parentClass) continue;
      if (!result[parentClass]) result[parentClass] = [];
      if (!result[parentClass].find(s => s.name === subName)) {
        result[parentClass].push({ id: slugify(subName), name: subName });
      }
    }
  }

  return result;
}

// ── Background parser ──────────────────────────────────────
function parseBackgrounds(text) {
  const backgrounds = [];
  const seen = new Set();
  const lines = text.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    // Look for "Skill Proficiencies:" as a strong signal we're in a background
    if (/^Skill Proficiencies?:/i.test(line)) {
      // Find background name by looking back
      let bgName = '';
      for (let j = i - 1; j >= Math.max(0, i - 10); j--) {
        const prev = lines[j].trim();
        if (prev && prev.length < 60 && /^[A-Z]/.test(prev) && !/^(As a|Your|You|The|This)/.test(prev) && !/[.:]$/.test(prev)) {
          bgName = prev;
          break;
        }
      }
      if (!bgName || seen.has(bgName) || bgName.length > 50) continue;
      seen.add(bgName);

      // Collect block
      const blockLines = [];
      for (let k = i; k < Math.min(lines.length, i + 50); k++) {
        if (k > i + 3 && /^[A-Z][A-Z\s]{6,}$/.test(lines[k].trim())) break;
        blockLines.push(lines[k].trim());
      }
      const block = blockLines.join('\n');

      const bg = {
        id: slugify(bgName),
        name: bgName,
        skillProficiencies: [],
        languages: 0,
        toolProficiencies: [],
        equipment: [],
        feature: `${bgName} Feature`,
      };

      // Skills
      const skillLine = block.match(/Skill Proficiencies?:\s*([^\n]+)/i);
      if (skillLine) {
        bg.skillProficiencies = skillLine[1].split(/,\s*and\s*|,\s*|\s+and\s+/)
          .map(s => s.trim()).filter(s => SKILL_NAMES.includes(s));
      }

      // Tool proficiencies
      const toolLine = block.match(/Tool Proficiencies?:\s*([^\n]+)/i);
      if (toolLine) {
        bg.toolProficiencies = toolLine[1].split(/,\s*/).map(s => s.trim()).filter(s => s && s !== 'None');
      }

      // Languages
      const langLine = block.match(/Languages?:\s*([^\n]+)/i);
      if (langLine) {
        const lcount = (langLine[1].match(/\bone\b/i) ? 1 : 0) + (langLine[1].match(/\btwo\b/i) ? 2 : 0);
        bg.languages = lcount || (langLine[1].toLowerCase().includes('any') ? 1 : 0);
      }

      // Equipment — find "Equipment:" line
      const eqLine = block.match(/Equipment:\s*([^\n]{10,})/i);
      if (eqLine) {
        bg.equipment = eqLine[1].split(/,\s*(?:and\s+)?/).map(s => s.trim()).filter(Boolean);
      }

      // Feature name
      const featureMatch = block.match(/Feature:\s*([^\n]+)/i);
      if (featureMatch) bg.feature = featureMatch[1].trim();

      if (bg.skillProficiencies.length >= 1) backgrounds.push(bg);
    }
  }

  return backgrounds;
}

// ── Feat parser ────────────────────────────────────────────
function parseFeats(text) {
  const feats = [];
  const seen = new Set();
  const lines = text.split('\n');

  // Feats sections often have "Prerequisite:" lines
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (/^Prerequisite(?:s)?:/i.test(line) || /^Prerequisite(?:s)?:\s*None/i.test(line)) {
      // Name is a line or two back
      let featName = '';
      for (let j = i - 1; j >= Math.max(0, i - 5); j--) {
        const prev = lines[j].trim();
        if (prev && prev.length < 60 && /^[A-Z]/.test(prev) && !/^(As a|Your|You|The|This)/.test(prev)) {
          featName = prev;
          break;
        }
      }
      if (!featName || seen.has(featName)) continue;
      seen.add(featName);

      const prereqLine = line.replace(/^Prerequisite(?:s)?:\s*/i, '').trim();

      // Get description — next few lines
      const descLines = [];
      for (let k = i + 1; k < Math.min(lines.length, i + 10); k++) {
        const dl = lines[k].trim();
        if (/^[A-Z][A-Z\s]{6,}$/.test(dl) || /^Prerequisite/i.test(dl)) break;
        if (dl) descLines.push(dl);
      }

      feats.push({
        id: slugify(featName),
        name: featName,
        prerequisite: prereqLine && !/none/i.test(prereqLine) ? prereqLine : null,
        summary: descLines.slice(0, 2).join(' ').slice(0, 300) || `${featName} feat.`,
      });
    }
  }

  // Also pick up feats without prerequisites by looking for feat-like entries
  // in dedicated "Feats" chapter sections
  const featSectionRe = /(?:^|\n)(Feats?\n|FEATS?\n)([\s\S]{0,50000}?)(?=\nChapter|\nAppendix|\nIndex)/i;
  const featSection = text.match(featSectionRe);
  if (featSection) {
    const sectionLines = featSection[2].split('\n');
    for (let i = 0; i < sectionLines.length; i++) {
      const line = sectionLines[i].trim();
      // Short all-title-case lines followed by descriptive text
      if (line.length > 2 && line.length < 50 && /^[A-Z][a-zA-Z ]+$/.test(line) && !seen.has(line)) {
        const nextLine = (sectionLines[i + 1] || '').trim();
        if (nextLine.length > 30 && /[a-z]/.test(nextLine)) {
          seen.add(line);
          feats.push({
            id: slugify(line),
            name: line,
            prerequisite: null,
            summary: nextLine.slice(0, 250),
          });
        }
      }
    }
  }

  return feats;
}

// ── Spell parser ───────────────────────────────────────────
function parseSpells(text) {
  const spells = [];
  const seen = new Set();
  const lines = text.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // Spell level line: "1st-level evocation" or "Cantrip (evocation)"
    const levelMatch = line.match(/^(\d+)(?:st|nd|rd|th)-level\s+(\w+)/i) ||
                       line.match(/^(cantrip)\s*\((\w+)\)/i) ||
                       line.match(/^(Cantrip)\s+\((\w+)\)/i);

    if (levelMatch) {
      const rawLevel = levelMatch[1];
      const school = capitalize(levelMatch[2]);
      if (!SPELL_SCHOOLS.includes(school)) continue;

      const level = /cantrip/i.test(rawLevel) ? 0 : parseInt(rawLevel);

      // Spell name is the line before
      const spellName = (lines[i - 1] || '').trim();
      if (!spellName || spellName.length > 60 || seen.has(spellName) || !/^[A-Z]/.test(spellName)) continue;
      seen.add(spellName);

      // Collect casting info
      const blockLines = [];
      for (let k = i + 1; k < Math.min(lines.length, i + 20); k++) {
        const bl = lines[k].trim();
        if (/^\d+(?:st|nd|rd|th)-level/i.test(bl) || /^Cantrip/i.test(bl)) break;
        if (bl) blockLines.push(bl);
      }
      const block = blockLines.join(' ');

      // Which classes can use this spell
      const classesForSpell = [];
      for (const cls of CLASS_NAMES) {
        // Look in surrounding context for class spell list headers
        const context = lines.slice(Math.max(0, i - 100), i).join(' ');
        if (new RegExp(`${cls}\\s+Spells?|${cls}\\s+Spell\\s+List`, 'i').test(context)) {
          classesForSpell.push(cls.toLowerCase().replace(' ', '-'));
        }
      }

      // Description: first full sentence from block
      const descMatch = block.match(/([A-Z][^.!?]{20,200}[.!?])/);
      const summary = descMatch ? descMatch[1].trim() : block.slice(0, 200);

      spells.push({
        name: spellName,
        level,
        school,
        classes: classesForSpell,
        summary: summary || `${spellName} (level ${level} ${school})`,
      });
    }
  }

  return spells;
}

// ── Class parser ───────────────────────────────────────────
function parseClasses(text, subclassesByClass) {
  const classes = [];
  const seen = new Set();
  const lines = text.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // Find class names as standalone headers
    const classMatch = CLASS_NAMES.find(c => line === c || line === c.toUpperCase());
    if (!classMatch || seen.has(classMatch)) continue;

    // Confirm it looks like a class section by checking nearby lines for "Hit Points" or "Hit Die"
    const context = lines.slice(i, Math.min(lines.length, i + 60)).join('\n');
    if (!/Hit (?:Points|Die)/i.test(context)) continue;

    seen.add(classMatch);

    const cls = {
      id: slugify(classMatch),
      name: classMatch,
      hitDie: 8,
      primaryAbility: [],
      savingThrows: [],
      armorProficiencies: [],
      weaponProficiencies: [],
      toolProficiencies: [],
      skillChoices: { count: 2, options: [] },
      spellcasting: null,
      subclassLevel: 3,
      subclasses: subclassesByClass[classMatch.toLowerCase()] || [],
      startingEquipment: [],
    };

    // Hit Die
    const hdMatch = context.match(/Hit Die:\s*(?:a\s+)?d(\d+)/i) ||
                    context.match(/(\d+)\s+\+\s*your Constitution/);
    if (hdMatch) cls.hitDie = parseInt(hdMatch[1]);

    // Saving throws
    const stMatch = context.match(/Saving Throws?:\s*([^\n]+)/i);
    if (stMatch) {
      const stLine = stMatch[1];
      for (const [long, short] of Object.entries(ABILITY_SHORT)) {
        if (new RegExp(long, 'i').test(stLine)) cls.savingThrows.push(short);
      }
    }

    // Armor proficiencies
    const armorMatch = context.match(/Armor:\s*([^\n]+)/i);
    if (armorMatch) {
      cls.armorProficiencies = armorMatch[1].split(/,\s*/).map(s => s.trim()).filter(Boolean);
    }

    // Weapon proficiencies
    const wpnMatch = context.match(/Weapons?:\s*([^\n]+)/i);
    if (wpnMatch) {
      cls.weaponProficiencies = wpnMatch[1].split(/,\s*/).map(s => s.trim()).filter(Boolean);
    }

    // Skills
    const skillMatch = context.match(/Skills?:.*?choose\s+(\w+).*?from\s+([^\n]+)/i);
    if (skillMatch) {
      const countWord = skillMatch[1];
      const count = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6 }[countWord.toLowerCase()] || 2;
      cls.skillChoices.count = count;
      cls.skillChoices.options = skillMatch[2].split(/,\s*(?:and\s+)?/).map(s => s.trim())
        .filter(s => SKILL_NAMES.includes(s));
    }

    // Spellcasting
    if (/Spellcasting/i.test(context)) {
      const abMatch = context.match(/(?:spellcasting\s+ability\s+is|spell\s+save\s+DC[^.]+)\s+([A-Z][a-z]+)/i);
      const abName = abMatch ? abMatch[1].toLowerCase() : null;
      const ab = ABILITY_SHORT[abName] || null;
      if (ab) {
        cls.spellcasting = { ability: ab, type: 'prepared', cantripsAt1: 0 };
        const cantripMatch = context.match(/you\s+know\s+(\w+)\s+cantrips?/i);
        if (cantripMatch) {
          const n = { one: 1, two: 2, three: 3, four: 4, five: 5 }[cantripMatch[1].toLowerCase()];
          if (n) cls.spellcasting.cantripsAt1 = n;
        }
      }
    }

    // Starting equipment — look for "You start with" or "Starting Equipment"
    const eqMatch = context.match(/(?:Starting Equipment|You start with)[^:]*:([\s\S]{0,600}?)(?=\n[A-Z][A-Z\s]{5,}|$)/i);
    if (eqMatch) {
      cls.startingEquipment = eqMatch[1].trim().split(/\n|•|·/).map(s => s.trim()).filter(s => s.length > 3).slice(0, 6);
    }

    classes.push(cls);
  }

  return classes;
}

// ── Main extraction orchestrator ───────────────────────────
async function extractDnDContent(file, onProgress) {
  onProgress('loading', 0, 1);
  const pages = await extractTextFromPDF(file, (cur, total) => {
    onProgress('reading', cur, total);
  });

  onProgress('parsing', 0, 1);
  const fullText = joinPages(pages);

  const subclassesByClass = parseSubclasses(fullText);
  const races = parseRaces(fullText);
  const classes = parseClasses(fullText, subclassesByClass);
  const backgrounds = parseBackgrounds(fullText);
  const feats = parseFeats(fullText);
  const spells = parseSpells(fullText);

  // Deduplicate
  function dedup(arr, key) {
    const seen = new Set();
    return arr.filter(x => {
      const k = x[key];
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  const result = {
    source: file.name.replace(/\.pdf$/i, '').replace(/_/g, ' '),
    races: dedup(races, 'id'),
    classes: dedup(classes, 'id'),
    backgrounds: dedup(backgrounds, 'id'),
    feats: dedup(feats, 'id'),
    spells: dedup(spells, 'name'),
    equipment: { weapons: [], armor: [], packs: [], adventuringGear: [] },
  };

  onProgress('done', 1, 1);
  return result;
}

window.DnDPDFParser = { extractDnDContent };
