// Character Forge — PDF Export (v4 — step-by-step diagnostic)

const JSPDF_CDN = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';

const ExportPDF = {
  async export() {
    const btn = document.querySelector('[onclick*="ExportPDF.export"]');
    const setBtn = (label, bg) => {
      if (!btn) return;
      btn.textContent = label;
      btn.disabled = bg === 'working';
      btn.style.background = (bg && bg !== 'working') ? bg : '';
    };

    try {
      const H = window._pdfHelpers;
      if (!H) throw new Error('App helpers not ready.');

      const { state, DATA, getRace, getClass, getBackground, finalAbilityScores,
              computeHP, computeAC, abilityMod, proficiencyBonus, fmtMod,
              getSkillRows, getSavingThrows, getClassResources, getRaceResources,
              getSpellSlots, ABILITIES, ABILITY_NAMES } = H;
      const SUBCLASS_FEATURES = window._SUBCLASS_FEATURES || {};

      const c = state.character;
      if (!c) throw new Error('No character loaded.');

      // Load jsPDF
      if (!window.jspdf) {
        setBtn('⏳ Loading…', 'working');
        await new Promise((res, rej) => {
          const el = document.createElement('script');
          el.src = JSPDF_CDN;
          el.onload = res;
          el.onerror = () => rej(new Error('Could not load PDF library. Check your internet connection.'));
          document.head.appendChild(el);
        });
      }
      setBtn('⏳ Building…', 'working');

      const { jsPDF } = window.jspdf;

      // ── Monkey-patch jsPDF to find the exact bad call ─────
      // We wrap the internal f3 so it logs what value triggered the error
      const origDoc = new jsPDF({ orientation:'portrait', unit:'mm', format:'a4' });
      const origF3 = origDoc.internal.f3.bind(origDoc.internal);
      origDoc.internal.f3 = function(val) {
        if (!isFinite(val) || val === null || val === undefined) {
          const err = new Error(`jsPDF.f3 received bad value: ${JSON.stringify(val)}`);
          console.error(err);
          // Capture stack trace
          console.trace();
          throw err;
        }
        return origF3(val);
      };
      const doc = origDoc;

      // ── Safe helpers ──────────────────────────────────────
      // str: always a non-empty string
      const str = (v, fb = '—') => {
        if (v === null || v === undefined) return fb;
        const out = String(v).trim();
        return (out === '' || out === 'null' || out === 'undefined' || out === 'NaN') ? fb : out;
      };
      // num: always a finite number
      const num = (v, fb = 0) => {
        const n = Number(v);
        return (isFinite(n) && !isNaN(n)) ? n : fb;
      };
      // safe text
      const tx = (v, x, y, opts) => {
        const xs = num(x), ys = num(y);
        const vs = str(v);
        doc.text(vs, xs, ys, opts);
      };
      // safe rect
      const rect = (x,y,w,h,style) => doc.rect(num(x),num(y),num(w,1),num(h,1),style);
      // safe roundedRect
      const rrect = (x,y,w,h,rx,ry,style) => doc.roundedRect(num(x),num(y),num(w,1),num(h,1),num(rx,1),num(ry,1),style);
      // safe circle
      const circ = (x,y,r,style) => doc.circle(num(x),num(y),num(r,1),style);
      // safe line
      const line = (x1,y1,x2,y2) => doc.line(num(x1),num(y1),num(x2),num(y2));

      const K = { bg:'#1c1a22', panel:'#262231', gold:'#c9a227', crimson:'#9a3c3c',
                  parch:'#efe6d3', text:'#ece7da', muted:'#a89fc0', border:'#40384f', dark:'#2b2418' };
      // Expand 3-digit hex to 6-digit before parsing
      const rgb = h => {
        h = h.replace('#','');
        if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
        return [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
      };
      const F  = col => doc.setFillColor(...rgb(col));
      const D  = col => doc.setDrawColor(...rgb(col));
      const T  = col => doc.setTextColor(...rgb(col));
      const fo = (sz,st='normal') => { doc.setFont('helvetica',st); doc.setFontSize(num(sz,7)); };

      // ── Data ──────────────────────────────────────────────
      const race  = getRace(c.raceId);
      const cls   = getClass(c.classId);
      const bgd   = getBackground(c.backgroundId);
      const sub   = cls?.subclasses?.find(x => x.id === c.subclassId) || null;
      const feat  = c.feat ? DATA.feats.find(f => f.id === c.feat) : null;
      const scores = finalAbilityScores(c);

      // Validate scores — log any bad values
      ABILITIES.forEach(a => {
        if (!isFinite(scores[a])) console.warn(`Bad score for ${a}:`, scores[a]);
      });

      const pb    = num(proficiencyBonus(num(c.level, 1)));
      const rawHp = computeHP(c);
      const hp    = (rawHp !== null && rawHp !== undefined) ? num(rawHp) : null;
      const ac    = num(computeAC(c), 10) + num(c.tempAc);
      const curHp = (hp !== null) ? num(c.currentHp ?? hp) : num(c.currentHp ?? 0);
      const spd   = num(race?.speed, 30);
      const initM = num(abilityMod(num(scores.dex, 10)));

      const W = 210, PH = 297, mg = 12;
      const colW = num((W - mg*2 - 4) / 3, 60);
      const c1x = mg, c2x = mg + colW + 2, c3x = mg + (colW+2)*2;

      // ── Page ──────────────────────────────────────────────
      F(K.bg); rect(0,0,W,PH,'F');

      // Banner
      F('#6e2a2a'); rect(0,0,W,28,'F');
      F(K.crimson); rect(0,0,W*0.55,28,'F');
      F(K.bg); D(K.gold); doc.setLineWidth(0.7);
      circ(mg+8,14,7,'FD');
      T(K.gold); fo(11,'bold'); tx(str(c.name,'?').charAt(0).toUpperCase(), mg+8,16.5,{align:'center'});
      T('#ffffff'); fo(15,'bold'); tx(str(c.name,'Unnamed'), mg+20,11);
      fo(8.5,'normal'); T('#f0d0d0');
      tx([`Level ${num(c.level,1)}`, race?.name, cls?.name, sub?`(${sub.name})`:null].filter(Boolean).join(' '), mg+20,17);
      T('#d9b8b8'); tx(str(bgd?.name,'No background'), mg+20,22);
      F(K.gold); rect(0,27,W,0.8,'F');

      // Vitals
      const vitals = [
        {l:'ARMOR CLASS',  v:str(ac)},
        {l:'HIT POINTS',   v: hp!==null ? `${curHp} / ${hp}` : str(curHp||'—')},
        {l:'INITIATIVE',   v:str(fmtMod(initM))},
        {l:'SPEED',        v:`${spd} ft`},
        {l:'HIT DIE',      v:cls?.hitDie ? `d${cls.hitDie}` : '—'},
        {l:'PROFICIENCY',  v:str(fmtMod(pb))},
      ];
      const vw = num((W-mg*2)/vitals.length, 30);
      vitals.forEach((v,i) => {
        const x = num(mg + i*vw);
        F(K.parch); rrect(x+0.5,30,vw-1,14,2,2,'F');
        F(K.gold);  rect(x+0.5,42,vw-1,1.5,'F');
        T(K.dark);  fo(11,'bold'); tx(v.v, x+vw/2, 37.5, {align:'center'});
        fo(5.5,'normal');          tx(v.l, x+vw/2, 41.5, {align:'center'});
      });

      const topY = 48;

      // Card helper
      const card = (cx,cy,cw,ch,title) => {
        cy=num(cy); ch=Math.max(num(ch),10);
        F(K.panel); D(K.border); doc.setLineWidth(0.25);
        rrect(cx,cy,cw,ch,1.5,1.5,'FD');
        T(K.gold); fo(6,'bold'); tx(title.toUpperCase(),cx+3,cy+4.5);
        D(K.border); doc.setLineWidth(0.2); line(cx+1,cy+6.5,cx+cw-1,cy+6.5);
        return cy+8.5;
      };
      const prow = (cx,cy,cw,label,val,prof) => {
        cy=num(cy);
        if(prof){F(K.gold);circ(cx+2,cy-1,1.3,'F');}
        else{D(K.gold);doc.setLineWidth(0.25);circ(cx+2,cy-1,1.3,'D');}
        T(K.text);fo(6,'normal');tx(label,cx+5,cy);
        T(K.muted);fo(6,'bold');tx(str(val),cx+cw-2,cy,{align:'right'});
        return cy+4.5;
      };
      const hdiv = (cx,cy,cw) => { D(K.border);doc.setLineWidth(0.2);line(cx+1,cy,cx+cw-1,cy); return cy+3; };

      // ── Col 1: Scores / Saves / Skills ───────────────────
      let y1=topY;

      let iy = card(c1x,y1,colW,44,'Ability Scores');
      const abW=num(colW/3,20);
      ABILITIES.forEach((a,i)=>{
        const bx=num(c1x+(i%3)*abW+0.5), by=num(iy+Math.floor(i/3)*15.5);
        F(K.parch);rrect(bx,by,abW-1,14,1.5,1.5,'F');
        T('#555555');fo(5,'normal');tx(a.toUpperCase(),bx+(abW-1)/2,by+3.5,{align:'center'});
        T(K.dark);fo(9,'bold');tx(str(fmtMod(abilityMod(num(scores[a],10)))),bx+(abW-1)/2,by+9,{align:'center'});
        T('#888888');fo(5.5,'normal');tx(str(scores[a],'10'),bx+(abW-1)/2,by+13,{align:'center'});
      });
      y1+=44+2;

      const savesData=getSavingThrows(c);
      const saveH=num(8+savesData.length*4.6,20);
      let sy=card(c1x,y1,colW,saveH,'Saving Throws');
      savesData.forEach(sv=>{sy=prow(c1x+2,sy,colW-4,str(ABILITY_NAMES[sv.ability]),fmtMod(sv.mod),sv.proficient);});
      y1+=saveH+2;

      const skillData=getSkillRows(c);
      const pp=num(10+(skillData.find(sk=>sk.name==='Perception')?.mod||0));
      const skH=num(12+skillData.length*4.6,20);
      let skY=card(c1x,y1,colW,skH,'Skills');
      T(K.muted);fo(5.8,'normal');tx(`Passive Perception: ${pp}`,c1x+3,skY);skY+=5;
      hdiv(c1x,skY-1,colW);skY+=1;
      skillData.forEach(sk=>{skY=prow(c1x+2,skY,colW-4,`${sk.name} (${sk.ability.toUpperCase()})`,fmtMod(sk.mod),sk.proficient);});
      y1+=skH+2;

      // ── Col 2: HP / Resources / Equipment ────────────────
      let y2=topY;

      {
        const pct=(hp&&hp>0)?Math.min(1,num(curHp)/num(hp)):1;
        const barCol=pct>0.5?'#4caf50':pct>0.25?'#e6a817':'#c1504f';
        const hpH=32+((c.tempHp||0)>0?5:0);
        let hy=card(c2x,y2,colW,hpH,'Hit Points & Rests');
        const bw=num(colW-6,50);
        F(K.border);rrect(c2x+3,hy,bw,3,1,1,'F');
        F(barCol);rrect(c2x+3,hy,num(bw*pct),3,1,1,'F');
        hy+=5;
        T(K.text);fo(14,'bold');tx(str(curHp,'—'),c2x+colW/2,hy+7,{align:'center'});
        T(K.muted);fo(7,'normal');tx(`/ ${hp!==null?hp:'—'} max`,c2x+colW/2,hy+12,{align:'center'});
        hy+=14;
        if((c.tempHp||0)>0){T('#64b5f6');fo(6.5,'normal');tx(`+${c.tempHp} Temp HP`,c2x+4,hy);hy+=5;}
        T(K.muted);fo(6,'normal');tx(`Hit Dice: ${num(c.level)-num(c.hitDiceUsed)}/${c.level} d${cls?.hitDie??8}`,c2x+4,hy);
        y2+=hpH+2;
      }

      const allRes=[...getClassResources(c),...getRaceResources(c)].filter(r=>r.max!==null&&r.max>0);
      if(allRes.length){
        let totalH=9;
        allRes.forEach(r=>{totalH+=4+5+(r.desc?Math.min(2,Math.ceil(str(r.desc).length/55))*3.3:0)+2;});
        const resH=num(totalH,20);
        let ry=card(c2x,y2,colW,Math.max(resH,20),'Class & Race Resources');
        allRes.forEach(r=>{
          const used=num((c.resources||{})[r.id]);
          const rmax=num(r.max,1);
          T(K.text);fo(6.5,'bold');tx(`${str(r.icon,'')} ${str(r.name)}`,c2x+3,ry);
          T(K.muted);fo(5.5,'normal');tx(`${rmax-used}/${rmax} · ${r.recharge==='short'?'☽':'☀'} rest`,c2x+colW-3,ry,{align:'right'});
          ry+=4;
          const maxPips=Math.min(rmax,20);
          const pg=num((colW-8)/Math.max(maxPips,1),4);
          for(let i=0;i<maxPips;i++){
            const px=num(c2x+4+i*pg);
            if(i<used){F(K.gold);circ(px,ry-0.5,1.4,'F');}
            else{D(K.gold);doc.setLineWidth(0.3);circ(px,ry-0.5,1.4,'D');}
          }
          if(rmax>20){T(K.gold);fo(5.5,'normal');tx(`${rmax-used} remaining`,c2x+3,ry+1.5);}
          ry+=5;
          if(r.desc){
            const dl=doc.splitTextToSize(str(r.desc),colW-6);
            T(K.muted);fo(5.5,'normal');
            dl.slice(0,2).forEach(l=>{tx(l,c2x+3,ry);ry+=3.3;});
          }
          ry+=1;
        });
        y2+=Math.max(resH,20)+2;
      }

      {
        const wlib=DATA.equipment?.weapons||[];
        const gt=[...(cls?.startingEquipment||[]),...(bgd?.equipment||[]),str(c.extraGear,'')].join(', ').toLowerCase();
        const wpns=wlib.filter(w=>w?.name&&gt.includes(w.name.toLowerCase()));
        const gl=[...(cls?.startingEquipment||[]),...(bgd?.equipment||[]),
          c.armorId?`Armor: ${c.armorId}`:null,c.shield?'Shield (+2 AC)':null,c.extraGear?str(c.extraGear):null].filter(Boolean);
        const eqH=num(9+(wpns.length?wpns.length*6+8:0)+Math.min(gl.length,10)*4,18);
        let ey=card(c2x,y2,colW,Math.max(eqH,18),'Equipment & Weapons');
        if(wpns.length){
          T(K.muted);fo(5.5,'normal');tx('WEAPON',c2x+3,ey);tx('ATK',c2x+colW*0.68,ey);tx('DMG',c2x+colW-3,ey,{align:'right'});
          ey+=3.5;hdiv(c2x,ey-1,colW);
          wpns.forEach(w=>{
            const props=(w.properties||[]).map(p=>str(p).toLowerCase());
            const isr=str(w.category).toLowerCase().includes('ranged');
            const isf=props.some(p=>p.includes('finesse'));
            const prof=(cls?.weaponProficiencies||[]).some(p=>{
              const pl=str(p).toLowerCase(),cat=str(w.category).toLowerCase();
              return(pl.includes('simple')&&cat.includes('simple'))||(pl.includes('martial')&&cat.includes('martial'))||pl===str(w.name).toLowerCase();
            });
            let am=isf?Math.max(num(abilityMod(num(scores.str,10))),num(abilityMod(num(scores.dex,10))))
                  :isr?num(abilityMod(num(scores.dex,10))):num(abilityMod(num(scores.str,10)));
            const atk=num(am)+(prof?pb:0);
            T(K.text);fo(6.5,'normal');tx(str(w.name),c2x+3,ey);
            T(K.gold);fo(6.5,'bold');tx(str(fmtMod(atk)),c2x+colW*0.68,ey);
            T(K.text);fo(6,'normal');tx(`${str(w.damage,'—').split(' ')[0]}${am!==0?` ${fmtMod(am)}`:''}`,c2x+colW-3,ey,{align:'right'});
            ey+=5.5;
          });
          ey+=2;hdiv(c2x,ey-1,colW);
        }
        T(K.muted);fo(5.5,'normal');
        gl.slice(0,10).forEach(l=>{tx(`• ${str(l).slice(0,52)}`,c2x+3,ey);ey+=3.8;});
        y2+=Math.max(eqH,18)+2;
      }

      // ── Col 3: Spellcasting / Features / Notes ────────────
      let y3=topY;

      const CASTER_AB={bard:'cha',cleric:'wis',druid:'wis',paladin:'cha',ranger:'wis',sorcerer:'cha',warlock:'cha',wizard:'int',artificer:'int'};
      const scAb=cls?.spellcasting?.ability||CASTER_AB[c.classId]||null;
      const slotInfo=getSpellSlots(c.classId,c.level);
      if(scAb||slotInfo){
        const abMd=scAb?num(abilityMod(num(scores[scAb],10))):0;
        const saveDC=8+pb+abMd, atkBon=pb+abMd;
        const ords=['1st','2nd','3rd','4th','5th','6th','7th','8th','9th'];
        const srows=slotInfo?.type==='pact'?slotInfo.slots:(slotInfo?.slots||[]);
        const cant=DATA.spells.filter(sp=>c.cantrips.includes(sp.name));
        const knwn=DATA.spells.filter(sp=>c.spellsKnown.includes(sp.name)).sort((a,b)=>a.level-b.level);
        const spH=num(9+10+srows.length*6+(cant.length?4+cant.length*4:0)+(knwn.length?6+knwn.length*4.5:0),25);
        let sp=card(c3x,y3,colW,Math.max(spH,20),'Spellcasting');
        T(K.text);fo(7.5,'bold');
        tx(scAb?str(ABILITY_NAMES[scAb]):'—',c3x+3,sp+2);
        tx(str(saveDC),c3x+colW*0.44,sp+2);
        tx(str(fmtMod(atkBon)),c3x+colW*0.72,sp+2);
        T(K.muted);fo(5,'normal');
        tx('ABILITY',c3x+3,sp+5.5);tx('SAVE DC',c3x+colW*0.44,sp+5.5);tx('ATK BONUS',c3x+colW*0.72,sp+5.5);
        sp+=9;hdiv(c3x,sp,colW);
        if(srows.length){
          T(K.muted);fo(5.5,'bold');tx(slotInfo.type==='pact'?'PACT MAGIC SLOTS':'SPELL SLOTS',c3x+3,sp);sp+=4;
          srows.forEach(sl=>{
            const key=slotInfo.type==='pact'?'pact':String(sl.level);
            const used=num((c.spellSlots||{})[key]);
            const msl=num(sl.max,1);
            T(K.text);fo(5.8,'normal');tx(slotInfo.type==='pact'?`Lvl ${sl.level}`:str(ords[sl.level-1]),c3x+3,sp);
            const pg=num((colW-25)/Math.max(msl,1),4);
            for(let i=0;i<msl;i++){
              const px=num(c3x+20+i*pg);
              if(i<used){F(K.crimson);circ(px,sp-1,1.5,'F');}
              else{D(K.gold);doc.setLineWidth(0.3);circ(px,sp-1,1.5,'D');}
            }
            T(K.muted);fo(5,'normal');tx(`${msl-used}/${msl}`,c3x+colW-3,sp,{align:'right'});
            sp+=5.5;
          });
          hdiv(c3x,sp,colW);
        }
        if(cant.length){T(K.gold);fo(5.5,'bold');tx('CANTRIPS',c3x+3,sp);sp+=4;cant.forEach(cv=>{T(K.text);fo(6,'normal');tx(`• ${str(cv.name)}`,c3x+3,sp);sp+=4;});hdiv(c3x,sp,colW);}
        if(knwn.length){
          T(K.gold);fo(5.5,'bold');tx('SPELLS KNOWN / PREPARED',c3x+3,sp);sp+=4;
          let cl=-1;
          knwn.forEach(kn=>{
            if(kn.level!==cl){T(K.muted);fo(5,'normal');tx(str(ords[kn.level-1],`L${kn.level}`).toUpperCase(),c3x+3,sp);sp+=3.5;cl=kn.level;}
            T(K.text);fo(5.8,'normal');tx(`  • ${str(kn.name)}`,c3x+3,sp);sp+=4;
          });
        }
        y3+=Math.max(spH,20)+2;
      }

      {
        const sf=(sub&&SUBCLASS_FEATURES[sub.id])?SUBCLASS_FEATURES[sub.id].filter(f=>f.level<=c.level):[];
        const items=[
          ...(race?.traits?.map(t=>({h:null,b:str(t)}))||[]),
          bgd?{h:`Background — ${str(bgd.name)}`,b:str(bgd.feature)}:null,
          feat?{h:str(feat.name),b:str(feat.summary)}:null,
          ...sf.map(f=>({h:`${str(f.name)} (lvl ${f.level})`,b:str(f.desc)})),
        ].filter(Boolean);
        if(items.length){
          let estH=9;
          items.forEach(f=>{if(f.h)estH+=5;estH+=doc.splitTextToSize(str(f.b),colW-6).length*3.8+2;});
          estH=Math.min(num(estH),PH-y3-mg-2);
          let fy=card(c3x,y3,colW,Math.max(estH,15),'Features & Traits');
          items.forEach(f=>{
            if(num(fy)>y3+estH-4)return;
            if(f.h){T(K.gold);fo(6.5,'bold');tx(str(f.h),c3x+3,fy);fy+=4.5;}
            T(K.text);fo(5.8,'normal');
            doc.splitTextToSize(str(f.b),colW-6).forEach(l=>{if(num(fy)<=y3+estH-2){tx(l,c3x+3,fy);fy+=3.8;}});
            fy+=1.5;
          });
          y3+=estH+2;
        }
      }

      if(c.notes&&str(c.notes).length>0){
        const nl=doc.splitTextToSize(str(c.notes),colW-6);
        const nh=Math.min(num(9+nl.length*3.8),PH-y3-mg-2);
        if(nh>12){
          let ny=card(c3x,y3,colW,nh,'Notes');
          T(K.text);fo(6,'normal');
          nl.forEach(l=>{if(num(ny)<y3+nh-2){tx(l,c3x+3,ny);ny+=3.8;}});
        }
      }

      // Footer
      F(K.border);rect(0,PH-7,W,7,'F');
      T(K.muted);fo(5,'normal');
      tx('Character Forge — D&D 5e Character Creator',mg,PH-2.5);
      tx(`Exported ${new Date().toLocaleDateString()}`,W-mg,PH-2.5,{align:'right'});

      // Save
      doc.save(`${str(c.name,'character').replace(/[^a-z0-9]/gi,'_').toLowerCase()}_sheet.pdf`);
      setBtn('✅ Downloaded!','#2e7d32');
      setTimeout(()=>setBtn('⬇ Export PDF',''),2500);

    } catch(err) {
      console.error('PDF export error:', err);
      // Show the actual error message including the bad value
      const msg = err.message || String(err);
      if (btn) {
        btn.textContent = `❌ ${msg.slice(0,60)}`;
        btn.disabled = false;
        btn.style.background = '#9a2020';
        setTimeout(()=>{ btn.textContent='⬇ Export PDF'; btn.style.background=''; },8000);
      }
      // Also show in an alert so we can read the full stack
      setTimeout(() => alert(`PDF Export Error:\n\n${msg}\n\nCheck browser console (F12) for the exact location.`), 100);
    }
  }
};

window.ExportPDF = ExportPDF;
