# Character Forge — 5e Character Creator

A local web app for building and saving D&D 5e characters: pick race, class,
background, ability scores, skills, equipment, and spells through a wizard,
then save characters to a real database that persists across sessions and
devices on your network.

## Why it's "quick" but still real

- **Backend:** Node.js + Express + SQLite (via `better-sqlite3`). SQLite is
  just a file (`server/characters.db`) — no database server to install or
  configure.
- **Frontend:** Plain HTML/CSS/JS. No build step, no framework — open it and
  it works.
- **Rules content:** Seeded with a subset of the **5e SRD (System Reference
  Document 5.1)** — the portion of D&D 5e rules Wizards of the Coast has
  released under an open license. That's races, classes, backgrounds, feats,
  core equipment, and a solid handful of the most-used spells at each level.

## Running it

```bash
cd dnd-creator
npm install
npm start
```

Then open **http://localhost:3000** in your browser. That's it — the SQLite
file is created automatically on first run.

To make it reachable from other devices on your home network, run it on a
machine that stays on (a home server, NAS, or old laptop) and visit
`http://<that-machine's-LAN-IP>:3000` from your phone/tablet. For access from
outside your home network you'd want a proper deployment (a small VPS + a
process manager like `pm2`, plus HTTPS) — happy to help set that up if you
want it later.

## Adding your other books and playtest material

I couldn't pre-load the actual text of official books (Xanathar's, Tasha's,
Volo's, Fizban's, the 2024 core books, Unearthed Arcana / playtest packets,
etc.) since that's Wizards of the Coast's copyrighted content. But the app is
built so you can drop your own data in without touching any app code — it's
just JSON files under `server/data/custom/`, merged in automatically every
time the data API is called (just refresh your browser, no server restart
needed).

Create any of these files (all optional, all arrays unless noted):

- `server/data/custom/races.json`
- `server/data/custom/classes.json`
- `server/data/custom/backgrounds.json`
- `server/data/custom/feats.json`
- `server/data/custom/spells.json`
- `server/data/custom/equipment.json` — this one is an **object** with the
  same shape as `server/data/equipment.json` (keys: `weapons`, `armor`,
  `packs`, `adventuringGear`), not a flat array.

Use `server/data/races.json`, `classes.json`, etc. as templates for the exact
field names each entry needs — just copy the shape of an existing entry and
fill in your own content. An entry whose `id` (or `name`, for spells) matches
an existing one will **override** it; a new `id`/`name` **adds** a new entry.

Example — adding a custom race in `server/data/custom/races.json`:

```json
[
  {
    "id": "my-homebrew-race",
    "name": "Starforged",
    "size": "Medium",
    "speed": 30,
    "abilityBonuses": { "cha": 2, "wis": 1 },
    "traits": ["Darkvision 60 ft.", "Resistance to radiant damage"],
    "languages": ["Common", "Celestial"]
  }
]
```

Example — adding a playtest class option in `server/data/custom/classes.json`,
just fill in the same fields as the built-in classes in
`server/data/classes.json`.

## Character sheet view

Clicking a character card opens a read-only, D&D Beyond-style sheet: banner
header, AC/HP/Initiative/Speed/Hit Die/Proficiency stat row, ability score
tiles, saving throws and skills with proficiency dots, features & traits,
equipment, and a spellcasting panel with save DC/attack bonus when
applicable. Click **Edit Character** from there to jump back into the wizard.

## What the wizard covers

1. **Basics** — name, level, ability-score method
2. **Race** — all SRD races/subraces, with Half-Elf's "choose 2" bonus
3. **Class** — all 12 SRD classes, starting gear, subclass (once unlocked)
4. **Background** — skills, tools, equipment, feature text
5. **Ability Scores** — Standard Array, Point Buy (27 pts), or manual/rolled
6. **Skills & Feat** — class + background skill proficiencies, optional feat
7. **Equipment** — starting gear, armor (auto AC calc), shield, free-text extras
8. **Spells** — cantrips/spells filtered to your class from the spell library
9. **Review & Save** — computed HP, AC, modifiers, proficiency bonus; save to DB

Notes on simplifications (this is a "quick tool," not a full rules engine):
HP uses average-roll-per-level math rather than manual rolling; spell-slot
tracking and multiclassing math aren't modeled; feats aren't gated by the
Ability Score Improvement schedule (pick one whenever, and apply your table's
own rules). All of these are straightforward to extend in `app.js` if you
want to go further.

## Project structure

```
dnd-creator/
  package.json
  server/
    server.js          # Express app + API routes
    db.js               # SQLite setup
    data/                # SRD JSON (races, classes, backgrounds, feats, spells, equipment)
    data/custom/          # <- put your own book/playtest content here
  public/
    index.html
    style.css
    app.js               # all wizard/state/rendering logic
```

## API reference (if you want to script against it)

- `GET /api/data` — full merged rules dataset
- `GET /api/data/{races|classes|backgrounds|feats|spells|equipment}`
- `GET /api/characters` — list saved characters (summary)
- `GET /api/characters/:id` — full character sheet
- `POST /api/characters` — create (body = character JSON, needs `name`)
- `PUT /api/characters/:id` — update
- `DELETE /api/characters/:id`
