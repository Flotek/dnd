# ⚔ Character Forge — D&D 5e Character Creator

**→ Open `HOW TO INSTALL.html` for full setup instructions.**

## Quick start

| Platform | What to do |
|---|---|
| **Windows** | Double-click `Start Windows.bat` |
| **Mac** | Right-click `Start Mac.command` → Open |
| **Linux** | Run `./Start\ Linux.sh` in a terminal |

The launcher checks for Node.js, installs dependencies on first run, and opens your browser automatically at http://localhost:3000.

## Requirements

- **Node.js LTS** — https://nodejs.org (free, installed automatically on Windows if winget is available)
- A modern browser (Chrome, Firefox, Edge, Safari)
- ~100 MB disk space

## Your data

Characters are saved in `dnd-creator/server/characters.db`.  
Back up that file to keep your characters safe.

## PDF import

Go to **📚 Import PDFs** in the nav bar to load your sourcebooks.  
All processing is local — nothing leaves your machine.

---
Built with Node.js + Express + SQLite. Rules content: D&D 5e SRD 5.1.

## Random character button

A **🎲 Random Character** button sits in the top bar, and a **Roll it for me** panel
appears on the wizard's *Basics* step. Rolling picks race (plus lineage, ancestry,
tool and language choices), class, subclass, background, ability scores and skill
proficiencies.

Two things are deliberately never rolled: **your level**, and **your feat / ASI
choices**. Set the level in Basics and pick feats in *Skills & Feat* as usual —
re-rolling around them leaves them alone.

- Tick or untick any part (name, race, class, subclass, background, scores, skills)
  to lock the rest and re-roll only what you want.
- Ability scores honour the method chosen in Basics: standard array, a legal
  27-point buy, or 4d6-drop-lowest for Manual/Rolled.
- **Best for the class** arranges scores by the class's key abilities;
  **However they land** assigns them at random.
- Each of the Race / Class / Background / Ability Scores steps also has its own
  small re-roll button.

Everything lives in `public/randomizer.js` (plus a styles block at the end of
`public/style.css`). It wraps the existing step renderers rather than modifying
them, so deleting the one `<script>` tag in `index.html` removes the feature cleanly.
