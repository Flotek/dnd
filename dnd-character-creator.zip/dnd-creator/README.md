# ⚔ Character Forge — D&D 5e Character Creator

**→ Open `HOW TO INSTALL.html` for full setup instructions.**

## Quick start

| Platform | What to do |
|---|---|
| **Windows** | Double-click `Start Windows.bat` |
| **Mac** | Right-click `Start Mac.command` → Open |
| **Linux** | Run `./Start\ Linux.sh` in a terminal |

The launcher checks for Node.js, installs dependencies on first run, and opens your browser automatically at http://localhost:3000.

## Requirements

- **Node.js LTS** — https://nodejs.org (free, installed automatically on Windows if winget is available)
- A modern browser (Chrome, Firefox, Edge, Safari)
- ~100 MB disk space

## Your data

Characters are saved in `dnd-creator/server/characters.db`.  
Back up that file to keep your characters safe.

## PDF import

Go to **📚 Import PDFs** in the nav bar to load your sourcebooks.  
All processing is local — nothing leaves your machine.

---
Built with Node.js + Express + SQLite. Rules content: D&D 5e SRD 5.1.
